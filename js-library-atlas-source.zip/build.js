// Build: extract manuals/guides from the original file, merge with new sources, emit one offline HTML.
const fs=require('fs'),vm=require('vm'),path=require('path');
const orig=fs.readFileSync(path.join(__dirname,'orig/original.html'),'utf8');
const scripts=[...orig.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
const ctx={};vm.createContext(ctx);vm.runInContext(scripts[0]+';this.INFO=INFO;this.REF=REF;',ctx);
const MAN=Object.assign({},ctx.INFO);for(const r of ctx.REF)MAN[r[0]]=r[2];
const grab=name=>{const m=scripts[1].match(new RegExp('const '+name+'=(\\[[\\s\\S]*?\\]\\]?\\]?);\\n'));if(!m)throw new Error('no '+name);return vm.runInNewContext('('+m[1]+')');};
const TF=grab('TF'),GD=grab('GD'),T=grab('T'),STACK=grab('C');
const src=path.join(__dirname,'src'),files=fs.readdirSync(src).sort();
const extra=files.filter(f=>f.startsWith('80_')).map(f=>fs.readFileSync(path.join(src,f),'utf8')).join('\n');
const x={};vm.createContext(x);vm.runInContext(extra+';this.MAN2=MAN2;this.TF2=TF2;',x);
Object.assign(MAN,x.MAN2);TF.push(...x.TF2);
const css=fs.readFileSync(path.join(src,'00_style.css'),'utf8');
const VEND={d3:'d3/dist/d3.min.js',marked:'marked/lib/marked.umd.js',cytoscape:'cytoscape/dist/cytoscape.min.js',katex:'katex/dist/katex.min.js'};
const KD='/opt/npm-tools/node_modules/katex/dist/';const KCSS=fs.readFileSync(KD+'katex.min.css','utf8').replace(/url\(fonts\/([^)]+?)\.woff2\) format\("woff2"\)(,url\([^)]+\) format\("[a-z]+"\))*/g,(m,f)=>'url(data:font/woff2;base64,'+fs.readFileSync(KD+'fonts/'+f+'.woff2').toString('base64')+') format("woff2")');
const vend='const VENDOR={'+Object.entries(VEND).map(([k,f])=>JSON.stringify(k)+':'+JSON.stringify(fs.readFileSync('/opt/npm-tools/node_modules/'+f,'utf8'))).join(',')+'};\nconst KATEX_CSS='+JSON.stringify(KCSS)+';function needKatex(){if(!window.__kcss){const st=document.createElement("style");st.textContent=KATEX_CSS;document.head.appendChild(st);window.__kcss=1;}return needLib("katex");}\nfunction needLib(n){if(window.__vl&&window.__vl[n])return window[n];window.__vl=window.__vl||{};const sc=document.createElement("script");sc.textContent=VENDOR[n];document.head.appendChild(sc);window.__vl[n]=1;return window[n];}\n';
const js0=vend+files.filter(f=>f.endsWith('.js')&&!f.startsWith('80_')).map(f=>'/* ---- '+f+' ---- */\n'+fs.readFileSync(path.join(src,f),'utf8')).join('\n');
const js=js0.replace(/<\/script/gi,'<\\/script');
try{new vm.Script(js);}catch(e){console.error('SYNTAX',e.message);for(const f of files.filter(f=>f.endsWith('.js')&&!f.startsWith('80_'))){try{new vm.Script(fs.readFileSync(path.join(src,f),'utf8'));}catch(e2){console.error(f,e2.message);}}process.exit(1);}
const data=('const MAN='+JSON.stringify(MAN)+';\nconst GUIDE='+JSON.stringify({TF,GD,T,STACK})+';\n').replace(/<\/script/gi,'<\\/script');
const html=`<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>JS Library Atlas · live, offline archive of JavaScript libraries</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
<style>
${css}
</style>
</head>
<body><div id="liq" aria-hidden="true"><i></i><i></i><i></i><i></i></div><div id="reticle" aria-hidden="true"></div>
<header id="top"><button class="tbtn" id="menu">☰</button><a id="logo" href="#/"><i>JS</i><span>Library Atlas</span><em>offline</em></a><div id="sbox"><input id="q" type="search" placeholder="Search libraries & examples…" autocomplete="off"><div id="res"></div></div><button class="tbtn" id="pz">❚❚ Pause all</button></header>
<nav id="side"></nav>
<main id="main"></main>
<div id="tip"></div>
<script>
${data}
${js}
boot();
</script>
</body>
</html>`;
fs.writeFileSync(path.join(__dirname,'js-library-atlas.html'),html);
console.log('ok',(html.length/1024).toFixed(0)+'KB','manuals',Object.keys(MAN).length);
