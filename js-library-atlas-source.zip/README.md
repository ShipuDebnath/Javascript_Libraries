# JS Library Atlas — source

A single-file, fully offline archive of JavaScript libraries with live, interactive examples.

## Build

```bash
node build.js        # → js-library-atlas.html (one self-contained file, ~2.6 MB)
```

Requirements: Node 18+. The build embeds four real libraries from `node_modules` (d3, marked, cytoscape, KaTeX plus its fonts), so install them first if they are missing:

```bash
npm i d3 marked cytoscape katex
```

Edit the `VEND` paths in `build.js` if your `node_modules` lives elsewhere (it defaults to `/opt/npm-tools/node_modules`).

`orig/original.html` (the first version of the showcase) supplies the manuals and guide tables; keep it next to `build.js`.

## Layout

| File(s) | What it holds |
|---|---|
| `src/00_style.css` | Theme: lavender porcelain glass, prism rims, glassmorphism, dock, focus mode, ambient layer |
| `src/01_core.js` | Framework: `lib()`, `ex()`, canvas mounting, controls, colour and drawing helpers |
| `src/02_glx.js` | GLX: the small WebGL engine (PBR-ish materials, instancing, lines, points, globe) |
| `src/10–30_*.js` | Libraries by category (3D, charts, animation, physics, bio, maths, UI, maps, hybrids…) |
| `src/27_gallery.js` | "Every chart type" galleries for ECharts, Plotly, Chart.js and ApexCharts |
| `src/31–37_rw_*.js` | Reworked examples (they replace earlier ones via `relib(id)` / `replaceEx()`) |
| `src/80_manuals.js` | Extra manual entries and the "which library for which task" rows |
| `src/88–92_*.js` | Hero scene, featured strip, app shell, features (drag-reorder, focus, file-drop lab, eco mode), ambient themes |

## App features

- **⌘K / Ctrl K**: command palette that jumps to any library, example, view or action.
- **Board** (`#/board`): an infinite canvas of live highlights; drag to pan, scroll to zoom.
- **Compare** (`#/compare/<type>`): one chart type drawn in the default look of ECharts, Plotly, Chart.js and ApexCharts.
- **Guided tour** (`#/tour`): 12 stops played full-screen; ← → to step, Esc to stop.
- **Display popover** (the Ambient button): ambient scene on/off, theme, density, and a colour-blind-safe (Okabe–Ito) palette.
- Drag-and-drop reordering, focus mode, the file-drop lab, eco mode, and a hideable sidebar (`\`).

## Performance notes

- Examples only initialise when they first scroll near the viewport, and only visible ones animate.
- Off-screen cards use `content-visibility:auto`, so the browser skips painting them.
- The background blobs animate with transform only, and card headers don't stack a second backdrop blur.
- Small instanced objects use a low-poly sphere (`LOSPH()`), and geometry that changes every frame is updated in place (`G.upd`) instead of reallocated.

## Adding an example

```js
CL = LIBMAP['three'];            // or lib('id','Name','category','tagline',{...})
ex({
  t: 'Title', d: 'Description', hint: 'What to try',
  controls: [{type:'range', k:'speed', l:'Speed', min:0, max:2, step:.1, v:1}],
  init(s){ /* state on s (avoid s.t, s.c, s.M, s.p, s.X …) */ },
  draw(ctx, s, t, dt){ /* 720×440 logical canvas; s.p.speed holds the control value */ },
  code: `// the snippet shown in the code panel, written against the real library API`
});
```

The WebGL examples call `G3()` (`begin` → `draw` / `inst` / `lines` / `points` → `end(ctx)`). DOM examples use `dom(el, s)` instead of `draw`.
