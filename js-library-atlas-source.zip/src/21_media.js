/* ===================== AUDIO & MEDIA ===================== */
function ocv(w,h){const c=document.createElement("canvas");c.width=w;c.height=h;return c;}
let _AC=null,_MST=null,_ANA=null;
function AC(){if(!_AC){try{_AC=new(window.AudioContext||window.webkitAudioContext)();}catch(e){return null;}}if(_AC.state==='suspended')_AC.resume();return _AC;}
function MASTER(){const a=AC();if(!a)return null;if(!_MST){_MST=a.createGain();_MST.gain.value=.7;const comp=a.createDynamicsCompressor();_ANA=a.createAnalyser();_ANA.fftSize=2048;_ANA.smoothingTimeConstant=.78;_MST.connect(comp);comp.connect(_ANA);_ANA.connect(a.destination);}return _MST;}
const mtof=m=>440*Math.pow(2,(m-69)/12);
function blip(f,dur,o){const a=AC();if(!a)return;o=o||{};const t0=a.currentTime+(o.at||0),os=a.createOscillator(),g=a.createGain();os.type=o.type||'triangle';os.frequency.setValueAtTime(f,t0);if(o.slide)os.frequency.exponentialRampToValueAtTime(o.slide,t0+dur);
 g.gain.setValueAtTime(0,t0);g.gain.linearRampToValueAtTime(o.vol||.16,t0+(o.atk||.008));g.gain.exponentialRampToValueAtTime(.0001,t0+dur);let node=os;
 if(o.cut){const fl=a.createBiquadFilter();fl.type='lowpass';fl.frequency.value=o.cut;fl.Q.value=o.q||4;os.connect(fl);node=fl;}node.connect(g);
 if(o.pan!==undefined&&a.createStereoPanner){const p=a.createStereoPanner();p.pan.value=o.pan;g.connect(p);p.connect(o.dest||MASTER());}else g.connect(o.dest||MASTER());os.start(t0);os.stop(t0+dur+.05);}
function noiseHit(dur,o){const a=AC();if(!a)return;o=o||{};const n=Math.floor(a.sampleRate*dur),b=a.createBuffer(1,n,a.sampleRate),d=b.getChannelData(0);for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/n,o.decay||4);
 const src=a.createBufferSource();src.buffer=b;const fl=a.createBiquadFilter();fl.type=o.type||'highpass';fl.frequency.value=o.f||6000;const g=a.createGain();g.gain.value=o.vol||.2;src.connect(fl);fl.connect(g);g.connect(MASTER());src.start(a.currentTime+(o.at||0));}
function kick(at){const a=AC();if(!a)return;blip(150,.42,{type:'sine',slide:42,vol:.55,at});}
function scopeData(n,t,fn){const out=new Float32Array(n);if(_ANA&&_AC&&_AC.state==='running'){const b=new Float32Array(_ANA.fftSize);_ANA.getFloatTimeDomainData(b);let z=0;for(let i=1;i<b.length/2;i++)if(b[i-1]<0&&b[i]>=0){z=i;break;}for(let i=0;i<n;i++)out[i]=b[z+i]||0;let pk=0;for(const v of out)pk=Math.max(pk,Math.abs(v));if(pk>.004)return out;}for(let i=0;i<n;i++)out[i]=fn?fn(i/n,t):0;return out;}
function specData(n){const out=new Float32Array(n);if(_ANA&&_AC&&_AC.state==='running'){const b=new Uint8Array(_ANA.frequencyBinCount);_ANA.getByteFrequencyData(b);for(let i=0;i<n;i++){const k=Math.floor(Math.pow(i/n,1.8)*b.length*.6);out[i]=b[k]/255;}}return out;}
function audioBadge(ctx){const on=_AC&&_AC.state==='running';badge(ctx,on?'♪ audio on':'click to enable sound',W-14,14,on?'#0d9488':'#140E29','#fff','right');}

lib('tone','Tone.js','media','A Web Audio framework for music: synths, effects, transport, sequencing and sample playback.',{ik:'Tone.js / Web Audio'});
const PENTA=[0,2,4,7,9,12,14,16];
ex({t:'Step sequencer with a 16-step transport',d:'Eight voices of a pentatonic scale × 16 steps plus a drum lane. Toggle cells, press play and Tone.Transport keeps sample-accurate time while triggered cells ripple.',hint:'Click cells to toggle · press ▶ to hear it.',int:1,
 controls:[{type:'btn',l:'▶ / ❚❚ Play',fn:s=>{s.play=!s.play;if(s.play){AC();MASTER();s.next=0;}}},{type:'range',k:'bpm',l:'BPM',min:70,max:160,step:1,v:112},{type:'select',k:'wave',l:'Voice',v:'triangle',opts:['triangle','sine','square','sawtooth']},{type:'btn',l:'Randomise',fn:s=>{const r=rng(Date.now()%1e5);s.G=s.G.map(row=>row.map(()=>r()<.16));}},{type:'btn',l:'Clear',fn:s=>{s.G=s.G.map(row=>row.map(()=>false));}}],
 init(s){const r=rng(7);s.G=Array.from({length:9},(_,y)=>Array.from({length:16},(_,x)=>y===8?x%4===0:r()<.14));s.step=-1;s.rip=[];s.play=false;s.clock=0;
  s.onDown=(x,y)=>{const c=seqCell(x,y);if(c){s.G[c[1]][c[0]]=!s.G[c[1]][c[0]];if(s.G[c[1]][c[0]]&&c[1]<8){AC();blip(mtof(60+PENTA[7-c[1]]),.35,{type:s.p.wave,cut:2400});}}};},
 draw(ctx,s,t,dt){lav(ctx,'#fbf9ff','#efe7fb');const L=seqLayout();
  if(s.play){s.clock+=dt;const spb=60/s.p.bpm/4;while(s.clock>=spb){s.clock-=spb;s.step=(s.step+1)%16;for(let y=0;y<9;y++)if(s.G[y][s.step]){if(y===8)kick();else blip(mtof(60+PENTA[7-y]),.32,{type:s.p.wave,cut:2600,vol:.11,pan:(s.step/15-.5)*.8});const c=L.c(s.step,y);s.rip.push({x:c[0],y:c[1],t:0,col:y===8?'#e11d48':PAL[y%PAL.length]});}}}
  for(let y=0;y<9;y++)for(let x=0;x<16;x++){const [cx,cy]=L.c(x,y),on=s.G[y][x],cur=x===s.step&&s.play,col=y===8?'#e11d48':scale(['#7c3aed','#0284c7','#0d9488','#d97706'],y/7);
   ctx.save();if(on){ctx.shadowColor=rgba(hex2rgb2(col),.5);ctx.shadowBlur=cur?22:10;}ctx.fillStyle=on?col:(cur?'rgba(124,58,237,.16)':(x%4===0?'rgba(255,255,255,.95)':'rgba(255,255,255,.7)'));rr(ctx,cx-L.w/2,cy-L.h/2,L.w,L.h,7);ctx.fill();ctx.restore();
   if(!on){ctx.strokeStyle='rgba(124,58,237,.14)';ctx.lineWidth=1;rr(ctx,cx-L.w/2+.5,cy-L.h/2+.5,L.w-1,L.h-1,7);ctx.stroke();}else{ctx.fillStyle='rgba(255,255,255,.35)';rr(ctx,cx-L.w/2+3,cy-L.h/2+3,L.w-6,L.h*.35,4);ctx.fill();}}
  for(let y=0;y<9;y++){const c=L.c(0,y);text(ctx,y===8?'kick':['C6','A5','G5','E5','D5','C5','A4','G4'][y].replace('C6','C6'),c[0]-L.w/2-12,c[1]+4,'#6b6288',11,'right',MONO);}
  if(s.play){const c=L.c(s.step,0);ctx.fillStyle='rgba(124,58,237,.08)';rr(ctx,c[0]-L.w/2-3,L.y0-6,L.w+6,L.gh+12,9);ctx.fill();}
  s.rip=s.rip.filter(r=>(r.t+=dt)<.7);for(const r of s.rip){ctx.strokeStyle=rgba(hex2rgb2(r.col),(1-r.t/.7)*.7);ctx.lineWidth=2;ctx.beginPath();ctx.arc(r.x,r.y,8+r.t*60,0,TAU);ctx.stroke();}
  hud(ctx,['Tone.Transport.bpm = '+s.p.bpm,'step '+(s.step<0?'–':s.step+1)+' / 16',s.play?'▶ playing':'■ stopped'],14,14);audioBadge(ctx);},
 code:`const synth=new Tone.PolySynth(Tone.Synth,{oscillator:{type:'triangle'}}).toDestination();
const kick=new Tone.MembraneSynth().toDestination();
const notes=['C6','A5','G5','E5','D5','C5','A4','G4'];
const seq=new Tone.Sequence((time,step)=>{
  notes.forEach((n,row)=>grid[row][step]&&synth.triggerAttackRelease(n,'16n',time));
  if(grid[8][step])kick.triggerAttackRelease('C1','8n',time);
  Tone.Draw.schedule(()=>highlight(step),time);
},[...Array(16).keys()],'16n').start(0);
Tone.Transport.bpm.value=112;await Tone.start();Tone.Transport.start();`});
function seqLayout(){const x0=96,y0=58,gw=W-x0-30,gh=H-y0-38,w=gw/16-5,h=gh/9-6;return{x0,y0,gw,gh,w,h,c:(x,y)=>[x0+(x+.5)*gw/16,y0+(y+.5)*gh/9+(y===8?4:0)]};}
function seqCell(px,py){const L=seqLayout();const x=Math.floor((px-L.x0)/(L.gw/16)),y=Math.floor((py-L.y0)/(L.gh/9));return x>=0&&x<16&&y>=0&&y<9?[x,y]:null;}

ex({t:'Playable synth: keyboard, filter envelope & live scope',d:'Two octaves of keys (mouse or computer keys A–K, W–U for sharps). The patch is oscillator → low-pass filter → amp envelope, and the oscilloscope and spectrum read the real analyser output.',hint:'Click keys, or focus the canvas and type A S D F G H J K.',int:1,
 controls:[{type:'seg',k:'osc',l:'Wave',v:'sawtooth',opts:['sine','triangle','square','sawtooth']},{type:'range',k:'cut',l:'Cutoff',min:200,max:8000,step:10,v:2200,fmt:v=>v+' Hz'},{type:'range',k:'q',l:'Resonance',min:.5,max:18,step:.1,v:6},{type:'range',k:'rel',l:'Release',min:.1,max:2.5,step:.05,v:.7,fmt:v=>v+' s'}],
 init(s){s.held={};s.lit={};const KM='awsedftgyhujkolp';s.onKey=e=>{const i=KM.indexOf(e.key.toLowerCase());if(i>=0){synthNote(s,60+i);e.preventDefault();}};s.onDown=(x,y)=>{const k=keyAt(x,y);if(k!==null)synthNote(s,k);};},
 draw(ctx,s,t){lav(ctx,'#fdfbff','#f1eafc');const sc=scopeData(512,t,(u,tt)=>{const f=3+Math.sin(tt*.6);const raw=s.p.osc==='sine'?Math.sin(u*TAU*f):s.p.osc==='square'?Math.sign(Math.sin(u*TAU*f)):s.p.osc==='triangle'?Math.asin(Math.sin(u*TAU*f))*2/Math.PI:((u*f)%1)*2-1;return raw*.35*(.6+.4*Math.sin(tt*2));});
  const bx=30,by=24,bw=W-60,bh=150;ctx.fillStyle='rgba(20,14,41,.94)';rr(ctx,bx,by,bw,bh,16);ctx.fill();ctx.save();rr(ctx,bx,by,bw,bh,16);ctx.clip();ctx.strokeStyle='rgba(167,139,250,.12)';ctx.lineWidth=1;for(let i=1;i<10;i++){line(ctx,bx+i*bw/10,by,bx+i*bw/10,by+bh,'rgba(167,139,250,.10)',1);}for(let i=1;i<6;i++)line(ctx,bx,by+i*bh/6,bx+bw,by+i*bh/6,'rgba(167,139,250,.10)',1);
  const sp=specData(96);for(let i=0;i<96;i++){const v=sp[i],x=bx+bw*.55+i*(bw*.43/96);ctx.fillStyle=rgba(hex2rgb2(scale(['#0d9488','#7c3aed','#e11d48'],i/96)),.75);ctx.fillRect(x,by+bh-8-v*(bh-20),bw*.43/96-1,v*(bh-20));}
  for(let pass=0;pass<2;pass++){ctx.strokeStyle=pass?'#e9d5ff':'rgba(167,139,250,.35)';ctx.lineWidth=pass?1.8:6;ctx.beginPath();for(let i=0;i<512;i++){const x=bx+10+i/511*(bw*.52),y=by+bh/2-sc[i]*bh*.9;i?ctx.lineTo(x,y):ctx.moveTo(x,y);}ctx.stroke();}ctx.restore();
  text(ctx,'oscilloscope',bx+14,by+18,'#a78bfa',10.5,'left',MONO);text(ctx,'spectrum',bx+bw*.55,by+18,'#a78bfa',10.5,'left',MONO);
  // filter curve
  const fx=bx,fy=by+bh+14,fw=200,fh=58;ctx.fillStyle='rgba(255,255,255,.75)';rr(ctx,fx,fy,fw,fh,10);ctx.fill();ctx.beginPath();for(let i=0;i<=100;i++){const f=20*Math.pow(1000,i/100),r=f/s.p.cut,m=1/Math.sqrt(Math.pow(1-r*r,2)+Math.pow(r/s.p.q,2));const y=fy+fh-6-clamp(Math.log10(m)*14+26,0,fh-10);i?ctx.lineTo(fx+6+i*(fw-12)/100,y):ctx.moveTo(fx+6,y);}ctx.strokeStyle='#7c3aed';ctx.lineWidth=2;ctx.stroke();text(ctx,'Tone.Filter lowpass Q '+s.p.q,fx+8,fy+13,'#4c4369',10,'left',MONO);
  const ex0=fx+fw+12;ctx.fillStyle='rgba(255,255,255,.75)';rr(ctx,ex0,fy,200,fh,10);ctx.fill();const A=.02,D=.18,Sl=.55,R=s.p.rel,tot=A+D+.4+R;const P=[[0,0],[A,1],[A+D,Sl],[A+D+.4,Sl],[tot,0]];ctx.beginPath();P.forEach((p,i)=>{const x=ex0+8+p[0]/tot*184,y=fy+fh-6-p[1]*(fh-20);i?ctx.lineTo(x,y):ctx.moveTo(x,y);});ctx.strokeStyle='#0d9488';ctx.lineWidth=2;ctx.stroke();text(ctx,'ADSR · release '+R+'s',ex0+8,fy+13,'#4c4369',10,'left',MONO);
  // keyboard
  const K=kbLayout();for(const k of K.white){const lit=s.lit[k.m]&&t-s.lit[k.m]<.25;ctx.fillStyle=lit?'#ede9fe':'#fff';ctx.shadowColor='rgba(76,29,149,.15)';ctx.shadowBlur=8;rr(ctx,k.x,k.y,k.w,k.h,8);ctx.fill();ctx.shadowBlur=0;ctx.strokeStyle='rgba(124,58,237,.18)';ctx.stroke();if(lit){ctx.fillStyle='#7c3aed';rr(ctx,k.x+4,k.y+k.h-10,k.w-8,5,3);ctx.fill();}if(k.lab)text(ctx,k.lab,k.x+k.w/2,k.y+k.h-18,'#a49cc0',10,'center',MONO);}
  for(const k of K.black){const lit=s.lit[k.m]&&t-s.lit[k.m]<.25;const g=ctx.createLinearGradient(0,k.y,0,k.y+k.h);g.addColorStop(0,lit?'#7c3aed':'#2a2145');g.addColorStop(1,lit?'#a78bfa':'#140e29');ctx.fillStyle=g;rr(ctx,k.x,k.y,k.w,k.h,6);ctx.fill();}
  s.T=t;audioBadge(ctx);},
 code:`const filter=new Tone.Filter(2200,'lowpass',-24).toDestination();
const synth=new Tone.MonoSynth({oscillator:{type:'sawtooth'},filter:{Q:6},
  envelope:{attack:.02,decay:.18,sustain:.55,release:.7},
  filterEnvelope:{attack:.01,decay:.3,sustain:.4,baseFrequency:300,octaves:3}}).connect(filter);
const wave=new Tone.Waveform(512),fft=new Tone.FFT(96);synth.connect(wave);synth.connect(fft);
keyboard.on('down',note=>synth.triggerAttackRelease(note,'8n'));`});
function kbLayout(){const x0=30,y0=262,wk=17.5,h=H-262-16,white=[],black=[],labs='ASDFGHJK';let wi=0;for(let m=60;m<84;m++){const n=m%12,isB=[1,3,6,8,10].includes(n);if(!isB){white.push({m,x:x0+wi*wk-(wi?0:0),y:y0,w:wk-2,h,lab:wi<8?labs[wi]:''});wi++;}}
 wi=0;for(let m=60;m<84;m++){const n=m%12,isB=[1,3,6,8,10].includes(n);if(isB)black.push({m,x:x0+wi*wk-6,y:y0,w:11,h:h*.6});else wi++;}
 const sc=(W-30-x0)/(wi*wk);white.forEach(k=>{k.x=x0+(k.x-x0)*sc;k.w=wk*sc-2;});black.forEach(k=>{k.x=x0+(k.x-x0)*sc;k.w=11*sc;});return{white,black};}
function keyAt(x,y){const K=kbLayout();for(const k of K.black)if(x>=k.x&&x<=k.x+k.w&&y>=k.y&&y<=k.y+k.h)return k.m;for(const k of K.white)if(x>=k.x&&x<=k.x+k.w&&y>=k.y&&y<=k.y+k.h)return k.m;return null;}
function synthNote(s,m){AC();const map={60:60,61:61,62:62,63:63,64:64,65:65,66:66,67:67,68:68,69:69,70:70,71:71,72:72};blip(mtof(m),s.p.rel+.3,{type:s.p.osc,cut:s.p.cut,q:s.p.q,vol:.2});s.lit[m]=s.T||0;}

ex({t:'Euclidean rhythms: polymeter in rotating rings',d:'Each ring distributes k hits over n steps as evenly as possible (Bjorklund), the algorithm behind many world-music rhythms. Rings run at once as polymeter; hits flash where the sweeping hand crosses them.',hint:'Press ▶ to hear the rhythms; adjust the hit counts.',
 controls:[{type:'btn',l:'▶ / ❚❚',fn:s=>{s.play=!s.play;AC();}},{type:'range',k:'k1',l:'Ring 1 hits',min:1,max:16,step:1,v:5},{type:'range',k:'k2',l:'Ring 2 hits',min:1,max:12,step:1,v:3},{type:'range',k:'k3',l:'Ring 3 hits',min:1,max:9,step:1,v:4},{type:'range',k:'bpm',l:'BPM',min:60,max:150,step:1,v:96}],
 init(s){s.ph=0;s.last=[-1,-1,-1];s.fl=[{},{},{}];},
 draw(ctx,s,t,dt){lav(ctx,'#fcfaff','#efe7fb');const cx=W*.42,cy=H/2,RINGS=[[16,s.p.k1,180,'#7c3aed'],[12,s.p.k2,132,'#0284c7'],[9,s.p.k3,86,'#e11d48']];s.ph+=dt*s.p.bpm/60/4;
  RINGS.forEach(([n,k,R,col],ri)=>{const pat=euclid(Math.min(k,n),n);const step=Math.floor((s.ph%1)*n);if(step!==s.last[ri]){s.last[ri]=step;if(pat[step]){s.fl[ri][step]=t;if(s.play){if(ri===0)kick();else if(ri===1)noiseHit(.12,{f:7000,vol:.12});else blip(mtof(72+[0,3,7,10][step%4]),.25,{type:'sine',vol:.12});}}}
   ctx.strokeStyle=rgba(hex2rgb2(col),.18);ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(cx,cy,R,0,TAU);ctx.stroke();
   const poly=[];pat.forEach((h,i)=>{const a=i/n*TAU-Math.PI/2;if(h)poly.push([cx+Math.cos(a)*R,cy+Math.sin(a)*R]);});if(poly.length>2){ctx.fillStyle=rgba(hex2rgb2(col),.07);ctx.strokeStyle=rgba(hex2rgb2(col),.5);ctx.lineWidth=1.5;ctx.beginPath();poly.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.closePath();ctx.fill();ctx.stroke();}
   pat.forEach((h,i)=>{const a=i/n*TAU-Math.PI/2,x=cx+Math.cos(a)*R,y=cy+Math.sin(a)*R,f=s.fl[ri][i]!==undefined?clamp(1-(t-s.fl[ri][i])/.5,0,1):0;if(h){ctx.save();ctx.shadowColor=col;ctx.shadowBlur=6+f*24;circle(ctx,x,y,7+f*6,col);ctx.restore();circle(ctx,x-2,y-2,2.4,'rgba(255,255,255,.7)');}else circle(ctx,x,y,3.2,'#fff',rgba(hex2rgb2(col),.4),1.2);});});
  const a=(s.ph%1)*TAU-Math.PI/2;const g=ctx.createLinearGradient(cx,cy,cx+Math.cos(a)*200,cy+Math.sin(a)*200);g.addColorStop(0,'rgba(20,14,41,.0)');g.addColorStop(1,'rgba(20,14,41,.55)');line(ctx,cx,cy,cx+Math.cos(a)*200,cy+Math.sin(a)*200,g,2);circle(ctx,cx,cy,5,'#140e29');
  const bx=W*.74;text(ctx,'Bjorklund patterns',bx,70,'#140E29',15,'left',FONT,700);RINGS.forEach(([n,k,R,col],i)=>{const p=euclid(Math.min(k,n),n);text(ctx,'E('+Math.min(k,n)+','+n+')',bx,104+i*58,col,13,'left',MONO,700);p.forEach((h,j)=>{ctx.fillStyle=h?col:'rgba(124,58,237,.12)';rr(ctx,bx+j*10.5,112+i*58,8.5,16,2.5);ctx.fill();});});
  text(ctx,'Tresillo = E(3,8) · Cinquillo = E(5,8) · Bossa = E(5,16)',bx,300,'#6b6288',10.5,'left',MONO);audioBadge(ctx);},
 code:`function euclid(k,n){/* Bjorklund */ ... }
const pat=euclid(5,16);
new Tone.Sequence((time,hit)=>hit&&kick.triggerAttackRelease('C1','16n',time),pat,'16n').start(0);
new Tone.Sequence((time,hit)=>hit&&hat.triggerAttackRelease('32n',time),euclid(3,12),'16n').start(0);   // polymeter`});
function euclid(k,n){if(k<=0)return Array(n).fill(0);let a=Array.from({length:k},()=>[1]),b=Array.from({length:n-k},()=>[0]);while(b.length>1){const m=Math.min(a.length,b.length),na=[];for(let i=0;i<m;i++)na.push(a[i].concat(b[i]));const rest=a.length>m?a.slice(m):b.slice(m);a=na;b=rest;}return a.concat(b).flat();}

lib('howler','Howler.js','media','Reliable cross-browser audio playback: sprites, spatial audio, fades and many simultaneous sounds.',{ik:'Howler.js'});
const SPR=[['laser',0,.32,'#7c3aed'],['coin',.42,.3,'#d97706'],['jump',.84,.35,'#0d9488'],['power-up',1.3,.75,'#e11d48'],['hit',2.15,.22,'#0284c7'],['chime',2.5,.9,'#a21caf']];
function playSprite(name){switch(name){case 'laser':blip(1400,.3,{type:'sawtooth',slide:180,vol:.12,cut:5000});break;case 'coin':blip(988,.08,{type:'square',vol:.1});blip(1319,.28,{type:'square',vol:.1,at:.08});break;case 'jump':blip(260,.3,{type:'square',slide:780,vol:.1,cut:3000});break;
 case 'power-up':[0,4,7,12,16,19,24].forEach((n,i)=>blip(mtof(60+n),.18,{type:'triangle',vol:.12,at:i*.08}));break;case 'hit':noiseHit(.2,{type:'lowpass',f:900,vol:.5});blip(120,.2,{type:'sine',slide:50,vol:.3});break;case 'chime':[76,83,88].forEach((m,i)=>blip(mtof(m),.9,{type:'sine',vol:.1,at:i*.06}));}}
function spriteWave(name,u){const f={laser:x=>Math.sin(x*200*(1-x*.85))*(1-x),coin:x=>Math.sign(Math.sin(x*(x<.25?90:120)))*Math.pow(1-x,1.5),jump:x=>Math.sign(Math.sin(x*40*(1+x*2)))*(1-x)*.8,'power-up':x=>Math.sin(x*TAU*(20+Math.floor(x*7)*6))*(.4+.6*((x*7)%1<.8)),hit:x=>(Math.random()*2-1)*Math.pow(1-x,3),chime:x=>Math.sin(x*300)*Math.exp(-x*3.5)}[name];return f(u);}
ex({t:'Audio sprites: one file, many named sounds',d:'A single sound file is sliced into named regions with offsets and durations. Click a region or press a pad; the playhead runs over the sprite and several sounds can overlap.',hint:'Click a pad or a region of the waveform.',int:1,
 init(s){s.voices=[];s.wf=[];const n=1400,total=3.5;for(let i=0;i<n;i++){const ts=i/n*total;let v=0;for(const [nm,o,d] of SPR)if(ts>=o&&ts<o+d)v=spriteWave(nm,(ts-o)/d);s.wf.push(v*(.85+.15*Math.random()));}
  s.onDown=(x,y)=>{const total=3.5;if(y>40&&y<190){const ts=(x-30)/(W-60)*total;for(const sp of SPR)if(ts>=sp[1]&&ts<sp[1]+sp[2])fire(s,sp);}else for(let i=0;i<SPR.length;i++){const b=padRect(i);if(x>b[0]&&x<b[0]+b[2]&&y>b[1]&&y<b[1]+b[3])fire(s,SPR[i]);}};},
 draw(ctx,s,t,dt){lav(ctx,'#fdfbff','#f1eafc');const x0=30,w=W-60,y0=48,h=140,total=3.5;ctx.fillStyle='rgba(255,255,255,.8)';rr(ctx,x0-10,y0-14,w+20,h+30,14);ctx.fill();
  for(const [nm,o,d,col] of SPR){const a=x0+o/total*w,b=d/total*w,act=s.voices.some(v=>v.sp[0]===nm);ctx.fillStyle=rgba(hex2rgb2(col),act?.2:.08);rr(ctx,a,y0,b,h,8);ctx.fill();ctx.fillStyle=col;rr(ctx,a,y0,b,3,2);ctx.fill();text(ctx,nm,a+6,y0+16,col,11,'left',MONO,700);text(ctx,o.toFixed(2)+'s',a+6,y0+h-6,'#a49cc0',9.5,'left',MONO);}
  const n=s.wf.length;for(let i=0;i<n;i+=2){const x=x0+i/n*w,v=Math.abs(s.wf[i]),ts=i/n*total;let col='rgba(76,67,105,.35)';for(const [nm,o,d,c] of SPR)if(ts>=o&&ts<o+d)col=c;const act=s.voices.find(v=>{const sp=v.sp;return ts>=sp[1]&&ts<sp[1]+v.e*sp[2];});ctx.fillStyle=act?col:rgba(hex2rgb2(col),.45);ctx.fillRect(x,y0+h/2-v*h*.38,1.2,Math.max(1,v*h*.76));}
  s.voices=s.voices.filter(v=>(v.e+=dt/v.sp[2])<1);for(const v of s.voices){const x=x0+(v.sp[1]+v.e*v.sp[2])/total*w;line(ctx,x,y0-6,x,y0+h+6,'#140E29',1.6);circle(ctx,x,y0-6,3.5,'#140E29');}
  for(let i=0;i<SPR.length;i++){const b=padRect(i),act=s.voices.some(v=>v.sp===SPR[i]),col=SPR[i][3];ctx.save();ctx.shadowColor=rgba(hex2rgb2(col),.5);ctx.shadowBlur=act?24:8;const g=ctx.createLinearGradient(0,b[1],0,b[1]+b[3]);g.addColorStop(0,mixHex(col,'#ffffff',.25));g.addColorStop(1,col);ctx.fillStyle=act?g:'#fff';rr(ctx,...b,14);ctx.fill();ctx.restore();text(ctx,SPR[i][0],b[0]+b[2]/2,b[1]+b[3]/2+5,act?'#fff':col,13,'center',FONT,700);}
  hud(ctx,['sound.play("'+(s.voices.length?s.voices[s.voices.length-1].sp[0]:'…')+'")','voices '+s.voices.length],14,H-56);audioBadge(ctx);},
 code:`const sfx=new Howl({src:['sfx.webm','sfx.mp3'],sprite:{
  laser:[0,320],coin:[420,300],jump:[840,350],'power-up':[1300,750],hit:[2150,220],chime:[2500,900]}});
pad.onclick=()=>sfx.play('coin');   // each play() returns an id you can fade, rate() or stop()`});
function padRect(i){const w=(W-60-50)/6;return[30+i*(w+10),222,w,64];}
function fire(s,sp){AC();playSprite(sp[0]);s.voices.push({sp,e:0});}
ex({t:'Spatial audio: drag the sound around the listener',d:'HRTF panning with distance roll-off. Drag the source around the head; the stereo meters, pan value and attenuation update and the source plays a soft pulse while sound is on.',hint:'Drag the glowing source · toggle the pulse.',int:1,
 controls:[{type:'toggle',k:'on',l:'Play pulse',v:false},{type:'select',k:'model',l:'Roll-off',v:'inverse',opts:['inverse','linear','exponential']}],
 init(s){s.src=[W*.68,H*.32];s.beat=0;s.onDown=(x,y)=>{if(Math.hypot(x-s.src[0],y-s.src[1])<40){s.grab=true;}};s.onMove=(x,y)=>{if(s.grab&&s.down)s.src=[clamp(x,40,W-40),clamp(y,40,H-40)];};s.onUp=()=>{s.grab=false;};},
 draw(ctx,s,t,dt){lav(ctx,'#fbf9ff','#eee6fb');const cx=W*.42,cy=H*.54;for(let r=60;r<=300;r+=60){ctx.strokeStyle='rgba(124,58,237,'+(.18-r/2400)+')';ctx.setLineDash([4,6]);ctx.beginPath();ctx.arc(cx,cy,r,0,TAU);ctx.stroke();text(ctx,(r/60)+' m',cx+r+4,cy-4,'#a49cc0',9.5,'left',MONO);}ctx.setLineDash([]);
  const dx=(s.src[0]-cx)/60,dz=(s.src[1]-cy)/60,dist=Math.hypot(dx,dz),ref=1,rolloff=1,gain=s.p.model==='inverse'?ref/(ref+rolloff*(Math.max(dist,ref)-ref)):s.p.model==='linear'?clamp(1-rolloff*(dist-ref)/(10-ref),0,1):Math.pow(Math.max(dist,ref)/ref,-rolloff),pan=clamp(dx/Math.max(dist,.001),-1,1);
  s.beat+=dt;if(s.beat>.55){s.beat=0;if(s.p.on)blip(mtof(76),.25,{type:'sine',vol:.25*gain,pan});s.ring=t;}
  // sound cone
  const ang=Math.atan2(s.src[1]-cy,s.src[0]-cx);const g=ctx.createRadialGradient(s.src[0],s.src[1],0,s.src[0],s.src[1],160);g.addColorStop(0,'rgba(225,29,72,.18)');g.addColorStop(1,'rgba(225,29,72,0)');ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(s.src[0],s.src[1]);ctx.arc(s.src[0],s.src[1],160,ang+Math.PI-.6,ang+Math.PI+.6);ctx.closePath();ctx.fill();
  if(s.ring!==undefined){const k=(t-s.ring)/1.2;if(k<1){ctx.strokeStyle='rgba(225,29,72,'+(1-k)*.6+')';ctx.lineWidth=2;ctx.beginPath();ctx.arc(s.src[0],s.src[1],10+k*dist*60,0,TAU);ctx.stroke();}}
  line(ctx,cx,cy,s.src[0],s.src[1],'rgba(20,14,41,.25)',1.2,[3,4]);
  // head
  ctx.save();ctx.shadowColor='rgba(76,29,149,.25)';ctx.shadowBlur=18;circle(ctx,cx,cy,26,'#fff','#7c3aed',2);ctx.restore();ctx.fillStyle='#7c3aed';ctx.beginPath();ctx.moveTo(cx-7,cy-25);ctx.lineTo(cx,cy-36);ctx.lineTo(cx+7,cy-25);ctx.fill();circle(ctx,cx-27,cy,6,'#c4b5fd');circle(ctx,cx+27,cy,6,'#c4b5fd');text(ctx,'listener',cx,cy+44,'#4c4369',11,'center',MONO);
  ctx.save();ctx.shadowColor='#e11d48';ctx.shadowBlur=26;circle(ctx,s.src[0],s.src[1],15,'#e11d48');ctx.restore();circle(ctx,s.src[0]-4,s.src[1]-4,4,'rgba(255,255,255,.7)');text(ctx,'♪',s.src[0],s.src[1]+5,'#fff',13,'center');
  const L=gain*Math.sqrt((1-pan)/2),R=gain*Math.sqrt((1+pan)/2),mx=W-150;[['L',L],['R',R]].forEach(([n,v],i)=>{const x=mx+i*46,y=60,h=260;ctx.fillStyle='rgba(255,255,255,.8)';rr(ctx,x,y,30,h,10);ctx.fill();for(let k=0;k<26;k++){const on=k/26<v;ctx.fillStyle=on?scale(['#0d9488','#d97706','#e11d48'],k/26):'rgba(124,58,237,.08)';rr(ctx,x+5,y+h-8-(k+1)*9.6,20,7,2);ctx.fill();}text(ctx,n,x+15,y+h+18,'#4c4369',12,'center',MONO,700);});
  hud(ctx,['sound.pos('+dx.toFixed(2)+', 0, '+dz.toFixed(2)+')','distance '+dist.toFixed(2)+' m','gain '+gain.toFixed(2)+'  pan '+pan.toFixed(2),'panningModel: HRTF'],14,14);audioBadge(ctx);},
 code:`const s=new Howl({src:['pulse.webm'],loop:true});const id=s.play();
s.pannerAttr({panningModel:'HRTF',distanceModel:'inverse',refDistance:1,rolloffFactor:1},id);
drag.on('move',({x,z})=>s.pos(x,0,z,id));   // Howler.pos() moves the listener`});

lib('vexflow','VexFlow','media','Engraves sheet music and guitar tablature in SVG or canvas: staves, notes, beams, ties and chords.',{ik:'VexFlow'});
const SMUFL='"Bravura","Noto Music","Segoe UI Symbol","Apple Symbols","Musica","Symbola",serif';
function staff(ctx,x,y,w,gap){for(let i=0;i<5;i++)line(ctx,x,y+i*gap,x+w,y+i*gap,'#4c4369',1);}
function noteHead(ctx,x,y,gap,filled,col){ctx.save();ctx.translate(x,y);ctx.rotate(-.35);ctx.beginPath();ctx.ellipse(0,0,gap*.66,gap*.45,0,0,TAU);if(filled){ctx.fillStyle=col;ctx.fill();}else{ctx.strokeStyle=col;ctx.lineWidth=1.8;ctx.stroke();}ctx.restore();}
const SCORE=[// [beat, staffStep (0 = bottom line E4 treble), dur, acc]
 [0,2,1,''],[1,4,.5,''],[1.5,5,.5,''],[2,6,.5,''],[2.5,5,.5,''],[3,4,1,''],[4,3,.5,'♯'],[4.5,4,.5,''],[5,5,.5,''],[5.5,7,.5,''],[6,6,2,''],[8,8,.5,''],[8.5,7,.5,''],[9,6,.5,''],[9.5,5,.5,'♭'],[10,4,1,''],[11,2,1,''],[12,0,.5,''],[12.5,2,.5,''],[13,4,.5,''],[13.5,6,.5,''],[14,7,2,'']];
const BASS=[[0,[0,2,4],4],[4,[1,3,5],4],[8,[-1,1,3],4],[12,[0,2,4],4]];
const STEPMIDI=s=>{const sc=[64,65,67,69,71,72,74,76,77,79,81,83,84];return s>=0&&s<sc.length?sc[s]:64;};
ex({t:'Engraved grand staff with playback cursor',d:'A two-stave system: treble melody with beamed eighths, accidentals and ledger lines over bass-clef chords, with chord symbols and measure numbers. Press play and a cursor follows the music, lighting notes as they sound.',hint:'Press ▶ to play the score.',
 controls:[{type:'btn',l:'▶ / ■ Play',fn:s=>{s.play=!s.play;s.beat=-.01;AC();}},{type:'range',k:'bpm',l:'Tempo',min:60,max:160,step:1,v:96}],
 init(s){s.beat=-1;s.play=false;s.played=new Set();},
 draw(ctx,s,t,dt){paper(ctx,'#fffdf9');const g=9,x0=46,x1=W-24,yT=96,yB=yT+g*4+64,mx0=x0+92,mw=(x1-mx0)/4;
  staff(ctx,x0,yT,x1-x0,g);staff(ctx,x0,yB,x1-x0,g);line(ctx,x0,yT,x0,yB+g*4,'#140E29',1.6);ctx.strokeStyle='#140E29';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(x0-10,yT);ctx.quadraticCurveTo(x0-18,(yT+yB+g*4)/2,x0-10,yB+g*4);ctx.stroke();
  text(ctx,'𝄞',x0+4,yT+g*4+8,'#140E29',g*6.4,'left',SMUFL);text(ctx,'𝄢',x0+6,yB+g*2.6,'#140E29',g*3.6,'left',SMUFL);
  text(ctx,'4',x0+56,yT+g*2-1,'#140E29',g*2.4,'center','Georgia,serif',700);text(ctx,'4',x0+56,yT+g*4-1,'#140E29',g*2.4,'center','Georgia,serif',700);text(ctx,'4',x0+56,yB+g*2-1,'#140E29',g*2.4,'center','Georgia,serif',700);text(ctx,'4',x0+56,yB+g*4-1,'#140E29',g*2.4,'center','Georgia,serif',700);
  for(let m=1;m<=4;m++){const bx=mx0+m*mw-6;line(ctx,bx,yT,bx,yB+g*4,'#140E29',m===4?3:1.2);text(ctx,String(m),mx0+(m-1)*mw-2,yT-14,'#a49cc0',10,'left',MONO);}
  ['C','G/B','Am','C'].forEach((c,i)=>text(ctx,c,mx0+i*mw+4,yT-30,'#7c3aed',14,'left','Georgia,serif',700));
  text(ctx,'Allegretto  ♩ = '+s.p.bpm,x0,40,'#140E29',13,'left','Georgia,serif',700);text(ctx,'Study in C',W/2,40,'#140E29',18,'center','Georgia,serif',700);
  if(s.play){s.beat+=dt*s.p.bpm/60;if(s.beat>16){s.beat=-.01;s.played.clear();}}
  const bxOf=b=>mx0+Math.floor(b/4)*mw+((b%4)/4)*(mw-26)+16,yTs=st=>yT+g*4-st*g/2;
  const pos=SCORE.map(n=>({n,x:bxOf(n[0]),y:yTs(n[1])}));
  // beams for eighth pairs
  for(let i=0;i<pos.length;i++){const a=pos[i];const on=s.play&&s.beat>=a.n[0]&&s.beat<a.n[0]+a.n[2];const col=on?'#e11d48':'#140E29';
   if(on&&!s.played.has(i)){s.played.add(i);blip(mtof(STEPMIDI(a.n[1])+(a.n[3]==='♯'?1:a.n[3]==='♭'?-1:0)),.5*a.n[2]*60/s.p.bpm*1.6,{type:'triangle',vol:.14});}
   for(let l=-2;l>=a.n[1];l-=2)line(ctx,a.x-g,yTs(l),a.x+g,yTs(l),'#140E29',1.2);for(let l=10;l<=a.n[1];l+=2)line(ctx,a.x-g,yTs(l),a.x+g,yTs(l),'#140E29',1.2);
   noteHead(ctx,a.x,a.y,g,a.n[2]<2,col);if(a.n[3])text(ctx,a.n[3],a.x-g*1.9,a.y+5,col,g*1.8,'center','Georgia,serif');const up=a.n[1]<4;const sx=up?a.x+g*.6:a.x-g*.6;
   if(a.n[2]===.5&&i<pos.length-1&&pos[i+1].n[2]===.5&&a.n[0]%1===0){const b=pos[i+1],bu=up&&b.n[1]<4?1:-1,dir=bu>0?-1:1,yA=Math.min(a.y,b.y)*(bu>0?1:0)+Math.max(a.y,b.y)*(bu>0?0:1)+dir*g*3.4,ax=bu>0?a.x+g*.6:a.x-g*.6,bxx=bu>0?b.x+g*.6:b.x-g*.6,slope=clamp((b.y-a.y)*.25,-g,g);
    line(ctx,ax,a.y,ax,yA-slope/2,col,1.4);line(ctx,bxx,b.y,bxx,yA+slope/2,col,1.4);ctx.strokeStyle=col;ctx.lineWidth=g*.5;ctx.beginPath();ctx.moveTo(ax,yA-slope/2);ctx.lineTo(bxx,yA+slope/2);ctx.stroke();a.beamed=b.beamed=true;}
   else if(!a.beamed&&a.n[2]<2){line(ctx,sx,a.y,sx,a.y+(up?-1:1)*g*3.4,col,1.4);}}
  // bass chords (whole notes)
  BASS.forEach(([b,ch])=>{const x=bxOf(b)+mw*.3,on=s.play&&s.beat>=b&&s.beat<b+4;ch.forEach(st=>{const y=yB+g*4-(st+2)*g/2;noteHead(ctx,x,y,g,false,on?'#0284c7':'#140E29');});if(on&&!s.played.has('b'+b)){s.played.add('b'+b);ch.forEach(st=>blip(mtof(STEPMIDI(st)-24),2.2*60/s.p.bpm,{type:'sine',vol:.09}));}});
  text(ctx,'p',mx0,yB+g*4+28,'#140E29',16,'left','Georgia,serif',700);ctx.strokeStyle='#140E29';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(mx0+30,yB+g*4+18);ctx.lineTo(mx0+190,yB+g*4+24);ctx.lineTo(mx0+30,yB+g*4+30);ctx.stroke();
  if(s.play&&s.beat>=0){const x=bxOf(Math.min(15.99,s.beat))-4;ctx.fillStyle='rgba(124,58,237,.14)';rr(ctx,x-6,yT-18,12,yB+g*4-yT+36,6);ctx.fill();line(ctx,x,yT-18,x,yB+g*4+18,'#7c3aed',2);}
  cap(ctx,'new Formatter().joinVoices([voice]).format([voice], 520); Beam.generateBeams(notes)');},
 code:`const {Renderer,Stave,StaveNote,Voice,Formatter,Beam,Accidental,StaveConnector}=Vex.Flow;
const r=new Renderer(div,Renderer.Backends.SVG);r.resize(720,300);const c=r.getContext();
const treble=new Stave(10,40,700).addClef('treble').addTimeSignature('4/4').setContext(c).draw();
const notes=[new StaveNote({keys:['g/4'],duration:'q'}),new StaveNote({keys:['b/4'],duration:'8'}),
  new StaveNote({keys:['f#/4'],duration:'8'}).addModifier(new Accidental('#'))];
const beams=Beam.generateBeams(notes);Formatter.FormatAndDraw(c,treble,notes);beams.forEach(b=>b.setContext(c).draw());
new StaveConnector(treble,bass).setType('brace').setContext(c).draw();`});
ex({t:'Guitar tablature with chord diagrams',d:'A six-line tab staff under standard notation, with fret numbers, hammer-ons, slides and bends, plus chord boxes above. Hover a chord box to hear it strummed.',hint:'Hover the chord diagrams.',int:1,
 init(s){s.hov=-1;s.last=-1;},
 draw(ctx,s,t){paper(ctx,'#fffdf9');const CH=[['C',[-1,3,2,0,1,0],[0,3,2,0,1,0]],['Am',[-1,0,2,2,1,0],[0,0,2,2,1,0]],['F',[1,3,3,2,1,1],[1,3,3,2,1,1]],['G',[3,2,0,0,0,3],[3,2,0,0,0,3]]];const OPEN=[40,45,50,55,59,64];
  s.hov=-1;CH.forEach(([nm,fr],i)=>{const bx=70+i*160,by=36,cw=16,rh=17,hov=s.hover&&s.mx>bx-14&&s.mx<bx+cw*5+14&&s.my>by-10&&s.my<by+rh*4+20;if(hov)s.hov=i;
   if(hov){ctx.fillStyle='rgba(124,58,237,.08)';rr(ctx,bx-16,by-24,cw*5+32,rh*4+52,12);ctx.fill();}
   text(ctx,nm,bx+cw*2.5,by-8,hov?'#7c3aed':'#140E29',15,'center','Georgia,serif',700);ctx.fillStyle='#140E29';ctx.fillRect(bx,by,cw*5,3);for(let k=0;k<6;k++)line(ctx,bx+k*cw,by,bx+k*cw,by+rh*4,'#4c4369',1);for(let f=1;f<=4;f++)line(ctx,bx,by+f*rh,bx+cw*5,by+f*rh,'#4c4369',1);
   fr.forEach((f,k)=>{const x=bx+k*cw;if(f<0)text(ctx,'×',x,by-2,'#e11d48',11,'center');else if(f===0)circle(ctx,x,by-5,3.5,null,'#140E29',1.2);else{circle(ctx,x,by+(f-.5)*rh,6,hov?'#7c3aed':'#140E29');}});
   if(nm==='F'){ctx.fillStyle=hov?'#7c3aed':'#140E29';rr(ctx,bx-4,by+rh*.5-5,cw*5+8,10,5);ctx.fill();}});
  if(s.hov!==s.last){s.last=s.hov;if(s.hov>=0){AC();CH[s.hov][2].forEach((f,k)=>{if(CH[s.hov][1][k]>=0)blip(mtof(OPEN[k]+f),1.6,{type:'triangle',vol:.09,at:k*.03,cut:3200});});}}
  const tx=40,ty=218,tg=17,tw=W-80;for(let i=0;i<6;i++)line(ctx,tx+40,ty+i*tg,tx+tw,ty+i*tg,'#4c4369',1);text(ctx,'T',tx+16,ty+tg*1.2,'#140E29',17,'center','Georgia,serif',700);text(ctx,'A',tx+16,ty+tg*2.8,'#140E29',17,'center','Georgia,serif',700);text(ctx,'B',tx+16,ty+tg*4.4,'#140E29',17,'center','Georgia,serif',700);
  line(ctx,tx+40,ty,tx+40,ty+tg*5,'#140E29',2);line(ctx,tx+tw,ty,tx+tw,ty+tg*5,'#140E29',2);for(let m=1;m<4;m++)line(ctx,tx+40+m*(tw-40)/4,ty,tx+40+m*(tw-40)/4,ty+tg*5,'#140E29',1.2);
  const TAB=[[0,4,'3'],[0,2,'2'],[1,3,'0'],[1.5,1,'1'],[2,0,'0'],[3,1,'1'],[3.5,1,'3','h'],[4,4,'0'],[4.5,3,'2'],[5,2,'2'],[6,1,'1'],[7,1,'3','b'],[8,5,'1'],[8.5,4,'3'],[9,3,'3'],[10,2,'2'],[11,2,'5','s'],[12,5,'3'],[12.5,4,'2'],[13,0,'3'],[14,0,'3'],[14.5,1,'0'],[15,0,'3']];
  const prog=(t*.9)%16;TAB.forEach(([b,st,f,tech])=>{const x=tx+60+b/16*(tw-80),y=ty+st*tg,on=prog>=b&&prog<b+.5;ctx.fillStyle='#fffdf9';ctx.fillRect(x-7,y-8,14,16);text(ctx,f,x,y+5,on?'#e11d48':'#140E29',13,'center',MONO,700);
   if(tech==='h'){ctx.strokeStyle='#7c3aed';ctx.lineWidth=1.2;ctx.beginPath();ctx.arc(x-12,y-8,12,Math.PI*1.15,Math.PI*1.85);ctx.stroke();text(ctx,'H',x-12,y-22,'#7c3aed',9,'center',MONO,700);}
   if(tech==='b'){ctx.strokeStyle='#e11d48';ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(x+8,y);ctx.quadraticCurveTo(x+20,y,x+20,y-22);ctx.stroke();arrow(ctx,x+20,y-12,x+20,y-24,'#e11d48',1.4,5);text(ctx,'full',x+22,y-28,'#e11d48',9,'left',MONO);}
   if(tech==='s')line(ctx,x-18,y+4,x-8,y-4,'#0d9488',1.6);});
  const px=tx+60+prog/16*(tw-80);line(ctx,px,ty-8,px,ty+tg*5+8,'rgba(124,58,237,.6)',2);text(ctx,'H = hammer-on · bend full · / slide',tx+40,ty+tg*5+26,'#6b6288',10.5,'left',MONO);audioBadge(ctx);},
 code:`const tab=new TabStave(10,40,700).addTabGlyph().setContext(c).draw();
const notes=[new TabNote({positions:[{str:5,fret:3}],duration:'8'}),
  new TabNote({positions:[{str:2,fret:3}],duration:'8'}).addModifier(new Bend('Full'),0)];
const ties=[new TabTie({first_note:notes[5],last_note:notes[6]},'H')];
Formatter.FormatAndDraw(c,tab,notes);ties.forEach(t=>t.setContext(c).draw());`});

lib('wavesurfer','Wavesurfer.js','media','Interactive audio waveforms with regions, zoom, minimap, spectrogram and timeline plugins.',{isNew:true,info:{what:'Wavesurfer.js renders audio as an interactive waveform with a cursor you can click to seek. Plugins add regions, markers, minimap, timeline, spectrogram and recording.',best:['Podcast and audio editors','Transcription tools with clickable timestamps','Music players with waveform scrubbing','Annotating audio datasets'],not:['Very long files without pre-computed peaks','Real-time audio synthesis (use Tone.js)'],tip:'Pre-compute peaks on the server for long files and pass them as peaks: the browser then never decodes the whole file.'}});
function songBuffer(){if(window._SONG)return window._SONG;const sr=8000,dur=24,n=sr*dur,d=new Float32Array(n),r=rng(3);const chords=[[48,52,55],[45,48,52],[41,45,48],[43,47,50]];
 for(let i=0;i<n;i++){const ts=i/sr,bar=Math.floor(ts/1.5)%4,beat=ts%.375,ch=chords[bar];let v=0;
  if(ts>2)ch.forEach(m=>v+=Math.sin(TAU*mtof(m)*ts)*.08);if(ts>6&&ts<20){const ph=ts%.375;v+=Math.sin(TAU*55*Math.exp(-ph*18)*ph*8)*Math.exp(-ph*16)*.55;}
  if(ts>8&&ts<21){const mel=[72,74,76,79,76,74,72,69][Math.floor(ts/.375)%8];v+=Math.sin(TAU*mtof(mel)*ts)*Math.exp(-(ts%.375)*6)*.2;}
  if(ts>10&&ts<20&&(ts%.1875)<.02)v+=(r()*2-1)*.15;v*=ts<1?ts:ts>22?(24-ts)/2:1;d[i]=v;}
 return window._SONG={d,sr,dur};}
ex({t:'Waveform with regions, zoom and minimap',d:'A 24-second track (intro, groove, solo, outro) drawn as mirrored peaks. Click to seek, drag on the waveform to create a region, scroll to zoom, and the minimap shows where the view sits.',hint:'Click to seek · drag to make a region · scroll to zoom · ▶ plays.',int:1,
 controls:[{type:'btn',l:'▶ / ❚❚',fn:s=>{s.play=!s.play;if(s.play)startSong(s);else stopSong(s);}},{type:'range',k:'zoom',l:'Zoom',min:1,max:8,step:.1,v:1.6,fmt:v=>v.toFixed(1)+'×'},{type:'toggle',k:'loop',l:'Loop region',v:true}],
 init(s){const S=songBuffer();s.cur=0;s.view=0;s.R=[{a:2,b:6,c:'#0284c7',n:'intro'},{a:8,b:14,c:'#7c3aed',n:'solo'}];s.peaks=[];const B=2400,per=Math.floor(S.d.length/B);for(let i=0;i<B;i++){let mn=0,mx=0;for(let k=0;k<per;k++){const v=S.d[i*per+k];if(v<mn)mn=v;if(v>mx)mx=v;}s.peaks.push([mn,mx]);}
  const X0=30,X1=W-30,toT=x=>s.view+(x-X0)/(X1-X0)*(S.dur/s.p.zoom);s.onDown=(x,y)=>{if(y>60&&y<300){s.drag=[toT(x),toT(x)];}else if(y>320&&y<370){s.view=clamp((x-X0)/(X1-X0)*S.dur-S.dur/s.p.zoom/2,0,S.dur-S.dur/s.p.zoom);}};
  s.onMove=(x,y)=>{if(s.down&&s.drag)s.drag[1]=toT(x);else if(s.down&&y>320)s.view=clamp((x-X0)/(X1-X0)*S.dur-S.dur/s.p.zoom/2,0,S.dur-S.dur/s.p.zoom);};
  s.onUp=()=>{if(s.drag){const[a,b]=s.drag;if(Math.abs(b-a)>.3)s.R.push({a:Math.min(a,b),b:Math.max(a,b),c:PAL[s.R.length%PAL.length],n:'region '+(s.R.length+1)});else{s.cur=a;if(s.play){stopSong(s);startSong(s);}}s.drag=null;}};
  s.onWheel=d=>{s.p.zoom=clamp(s.p.zoom*(d>0?.9:1.1),1,8);};s.destroy=()=>stopSong(s);},
 draw(ctx,s,t,dt){const S=songBuffer(),X0=30,X1=W-30,span=S.dur/s.p.zoom;lav(ctx,'#fdfbff','#f1eafc');if(s.play){s.cur+=dt;const lr=s.R[s.R.length-1];if(s.p.loop&&lr&&s.cur>lr.b&&s.cur-dt<=lr.b){s.cur=lr.a;stopSong(s);startSong(s);}if(s.cur>S.dur){s.cur=0;stopSong(s);startSong(s);}if(s.cur>s.view+span*.85||s.cur<s.view)s.view=clamp(s.cur-span*.15,0,S.dur-span);}
  s.view=clamp(s.view,0,S.dur-span);const tx=tt=>X0+(tt-s.view)/span*(X1-X0),cy=180,amp=105;ctx.fillStyle='rgba(255,255,255,.8)';rr(ctx,X0-10,56,X1-X0+20,250,16);ctx.fill();
  ctx.save();ctx.beginPath();ctx.rect(X0,56,X1-X0,250);ctx.clip();for(const r of s.R){ctx.fillStyle=rgba(hex2rgb2(r.c),.1);ctx.fillRect(tx(r.a),60,tx(r.b)-tx(r.a),240);ctx.fillStyle=r.c;ctx.fillRect(tx(r.a),60,2,240);ctx.fillRect(tx(r.b)-2,60,2,240);text(ctx,r.n,tx(r.a)+6,74,r.c,11,'left',MONO,700);}
  if(s.drag){const a=tx(Math.min(...s.drag)),b=tx(Math.max(...s.drag));ctx.fillStyle='rgba(124,58,237,.15)';ctx.fillRect(a,60,b-a,240);}
  const B=s.peaks.length,i0=Math.floor(s.view/S.dur*B),i1=Math.ceil((s.view+span)/S.dur*B),bw=(X1-X0)/(i1-i0);
  for(let i=i0;i<i1;i++){const[mn,mx]=s.peaks[i]||[0,0],x=X0+(i-i0)*bw,played=i/B*S.dur<s.cur;const g=played?'#7c3aed':'#c4b5fd';ctx.fillStyle=g;const h1=mx*amp*1.4,h2=-mn*amp*1.4;rr(ctx,x+bw*.15,cy-h1,Math.max(1,bw*.7),Math.max(1.5,h1+h2*.6),Math.min(2,bw*.3));ctx.fill();}
  line(ctx,X0,cy,X1,cy,'rgba(124,58,237,.15)',1);const cx=tx(s.cur);line(ctx,cx,56,cx,306,'#e11d48',2);circle(ctx,cx,60,5,'#e11d48');
  for(let k=Math.ceil(s.view);k<=s.view+span;k+=s.p.zoom>3?1:2){const x=tx(k);line(ctx,x,292,x,300,'#a49cc0',1);text(ctx,'0:'+String(k).padStart(2,'0'),x+3,298,'#a49cc0',9.5,'left',MONO);}ctx.restore();
  // minimap
  const my=322;ctx.fillStyle='rgba(255,255,255,.75)';rr(ctx,X0,my,X1-X0,46,10);ctx.fill();for(let i=0;i<B;i+=4){const[mn,mx]=s.peaks[i],x=X0+i/B*(X1-X0);ctx.fillStyle=i/B*S.dur<s.cur?'#a78bfa':'#ddd6fe';ctx.fillRect(x,my+23-mx*40,1.6,Math.max(1,(mx-mn)*40*.7));}
  ctx.strokeStyle='#7c3aed';ctx.lineWidth=1.5;rr(ctx,X0+s.view/S.dur*(X1-X0),my+2,span/S.dur*(X1-X0),42,8);ctx.stroke();ctx.fillStyle='rgba(124,58,237,.08)';ctx.fill();
  hud(ctx,['ws.getCurrentTime() = '+s.cur.toFixed(2)+'s','zoom '+s.p.zoom.toFixed(1)+'× · '+s.R.length+' regions'],14,10);audioBadge(ctx);},
 code:`const ws=WaveSurfer.create({container:'#wave',waveColor:'#c4b5fd',progressColor:'#7c3aed',
  barWidth:3,barRadius:2,cursorColor:'#e11d48',url:'track.mp3',
  plugins:[RegionsPlugin.create(),Minimap.create({height:46}),TimelinePlugin.create()]});
const regions=ws.plugins[0];regions.enableDragSelection({color:'rgba(124,58,237,.15)'});
regions.on('region-out',r=>loop&&r.play());ws.on('click',()=>ws.play());ws.zoom(80);`});
function startSong(s){const a=AC();if(!a)return;const S=songBuffer(),b=a.createBuffer(1,S.d.length,S.sr);b.copyToChannel?b.copyToChannel(S.d,0):b.getChannelData(0).set(S.d);const src=a.createBufferSource();src.buffer=b;src.connect(MASTER());src.start(0,s.cur);s.node=src;}
function stopSong(s){if(s.node){try{s.node.stop();}catch(e){}s.node=null;}}
ex({t:'Spectrogram plugin: frequency over time',d:'A short-time Fourier transform (256-point, Hann window) of the same track: kick drums are low thumps, the melody draws bright harmonic ladders and hats are high noise. A frequency cursor reads the bin under the pointer.',hint:'Hover to read time and frequency.',int:1,
 init(s){const S=songBuffer(),N=256,hop=160,cols=Math.floor((S.d.length-N)/hop),B=N/2;s.cols=cols;s.B=B;s.sg=new Float32Array(cols*B);const win=Array.from({length:N},(_,i)=>.5-.5*Math.cos(TAU*i/(N-1)));const re=new Float32Array(N),im=new Float32Array(N);
  for(let c=0;c<cols;c++){for(let i=0;i<N;i++){re[i]=S.d[c*hop+i]*win[i];im[i]=0;}fft(re,im);for(let k=0;k<B;k++)s.sg[c*B+k]=Math.log10(1e-6+Math.hypot(re[k],im[k]))*20;}
  const cv=ocv(cols,B),cx=cv.getContext('2d'),img=cx.createImageData(cols,B),M=['#140e29','#2e1065','#5b21b6','#a21caf','#e11d48','#f97316','#fde68a','#fffbeb'].map(hex2rgb);
  for(let c=0;c<cols;c++)for(let k=0;k<B;k++){const v=clamp((s.sg[c*B+k]+52)/62,0,1),u=v*(M.length-1),i0=Math.min(M.length-2,Math.floor(u)),f=u-i0,o=((B-1-k)*cols+c)*4;for(let j=0;j<3;j++)img.data[o+j]=M[i0][j]+(M[i0+1][j]-M[i0][j])*f;img.data[o+3]=255;}
  cx.putImageData(img,0,0);s.img=cv;},
 draw(ctx,s,t){bg(ctx,'#fbf9ff');const x0=64,y0=26,w=W-90,h=H-74;ctx.save();rr(ctx,x0,y0,w,h,12);ctx.clip();ctx.imageSmoothingEnabled=true;ctx.drawImage(s.img,x0,y0,w,h);ctx.restore();
  for(let f=0;f<=4000;f+=500){const y=y0+h-f/4000*h;text(ctx,f>=1000?(f/1000)+'k':String(f),x0-8,y+4,'#6b6288',10,'right',MONO);line(ctx,x0-4,y,x0,y,'#a49cc0',1);}
  for(let k=0;k<=24;k+=4){const x=x0+k/24*w;text(ctx,k+'s',x,y0+h+16,'#6b6288',10,'center',MONO);}text(ctx,'Hz',x0-36,y0+8,'#6b6288',10,'left',MONO);
  const px=x0+((t*.8)%24)/24*w;line(ctx,px,y0,px,y0+h,'rgba(255,255,255,.8)',1.5);
  if(s.hover&&s.mx>x0&&s.mx<x0+w&&s.my>y0&&s.my<y0+h){line(ctx,x0,s.my,x0+w,s.my,'rgba(255,255,255,.6)',1,[3,3]);line(ctx,s.mx,y0,s.mx,y0+h,'rgba(255,255,255,.6)',1,[3,3]);const tt=(s.mx-x0)/w*24,fq=(y0+h-s.my)/h*4000,c=Math.floor(tt/24*s.cols),k=Math.floor(fq/4000*s.B);const db=s.sg[clamp(c,0,s.cols-1)*s.B+clamp(k,0,s.B-1)];const nn=12*Math.log2(fq/440)+69,names=['C','C♯','D','D♯','E','F','F♯','G','G♯','A','A♯','B'];
   tooltip(ctx,s.mx,s.my,[tt.toFixed(2)+' s · '+fq.toFixed(0)+' Hz',(fq>30?names[Math.round(nn)%12]+(Math.floor(Math.round(nn)/12)-1):'–')+' · '+db.toFixed(1)+' dB']);}
  cap(ctx,'SpectrogramPlugin.create({ fftSamples: 256, labels: true, colorMap: "roseus" })');},
 code:`ws.registerPlugin(Spectrogram.create({labels:true,height:300,fftSamples:256,frequencyMax:4000,colorMap:'roseus'}));`});
function fft(re,im){const n=re.length;for(let i=1,j=0;i<n;i++){let b=n>>1;for(;j&b;b>>=1)j^=b;j^=b;if(i<j){[re[i],re[j]]=[re[j],re[i]];[im[i],im[j]]=[im[j],im[i]];}}
 for(let len=2;len<=n;len<<=1){const a=-TAU/len,wr=Math.cos(a),wi=Math.sin(a);for(let i=0;i<n;i+=len){let cr=1,ci=0;for(let j=0;j<len/2;j++){const ur=re[i+j],ui=im[i+j],vr=re[i+j+len/2]*cr-im[i+j+len/2]*ci,vi=re[i+j+len/2]*ci+im[i+j+len/2]*cr;re[i+j]=ur+vr;im[i+j]=ui+vi;re[i+j+len/2]=ur-vr;im[i+j+len/2]=ui-vi;const nr=cr*wr-ci*wi;ci=cr*wi+ci*wr;cr=nr;}}}}

lib('pannellum','Pannellum','media','A lightweight WebGL panorama viewer for 360° equirectangular images, with hotspots and virtual tours.',{isNew:true,info:{what:'Pannellum shows equirectangular or cube-map panoramas in a drag-to-look viewer, with hotspots, scene links (virtual tours), auto-rotate and compass.',best:['Real-estate and venue tours','Museum and heritage walkthroughs','Showing 360° photos from phones'],not:['Full 3D scenes you can walk through (use Three.js)','Video-heavy VR (consider A-Frame)'],tip:'Keep panoramas at 4096×2048 for phones and lazy-load the next scene of a tour.'}});
function panoImage(){if(window._PANO)return window._PANO;const w=2048,h=1024,cv=ocv(w,h),c=cv.getContext('2d'),img=c.createImageData(w,h),D=img.data;
 for(let y=0;y<h;y++){const la=(.5-y/h)*Math.PI;for(let x=0;x<w;x++){const lo=x/w*TAU;let col;const o=(y*w+x)*4;
  const ridge=.06+.11*fbm(lo*1.6,3.1)+.05*fbm(lo*6,1.3)+.015*noise(lo*30,2),ridge2=.02+.07*fbm(lo*2.3+9,7);
  if(la>ridge){const k=clamp(la/1.2,0,1);col=mixc([1,.86,.9],[.55,.62,.98],Math.pow(k,.6));const sx=Math.cos(la)*Math.cos(lo-1),sy=Math.sin(la),sd=Math.acos(clamp(Math.cos(la)*Math.cos(lo-1.2)*Math.cos(.22)+Math.sin(la)*Math.sin(.22),-1,1));col=mixc(col,[1,.95,.85],Math.exp(-sd*sd*60)*.9+Math.exp(-sd*sd*4)*.25);
   const cl=fbm(lo*5+1,la*14)*Math.exp(-Math.pow((la-.32)*5,2));col=mixc(col,[1,1,1],clamp(cl*1.6-.55,0,.7));}
  else if(la>ridge2){const sh=.5+.5*fbm(lo*12,la*30);col=mixc([.42,.36,.62],[.62,.55,.82],sh);col=mixc(col,[.9,.86,.98],clamp((la-ridge2)/(ridge-ridge2)*.3,0,.3));if(la>ridge-.012&&fbm(lo*40,9)>.45)col=[.96,.95,1];}
  else if(la>0){col=mixc([.17,.34,.32],[.3,.5,.42],fbm(lo*20,la*50));const tr=fbm(lo*60,la*90);if(tr>.55)col=mixc(col,[.08,.22,.2],.6);}
  else{const k=clamp(-la/1.4,0,1),refl=1-k;const rl=-la,rc=mixc([.62,.66,.96],[.95,.82,.9],1-clamp(rl/1.2,0,1));col=mixc(rc,[.2,.28,.42],k*.75);const wv=noise(lo*80,la*400+0)*.05;col=mixc(col,[1,1,1],clamp(wv,0,.05));if(la>-.012)col=mixc(col,[.95,.92,1],.5);}
  if(Math.abs(la+.18)<.04&&Math.abs(((lo/TAU*2048)%2048)-1500)<120){const u=(((lo/TAU*2048)%2048)-1500)/120;col=mixc(col,[.88,.83,.75],.0);}
  D[o]=col[0]*255;D[o+1]=col[1]*255;D[o+2]=col[2]*255;D[o+3]=255;}}
 c.putImageData(img,0,0);const lab=c;lab.fillStyle='rgba(20,14,41,.9)';[[600,350,30,130],[1260,340,60,150],[1290,300,10,40]].forEach(([x,y,w2,h2])=>{});
 return window._PANO={cv,d:c.getImageData(0,0,w,h).data,w,h};}
ex({t:'Drag-to-look 360° panorama with hotspots',d:'An equirectangular panorama (sky, sun, clouds, mountain ridges, forest and a reflecting lake) re-projected per pixel into a rectilinear view. Drag to look, scroll to zoom; hotspots stay pinned to their direction and a compass tracks the heading.',hint:'Drag to look around · scroll to zoom · hover the hotspots.',int:1,orbit:{ry:0,rx:0,auto:.05},
 controls:[{type:'range',k:'fov',l:'Field of view',min:40,max:110,step:1,v:85,fmt:v=>v+'°'}],
 init(s){s.onWheel=d=>{s.p.fov=clamp(s.p.fov+d*.05,40,110);};s.ow=360;s.oh=220;s.out=ocv(s.ow,s.oh);s.oc=s.out.getContext('2d');s.oi=s.oc.createImageData(s.ow,s.oh);},
 draw(ctx,s,t){const P=panoImage(),yaw=-s.ry*.6,pitch=clamp(-s.rx*.6,-1.2,1.2),f=1/Math.tan(s.p.fov*D2R/2),asp=s.ow/s.oh,D=s.oi.data,cy=Math.cos(yaw),sy=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch);
  for(let j=0;j<s.oh;j++){const v=(1-2*(j+.5)/s.oh);for(let i=0;i<s.ow;i++){const u=(2*(i+.5)/s.ow-1)*asp;let x=u,y=v,z=f;const y2=y*cp+z*sp,z2=-y*sp+z*cp;const x3=x*cy+z2*sy,z3=-x*sy+z2*cy;const lo=Math.atan2(x3,z3),la=Math.atan2(y2,Math.hypot(x3,z3));let px=((lo/TAU+1)%1)*P.w,py=(.5-la/Math.PI)*P.h;const k=((py|0)*P.w+(px|0))*4,o=(j*s.ow+i)*4;D[o]=P.d[k];D[o+1]=P.d[k+1];D[o+2]=P.d[k+2];D[o+3]=255;}}
  s.oc.putImageData(s.oi,0,0);ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';ctx.drawImage(s.out,0,0,W,H);
  const HS=[['Summit',.9,.13,'#7c3aed','2,310 m · snowfield'],['Lake shore',2.6,-.08,'#0284c7','swim zone · 14 °C'],['Forest trail',4.2,.02,'#0d9488','loop 6.4 km'],['Sunset point',1.2,.25,'#d97706','golden hour 19:42']];
  HS.forEach(([n,lo,la,col,info])=>{let x3=Math.cos(la)*Math.sin(lo),y3=Math.sin(la),z3=Math.cos(la)*Math.cos(lo);const xr=x3*cy-z3*sy,zr=x3*sy+z3*cy;const y2=y3*cp-zr*sp,z2=y3*sp+zr*cp;if(z2<=.05)return;const sx=(xr/z2*f/asp*.5+.5)*W,syy=(.5-y2/z2*f*.5)*H;if(sx<-40||sx>W+40)return;
   const hov=s.hover&&Math.hypot(s.mx-sx,s.my-syy)<18,pul=(t*1.2+lo)%1;ctx.strokeStyle=rgba(hex2rgb2(col),1-pul);ctx.lineWidth=2;ctx.beginPath();ctx.arc(sx,syy,10+pul*16,0,TAU);ctx.stroke();ctx.save();ctx.shadowColor='rgba(0,0,0,.3)';ctx.shadowBlur=10;circle(ctx,sx,syy,11,'#fff');ctx.restore();circle(ctx,sx,syy,6,col);
   if(hov)tooltip(ctx,sx,syy-10,[n,info]);else{ctx.font='600 11.5px '+FONT;const tw=ctx.measureText(n).width+16;ctx.fillStyle='rgba(255,255,255,.85)';rr(ctx,sx-tw/2,syy+16,tw,20,10);ctx.fill();text(ctx,n,sx,syy+30,'#140E29',11.5,'center',FONT,600);}});
  const cx=W-50,cyy=50;ctx.fillStyle='rgba(255,255,255,.85)';circle(ctx,cx,cyy,30,'rgba(255,255,255,.85)','rgba(124,58,237,.3)',1);ctx.save();ctx.translate(cx,cyy);ctx.rotate(-yaw);ctx.fillStyle='#e11d48';ctx.beginPath();ctx.moveTo(0,-22);ctx.lineTo(6,0);ctx.lineTo(-6,0);ctx.fill();ctx.fillStyle='#4c4369';ctx.beginPath();ctx.moveTo(0,22);ctx.lineTo(6,0);ctx.lineTo(-6,0);ctx.fill();ctx.restore();text(ctx,'N',cx,cyy-34,'#e11d48',10,'center',MONO,700);
  hud(ctx,['yaw '+(((yaw/D2R)%360+360)%360).toFixed(0)+'°  pitch '+(pitch/D2R).toFixed(0)+'°','hfov '+s.p.fov+'°'],14,14);},
 code:`pannellum.viewer('pano',{type:'equirectangular',panorama:'lake-4096.jpg',autoLoad:true,autoRotate:-2,compass:true,
  hfov:85,hotSpots:[{pitch:7.4,yaw:51.6,type:'info',text:'Summit · 2,310 m'},
                    {pitch:-4.6,yaw:149,type:'scene',text:'Lake shore',sceneId:'shore'}]});`});
