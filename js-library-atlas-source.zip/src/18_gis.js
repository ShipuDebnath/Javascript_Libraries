/* ===================== Maps & GIS ===================== */
function terrainImg(w,h,sx,sy,pal){const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d'),id=x.createImageData(w,h);
 for(let y=0;y<h;y++)for(let i=0;i<w;i++){const e=fbm(i*sx+3,y*sy+3),k=(y*w+i)*4;let col;if(pal==='pastel'){if(e<.42)col=[204,226,240];else if(e<.45)col=[236,232,220];else if(e<.62)col=[232,240,222];else if(e<.75)col=[214,230,204];else col=[226,222,214];}
  else{if(e<.4)col=[150,196,226];else if(e<.46)col=[176,214,236];else if(e<.49)col=[236,226,196];else if(e<.64)col=[188,214,160];else if(e<.78)col=[146,184,120];else col=[200,190,170];}id.data[k]=col[0];id.data[k+1]=col[1];id.data[k+2]=col[2];id.data[k+3]=255;}x.putImageData(id,0,0);return c;}
const CITY2=[['New York',40.7,-74],['London',51.5,-.1],['Cairo',30,31.2],['Mumbai',19,72.8],['Tokyo',35.7,139.7],['São Paulo',-23.5,-46.6],['Sydney',-33.9,151.2],['Lagos',6.5,3.4],['Moscow',55.75,37.6],['Singapore',1.35,103.8],['Los Angeles',34,-118.2],['Mexico City',19.4,-99.1]];
function eqr(lat,lon,x0,y0,w,h){return[x0+(lon+180)/360*w,y0+(90-lat)/180*h];}
function dotWorld(ctx,x0,y0,w,h,col){for(const q of GL){if(!q.land)continue;const p=eqr(q.lat/D2R,q.lon/D2R,x0,y0,w,h);ctx.fillStyle=col||'#d6d3d1';ctx.fillRect(p[0]-1.4,p[1]-1.4,2.8,2.8);}}

lib('deckgl','deck.gl','gis','GPU-powered layers for massive geospatial data: columns, hexagons, arcs, trips, heatmaps and point clouds.',{ik:'deck.gl'});
ex({t:'ColumnLayer: extruded 3D columns',d:'A 22×22 grid of columns whose height and colour encode value, growing in on load. Tilt the view with the pointer.',hint:'Move the pointer up/down to tilt · drag to rotate.',orbit:{ry:.3,rx:1,auto:.12},
 init(s){const n=22;s.n=n;s.h=[];for(let i=0;i<n;i++){s.h[i]=[];for(let j=0;j<n;j++){const a=Math.exp(-(Math.pow(i-6,2)+Math.pow(j-7,2))/18),b=Math.exp(-(Math.pow(i-15,2)+Math.pow(j-13,2))/26);s.h[i][j]=clamp(a*.9+b*.7+fbm(i*.35,j*.35)*.35-.1,0,1.1);}}},
 draw(ctx,s,t){vgrad(ctx,'#f8fafc','#eef2f7');const rx=s.hover?.45+s.my/H*.8:s.rx,D=6,sc=108,n=s.n,g=easeOut(clamp((t%14)/1.8,0,1)),sp=.13,hw=.05,Q=[];
  poly(ctx,[[-1.5,.45,-1.5],[1.5,.45,-1.5],[1.5,.45,1.5],[-1.5,.45,1.5]].map(p=>pr(rot(p,s.ry,rx),sc,D)),'#e2e8f0');
  for(let i=0;i<n;i++)for(let j=0;j<n;j++){const hv=s.h[i][j];if(hv<.06)continue;const x=(i-n/2+.5)*sp,z=(j-n/2+.5)*sp,ht=hv*1.3*g;boxQuads([x,.45-ht/2,z],hw,ht/2,hw,{v1:hv}).forEach(q=>Q.push(q));}
  renderQuads(ctx,Q,{ry:s.ry,rx,sc,d:D,col:(q,dif)=>mixHex(hex2rgb2(scale(['#fde68a','#fb923c','#e11d48','#7c3aed'],q.v1/1.1)),'#1c1917',.35-dif*.35)});cap(ctx,'new ColumnLayer({data, getElevation:d=>d.value, extruded:true, radius:2000})');},
 code:`new deck.DeckGL({container:'map',initialViewState:{longitude:-1.4,latitude:52.5,zoom:6,pitch:50,bearing:20},controller:true,
  layers:[new deck.ColumnLayer({id:'cols',data,diskResolution:4,radius:2000,extruded:true,elevationScale:500,
    getPosition:d=>d.coord,getElevation:d=>d.value,getFillColor:d=>colorScale(d.value),transitions:{getElevation:1000}})]});`});
ex({t:'ArcLayer: global flows',d:'Arcs between twelve cities with a source-to-target colour gradient and pulses travelling along them, over a dotted world map.',hint:'Hover a city to isolate its flows.',int:1,
 init(s){s.A=[];for(let i=0;i<CITY2.length;i++)for(let k=0;k<2;k++){const j=(i+1+k*4)%CITY2.length;s.A.push([i,j]);}},
 draw(ctx,s,t){bg(ctx,'#ffffff');const x0=20,y0=20,w=W-40,h=(W-40)/2,P=c=>eqr(c[1],c[2],x0,y0,w,h);dotWorld(ctx,x0,y0,w,h,'#e7e5e4');let hv=-1;CITY2.forEach((c,i)=>{const p=P(c);if(s.hover&&Math.hypot(p[0]-s.mx,p[1]-s.my)<12)hv=i;});
  s.A.forEach(([a,b],k)=>{if(hv>=0&&a!==hv&&b!==hv)return;const A=P(CITY2[a]),B=P(CITY2[b]),d=Math.hypot(B[0]-A[0],B[1]-A[1]),mx=(A[0]+B[0])/2,my=(A[1]+B[1])/2-d*.35;const g=ctx.createLinearGradient(A[0],A[1],B[0],B[1]);g.addColorStop(0,'rgba(79,70,229,.55)');g.addColorStop(1,'rgba(225,29,72,.55)');ctx.strokeStyle=g;ctx.lineWidth=hv>=0?2.5:1.6;ctx.beginPath();ctx.moveTo(A[0],A[1]);ctx.quadraticCurveTo(mx,my,B[0],B[1]);ctx.stroke();
   const u=(t*.35+k*.13)%1,qx=(1-u)*(1-u)*A[0]+2*(1-u)*u*mx+u*u*B[0],qy=(1-u)*(1-u)*A[1]+2*(1-u)*u*my+u*u*B[1];circle(ctx,qx,qy,3,mixHex('#4f46e5','#e11d48',u));});
  CITY2.forEach((c,i)=>{const p=P(c);circle(ctx,p[0],p[1],i===hv?7:4.5,'#1c1917','#fff',1.5);if(i===hv)text(ctx,c[0],p[0]+10,p[1]-8,C.ink,13,'left',FONT,700);});cap(ctx,'new ArcLayer({data, getSourceColor:[79,70,229], getTargetColor:[225,29,72]})');},
 code:`new deck.ArcLayer({id:'flows',data:flows,getSourcePosition:d=>d.from,getTargetPosition:d=>d.to,
  getSourceColor:[79,70,229],getTargetColor:[225,29,72],getWidth:2,pickable:true,
  onHover:({object})=>setTooltip(object)});`});
ex({t:'TripsLayer: animated vehicle paths',d:'Sixty vehicles drive a street grid; each draws a fading trail of its last few seconds, the TripsLayer currentTime + trailLength pattern.',controls:[{type:'range',k:'tl',l:'Trail length',min:.5,max:6,step:.5,v:3}],
 init(s){const r=rng(19);s.V=Array.from({length:60},()=>{const pts=[];let x=Math.floor(r()*14),y=Math.floor(r()*9),dir=Math.floor(r()*4);pts.push([x,y]);for(let k=0;k<60;k++){if(r()<.35)dir=(dir+(r()<.5?1:3))%4;const nx=x+[1,0,-1,0][dir],ny=y+[0,1,0,-1][dir];if(nx<0||nx>14||ny<0||ny>9){dir=(dir+2)%4;continue;}x=nx;y=ny;pts.push([x,y]);}return{pts,c:r()<.5?'#0d9488':'#e11d48',sp:.8+r()*.8,of:r()*20};});},
 draw(ctx,s,t){bg(ctx,'#f8fafc');const X=i=>40+i*46,Y=j=>30+j*42;ctx.strokeStyle='#e2e8f0';ctx.lineWidth=7;for(let i=0;i<=14;i++)line(ctx,X(i),Y(0),X(i),Y(9),'#e2e8f0',7);for(let j=0;j<=9;j++)line(ctx,X(0),Y(j),X(14),Y(j),'#e2e8f0',7);
  ctx.fillStyle='#f1f5f9';for(let i=0;i<14;i++)for(let j=0;j<9;j++){ctx.fillStyle=(i*7+j*3)%5===0?'#dcfce7':'#f1f5f9';rr(ctx,X(i)+6,Y(j)+6,34,30,4);ctx.fill();}
  s.V.forEach(v=>{const T=(t*v.sp+v.of)%(v.pts.length-1),tl=s.p.tl;ctx.lineCap='round';for(let k=0;k<12;k++){const a=T-tl*(k+1)/12,b=T-tl*k/12;if(a<0)continue;const pa=polyPt(v.pts,a/(v.pts.length-1)),pb=polyPt(v.pts,b/(v.pts.length-1));line(ctx,X(pa[0]),Y(pa[1]),X(pb[0]),Y(pb[1]),rgba(v.c,(1-k/12)*.85),3.5);}const p=polyPt(v.pts,T/(v.pts.length-1));circle(ctx,X(p[0]),Y(p[1]),4,v.c,'#fff',1.5);});
  cap(ctx,'new TripsLayer({data, currentTime, trailLength:'+s.p.tl*60+', fadeTrail:true})');},
 code:`const layer=t=>new deck.TripsLayer({id:'trips',data:trips,getPath:d=>d.path,getTimestamps:d=>d.timestamps,
  getColor:d=>d.vendor?[13,148,136]:[225,29,72],widthMinPixels:3,trailLength:180,currentTime:t,fadeTrail:true});
(function animate(t){deckgl.setProps({layers:[layer(t/50%1800)]});requestAnimationFrame(animate);})();`});

lib('maplibre','MapLibre GL JS','gis','Open-source GPU vector maps: custom styles, 3D terrain, extrusions, heatmaps and offline PMTiles.',{ik:'MapLibre GL JS'});
ex({t:'3D terrain with hillshade & sky',d:'Pitched terrain from procedural elevation with banded colours, an atmospheric sky and a moving camera.',hint:'Move the pointer up/down to change the pitch.',
 draw(ctx,s,t){const sk=ctx.createLinearGradient(0,0,0,H*.45);sk.addColorStop(0,'#bfdbfe');sk.addColorStop(1,'#fef3c7');ctx.fillStyle=sk;ctx.fillRect(0,0,W,H);const pitch=s.hover?.35+s.my/H*.9:.8,rows=46,cols=100,hs=H*.5*pitch,off=t*.8;
  for(let r=0;r<rows;r++){const f=r/(rows-1),by=H*.26+f*H*.7*(.5+pitch*.5),k=.35+f*.9,pts=[];for(let c=0;c<=cols;c++){const x=c/cols,e=fbm(x*3.2+4,(r-off)*.17+9),h=Math.max(0,e-.38)*1.6;pts.push([W/2+(x-.5)*W*1.5*k,by-h*hs*k,h]);}
   ctx.beginPath();ctx.moveTo(pts[0][0],H);pts.forEach(p=>ctx.lineTo(p[0],p[1]));ctx.lineTo(pts[cols][0],H);ctx.closePath();const haze=1-f;ctx.fillStyle=mixHex('#a3c48a','#e7eef5',haze*.7);ctx.fill();
   ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.strokeStyle=mixHex('#4d7c0f','#cbd5e1',haze*.75);ctx.lineWidth=.8+f*1.4;ctx.stroke();}
  cap(ctx,'map.setTerrain({ source:"dem", exaggeration:1.5 }); map.setSky({...})');},
 code:`const map=new maplibregl.Map({container:'map',style:'style.json',center:[11.39,47.27],zoom:12,pitch:70});
map.on('load',()=>{map.addSource('dem',{type:'raster-dem',url:'pmtiles://data/terrain.pmtiles',tileSize:256});
  map.setTerrain({source:'dem',exaggeration:1.5});
  map.addLayer({id:'hills',type:'hillshade',source:'dem'});});`});
ex({t:'Vector style switcher with pan & zoom',d:'A vector basemap (water, parks, roads, buildings, labels) re-styled instantly by swapping the style. Drag to pan, wheel to zoom.',hint:'Drag to pan · scroll to zoom · switch styles.',int:1,controls:[{type:'seg',k:'st',v:'Positron',opts:['Positron','Voyager','Pastel','Blueprint']}],
 init(s){const r=rng(7);s.ox=0;s.oy=0;s.z=1;s.roads=[];for(let i=0;i<14;i++){const y=r()*900-200;s.roads.push([[-400,y],[300,y+(r()-.5)*200],[1200,y+(r()-.5)*300]]);const x=r()*1100-200;s.roads.push([[x,-300],[x+(r()-.5)*200,300],[x+(r()-.5)*260,800]]);}
  s.parks=Array.from({length:8},()=>[r()*900-100,r()*700-100,40+r()*90]);s.bld=Array.from({length:260},()=>[r()*1000-150,r()*800-150,8+r()*18,8+r()*14]);s.labels=['Riverside','Old Town','Harbour','Northgate','Mill Park','Eastfield'].map(n=>[n,r()*800,r()*560]);
  let lx,ly;s.onDown=(x,y)=>{lx=x;ly=y;};s.onMove=(x,y)=>{if(s.down){s.ox+=x-lx;s.oy+=y-ly;lx=x;ly=y;}};s.onWheel=dy=>{const z0=s.z;s.z=clamp(s.z*(1-dy*.0015),.5,4);s.ox=s.mx-(s.mx-s.ox)*s.z/z0;s.oy=s.my-(s.my-s.oy)*s.z/z0;};},
 draw(ctx,s,t){const S={Positron:{bg:'#fafaf8',w:'#d4e4f1',p:'#e3efd9',r:'#ffffff',rc:'#e7e5e4',b:'#ece9e3',l:'#78716c'},Voyager:{bg:'#f6f3ee',w:'#a8d1ea',p:'#cfe8b9',r:'#fde68a',rc:'#f59e0b',b:'#e7ded3',l:'#57534e'},Pastel:{bg:'#fdf4ff',w:'#c7d2fe',p:'#bbf7d0',r:'#fbcfe8',rc:'#f9a8d4',b:'#fae8ff',l:'#86198f'},Blueprint:{bg:'#1e3a8a',w:'#1e40af',p:'#1d4ed8',r:'#93c5fd',rc:'#60a5fa',b:'#2547a5',l:'#dbeafe'}}[s.p.st];
  bg(ctx,S.bg);ctx.save();ctx.translate(s.ox,s.oy);ctx.scale(s.z,s.z);ctx.fillStyle=S.w;ctx.beginPath();ctx.moveTo(-500,420);for(let x=-500;x<=1400;x+=40)ctx.lineTo(x,420+Math.sin(x*.006)*60+Math.sin(x*.02)*14);ctx.lineTo(1400,1200);ctx.lineTo(-500,1200);ctx.fill();
  s.parks.forEach(p=>{ctx.fillStyle=S.p;ctx.beginPath();ctx.ellipse(p[0],p[1],p[2],p[2]*.7,0,0,TAU);ctx.fill();});s.bld.forEach(b=>{ctx.fillStyle=S.b;ctx.fillRect(b[0],b[1],b[2],b[3]);});
  [[S.rc,9/s.z+3],[S.r,6/s.z+2]].forEach(([c,w])=>{ctx.strokeStyle=c;ctx.lineWidth=w;ctx.lineCap='round';s.roads.forEach(R=>{ctx.beginPath();ctx.moveTo(R[0][0],R[0][1]);ctx.quadraticCurveTo(R[1][0],R[1][1],R[2][0],R[2][1]);ctx.stroke();});});ctx.restore();
  s.labels.forEach(([n,x,y])=>{const X=s.ox+x*s.z,Y=s.oy+y*s.z;ctx.lineWidth=4;ctx.strokeStyle=S.bg;ctx.font='600 '+(12+s.z*2)+'px '+FONT;ctx.textAlign='center';ctx.strokeText(n,X,Y);ctx.fillStyle=S.l;ctx.fillText(n,X,Y);});
  text(ctx,'zoom '+(12+Math.log2(s.z)).toFixed(1),W-14,H-14,S.l,12,'right',MONO);},
 code:`const styles={positron:'styles/positron.json',voyager:'styles/voyager.json'};   // local style files
const map=new maplibregl.Map({container:'map',style:styles.positron,center:[-0.12,51.5],zoom:13});
select.onchange=e=>map.setStyle(styles[e.target.value]);   // data sources are kept`});
ex({t:'Heatmap layer with zoom-dependent radius',d:'Thousands of points rendered as a kernel-density heatmap; radius and intensity grow with zoom, as in a MapLibre heatmap style expression.',controls:[{type:'range',k:'z',l:'Zoom',min:8,max:15,step:.1,v:11},{type:'range',k:'w',l:'Intensity',min:.4,max:2.5,step:.1,v:1.2}],
 init(s){const r=rng(3);s.P=[];[[260,180,60],[460,240,80],[380,330,40],[560,140,50]].forEach(([x,y,sd])=>{for(let i=0;i<500;i++)s.P.push([x+gauss(r)*sd,y+gauss(r)*sd*.7]);});for(let i=0;i<300;i++)s.P.push([r()*W,r()*H]);s.base=terrainImg(240,147,.012,.012,'pastel');s.acc=document.createElement('canvas');s.acc.width=360;s.acc.height=220;},
 draw(ctx,s,t){ctx.drawImage(s.base,0,0,W,H);const a=s.acc.getContext('2d'),z=s.p.z,rad=(4+(z-8)*2.2)/2,k=s.p.w;a.clearRect(0,0,360,220);a.globalCompositeOperation='lighter';s.P.forEach(p=>{const g=a.createRadialGradient(p[0]/2,p[1]/2,0,p[0]/2,p[1]/2,rad);g.addColorStop(0,'rgba(0,0,0,'+.06*k+')');g.addColorStop(1,'rgba(0,0,0,0)');a.fillStyle=g;a.fillRect(p[0]/2-rad,p[1]/2-rad,rad*2,rad*2);});
  a.globalCompositeOperation='source-over';const im=a.getImageData(0,0,360,220),d=im.data,pal=['#2563eb','#06b6d4','#84cc16','#facc15','#f97316','#dc2626'].map(hex2rgb);for(let i=0;i<d.length;i+=4){const v=d[i+3]/255;if(v<.03){d[i+3]=0;continue;}const u=clamp(v*1.4,0,1)*(pal.length-1),j=Math.min(pal.length-2,Math.floor(u)),f=u-j;d[i]=lerp(pal[j][0],pal[j+1][0],f);d[i+1]=lerp(pal[j][1],pal[j+1][1],f);d[i+2]=lerp(pal[j][2],pal[j+1][2],f);d[i+3]=clamp(v*2.2,0,.85)*255;}a.putImageData(im,0,0);ctx.drawImage(s.acc,0,0,W,H);
  cap(ctx,'"heatmap-radius":["interpolate",["linear"],["zoom"],8,4,15,20]');},
 code:`map.addLayer({id:'heat',type:'heatmap',source:'points',paint:{
  'heatmap-radius':['interpolate',['linear'],['zoom'],8,4,15,20],
  'heatmap-intensity':['interpolate',['linear'],['zoom'],8,1,15,3],
  'heatmap-color':['interpolate',['linear'],['heatmap-density'],0,'rgba(37,99,235,0)',.4,'#84cc16',.8,'#f97316',1,'#dc2626']}});`});

lib('leaflet','Leaflet','gis','The lightweight, mobile-friendly map library: tiles, markers, popups, GeoJSON and a huge plugin ecosystem.');
ex({t:'Pannable map with markers & popups',d:'Raster tiles (procedural here), pin markers, a popup on click and zoom buttons, the classic Leaflet starter.',hint:'Drag to pan · click a marker · use + / −.',int:1,
 init(s){s.map=terrainImg(280,180,.02,.02);s.MW=1400;s.MH=900;s.z=1;s.ox=-340;s.oy=-230;s.mk=[{x:640,y:440,n:'Station A',d:'NDVI 0.71'},{x:820,y:380,n:'Station B',d:'NDVI 0.48'},{x:560,y:560,n:'Field site',d:'Soil moisture 23%'},{x:900,y:560,n:'River gauge',d:'Level 1.8 m'}];s.pop=s.mk[0];
  const zoom=z1=>{const z0=s.z;s.ox=W/2-(W/2-s.ox)/z0*z1;s.oy=H/2-(H/2-s.oy)/z0*z1;s.z=z1;};let lx=0,ly=0;
  s.onDown=(x,y)=>{if(x<56&&y>14&&y<70){zoom(y<42?Math.min(2.4,s.z*1.5):Math.max(1,s.z/1.5));return;}for(const m of s.mk){const mx=m.x*s.z+s.ox,my=m.y*s.z+s.oy;if(Math.hypot(x-mx,y-(my-24))<20){s.pop=m;return;}}s.pop=null;lx=x;ly=y;s.pan=true;};
  s.onMove=(x,y)=>{if(s.down&&s.pan){s.ox+=x-lx;s.oy+=y-ly;lx=x;ly=y;}};s.onUp=()=>{s.pan=false;};},
 draw(ctx,s,t){s.ox=clamp(s.ox,W-s.MW*s.z,0);s.oy=clamp(s.oy,H-s.MH*s.z,0);ctx.imageSmoothingEnabled=true;ctx.drawImage(s.map,0,0,280,180,s.ox,s.oy,s.MW*s.z,s.MH*s.z);
  for(const m of s.mk){const x=m.x*s.z+s.ox,y=m.y*s.z+s.oy;softShadow(ctx,x+6,y,10,4,.3);ctx.fillStyle='#2563eb';ctx.beginPath();ctx.arc(x,y-26,14,Math.PI*.82,Math.PI*.18+TAU);ctx.lineTo(x,y);ctx.closePath();ctx.fill();circle(ctx,x,y-26,5.5,'#fff');}
  if(s.pop){const m=s.pop,x=m.x*s.z+s.ox,y=m.y*s.z+s.oy-60;ctx.save();ctx.shadowColor='rgba(0,0,0,.2)';ctx.shadowBlur=14;ctx.fillStyle='#fff';rr(ctx,x-84,y-54,168,54,10);ctx.fill();ctx.beginPath();ctx.moveTo(x-9,y);ctx.lineTo(x,y+10);ctx.lineTo(x+9,y);ctx.fill();ctx.restore();text(ctx,m.n,x-70,y-30,C.ink,14,'left',FONT,700);text(ctx,m.d,x-70,y-11,C.mut,12.5);}
  ctx.fillStyle='#fff';ctx.strokeStyle='rgba(0,0,0,.2)';rr(ctx,12,14,40,56,6);ctx.fill();ctx.stroke();line(ctx,12,42,52,42,'#e5e7eb',1);text(ctx,'+',32,36,C.ink,22,'center');text(ctx,'−',32,64,C.ink,22,'center');
  ctx.fillStyle='rgba(255,255,255,.75)';ctx.fillRect(W-170,H-18,170,18);text(ctx,'Leaflet | © demo tiles',W-6,H-5,C.ink2,11,'right');},
 code:`const map=L.map('map').setView([51.5,-0.1],13);
L.tileLayer('tiles/{z}/{x}/{y}.png',{maxZoom:18,attribution:'© local tiles'}).addTo(map);
L.marker([51.5,-0.09]).addTo(map).bindPopup('<b>Station A</b><br>NDVI 0.71').openPopup();`});
ex({t:'Choropleth with info control & legend',d:'Regions coloured by a value with a sequential scale; hover highlights a region and updates the info box, as in Leaflet’s interactive choropleth tutorial.',hint:'Hover the regions.',int:1,
 init(s){const r=rng(23),nx=9,ny=6,V=[];for(let j=0;j<=ny;j++){V[j]=[];for(let i=0;i<=nx;i++){const ed=i===0||j===0||i===nx||j===ny;V[j][i]=[40+i*(560/nx)+(ed?0:(r()-.5)*40),40+j*(360/ny)+(ed?0:(r()-.5)*36)];}}
  const names='Alder Birch Cedar Dale Elm Fern Glen Hollow Iris Juniper Kestrel Larch Maple Nettle Oak Pine Quill Rowan Sage Thorn Umber Vale Willow Yarrow Aspen Brook Clover Dune Ember Fox Gale Heath Ivy Jade Knoll Lark Moss Nook Orchid Poppy Quarry Reed Sorrel Tansy Upland Vetch Wren Yew Zephyr Ash Bay Cove Dell Ford'.split(' ');
  s.R=[];for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){const v=Math.round(fbm(i*.4,j*.4)*600+r()*120);s.R.push({p:[V[j][i],V[j][i+1],V[j+1][i+1],V[j+1][i]],v,n:names[(j*nx+i)%names.length]+' County'});}},
 draw(ctx,s,t){bg(ctx,'#f8fafc');const sc=['#ffffcc','#ffeda0','#fed976','#feb24c','#fd8d3c','#fc4e2a','#e31a1c','#b10026'],col=v=>sc[clamp(Math.floor(v/90),0,7)];let hv=null;
  s.R.forEach(R=>{if(s.hover&&pip(s.mx,s.my,R.p))hv=R;poly(ctx,R.p,col(R.v),'#fff',2);});if(hv){poly(ctx,hv.p,null,'#1c1917',3);}
  ctx.save();ctx.shadowColor='rgba(0,0,0,.12)';ctx.shadowBlur=10;ctx.fillStyle='rgba(255,255,255,.95)';rr(ctx,W-168,14,154,62,8);ctx.fill();ctx.restore();text(ctx,'Population density',W-156,34,C.ink,12.5,'left',FONT,700);text(ctx,hv?hv.n:'Hover over a region',W-156,52,C.ink2,12);if(hv)text(ctx,hv.v+' people / km²',W-156,68,C.mut,11.5);
  ctx.fillStyle='rgba(255,255,255,.95)';rr(ctx,W-110,H-178,96,166,8);ctx.fill();sc.forEach((c,i)=>{ctx.fillStyle=c;ctx.fillRect(W-100,H-170+i*19,16,16);text(ctx,i*90+(i<7?'–'+((i+1)*90):'+'),W-78,H-158+i*19,C.ink2,11);});},
 code:`const geo=L.geoJson(regions,{style:f=>({fillColor:getColor(f.properties.density),weight:2,color:'white',fillOpacity:.8}),
  onEachFeature:(f,layer)=>layer.on({mouseover:e=>{e.target.setStyle({weight:3,color:'#1c1917'});info.update(f.properties);},
    mouseout:e=>{geo.resetStyle(e.target);info.update();}})}).addTo(map);`});
ex({t:'Marker clustering (Leaflet.markercluster)',d:'Four hundred markers group into count bubbles that split apart as you zoom in. Click a cluster to zoom into it.',hint:'Click a cluster · use the zoom slider.',int:1,controls:[{type:'range',k:'z',l:'Zoom',min:1,max:5,step:.05,v:1}],
 init(s){const r=rng(61);s.M=[];[[200,160],[480,120],[380,300],[580,320],[150,330]].forEach(([x,y])=>{for(let i=0;i<80;i++)s.M.push([x+gauss(r)*45,y+gauss(r)*35]);});s.img=terrainImg(240,147,.016,.016);s.cx=W/2;s.cy=H/2;s.zt=1;s.zc=1;
  s.onDown=(x,y)=>{(s.cl||[]).forEach(c=>{if(c.n>1&&Math.hypot(x-c.x,y-c.y)<c.r){s.cx=s.cx+(c.x-W/2)/s.zc;s.cy=s.cy+(c.y-H/2)/s.zc;s.p.z=Math.min(5,s.zc*1.8);}});};},
 draw(ctx,s,t){s.zc=lerp(s.zc,s.p.z,.12);const z=s.zc,T=p=>[W/2+(p[0]-s.cx)*z,H/2+(p[1]-s.cy)*z];ctx.drawImage(s.img,W/2-s.cx*z,H/2-s.cy*z,W*z,H*z);const cell=90/z,G={};s.M.forEach(p=>{const k=Math.floor(p[0]/cell)+','+Math.floor(p[1]/cell);(G[k]=G[k]||[]).push(p);});
  s.cl=Object.values(G).map(g=>{const c=g.reduce((a,p)=>[a[0]+p[0],a[1]+p[1]],[0,0]).map(v=>v/g.length),q=T(c);return{x:q[0],y:q[1],n:g.length,r:g.length>1?14+Math.sqrt(g.length)*2.4:7};});
  s.cl.forEach(c=>{if(c.n===1){ctx.fillStyle='#2563eb';ctx.beginPath();ctx.arc(c.x,c.y-12,8,Math.PI*.8,Math.PI*.2+TAU);ctx.lineTo(c.x,c.y);ctx.fill();circle(ctx,c.x,c.y-12,3,'#fff');return;}const col=c.n>50?'#f97316':c.n>10?'#facc15':'#84cc16';circle(ctx,c.x,c.y,c.r+5,rgba(col,.4));circle(ctx,c.x,c.y,c.r,col);text(ctx,String(c.n),c.x,c.y+4.5,'#1c1917',12,'center',FONT,700);});
  badge(ctx,s.cl.length+' clusters · zoom '+z.toFixed(1),14,14,'#fff',C.ink2);},
 code:`const markers=L.markerClusterGroup({maxClusterRadius:80,spiderfyOnMaxZoom:true});
points.forEach(p=>markers.addLayer(L.marker(p.latlng).bindPopup(p.name)));
map.addLayer(markers);   // clusters split as you zoom; click to zoom to bounds`});

lib('openlayers','OpenLayers','gis','Full-featured web GIS: any projection, OGC services, GeoTIFF, vector tiles, drawing, editing and measuring.',{ik:'OpenLayers'});
ex({t:'Reprojection: flat map ↔ globe',d:'The same land data morphs between an equirectangular map (EPSG:4326) and an orthographic globe, with graticule lines reprojected on the fly.',
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const ph=(t%9)/9,m=ph<.2?0:ph<.45?ease((ph-.2)/.25):ph<.7?1:1-ease((ph-.7)/.3),ry=t*.25,rx=.35,xs=W*.9/TAU,ys=H*.8/Math.PI,sc=165;
  const pos=(lat,lon)=>{const ex_=W/2+lon*xs,ey=H/2-lat*ys,r=rot(ll(lat,lon),ry,rx),ox=W/2+r[0]*sc,oy=H/2+r[1]*sc;return[lerp(ex_,ox,m),lerp(ey,oy,m),lerp(1,r[2]>0?1:0,m)];};
  ctx.globalAlpha=1-m;ctx.strokeStyle='#cbd5e1';ctx.lineWidth=1.5;ctx.strokeRect(W/2-Math.PI*xs,H/2-Math.PI/2*ys,TAU*xs,Math.PI*ys);ctx.globalAlpha=m;circle(ctx,W/2,H/2,sc,'#eef4fb','#93c5fd',1.5);ctx.globalAlpha=1;
  const gs=(pa,pb)=>{const a=Math.min(pa[2],pb[2])*.6;if(a<.02)return;ctx.globalAlpha=a;line(ctx,pa[0],pa[1],pb[0],pb[1],'#93c5fd',1);};for(let lo=-180;lo<=150;lo+=30){let pp=null;for(let la=-90;la<=90;la+=6){const p=pos(la*D2R,lo*D2R);if(pp)gs(pp,p);pp=p;}}for(let la=-60;la<=60;la+=30){let pp=null;for(let lo=-180;lo<=180;lo+=6){const p=pos(la*D2R,clamp(lo*D2R,-3.14159,3.14159));if(pp)gs(pp,p);pp=p;}}
  for(const q of GL){if(!q.land)continue;const p=pos(q.lat,q.lon);if(p[2]<.03)continue;ctx.globalAlpha=p[2];ctx.fillStyle='#0d9488';ctx.fillRect(p[0]-1.5,p[1]-1.5,3,3);}ctx.globalAlpha=1;
  badge(ctx,m<.5?'EPSG:4326 · equirectangular':'orthographic',14,14,'#ecfeff','#0e7490');cap(ctx,'new View({ projection: getProjection("EPSG:4326") })');},
 code:`import {register} from 'ol/proj/proj4';proj4.defs('ortho','+proj=ortho +lat_0=20 +lon_0=0');register(proj4);
const map=new ol.Map({target:'map',layers:[new ol.layer.Vector({source:new ol.source.Vector({url:'data/land.geojson',format:new ol.format.GeoJSON()})})],
  view:new ol.View({projection:'ortho',center:[0,0],zoom:2})});`});
ex({t:'Draw & measure tool',d:'Click to add polygon vertices, double-click to finish. Live length and area are computed as you draw; drag a vertex afterwards to modify it.',hint:'Click to add points · double-click to close · drag vertices.',int:1,controls:[{type:'btn',l:'Clear',fn:s=>{s.P=[];s.done=false;}}],
 init(s){s.img=terrainImg(240,147,.016,.016);s.P=[[180,140],[420,110],[520,260],[300,330]];s.done=true;s.dv=-1;
  s.onDown=(x,y)=>{if(s.done){s.dv=s.P.findIndex(p=>Math.hypot(p[0]-x,p[1]-y)<10);if(s.dv<0){s.P=[[x,y]];s.done=false;}return;}s.P.push([x,y]);};s.onMove=(x,y)=>{if(s.down&&s.dv>=0)s.P[s.dv]=[x,y];};s.onUp=()=>{s.dv=-1;};s.onDbl=()=>{if(s.P.length>2)s.done=true;};},
 draw(ctx,s,t){ctx.drawImage(s.img,0,0,W,H);const P=s.done?s.P:s.P.concat(s.hover?[[s.mx,s.my]]:[]),km=.5;if(P.length>1){poly(ctx,P,s.done?'rgba(79,70,229,.18)':'rgba(79,70,229,.08)','#4f46e5',2.5,!s.done);
   let L=0;for(let i=1;i<P.length;i++)L+=Math.hypot(P[i][0]-P[i-1][0],P[i][1]-P[i-1][1]);if(s.done)L+=Math.hypot(P[0][0]-P[P.length-1][0],P[0][1]-P[P.length-1][1]);let A=0;for(let i=0;i<P.length;i++){const a=P[i],b=P[(i+1)%P.length];A+=a[0]*b[1]-b[0]*a[1];}A=Math.abs(A)/2;
   const c=P.reduce((a,p)=>[a[0]+p[0]/P.length,a[1]+p[1]/P.length],[0,0]);ctx.fillStyle='rgba(28,25,23,.85)';rr(ctx,c[0]-74,c[1]-24,148,44,8);ctx.fill();text(ctx,(L*km).toFixed(1)+' km perimeter',c[0],c[1]-6,'#fff',12,'center',FONT,600);if(P.length>2)text(ctx,(A*km*km).toFixed(0)+' km² area',c[0],c[1]+12,'#c7d2fe',12,'center',FONT,600);}
  s.P.forEach(p=>circle(ctx,p[0],p[1],6,'#fff','#4f46e5',2.5));line(ctx,20,H-24,120,H-24,C.ink,3);text(ctx,'50 km',70,H-30,C.ink,11.5,'center',FONT,600);cap(ctx,'new Draw({ source, type:"Polygon" }); getArea(geom), getLength(geom)');},
 code:`import Draw from 'ol/interaction/Draw';import Modify from 'ol/interaction/Modify';import {getArea,getLength} from 'ol/sphere';
const draw=new Draw({source,type:'Polygon'});map.addInteraction(draw);map.addInteraction(new Modify({source}));
draw.on('drawstart',e=>e.feature.getGeometry().on('change',g=>{
  label.textContent=(getArea(g.target)/1e6).toFixed(0)+' km²';}));`});

lib('globegl','Globe.gl','gis','A data-driven 3D globe on Three.js: points, arcs, rings, polygons, hex bins, paths and labels.',{ik:'Globe.gl'});
ex({t:'Animated flight arcs & pulsing rings',d:'Great-circle arcs with travelling dashes and expanding rings at each city on a soft light globe.',hint:'Drag to spin the globe.',orbit:{ry:0,rx:.4,auto:.3},
 draw(ctx,s,t){bg(ctx,'#fcfcfe');const sc=150,R=p=>rot(p,s.ry,s.rx),vis=r=>r[2]>0||(r[0]*r[0]+r[1]*r[1])>1;lightGlobe(ctx,s.ry,s.rx,sc,{hue:200});
  const ARC=[[0,1],[1,2],[2,3],[3,4],[4,6],[0,5],[5,1],[6,0],[8,4],[10,9]];ARC.forEach((ar,k)=>{const a=ll(CITY2[ar[0]][1]*D2R,CITY2[ar[0]][2]*D2R),b=ll(CITY2[ar[1]][1]*D2R,CITY2[ar[1]][2]*D2R),om=Math.acos(clamp(dot(a,b),-1,1)),sn=Math.sin(om)||1,pt=f=>mul(add(mul(a,Math.sin((1-f)*om)/sn),mul(b,Math.sin(f*om)/sn)),1+.28*Math.sin(Math.PI*f)*Math.min(1,om/2)),u=(t*.5+k*.13)%1.4;
   for(let i=0;i<40;i++){const f0=i/40,r0=R(pt(f0)),r1=R(pt((i+1)/40));if(!vis(r0)||!vis(r1))continue;const A=pr(r0,sc,60),B=pr(r1,sc,60),d=u-f0,al=d>0&&d<.3?1-d/.3:0;line(ctx,A[0],A[1],B[0],B[1],al?'rgba(234,88,12,'+(.3+al*.7)+')':'rgba(234,88,12,.2)',al?3:1.3);}});
  CITY2.forEach((c,i)=>{const cv=ll(c[1]*D2R,c[2]*D2R),r=R(cv);if(r[2]<=.02)return;const p=pr(r,sc,60);circle(ctx,p[0],p[1],3.5,'#ea580c');const ph=((t*.6+i*.3)%1),phi=ph*.3,hp=norm(cross(cv,[0,-1,0])),vv=cross(cv,hp);ctx.strokeStyle='rgba(234,88,12,'+(1-ph)+')';ctx.lineWidth=1.6;ctx.beginPath();
   for(let k=0;k<=28;k++){const a=k/28*TAU,q=add(mul(cv,Math.cos(phi)),mul(add(mul(hp,Math.cos(a)),mul(vv,Math.sin(a))),Math.sin(phi))),pq=pr(R(q),sc,60);k?ctx.lineTo(pq[0],pq[1]):ctx.moveTo(pq[0],pq[1]);}ctx.stroke();});cap(ctx,'Globe().arcsData(flights).arcDashAnimateTime(2000).ringsData(cities)');},
 code:`Globe()(document.getElementById('globe')).globeImageUrl('img/earth-day.jpg').backgroundColor('#fcfcfe')
  .arcsData(flights).arcColor(()=>'#ea580c').arcDashLength(.3).arcDashGap(1).arcDashAnimateTime(2000)
  .ringsData(cities).ringColor(()=>t=>'rgba(234,88,12,'+(1-t)+')').ringMaxRadius(4).ringPropagationSpeed(2);`});
ex({t:'Hex-bin population columns',d:'Population points aggregated into hexagonal bins whose columns rise from the surface, height and colour scaled by the sum.',hint:'Drag to spin.',orbit:{ry:-.8,rx:.45,auto:.2},
 init(s){const r=rng(5);s.B=[];CITY2.forEach(c=>{for(let i=0;i<5;i++){const lat=c[1]+gauss(r)*4,lon=c[2]+gauss(r)*5;s.B.push({p:ll(lat*D2R,lon*D2R),v:.15+r()*.6+(i===0?.4:0)});}});for(let i=0;i<60;i++){const q=GL[Math.floor(r()*GL.length)];if(q.land)s.B.push({p:q.p,v:.05+r()*.15});}},
 draw(ctx,s,t){bg(ctx,'#fcfcfe');const sc=150;lightGlobe(ctx,s.ry,s.rx,sc,{hue:220});const g=easeOut(clamp(t/2,0,1));s.B.map(b=>{const r0=rot(b.p,s.ry,s.rx),r1=rot(mul(b.p,1+b.v*.45*g),s.ry,s.rx);return[r0,r1,b];}).filter(x=>x[0][2]>0).sort((a,b)=>a[0][2]-b[0][2]).forEach(([r0,r1,b])=>{const A=pr(r0,sc,60),B=pr(r1,sc,60),c=scale(['#fde68a','#f97316','#be123c'],b.v);ctx.lineCap='butt';line(ctx,A[0],A[1],B[0],B[1],c,7*(.6+r0[2]*.4));circle(ctx,B[0],B[1],3.5*(.6+r0[2]*.4),mixHex(hex2rgb2(c),'#ffffff',.3));});cap(ctx,'.hexBinPointsData(pop).hexBinPointWeight("pop").hexAltitude(d=>d.sumWeight*6e-5)');},
 code:`Globe()(el).hexBinPointsData(population).hexBinPointWeight('pop').hexBinResolution(4)
  .hexAltitude(d=>d.sumWeight*6e-5).hexTopColor(d=>colorScale(d.sumWeight)).hexSideColor(d=>colorScale(d.sumWeight));`});

lib('turf','Turf.js','gis','Modular geospatial analysis in JavaScript: buffers, measurements, boolean tests, grids, Voronoi and interpolation.',{ik:'Turf.js'});
ex({t:'Buffer, point-in-polygon & nearest line',d:'A moving buffer counts the points inside it, points inside the polygon are ringed, and the distance to the nearest road is measured.',hint:'Hover to move the buffer · click to change its radius.',int:1,
 init(s){const r=rng(19);s.p=[];for(let i=0;i<70;i++)s.p.push([30+r()*(W-60),50+r()*(H-90)]);s.poly=[[90,110],[250,80],[320,190],[190,260],[80,200]];s.line=[[330,400],[430,300],[540,340],[680,250]];s.R=90;s.onDown=()=>{s.R=s.R>=140?50:s.R+45;};},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const cx=s.hover?s.mx:W/2+Math.cos(t*.6)*200,cy=s.hover?s.my:H/2+Math.sin(t*.9)*110;poly(ctx,s.poly,'rgba(124,58,237,.1)','#7c3aed',2);ctx.strokeStyle='#f59e0b';ctx.lineWidth=5;ctx.lineCap='round';ctx.beginPath();s.line.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.stroke();
  let best=1e9,bp=null;for(let i=1;i<s.line.length;i++){const a=s.line[i-1],b=s.line[i],dx=b[0]-a[0],dy=b[1]-a[1],u=clamp(((cx-a[0])*dx+(cy-a[1])*dy)/(dx*dx+dy*dy),0,1),px=a[0]+dx*u,py=a[1]+dy*u,d=Math.hypot(cx-px,cy-py);if(d<best){best=d;bp=[px,py];}}
  ctx.setLineDash([8,6]);circle(ctx,cx,cy,s.R,'rgba(13,148,136,.1)','#0d9488',2);ctx.setLineDash([]);line(ctx,cx,cy,bp[0],bp[1],'#db2777',2,[3,3]);let nb=0,np=0;
  for(const p of s.p){const ib=Math.hypot(p[0]-cx,p[1]-cy)<s.R,ip=pip(p[0],p[1],s.poly);if(ib)nb++;if(ip)np++;circle(ctx,p[0],p[1],ib?5.5:3.5,ib?'#0d9488':'#a8a29e');if(ip)circle(ctx,p[0],p[1],9,null,'#7c3aed',1.8);}
  circle(ctx,cx,cy,6,'#1c1917');badge(ctx,nb+' in buffer',14,14,'#ccfbf1','#0f766e');badge(ctx,np+' in polygon',120,14,'#ede9fe','#6d28d9');badge(ctx,'road '+(best*.5).toFixed(1)+' km',236,14,'#fce7f3','#be185d');},
 code:`const buf=turf.buffer(turf.point(cursor),45,{units:'kilometers'});
const inside=turf.pointsWithinPolygon(points,buf).features.length;
const near=turf.nearestPointOnLine(road,turf.point(cursor),{units:'kilometers'});   // near.properties.dist`});
ex({t:'Voronoi cells & nearest facility',d:'Turf.voronoi partitions the map into service areas around facilities; the pointer’s cell lights up and links to its nearest facility.',hint:'Move the pointer · click to add a facility.',int:1,
 init(s){const r=rng(9);s.F=Array.from({length:14},()=>[40+r()*(W-80),40+r()*(H-80)]);s.onDown=(x,y)=>{s.F.push([x,y]);s.dirty=true;};s.dirty=true;s.img=document.createElement('canvas');s.img.width=W/4;s.img.height=H/4;},
 draw(ctx,s,t){if(s.dirty){s.dirty=false;const x=s.img.getContext('2d'),im=x.createImageData(W/4,H/4);for(let j=0;j<H/4;j++)for(let i=0;i<W/4;i++){let b=0,bd=1e9,b2=1e9;s.F.forEach((f,k)=>{const d=Math.hypot(f[0]-i*4,f[1]-j*4);if(d<bd){b2=bd;bd=d;b=k;}else if(d<b2)b2=d;});const c=hex2rgb(PAL[b%PAL.length]),e=b2-bd<5,o=(j*W/4+i)*4;im.data[o]=e?255:lerp(c[0],255,.8);im.data[o+1]=e?255:lerp(c[1],255,.8);im.data[o+2]=e?255:lerp(c[2],255,.8);im.data[o+3]=255;}x.putImageData(im,0,0);}
  ctx.imageSmoothingEnabled=false;ctx.drawImage(s.img,0,0,W,H);const px=s.hover?s.mx:W/2+Math.cos(t*.5)*220,py=s.hover?s.my:H/2+Math.sin(t*.7)*130;let b=0,bd=1e9;s.F.forEach((f,k)=>{const d=Math.hypot(f[0]-px,f[1]-py);if(d<bd){bd=d;b=k;}});
  line(ctx,px,py,s.F[b][0],s.F[b][1],'#1c1917',2,[5,4]);s.F.forEach((f,k)=>{circle(ctx,f[0],f[1],k===b?10:7,PAL[k%PAL.length],'#fff',2.5);});circle(ctx,px,py,5,'#1c1917');badge(ctx,'nearest facility #'+(b+1)+' · '+(bd*.5).toFixed(1)+' km',14,14,'#fff',C.ink);cap(ctx,'turf.voronoi(facilities,{bbox}); turf.nearestPoint(pt, facilities)');},
 code:`const cells=turf.voronoi(facilities,{bbox:[-1,51,1,52]});
const nearest=turf.nearestPoint(turf.point(cursor),facilities);
const cell=cells.features.find(c=>turf.booleanPointInPolygon(cursor,c));`});
ex({t:'Along a route: distance, bearing, markers',d:'turf.along places a vehicle at a distance along a route, turf.bearing orients it, and kilometre markers are placed every 50 km.',controls:[{type:'range',k:'sp',l:'Speed',min:10,max:150,v:60}],
 init(s){s.R=[[60,360],[170,250],[300,290],[390,150],[520,190],[600,80],[680,120]];s.d=0;},
 draw(ctx,s,t,dt){gridBg(ctx,40,'#fbfdff','#eef2f7');let L=0;for(let i=1;i<s.R.length;i++)L+=Math.hypot(s.R[i][0]-s.R[i-1][0],s.R[i][1]-s.R[i-1][1]);const km=.5;s.d=(s.d+dt*s.p.sp/km/2)%L;ctx.lineCap='round';ctx.lineJoin='round';ctx.strokeStyle='#cbd5e1';ctx.lineWidth=10;poly(ctx,s.R,null,'#cbd5e1',10,true);poly(ctx,s.R,null,'#fff',4,true);
  for(let k=0;k*50/km<=L;k++){const p=polyPt(s.R,k*50/km/L);circle(ctx,p[0],p[1],5,'#fff','#0284c7',2);text(ctx,k*50+' km',p[0]+8,p[1]-8,'#0369a1',11,'left',FONT,600);}
  const p=polyPt(s.R,s.d/L),q=polyPt(s.R,Math.min(1,(s.d+2)/L)),br=Math.atan2(q[0]-p[0],-(q[1]-p[1]))/D2R;ctx.save();ctx.translate(p[0],p[1]);ctx.rotate(br*D2R);poly(ctx,[[0,-14],[10,10],[0,5],[-10,10]],'#e11d48','#fff',2);ctx.restore();
  ctx.fillStyle='rgba(255,255,255,.95)';rr(ctx,14,14,210,66,10);ctx.fill();text(ctx,'travelled '+(s.d*km).toFixed(0)+' / '+(L*km).toFixed(0)+' km',24,36,C.ink,13,'left',FONT,600);text(ctx,'bearing '+((br+360)%360).toFixed(0)+'°',24,56,C.mut,12.5,'left',MONO);text(ctx,'ETA '+((L-s.d)*km/s.p.sp*60).toFixed(0)+' min',24,72,C.mut,12.5,'left',MONO);},
 code:`const total=turf.length(route,{units:'kilometers'});
const here=turf.along(route,travelled,{units:'kilometers'});
const ahead=turf.along(route,travelled+.1,{units:'kilometers'});
const heading=turf.bearing(here,ahead);   // −180..180°`});

lib('geotiff','GeoTIFF.js → NDVI','gis','Reads GeoTIFF and Cloud-Optimised GeoTIFF rasters in the browser: bands, windows, metadata and pixel maths.',{ik:'GeoTIFF.js → NDVI'});
function ndviScene(){const w=180,h=110,mk=()=>{const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');return{c,x,id:x.createImageData(w,h)};},V=[mk(),mk(),mk()],B=[];
 const ndviCol=n=>{const st=[[-.2,[30,64,175]],[0,[161,98,7]],[.2,[202,138,4]],[.5,[101,163,13]],[.85,[22,101,52]]];n=clamp(n,-.2,.85);for(let i=1;i<st.length;i++){if(n<=st[i][0]){const f=(n-st[i-1][0])/(st[i][0]-st[i-1][0]),a=st[i-1][1],b=st[i][1];return[lerp(a[0],b[0],f),lerp(a[1],b[1],f),lerp(a[2],b[2],f)];}}return st[4][1];};
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const e=fbm(x*.03+1,y*.03+2),m=fbm(x*.04+10,y*.04+5),tx=(noise(x*.6,y*.6)-.5)*.06,patch=((Math.floor(x/18)*7+Math.floor(y/16)*13)%5)/5;let R,G,Bb,N;
  if(e<.4){R=.03;G=.06;Bb=.1+e*.05;N=.02;}else if(m>.5){const fld=m>.58?patch:.4;R=.05+tx;G=.09+tx;Bb=.04;N=.3+.32*fld+tx;if(m>.58)R+=.05*(1-fld);}else{R=.28+tx;G=.25+tx;Bb=.18;N=.33+tx;}
  const nd=(N-R)/(N+R+1e-6),i=(y*w+x)*4,g=v=>Math.round(255*Math.pow(clamp(v*3.2,0,1),.8)),c3=ndviCol(nd),cols=[[g(R),g(G),g(Bb)],[g(N*.9),g(R),g(G)],c3];B.push([R,G,Bb,N,nd]);for(let k=0;k<3;k++){V[k].id.data[i]=cols[k][0];V[k].id.data[i+1]=cols[k][1];V[k].id.data[i+2]=cols[k][2];V[k].id.data[i+3]=255;}}
 V.forEach(v=>v.x.putImageData(v.id,0,0));return{V:V.map(v=>v.c),B,w,h};}
ex({t:'True colour, false colour & NDVI',d:'A synthetic four-band scene shown as true colour, NIR false colour (vegetation turns red) and the computed NDVI with its legend.',hint:'Click to switch view.',int:1,
 init(s){Object.assign(s,ndviScene());s.mode=0;s.timer=0;s.onDown=()=>{s.mode=(s.mode+1)%3;s.timer=0;};},
 draw(ctx,s,t,dt){s.timer+=dt;if(s.timer>3.2){s.timer=0;s.mode=(s.mode+1)%3;}ctx.imageSmoothingEnabled=false;ctx.drawImage(s.V[s.mode],0,0,W,H);const nm=['True colour (R, G, B)','False colour (NIR, R, G): vegetation is red','NDVI = (NIR − Red) / (NIR + Red)'];ctx.fillStyle='rgba(255,255,255,.9)';rr(ctx,12,12,ctx.measureText?370:370,32,8);ctx.fill();text(ctx,nm[s.mode],24,33,C.ink,15,'left',FONT,600);
  if(s.mode==2){ctx.fillStyle='rgba(255,255,255,.9)';rr(ctx,W-262,H-58,250,46,8);ctx.fill();const gr=ctx.createLinearGradient(W-250,0,W-24,0);gr.addColorStop(0,'#1e40af');gr.addColorStop(.19,'#a16207');gr.addColorStop(.4,'#ca8a04');gr.addColorStop(.66,'#65a30d');gr.addColorStop(1,'#166534');ctx.fillStyle=gr;ctx.fillRect(W-250,H-38,226,12);text(ctx,'−0.2',W-250,H-44,C.ink2,11);text(ctx,'0.85',W-24,H-44,C.ink2,11,'right');}},
 code:`const tiff=await GeoTIFF.fromArrayBuffer(await file.arrayBuffer());   // local file input
const img=await tiff.getImage();
const [red,nir]=await img.readRasters({samples:[2,3]});
const ndvi=Float32Array.from(red,(r,i)=>(nir[i]-r)/(nir[i]+r));`});
ex({t:'Pixel inspector & NDVI histogram',d:'Hover the scene to read every band at that pixel (as readRasters with a 1×1 window would) while a histogram shows the whole scene’s NDVI distribution.',hint:'Hover the image.',int:1,
 init(s){Object.assign(s,ndviScene());s.hist=new Array(40).fill(0);s.B.forEach(b=>{s.hist[clamp(Math.floor((b[4]+.2)/1.1*40),0,39)]++;});},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const iw=440,ih=iw*s.h/s.w;ctx.imageSmoothingEnabled=false;ctx.drawImage(s.V[2],14,14,iw,ih);let px=null;if(s.hover&&s.mx>14&&s.mx<14+iw&&s.my>14&&s.my<14+ih){const x=Math.floor((s.mx-14)/iw*s.w),y=Math.floor((s.my-14)/ih*s.h);px=[x,y,s.B[y*s.w+x]];ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.strokeRect(14+x*iw/s.w-6,14+y*ih/s.h-6,12,12);}
  const hx=476,hy=250,hw=230,hh=200,mx=Math.max(...s.hist);text(ctx,'NDVI histogram',hx,40,C.ink,13,'left',FONT,700);s.hist.forEach((v,i)=>{const nd=-.2+i/40*1.1,h=v/mx*hh;ctx.fillStyle=nd<0?'#1e40af':nd<.2?'#ca8a04':'#65a30d';ctx.fillRect(hx+i*hw/40,hy-h,hw/40-1,h);});line(ctx,hx,hy,hx+hw,hy,C.line,1);text(ctx,'−0.2',hx,hy+16,C.mut,11);text(ctx,'0.9',hx+hw,hy+16,C.mut,11,'right');
  if(px){const v=px[2][4],x=hx+(v+.2)/1.1*hw;line(ctx,x,hy-hh,x,hy,'#e11d48',2);ctx.fillStyle='#fff';ctx.strokeStyle=C.grid;rr(ctx,hx,290,hw,130,10);ctx.fill();ctx.stroke();[['pixel',px[0]+', '+px[1]],['red',px[2][0].toFixed(3)],['green',px[2][1].toFixed(3)],['blue',px[2][2].toFixed(3)],['NIR',px[2][3].toFixed(3)],['NDVI',v.toFixed(3)]].forEach((r,i)=>{text(ctx,r[0],hx+14,312+i*19,C.mut,12);text(ctx,r[1],hx+hw-14,312+i*19,i===5?'#e11d48':C.ink,12.5,'right',MONO,i===5?700:400);});}else text(ctx,'Hover the image to inspect bands',hx,310,C.mut,12.5);},
 code:`canvas.onmousemove=async e=>{const [x,y]=toPixel(e);
  const px=await img.readRasters({window:[x,y,x+1,y+1]});      // one pixel, every band
  const ndvi=(px[3][0]-px[2][0])/(px[3][0]+px[2][0]);show(px,ndvi);};`});

lib('h3','H3-js','gis','Uber’s hexagonal hierarchical spatial index: bin points into hexagons, find neighbours and roll up resolutions.',{isNew:true,info:{lv:'Intermediate',r:'None (indexing; pair with a map)',s:'≈ 0.6 MB',u:'h3geo.org',t:['Aggregate points into equal-area hexagons','Neighbour (k-ring) and distance queries','Multi-resolution roll-ups and compaction','Hexagon heatmaps with deck.gl or MapLibre'],c:['latLngToCell, cellToBoundary, gridDisk (k-ring), gridDistance, cellToParent/children','16 resolutions from continents to square metres','Pure JS (compiled with Emscripten), works in browsers and Node'],l:['Hexagons cannot perfectly tile the globe (12 pentagons exist)','Cells do not nest exactly between resolutions'],o:'Fully offline (single UMD file).',k:`import {latLngToCell,cellToBoundary,gridDisk} from 'h3-js';
const cell=latLngToCell(51.5,-0.12,8);            // '88195da49bfffff'
const ring=gridDisk(cell,2);                       // cell + 2 rings of neighbours
const polygon=cellToBoundary(cell,true);           // [[lng,lat], …] for GeoJSON`,a:'deck.gl H3HexagonLayer, Turf hexGrid, S2'}});
function hexPath(ctx,cx,cy,r){ctx.beginPath();for(let k=0;k<6;k++){const a=(60*k-30)*D2R;ctx.lineTo(cx+r*Math.cos(a),cy+r*Math.sin(a));}ctx.closePath();}
function hexAt(x,y,r){const q=(Math.sqrt(3)/3*x-y/3)/r,rr2=(2/3*y)/r;let X=q,Z=rr2,Y=-X-Z,rx=Math.round(X),ry=Math.round(Y),rz=Math.round(Z);const dx=Math.abs(rx-X),dy=Math.abs(ry-Y),dz=Math.abs(rz-Z);if(dx>dy&&dx>dz)rx=-ry-rz;else if(dy>dz)ry=-rx-rz;else rz=-rx-ry;return[rx,rz];}
function hexCenter(q,r,R){return[R*Math.sqrt(3)*(q+r/2),R*1.5*r];}
ex({t:'Hexagon aggregation with resolution control',d:'Five thousand points binned into hexagons; change resolution and the bins re-aggregate. Hover a cell for its index and count.',hint:'Drag the resolution slider · hover a hexagon.',int:1,controls:[{type:'range',k:'res',l:'Resolution',min:5,max:9,v:7}],
 init(s){const r=rng(4);s.P=[];[[220,170,70],[470,250,90],[360,320,40],[600,120,45]].forEach(([x,y,sd])=>{for(let i=0;i<1200;i++)s.P.push([x+gauss(r)*sd,y+gauss(r)*sd*.7]);});for(let i=0;i<200;i++)s.P.push([r()*W,r()*H]);s.base=terrainImg(240,147,.012,.012,'pastel');},
 draw(ctx,s,t){ctx.drawImage(s.base,0,0,W,H);const R=[0,0,0,0,0,40,26,17,11,7.5][s.p.res],M={};s.P.forEach(p=>{const k=hexAt(p[0],p[1],R).join(',');M[k]=(M[k]||0)+1;});const mx=Math.max(...Object.values(M));let hv=null;
  Object.keys(M).forEach(k=>{const[q,r]=k.split(',').map(Number),c=hexCenter(q,r,R),v=M[k];hexPath(ctx,c[0],c[1],R*.96);ctx.fillStyle=scale(['#fef3c7','#fb923c','#e11d48','#4c1d95'],Math.pow(v/mx,.6));ctx.globalAlpha=.85;ctx.fill();ctx.globalAlpha=1;if(s.hover&&Math.hypot(s.mx-c[0],s.my-c[1])<R*.86)hv=[c,v,q,r];});
  if(hv){hexPath(ctx,hv[0][0],hv[0][1],R);ctx.strokeStyle=C.ink;ctx.lineWidth=2.5;ctx.stroke();tooltip(ctx,hv[0][0],hv[0][1]-R,['8'+s.p.res+'1'+(Math.abs(hv[2]*977+hv[3]*131)%0xfffff).toString(16).padStart(5,'0')+'fffff',hv[1]+' points']);}
  badge(ctx,'res '+s.p.res+' · '+Object.keys(M).length+' cells',14,14,'#fff',C.ink);},
 code:`const counts=new Map();
points.forEach(p=>{const h=h3.latLngToCell(p.lat,p.lng,res);counts.set(h,(counts.get(h)||0)+1);});
new deck.H3HexagonLayer({data:[...counts],getHexagon:d=>d[0],getFillColor:d=>color(d[1]),extruded:false});`});
ex({t:'k-ring neighbours (gridDisk)',d:'Hover a hexagon to see gridDisk rings 1 to 3 around it, the basis of H3 neighbourhood queries and smoothing.',hint:'Hover a hexagon · change k.',int:1,controls:[{type:'range',k:'k',l:'k',min:1,max:5,v:3}],
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const R=22,h=s.hover?hexAt(s.mx,s.my,R):hexAt(W/2+Math.cos(t*.4)*150,H/2+Math.sin(t*.6)*80,R),K=s.p.k;
  for(let r=-2;r<=22;r++)for(let q=-Math.floor(r/2)-1;q<20-Math.floor(r/2);q++){const c=hexCenter(q,r,R);if(c[0]<-R||c[0]>W+R||c[1]<-R||c[1]>H+R)continue;const dq=q-h[0],dr=r-h[1],d=(Math.abs(dq)+Math.abs(dr)+Math.abs(dq+dr))/2;hexPath(ctx,c[0],c[1],R*.94);ctx.fillStyle=d===0?'#1c1917':d<=K?scale(['#4f46e5','#a5b4fc','#e0e7ff'],(d-1)/Math.max(1,K-1)):'#f5f3ef';ctx.fill();if(d<=K&&d>0)text(ctx,String(d),c[0],c[1]+4,d<K/2+1?'#fff':C.indigo,10.5,'center',FONT,700);}
  badge(ctx,'gridDisk(cell, '+K+') → '+(1+3*K*(K+1))+' cells',14,14,'#fff',C.ink);},
 code:`const disk=h3.gridDisk(origin,3);                        // 37 cells
const rings=h3.gridDiskDistances(origin,3);             // [[origin],[6 cells],[12],[18]]
const d=h3.gridDistance(origin,other);`});
