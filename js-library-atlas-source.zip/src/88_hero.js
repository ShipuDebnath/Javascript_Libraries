/* ===================== HERO: live WebGL bio-observatory (DNA, RNA, cells, capsid, cursor field) ===================== */
function heroScene(){
 const HL=10.5,RAD=.62,TURN=3.4,NB=Math.round(HL/TURN*10.5);
 const hx=u=>{const y=(u-.5)*HL,a=u*HL/TURN*TAU;return[Math.cos(a)*RAD,y,Math.sin(a)*RAD];};
 const hx2=u=>{const y=(u-.5)*HL,a=u*HL/TURN*TAU+2.25;return[Math.cos(a)*RAD,y,Math.sin(a)*RAD];};
 const bb1=GEO.tube(hx,false,.075,900,16),bb2=GEO.tube(hx2,false,.075,900,16);
 const BASE=[[],[],[],[]],r=rng(11),NUC=[];
 for(let i=1;i<NB;i++){const u=i/NB,a=hx(u),b=hx2(u),m=mul(add(a,b),.5),k=Math.floor(r()*4),pair=[1,0,3,2][k];
  BASE[k].push(GEO.tube(f=>add(mul(a,1-f),mul(m,f)),false,.042,6,10));
  BASE[pair].push(GEO.tube(f=>add(mul(m,1-f),mul(b,f)),false,.042,6,10));NUC.push([a,k],[b,pair]);}
 for(let k=0;k<4;k++)BASE[k]=BASE[k].length?GEO.merge(...BASE[k]):null;
 const rnaPath=(ph,amp)=>f=>{const x=(f-.5)*7,y=Math.sin(f*TAU*1.6+ph)*amp+Math.sin(f*TAU*4.3+ph*2)*amp*.25,z=Math.cos(f*TAU*1.1+ph)*amp*.8;
  // hairpin loop near the end
  if(f>.78){const g=(f-.78)/.22,ang=g*TAU*.92;return[2.46+Math.sin(ang)*.42,y+(1-Math.cos(ang))*.42,z];}return[x,y,z];};
 const RNA=[GEO.tube(rnaPath(0,.55),false,.055,420,12),GEO.tube(rnaPath(2.1,.42),false,.05,420,12),GEO.tube(rnaPath(4,.5),false,.045,420,12)];
 const ico=GEO.icoEdges(1,2),icoP=new Float32Array(ico.E.length*6),icoC=new Float32Array(ico.E.length*8);ico.E.forEach(([a,b],i)=>{icoP.set(ico.V[a],i*6);icoP.set(ico.V[b],i*6+3);icoC.set([.49,.23,.93,.55,.01,.52,.78,.55],i*8);});
 const icoVP=new Float32Array(ico.V.length*3),icoVC=new Float32Array(ico.V.length*4);ico.V.forEach((v,i)=>{icoVP.set(v,i*3);icoVC.set([.88,.11,.43,.9],i*4);});
 const ring=GEO.torus(1,.035,220,12),lens=GEO.torus(1,.018,180,8);
 const N=3200,PP=new Float32Array(N*3),PV=[],PC=new Float32Array(N*4),PS=new Float32Array(N),HOME=[];
 for(let i=0;i<N;i++){const p=[(r()-.5)*15,(r()-.5)*8.5,(r()-.5)*7-1];HOME.push(p.slice());PV.push([0,0,0]);PP.set(p,i*3);PS[i]=.5+r()*1.4;const c=[[.49,.23,.93],[.01,.52,.78],[.05,.58,.53],[.88,.11,.43],[.85,.47,.04]][Math.floor(r()*r()*5)];PC.set([c[0],c[1],c[2],.55],i*4);}
 const CELLS=[[3.8,1.9,-1.2,.95],[5.6,-1.6,-.4,.7],[1.1,-2.6,.4,.55],[6.8,1.2,-2.4,1.15],[-.4,2.6,-2.2,.5]].map(c=>({p:c.slice(0,3),r:c[3],ph:r()*TAU,org:Array.from({length:7},()=>[(r()-.5)*1.1,(r()-.5)*1.1,(r()-.5)*1.1,.06+r()*.07])}));
 const SPH1=GEO.sphere(1,72,48),SPH2=GEO.sphere(1,32,20);
 const NUCP=new Float32Array(NUC.length*3),NUCC=new Float32Array(NUC.length*4),BC=[[.88,.11,.43],[.01,.52,.78],[.85,.47,.04],[.05,.58,.53]];NUC.forEach(([p,k],i)=>{NUCP.set(p,i*3);NUCC.set([...BC[k],1],i*4);});
 return{bb1,bb2,BASE,RNA,icoP,icoC,icoVP,icoVC,ring,lens,N,PP,PV,PC,PS,HOME,CELLS,SPH1,SPH2,NUCP,NUCC,BC};
}
function heroAnim(){const holder=document.getElementById('herocv');if(!holder)return;const box=holder.parentNode;
 let G=window._HG;if(!G){try{G=window._HG=makeGLX(box.clientWidth||900,box.clientHeight||600);}catch(e){G=null;}}
 if(!G||!G.ok){return heroAnim2D();}
 const cv=G.cv;cv.id='herocv';cv.className='hero-gl';holder.replaceWith(cv);
 const S=window._HS||(window._HS=heroScene());let mx=.5,my=.5,tmx=.5,tmy=.5,inside=false,px=-9e9,py=-9e9;
 box.addEventListener('pointermove',e=>{const b=box.getBoundingClientRect();px=e.clientX-b.left;py=e.clientY-b.top;tmx=px/b.width;tmy=py/b.height;inside=true;});
 box.addEventListener('pointerleave',()=>{inside=false;tmx=.5;tmy=.5;px=py=-9e9;});
 const s={vis:true,X:{t:'hero'},stage:cv,t:0,ctx:null};
 s.X.tick=(Z,t,dt)=>{if(document.body.classList.contains('perf')&&(s._k=(s._k||0)+1)%2)return;dt=Math.min(dt||.016,.05);const w=box.clientWidth,h=box.clientHeight;if(w<10)return;G.size(w,h);
  mx+= (tmx-mx)*.05;my+=(tmy-my)*.05;const asp=w/h,wide=asp>1.25,cx=wide?3.21*asp*.46:0;
  const eye=[(mx-.5)*2.4,(.5-my)*1.4+.3,10.5],tg=[0,0,0];G.begin({eye,target:tg,fov:34,fogD:.035,fog:hexv('#f4eeff'),exp:1.1});
  // DNA helix
  const dm=M4.chain(M4.T(cx+.4,0,-.6),M4.RZ(-.48),M4.RX(.12),M4.RY(t*.32));
  G.draw(S.bb1,{m:dm,color:'#7c3aed',rough:.16,clear:1,iri:.55,rim:'#c4b5fd',rimK:.55});
  G.draw(S.bb2,{m:dm,color:'#0284c7',rough:.16,clear:1,iri:.45,rim:'#bae6fd',rimK:.55});
  S.BASE.forEach((g,k)=>{if(g)G.draw(g,{m:dm,color:S.BC[k],rough:.3,clear:.8,sheen:.4});});
  G.points(S.NUCP,S.NUCC,null,{m:dm,size:2.4,soft:.4});
  // RNA strands
  const rm=[M4.chain(M4.T(cx-1.2,2.9,-2.8),M4.RZ(.12),M4.RY(Math.sin(t*.2)*.3)),M4.chain(M4.T(cx+.6,-3,-1.8),M4.RZ(-.08),M4.RY(Math.cos(t*.17)*.35+.4)),M4.chain(M4.T(cx+3.6,.2,-4.2),M4.RZ(1.2),M4.RX(t*.15))];
  const rc=['#e11d48','#0d9488','#d97706'];S.RNA.forEach((g,i)=>G.draw(g,{m:rm[i],color:rc[i],rough:.22,clear:1,sheen:.3,rim:'#ffffff',rimK:.35}));
  // cells: glass membranes with nucleus and organelles
  S.CELLS.forEach((c,i)=>{const p=add(c.p,[Math.sin(t*.3+c.ph)*.25,Math.cos(t*.37+c.ph)*.22,0]);p[0]+=cx-3.5;const pul=1+Math.sin(t*1.2+c.ph)*.025;
   const cm=M4.chain(M4.T(...p),M4.RY(t*.2+c.ph),M4.S(c.r*pul,c.r*pul*.94,c.r*pul));
   G.draw(S.SPH2,{m:M4.chain(M4.T(...p),M4.T(.12*c.r,.05,0),M4.S(c.r*.36)),color:'#7c3aed',rough:.35,sheen:.6,clear:.5});
   c.org.forEach((o,j)=>G.draw(S.SPH2,{m:M4.chain(cm,M4.T(o[0]*.7,o[1]*.7,o[2]*.7),M4.S(o[3]*1.4)),color:j%3?'#0d9488':'#e11d48',rough:.4,sheen:.5}));
   G.draw(S.SPH1,{m:cm,color:'#f5f0ff',glass:.86,rough:.06,clear:1,iri:.9,rim:'#a78bfa',rimK:1.2,op:.32});});
  // capsid + lens rings
  const im=M4.chain(M4.T(cx-3.3,-1.5,-1),M4.RY(t*.4),M4.RX(t*.23),M4.S(.95));G.lines(S.icoP,S.icoC,{m:im});G.points(S.icoVP,S.icoVC,null,{m:im,size:1.6,soft:.35});
  for(let k=0;k<3;k++)G.draw(k?S.lens:S.ring,{m:M4.chain(M4.T(cx+2.2,2.5,-2.4),M4.RX(1.2+k*.35+Math.sin(t*.4+k)*.2),M4.RY(t*.25*(k+1)),M4.S(.62+k*.2)),color:['#7c3aed','#0284c7','#e11d48'][k],metal:.6,rough:.15,clear:1,iri:.8});
  // cursor-reactive particle field
  let cur=null;if(inside){const ry=G.ray(px,py);const tt=(-1-ry.o[2])/ry.d[2];cur=add(ry.o,mul(ry.d,tt));}
  const P=S.PP,V=S.PV,Hm=S.HOME,C=S.PC;for(let i=0;i<S.N;i++){const k=i*3,v=V[i],hm=Hm[i];let x=P[k],y=P[k+1],z=P[k+2];
   v[0]+=((hm[0]+Math.sin(t*.3+i)*.15)-x)*.6*dt;v[1]+=((hm[1]+Math.cos(t*.27+i*.7)*.15)-y)*.6*dt;v[2]+=(hm[2]-z)*.6*dt;let glow=0;
   if(cur){const dx=x-cur[0],dy=y-cur[1],dz=z-cur[2],d2=dx*dx+dy*dy+dz*dz;if(d2<4.5){const d=Math.sqrt(d2)+.001,f=(1-d/2.12)*7*dt;v[0]+=dx/d*f-dy/d*f*.6;v[1]+=dy/d*f+dx/d*f*.6;v[2]+=dz/d*f;glow=1-d/2.12;}}
   v[0]*=.94;v[1]*=.94;v[2]*=.94;P[k]=x+v[0];P[k+1]=y+v[1];P[k+2]=z+v[2];C[i*4+3]=.5+glow*.5;}
  G.points(P,C,S.PS,{size:1.25,soft:.5});
  if(cur){const RP=new Float32Array(3),RC=new Float32Array([.49,.23,.93,.35]);RP.set(cur);G.points(RP,RC,new Float32Array([30]),{size:1,soft:.5});}
 };
 s.X.draw=()=>{};s.ctx=null;cv._s=s;ACTIVE.add(s);if(typeof IO!=='undefined'&&IO)IO.observe(cv);else s.vis=true;}
