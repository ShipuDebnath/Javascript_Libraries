/* ===================== Physics ===================== */
function circleWorld(B,dt,o){o=o||{};const st=o.steps||4,h=dt/st,g=o.g===undefined?900:o.g,e=o.e===undefined?.4:o.e;for(let k=0;k<st;k++){for(const b of B){if(b.fixed)continue;b.vy+=g*h;b.x+=b.vx*h;b.y+=b.vy*h;if(o.walls!==false){if(b.y>H-b.r-(o.floor||0)){b.y=H-b.r-(o.floor||0);b.vy*=-e;b.vx*=.985;}if(b.x<b.r){b.x=b.r;b.vx*=-.5;}if(b.x>W-b.r){b.x=W-b.r;b.vx*=-.5;}}}
 for(let i=0;i<B.length;i++)for(let j=i+1;j<B.length;j++){const a=B[i],c=B[j],dx=c.x-a.x,dy=c.y-a.y,d=Math.hypot(dx,dy),m=a.r+c.r;if(d<m&&d>.001){const nx=dx/d,ny=dy/d,o2=(m-d),ia=a.fixed?0:1,ic=c.fixed?0:1,s=ia+ic||1;a.x-=nx*o2*ia/s;a.y-=ny*o2*ia/s;c.x+=nx*o2*ic/s;c.y+=ny*o2*ic/s;const vr=(c.vx-a.vx)*nx+(c.vy-a.vy)*ny;if(vr<0){const im=-(1+e)*vr/s;if(ia){a.vx-=im*nx;a.vy-=im*ny;}if(ic){c.vx+=im*nx;c.vy+=im*ny;}}}}if(o.after)o.after(h);}}

lib('matter','Matter.js','phys','An approachable 2D rigid-body engine: bodies, constraints, composites, collisions and mouse dragging.',{ik:'Matter.js'});
ex({t:'Falling bodies with mouse constraint',d:'Sixty circle bodies with restitution and friction. Grab any body and throw it; click empty space to drop more.',hint:'Drag a body to throw it · click empty space to add more.',int:1,
 init(s){const r=rng(11),mk=(x,y,rd,i)=>({x,y,vx:(Math.random()-.5)*60,vy:0,r:rd,h:(i*37)%360});s.b=[];for(let i=0;i<55;i++)s.b.push(mk(r()*W,r()*200,10+r()*16,i));s.gr=null;
  s.onDown=(x,y)=>{s.gr=s.b.find(b=>Math.hypot(b.x-x,b.y-y)<b.r)||null;if(!s.gr){for(let i=0;i<3;i++)s.b.push(mk(x+i*6,y,10+Math.random()*15,s.b.length));while(s.b.length>160)s.b.shift();}};s.onUp=()=>{s.gr=null;};},
 draw(ctx,s,t,dt){paper(ctx,'#fbfaf8');if(s.gr&&s.down){s.gr.vx+=(s.mx-s.gr.x)*40*dt;s.gr.vy+=(s.my-s.gr.y)*40*dt;s.gr.vx*=.85;s.gr.vy*=.85;line(ctx,s.gr.x,s.gr.y,s.mx,s.my,C.indigo,2,[4,4]);}circleWorld(s.b,dt);
  for(const b of s.b){softShadow(ctx,b.x+3,b.y+b.r*.9,b.r,b.r*.3,.12);sphere(ctx,b.x,b.y,b.r,b.h,70,58);}cap(ctx,'Composite.add(world, MouseConstraint.create(engine,{mouse}))');},
 code:`const {Engine,Render,Runner,Bodies,Composite,Mouse,MouseConstraint}=Matter;
const engine=Engine.create(),render=Render.create({element:el,engine,options:{wireframes:false,background:'#fbfaf8'}});
Composite.add(engine.world,[...balls,Bodies.rectangle(360,450,720,20,{isStatic:true})]);
Composite.add(engine.world,MouseConstraint.create(engine,{mouse:Mouse.create(render.canvas)}));
Render.run(render);Runner.run(Runner.create(),engine);`});
ex({t:'Chain bridge with constraints',d:'A bridge of 22 links joined by distance constraints and pinned at both ends. Drop balls on it or drag a link.',hint:'Drag the bridge · click above it to drop a ball.',int:1,
 init(s){s.N=22;s.L=[];for(let i=0;i<s.N;i++){const x=80+i*(560/(s.N-1));s.L.push({x,y:200,px:x,py:200,pin:i===0||i===s.N-1});}s.B=[];s.dg=-1;
  s.onDown=(x,y)=>{s.dg=s.L.findIndex(p=>Math.hypot(p.x-x,p.y-y)<16&&!p.pin);if(s.dg<0&&y<190)s.B.push({x,y,vx:0,vy:0,r:16+Math.random()*12,h:Math.random()*360});};s.onUp=()=>{s.dg=-1;};},
 draw(ctx,s,t,dt){paper(ctx,'#fbfaf8');const L=s.L,seg=560/(s.N-1)*1.03;for(const p of L){if(p.pin)continue;const vx=(p.x-p.px)*.99,vy=(p.y-p.py)*.99;p.px=p.x;p.py=p.y;p.x+=vx;p.y+=vy+.4;}if(s.dg>=0&&s.down){L[s.dg].x=s.mx;L[s.dg].y=s.my;}
  for(const b of s.B){b.vy+=900*dt;b.x+=b.vx*dt;b.y+=b.vy*dt;}
  for(let k=0;k<12;k++){for(let i=1;i<L.length;i++){const a=L[i-1],b=L[i],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1,f=(d-seg)/d*.5;if(!a.pin){a.x+=dx*f;a.y+=dy*f;}if(!b.pin){b.x-=dx*f;b.y-=dy*f;}}
   for(const b of s.B)for(const p of L){const dx=b.x-p.x,dy=b.y-p.y,d=Math.hypot(dx,dy);if(d<b.r+6&&d>0){const o=(b.r+6-d)/d;b.x+=dx*o*.5;b.y+=dy*o*.5;if(!p.pin){p.x-=dx*o*.5;p.y-=dy*o*.5;}const n=[dx/d,dy/d],vn=b.vx*n[0]+b.vy*n[1];if(vn<0){b.vx-=vn*n[0]*1.2;b.vy-=vn*n[1]*1.2;}}}}
  s.B=s.B.filter(b=>b.y<H+60);ctx.fillStyle='#78716c';rr(ctx,50,190,40,H-190,6);ctx.fill();rr(ctx,630,190,40,H-190,6);ctx.fill();
  for(let i=1;i<L.length;i++){line(ctx,L[i-1].x,L[i-1].y,L[i].x,L[i].y,'#92400e',8);}L.forEach(p=>circle(ctx,p.x,p.y,5,p.pin?'#1c1917':'#fbbf24','#92400e',2));s.B.forEach(b=>sphere(ctx,b.x,b.y,b.r,b.h,70,58));cap(ctx,'Composites.chain(bridge, .3, 0, -.3, 0, {stiffness:.9})');},
 code:`const bridge=Composites.stack(80,200,22,1,0,0,(x,y)=>Bodies.rectangle(x,y,30,10,{chamfer:{radius:4}}));
Composites.chain(bridge,.3,0,-.3,0,{stiffness:.9,length:2});
Composite.add(world,[bridge,Constraint.create({pointA:{x:80,y:200},bodyB:bridge.bodies[0]}),
  Constraint.create({pointA:{x:640,y:200},bodyB:bridge.bodies[21]})]);`});
ex({t:'Galton board: a normal distribution appears',d:'Balls bounce through a triangle of pegs into bins. Over time the bins approach a binomial (bell-shaped) curve, drawn as a dashed overlay.',controls:[{type:'range',k:'rate',l:'Drop rate',min:1,max:20,v:8},{type:'btn',l:'Reset',fn:s=>s.reset()}],
 init(s){s.pegs=[];for(let r=0;r<10;r++)for(let c=0;c<=r;c++)s.pegs.push({x:W/2+(c-r/2)*34,y:60+r*24,r:4,fixed:true});s.reset=()=>{s.B=[];s.bins=new Array(12).fill(0);s.tot=0;};s.reset();s.acc=0;},
 draw(ctx,s,t,dt){bg(ctx,'#fbfaf8');s.acc+=dt*s.p.rate;while(s.acc>1){s.acc--;s.B.push({x:W/2+(Math.random()-.5)*2,y:30,vx:0,vy:0,r:5});}
  const all=s.pegs.concat(s.B);circleWorld(all,dt,{e:.35,walls:false,steps:3});const binW=34,x0=W/2-6*binW;
  for(let i=s.B.length-1;i>=0;i--){const b=s.B[i];if(b.y>320){const k=clamp(Math.floor((b.x-x0)/binW),0,11);s.bins[k]++;s.tot++;s.B.splice(i,1);}}
  s.pegs.forEach(p=>circle(ctx,p.x,p.y,4,'#57534e'));s.B.forEach(b=>circle(ctx,b.x,b.y,5,'#4f46e5'));const mx=Math.max(4,...s.bins);
  for(let k=0;k<12;k++){const h=s.bins[k]/mx*90;ctx.fillStyle=rgba('#4f46e5',.75);rr(ctx,x0+k*binW+3,H-20-h,binW-6,h,4);ctx.fill();line(ctx,x0+k*binW,330,x0+k*binW,H-20,'#d6d3cd',1);}
  ctx.strokeStyle='#e11d48';ctx.setLineDash([5,4]);ctx.lineWidth=2;ctx.beginPath();for(let k=0;k<=11;k++){const c=(n,k)=>{let r=1;for(let i=1;i<=k;i++)r=r*(n-k+i)/i;return r;},p=k>=1&&k<=11?c(10,k-1)/1024:0,y=H-20-p/(252/1024)*90*(s.tot>50?Math.max(...s.bins)/mx:1);k?ctx.lineTo(x0+k*binW+binW/2,y):ctx.moveTo(x0+k*binW+binW/2,y);}ctx.stroke();ctx.setLineDash([]);
  text(ctx,s.tot+' balls',W-14,24,C.mut,12,'right',MONO);},
 code:`for(let r=0;r<10;r++)for(let c=0;c<=r;c++)
  Composite.add(world,Bodies.circle(360+(c-r/2)*34,60+r*24,4,{isStatic:true}));
setInterval(()=>Composite.add(world,Bodies.circle(360,30,5,{restitution:.35,friction:.001})),120);`});
ex({t:'Soft body (pressure blob)',d:'A ring of 24 particles joined by springs, with internal pressure keeping its area. Drag the blob and fling it around.',hint:'Drag the blob.',int:1,
 init(s){const n=24;s.n=n;s.P=[];for(let i=0;i<n;i++){const a=i/n*TAU;s.P.push({x:W/2+Math.cos(a)*70,y:150+Math.sin(a)*70,px:W/2+Math.cos(a)*70,py:150+Math.sin(a)*70});}s.rest=TAU*70/n;s.A0=Math.PI*70*70;s.dg=null;s.onDown=(x,y)=>{if(Math.hypot(x-s.c[0],y-s.c[1])<90)s.dg=[x,y];};s.onUp=()=>{s.dg=null;};s.c=[W/2,150];},
 draw(ctx,s,t,dt){paper(ctx,'#fbfaf8');const P=s.P,n=s.n;for(const p of P){const vx=(p.x-p.px)*.995,vy=(p.y-p.py)*.995;p.px=p.x;p.py=p.y;p.x+=vx;p.y+=vy+.35;}
  if(s.dg&&s.down){const dx=s.mx-s.c[0],dy=s.my-s.c[1];P.forEach(p=>{p.x+=dx*.08;p.y+=dy*.08;});}
  for(let k=0;k<8;k++){for(let i=0;i<n;i++){const a=P[i],b=P[(i+1)%n],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1,f=(d-s.rest)/d*.5;a.x+=dx*f;a.y+=dy*f;b.x-=dx*f;b.y-=dy*f;}
   let A=0;for(let i=0;i<n;i++){const a=P[i],b=P[(i+1)%n];A+=a.x*b.y-b.x*a.y;}A/=2;const pr2=(s.A0-A)/(s.rest*n)*.4;for(let i=0;i<n;i++){const a=P[(i-1+n)%n],b=P[(i+1)%n],nx=b.y-a.y,ny=-(b.x-a.x),l=Math.hypot(nx,ny)||1;P[i].x+=nx/l*pr2;P[i].y+=ny/l*pr2;}
   for(const p of P){if(p.y>H-30){p.y=H-30;p.px=p.x-(p.x-p.px)*.8;}if(p.x<10)p.x=10;if(p.x>W-10)p.x=W-10;if(p.y<10)p.y=10;}}
  s.c=[P.reduce((a,p)=>a+p.x,0)/n,P.reduce((a,p)=>a+p.y,0)/n];ctx.fillStyle='#e7e5e4';ctx.fillRect(0,H-30,W,30);softShadow(ctx,s.c[0],H-30,80,10,.2);
  smoothClosed(ctx,P.map(p=>[p.x,p.y]));const g=ctx.createRadialGradient(s.c[0]-30,s.c[1]-30,10,s.c[0],s.c[1],100);g.addColorStop(0,'#f9a8d4');g.addColorStop(1,'#db2777');ctx.fillStyle=g;ctx.fill();ctx.strokeStyle='#9d174d';ctx.lineWidth=2;ctx.stroke();
  circle(ctx,s.c[0]-18,s.c[1]-10,7,'#fff');circle(ctx,s.c[0]+18,s.c[1]-10,7,'#fff');circle(ctx,s.c[0]-16,s.c[1]-9,3.5,'#1c1917');circle(ctx,s.c[0]+20,s.c[1]-9,3.5,'#1c1917');cap(ctx,'Composites.softBody(x, y, cols, rows, 0, 0, true, 8, {friction:.05})');},
 code:`const blob=Composites.softBody(250,100,6,6,0,0,true,10,
  {friction:.05,render:{fillStyle:'#db2777'}},{stiffness:.2,render:{visible:false}});
Composite.add(world,blob);`});

lib('rapier','Rapier','phys','Fast, deterministic 2D/3D physics in WebAssembly: rigid bodies, joints, CCD, ray casts and snapshots.');
ex({t:'Newton’s cradle (impulse joints)',d:'Five pendulums with rope joints and perfectly elastic collisions transfer momentum across the row.',hint:'Click to lift 1, 2 or 3 balls.',int:1,
 init(s){s.k=1;s.reset=()=>{s.th=[0,1,2,3,4].map(i=>i<s.k?-.75:0);s.w=[0,0,0,0,0];};s.reset();s.onDown=()=>{s.k=s.k%3+1;s.reset();};},
 draw(ctx,s,t,dt){vgrad(ctx,'#ffffff','#f1efea');const L=230,r=26,px=i=>W/2+(i-2)*2*r,py=60,n=5,st=8,h=dt/st,X=i=>px(i)+L*Math.sin(s.th[i]);
  for(let k=0;k<st;k++){for(let i=0;i<n;i++){s.w[i]+=-12*Math.sin(s.th[i])*h;s.w[i]*=.99995;s.th[i]+=s.w[i]*h;}for(let it=0;it<3;it++)for(let i=0;i<n-1;i++){if(X(i+1)-X(i)<2*r-1e-6&&s.w[i]>s.w[i+1]){const q=s.w[i];s.w[i]=s.w[i+1];s.w[i+1]=q;}}}
  ctx.fillStyle='#44403c';rr(ctx,W/2-5*r-30,py-14,10*r+60,14,5);ctx.fill();for(let i=0;i<n;i++){const x=X(i),y=py+L*Math.cos(s.th[i]);softShadow(ctx,x,H-40,30,6,.15);line(ctx,px(i)-8,py,x,y,'rgba(68,64,60,.6)',1.5);line(ctx,px(i)+8,py,x,y,'rgba(68,64,60,.6)',1.5);sphere(ctx,x,y,r,220,8,70);}
  cap(ctx,'world.createImpulseJoint(RAPIER.JointData.rope(2.3, a, b), anchor, ball)');},
 code:`const ball=world.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(x,-2.3));
world.createCollider(RAPIER.ColliderDesc.ball(.26).setRestitution(1).setFriction(0),ball);
world.createImpulseJoint(RAPIER.JointData.spherical({x:0,y:0},{x:0,y:2.3}),anchor,ball,true);`});
ex({t:'Deterministic snapshots: rewind a break shot',d:'A billiards break is simulated and every frame snapshotted. Scrub the timeline to rewind and replay exactly; determinism makes it identical each time.',hint:'Drag the timeline slider to rewind.',
 controls:[{type:'range',k:'f',l:'Timeline',min:0,max:599,v:0},{type:'btn',l:'▶ Replay',pri:1,fn:s=>{s.play=true;s.fr=0;}}],
 init(s){const B=[];const cue={x:150,y:220,vx:1250,vy:(Math.random()-.5)*20,r:11,c:'#fff'};B.push(cue);let k=0;const cols=['#facc15','#2563eb','#dc2626','#7c3aed','#ea580c','#16a34a','#7f1d1d','#111827','#facc15','#2563eb','#dc2626','#7c3aed','#ea580c','#16a34a','#7f1d1d'];for(let r=0;r<5;r++)for(let c=0;c<=r;c++)B.push({x:470+r*19.2,y:220+(c-r/2)*22.2,vx:0,vy:0,r:11,c:cols[k++]});
  s.snap=[];for(let f=0;f<600;f++){s.snap.push(B.map(b=>[b.x,b.y]));for(let q=0;q<2;q++){circleWorld(B,1/120,{g:0,e:.95,walls:false,steps:2});for(const b of B){b.vx*=.996;b.vy*=.996;if(b.x<60+b.r){b.x=60+b.r;b.vx*=-.9;}if(b.x>660-b.r){b.x=660-b.r;b.vx*=-.9;}if(b.y<70+b.r){b.y=70+b.r;b.vy*=-.9;}if(b.y>370-b.r){b.y=370-b.r;b.vy*=-.9;}}}}s.cols=B.map(b=>b.c);s.fr=0;s.play=true;},onCtl(s,k){if(k==='f'){s.fr=s.p.f;s.play=false;}},
 draw(ctx,s,t,dt){bg(ctx,'#fbfaf8');if(s.play){s.fr+=dt*60;if(s.fr>=599){s.fr=599;s.play=false;}}const f=Math.floor(s.fr);ctx.fillStyle='#78350f';rr(ctx,40,50,640,340,22);ctx.fill();ctx.fillStyle='#15803d';rr(ctx,60,70,600,300,8);ctx.fill();[[60,70],[360,64],[660,70],[60,370],[360,376],[660,370]].forEach(p=>circle(ctx,p[0],p[1],14,'#111'));
  for(let g=Math.max(0,f-20);g<f;g+=4)s.snap[g].forEach((p,i)=>circle(ctx,p[0],p[1],3,rgba(i?'#ffffff':'#fde047',.18)));s.snap[f].forEach((p,i)=>{softShadow(ctx,p[0]+3,p[1]+5,12,5,.3);circle(ctx,p[0],p[1],11,s.cols[i],'rgba(0,0,0,.25)',1);circle(ctx,p[0]-3,p[1]-3,3,'rgba(255,255,255,.6)');});
  ctx.fillStyle='#fff';rr(ctx,40,402,640,8,4);ctx.fill();ctx.fillStyle=C.indigo;rr(ctx,40,402,640*f/599,8,4);ctx.fill();text(ctx,'frame '+f+' / 600 · snapshot '+(f*15/1024).toFixed(1)+' KB',W-40,30,C.mut,12,'right',MONO);},
 code:`const snapshots=[];
for(let f=0;f<600;f++){snapshots.push(world.takeSnapshot());world.step();}
slider.oninput=e=>{world=RAPIER.World.restoreSnapshot(snapshots[+e.target.value]);render(world);};`});
ex({t:'Ray casts: a lidar sweep',d:'Sixty rays cast from the pointer against a scene of colliders; each ray stops at its first hit and the hit points form a scan.',hint:'Move the pointer around the room.',
 init(s){const r=rng(8);s.O=[];for(let i=0;i<9;i++)s.O.push({x:90+r()*540,y:70+r()*300,r:18+r()*34,vx:(r()-.5)*40,vy:(r()-.5)*40});},
 draw(ctx,s,t,dt){bg(ctx,'#fafaf9');s.O.forEach(o=>{o.x+=o.vx*dt;o.y+=o.vy*dt;if(o.x<o.r+20||o.x>W-o.r-20)o.vx*=-1;if(o.y<o.r+20||o.y>H-o.r-20)o.vy*=-1;});const ox=s.hover?s.mx:W/2+Math.cos(t*.5)*200,oy=s.hover?s.my:H/2+Math.sin(t*.7)*120;
  ctx.strokeStyle='#1c1917';ctx.lineWidth=3;ctx.strokeRect(20,20,W-40,H-40);s.O.forEach(o=>circle(ctx,o.x,o.y,o.r,'#e7e5e4','#a8a29e',2));const N=90,hits=[];
  for(let i=0;i<N;i++){const a=i/N*TAU+t*.2,dx=Math.cos(a),dy=Math.sin(a);let tm=Math.min(dx>0?(W-20-ox)/dx:dx<0?(20-ox)/dx:1e9,dy>0?(H-20-oy)/dy:dy<0?(20-oy)/dy:1e9);
   for(const o of s.O){const fx=ox-o.x,fy=oy-o.y,b=fx*dx+fy*dy,c=fx*fx+fy*fy-o.r*o.r,disc=b*b-c;if(disc>0){const q=-b-Math.sqrt(disc);if(q>0&&q<tm)tm=q;}}hits.push([ox+dx*tm,oy+dy*tm]);}
  ctx.fillStyle='rgba(225,29,72,.07)';poly(ctx,hits,ctx.fillStyle);hits.forEach(p=>{line(ctx,ox,oy,p[0],p[1],'rgba(225,29,72,.18)',1);circle(ctx,p[0],p[1],2.6,'#e11d48');});circle(ctx,ox,oy,8,'#1c1917');cap(ctx,'world.castRay(new RAPIER.Ray(origin, dir), maxToi, true)');},
 code:`for(let i=0;i<90;i++){const dir={x:Math.cos(i/90*TAU),y:Math.sin(i/90*TAU)};
  const hit=world.castRay(new RAPIER.Ray(origin,dir),50,true);
  if(hit){const p=new RAPIER.Ray(origin,dir).pointAt(hit.timeOfImpact);drawPoint(p);}}`});

lib('planck','Planck.js','phys','A JavaScript rewrite of Box2D: precise 2D mechanics with joints (revolute, prismatic, wheel, gear, pulley).',{ik:'Planck.js'});
ex({t:'Double pendulum chaos',d:'Two double pendulums started 0.001 rad apart, integrated with RK4. Within seconds their paths separate completely.',hint:'Click to restart.',int:1,
 init(s){s.reset=()=>{s.a=[[2.2,2.4,0,0],[2.2,2.401,0,0]];s.tr=[[],[]];s.age=0;};s.reset();s.onDown=s.reset;},
 draw(ctx,s,t,dt){bg(ctx,'#fffdf9');const g=9.8,f=y=>{const[a1,a2,w1,w2]=y,d=a1-a2,den=3-Math.cos(2*d);return[w1,w2,(-g*3*Math.sin(a1)-g*Math.sin(a1-2*a2)-2*Math.sin(d)*(w2*w2+w1*w1*Math.cos(d)))/den,(2*Math.sin(d)*(2*w1*w1+2*g*Math.cos(a1)+w2*w2*Math.cos(d)))/den];};
  const step=(y,h)=>{const k1=f(y),k2=f(y.map((v,i)=>v+k1[i]*h/2)),k3=f(y.map((v,i)=>v+k2[i]*h/2)),k4=f(y.map((v,i)=>v+k3[i]*h));return y.map((v,i)=>v+h/6*(k1[i]+2*k2[i]+2*k3[i]+k4[i]));};
  s.age+=dt;if(s.age>30)s.reset();const sub=Math.max(1,Math.round(dt*300)),h=dt/sub,ox=W/2,oy=165,sc=105;
  s.a.forEach((y,k)=>{for(let i=0;i<sub;i++)y=step(y,h);s.a[k]=y;const x1=ox+Math.sin(y[0])*sc,y1=oy+Math.cos(y[0])*sc,x2=x1+Math.sin(y[1])*sc,y2=y1+Math.cos(y[1])*sc;s.tr[k].push([x2,y2]);if(s.tr[k].length>420)s.tr[k].shift();
   const col=k?'225,29,72':'79,70,229',T=s.tr[k];for(let c=0;c<10;c++){ctx.beginPath();const a=Math.floor(c*T.length/10),b=Math.min(T.length,Math.floor((c+1)*T.length/10)+1);for(let i=a;i<b;i++)i==a?ctx.moveTo(T[i][0],T[i][1]):ctx.lineTo(T[i][0],T[i][1]);ctx.strokeStyle='rgba('+col+','+(c+1)/12+')';ctx.lineWidth=2;ctx.stroke();}
   ctx.strokeStyle='rgb('+col+')';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(ox,oy);ctx.lineTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();circle(ctx,x1,y1,8,'#fff','rgb('+col+')',2.5);circle(ctx,x2,y2,10,'rgb('+col+')');});
  circle(ctx,ox,oy,5,C.ink);cap(ctx,'Δθ₀ = 0.001 rad → trajectories diverge');},
 code:`const world=new planck.World({gravity:planck.Vec2(0,-9.8)});
const b1=world.createDynamicBody(planck.Vec2(0,-1)),b2=world.createDynamicBody(planck.Vec2(0,-2));
world.createJoint(planck.RevoluteJoint({},ground,b1,planck.Vec2(0,0)));
world.createJoint(planck.RevoluteJoint({},b1,b2,planck.Vec2(0,-1)));`});
ex({t:'Car on hilly terrain (wheel joints)',d:'Two wheels joined to a chassis by suspension springs drive over procedurally generated hills. Hold the arrow keys or the buttons to drive.',hint:'Click the scene, then hold ← / → (or use the buttons).',int:1,
 controls:[{type:'btn',l:'◀ Reverse',fn:s=>{s.th=-1;setTimeout(()=>s.th=0,700);}},{type:'btn',l:'Drive ▶',pri:1,fn:s=>{s.th=1;setTimeout(()=>s.th=0,1200);}}],
 init(s){s.gnd=x=>330-Math.sin(x*.006)*40-Math.sin(x*.017)*18-fbm(x*.004,1)*60;s.W=[{x:120,y:250,vx:0,vy:0,a:0},{x:190,y:250,vx:0,vy:0,a:0}];s.th=0;s.cam=0;s.onKey=e=>{if(e.key==='ArrowRight'){s.th=e.type==='keyup'?0:1;e.preventDefault();}if(e.key==='ArrowLeft'){s.th=e.type==='keyup'?0:-1;e.preventDefault();}};const ku=e=>{if(e.key==='ArrowRight'||e.key==='ArrowLeft')s.th=0;};window.addEventListener('keyup',ku);s.destroy=()=>window.removeEventListener('keyup',ku);},
 draw(ctx,s,t,dt){const th=s.th||(s.hover?0:(Math.floor(t/6)%2?.6:.6));const Wh=s.W,R=18,h=dt/6;for(let k=0;k<6;k++){for(const w of Wh){w.vy+=700*h;w.x+=w.vx*h;w.y+=w.vy*h;const gy=s.gnd(w.x),sl=(s.gnd(w.x+1)-s.gnd(w.x-1))/2,nx=-sl,ny=1,nl=Math.hypot(nx,ny);if(w.y>gy-R){w.y=gy-R;const vn=(w.vx*sl-w.vy)/Math.hypot(sl,1);w.vy=Math.min(w.vy,0)*.2+sl*w.vx;w.vx+=th*500*h;w.vx*=.995;}w.a+=w.vx*h/R;}
   const[a,b]=Wh,dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1,f=(d-70)/d*.5;a.x+=dx*f;a.y+=dy*f;b.x-=dx*f;b.y-=dy*f;const avx=(a.vx+b.vx)/2;a.vx=lerp(a.vx,avx,.2);b.vx=lerp(b.vx,avx,.2);}
  s.cam=lerp(s.cam,(Wh[0].x+Wh[1].x)/2-W*.35,.08);vgrad(ctx,'#e0f2fe','#fef9c3');ctx.save();ctx.translate(-s.cam,0);ctx.fillStyle='#86efac';ctx.beginPath();ctx.moveTo(s.cam,H);for(let x=s.cam;x<=s.cam+W+10;x+=8)ctx.lineTo(x,s.gnd(x));ctx.lineTo(s.cam+W+10,H);ctx.fill();ctx.strokeStyle='#15803d';ctx.lineWidth=3;ctx.beginPath();for(let x=s.cam;x<=s.cam+W+10;x+=8)x===s.cam?ctx.moveTo(x,s.gnd(x)):ctx.lineTo(x,s.gnd(x));ctx.stroke();
  for(let m=Math.floor(s.cam/200)*200;m<s.cam+W;m+=200){line(ctx,m,s.gnd(m),m,s.gnd(m)-24,'#78716c',2);text(ctx,m/10+'m',m+4,s.gnd(m)-14,C.ink2,11,'left',MONO);}
  const[a,b]=Wh,ang=Math.atan2(b.y-a.y,b.x-a.x),cx=(a.x+b.x)/2,cy=(a.y+b.y)/2;ctx.save();ctx.translate(cx,cy-22);ctx.rotate(ang);ctx.fillStyle='#e11d48';rr(ctx,-52,-14,104,26,10);ctx.fill();ctx.fillStyle='#bae6fd';rr(ctx,-16,-30,40,18,6);ctx.fill();ctx.strokeStyle='#9f1239';ctx.lineWidth=2;rr(ctx,-52,-14,104,26,10);ctx.stroke();ctx.restore();
  Wh.forEach(w=>{line(ctx,w.x,w.y,cx+(w.x-cx)*.8,cy-14,'#57534e',3);circle(ctx,w.x,w.y,R,'#1c1917');circle(ctx,w.x,w.y,8,'#a8a29e');line(ctx,w.x,w.y,w.x+Math.cos(w.a)*R*.8,w.y+Math.sin(w.a)*R*.8,'#fafaf9',2.5);});ctx.restore();
  text(ctx,'distance '+Math.round(cx/10)+' m · speed '+Math.abs(a.vx/10).toFixed(1)+' m/s',16,26,C.ink2,13,'left',MONO);},
 code:`const car=world.createDynamicBody(planck.Vec2(0,1));car.createFixture(planck.Box(1.25,.25),1);
const wheel=world.createDynamicBody(planck.Vec2(-1,.35));wheel.createFixture(planck.Circle(.4),{density:1,friction:.9});
const spring=world.createJoint(planck.WheelJoint({motorSpeed:0,maxMotorTorque:20,enableMotor:true,frequencyHz:4,dampingRatio:.7},
  car,wheel,wheel.getPosition(),planck.Vec2(0,1)));
addEventListener('keydown',e=>{if(e.key==='ArrowRight')spring.setMotorSpeed(-50);});`});
ex({t:'Gear joint & pulley joint',d:'A gear joint links two revolute joints with a fixed ratio (teeth counts), and a pulley joint balances two loads over a wheel.',hint:'Drag the ratio slider · drag the left load up/down.',int:1,controls:[{type:'range',k:'ratio',l:'Gear ratio',min:.3,max:3,step:.1,v:2}],
 init(s){s.a=0;s.y=0;s.vy=0;s.dg=false;s.onDown=(x,y)=>{if(x>420&&x<520)s.dg=true;};s.onUp=()=>{s.dg=false;};},
 draw(ctx,s,t,dt){bg(ctx,'#fbfaf8');s.a+=dt*1.2;const gear=(x,y,r,teeth,a,col)=>{ctx.save();ctx.translate(x,y);ctx.rotate(a);ctx.beginPath();for(let i=0;i<teeth*2;i++){const a0=i/(teeth*2)*TAU,a1=(i+1)/(teeth*2)*TAU,rr2=i%2?r:r+10;ctx.lineTo(Math.cos(a0)*rr2,Math.sin(a0)*rr2);ctx.lineTo(Math.cos(a1)*rr2,Math.sin(a1)*rr2);}ctx.closePath();ctx.fillStyle=col;ctx.fill();ctx.strokeStyle='rgba(0,0,0,.25)';ctx.stroke();circle(ctx,0,0,r*.35,'#fbfaf8');line(ctx,0,0,r*.8,0,'#fff',3);ctx.restore();};
  const r1=60,r2=r1*s.p.ratio>110?110:r1*s.p.ratio,t1=12,t2=Math.round(12*r2/r1);gear(160,220,r1,t1,s.a,'#4f46e5');gear(160+r1+r2+10,220,r2,t2,-s.a*r1/r2+Math.PI/t2,'#0d9488');text(ctx,'ratio '+(r2/r1).toFixed(2)+' : 1',160,360,C.ink2,13,'left',MONO);
  const px=560,py=80,R=34;if(s.dg&&s.down){s.y=clamp(s.my-240,-110,110);s.vy=0;}else{const m1=3,m2=2;s.vy+=(m1-m2)/(m1+m2)*300*dt;s.vy*=.99;s.y=clamp(s.y+s.vy*dt,-110,110);if(Math.abs(s.y)>=110)s.vy=0;}
  circle(ctx,px,py,R,'#e7e5e4','#57534e',3);circle(ctx,px,py,5,'#57534e');line(ctx,px,30,px,py,'#57534e',3);const yl=240+s.y,yr=240-s.y;line(ctx,px-R,py,px-R,yl,'#1c1917',2);line(ctx,px+R,py,px+R,yr,'#1c1917',2);
  ctx.fillStyle='#e11d48';rr(ctx,px-R-26,yl,52,52,8);ctx.fill();text(ctx,'3 kg',px-R,yl+31,'#fff',13,'center',FONT,700);ctx.fillStyle='#d97706';rr(ctx,px+R-22,yr,44,44,8);ctx.fill();text(ctx,'2 kg',px+R,yr+27,'#fff',13,'center',FONT,700);cap(ctx,'planck.GearJoint({}, b1, b2, revA, revB, ratio) · planck.PulleyJoint(...)');},
 code:`const gear=world.createJoint(planck.GearJoint({},gearA,gearB,revoluteA,revoluteB,2.0));
const pulley=world.createJoint(planck.PulleyJoint({},loadA,loadB,
  planck.Vec2(-1,10),planck.Vec2(1,10),loadA.getPosition(),loadB.getPosition(),1));`});

lib('cannon','Cannon-es','phys','A lightweight 3D physics engine that pairs naturally with Three.js: bodies, shapes, constraints and vehicles.',{ik:'Cannon-es'});
ex({t:'Spheres in a 3D box with shadows',d:'Fourteen bodies bounce off each other and the box walls under gravity. Contact shadows sit on the floor.',hint:'Drag to orbit · click to shake the box.',orbit:{ry:.3,rx:.5,auto:.25},int:1,
 init(s){const r=rng(5);s.b=[];for(let i=0;i<16;i++)s.b.push({p:[(r()-.5)*1.4,(r()-.5)*1.2,(r()-.5)*1.4],v:[(r()-.5)*2,(r()-.5)*2,(r()-.5)*2],r:.13+r()*.1,h:i*24});s.sh=()=>s.b.forEach(b=>{b.v=[b.v[0]+(Math.random()-.5)*5,-2-Math.random()*3,b.v[2]+(Math.random()-.5)*5];});s.last=0;s.onDown=()=>{s.sh();};},
 draw(ctx,s,t,dt){vgrad(ctx,'#ffffff','#efece6');if(t-s.last>9){s.last=t;s.sh();}const ry=s.ry,rx=s.rx,sc=125,D=6,Bd=1,st=4,h=dt/st,B=s.b;
  for(let k=0;k<st;k++){for(const b of B){b.v[1]+=3*h;for(let a=0;a<3;a++){b.p[a]+=b.v[a]*h;if(b.p[a]>Bd-b.r){b.p[a]=Bd-b.r;b.v[a]*=-.9;}else if(b.p[a]<-Bd+b.r){b.p[a]=-Bd+b.r;b.v[a]*=-.9;}}}
   for(let i=0;i<B.length;i++)for(let j=i+1;j<B.length;j++){const a=B[i],c=B[j],d3=sub(c.p,a.p),d=len3(d3),m=a.r+c.r;if(d<m&&d>.0001){const n=mul(d3,1/d),o=(m-d)/2;a.p=sub(a.p,mul(n,o));c.p=add(c.p,mul(n,o));const vr=dot(sub(c.v,a.v),n);if(vr<0){const im=-1.9*vr/2;a.v=sub(a.v,mul(n,im));c.v=add(c.v,mul(n,im));}}}}
  const P=p=>pr(rot(p,ry,rx),sc,D);poly(ctx,[[-1,1,-1],[1,1,-1],[1,1,1],[-1,1,1]].map(P),'rgba(120,113,108,.08)');wireBox(ctx,ry,rx,sc,D,[1,1,1]);
  const L=[];for(const b of B){const sp=P([b.p[0],Bd,b.p[2]]),q=P(b.p),hh=(Bd-b.p[1])/2;ctx.fillStyle='rgba(28,25,23,'+(.22*(1-hh*.6))+')';ctx.beginPath();ctx.ellipse(sp[0],sp[1],b.r*sc*sp[3],b.r*sc*sp[3]*.45,0,0,TAU);ctx.fill();L.push([q,rot(b.p,ry,rx)[2],b]);}
  L.sort((a,b)=>a[1]-b[1]).forEach(([q,,b])=>sphere(ctx,q[0],q[1],b.r*sc*q[3],b.h,70,58));cap(ctx,'world.addBody(new CANNON.Body({mass:1, shape:new CANNON.Sphere(r)}))');},
 code:`const world=new CANNON.World({gravity:new CANNON.Vec3(0,-9.82,0)});
const ball=new CANNON.Body({mass:1,shape:new CANNON.Sphere(.2),position:new CANNON.Vec3(0,2,0)});
world.addBody(ball);
renderer.setAnimationLoop(()=>{world.fixedStep();mesh.position.copy(ball.position);mesh.quaternion.copy(ball.quaternion);renderer.render(scene,camera);});`});
ex({t:'Wrecking ball vs a sphere pyramid',d:'A heavy ball on a point-to-point constraint swings into a stacked pyramid of light spheres, scattering them in 3D.',hint:'Drag to orbit · click to reset.',orbit:{ry:-.6,rx:.4,auto:.08},int:1,
 init(s){s.reset=()=>{s.B=[];for(let l=0;l<4;l++)for(let i=0;i<4-l;i++)for(let j=0;j<4-l;j++)s.B.push({p:[.4+(i-(3-l)/2)*.24,1-.12-l*.21,(j-(3-l)/2)*.24],v:[0,0,0],r:.12,m:1,h:(l*90+i*20)%360});s.ball={p:[-1.4,-.2,0],v:[0,0,0],r:.26,m:12};s.t0=s.t;};s.reset();s.onDown=()=>s.reset();},
 draw(ctx,s,t,dt){vgrad(ctx,'#ffffff','#efece6');const st=6,h=Math.min(dt,.03)/st,piv=[-.2,-1.6,0],L=1.75,Bl=s.ball,all=s.B.concat([Bl]);
  for(let k=0;k<st;k++){for(const b of all){b.v[1]+=6*h;b.p=add(b.p,mul(b.v,h));if(b.p[1]>1-b.r){b.p[1]=1-b.r;b.v[1]*=-.3;b.v[0]*=.96;b.v[2]*=.96;}}
   const d=sub(Bl.p,piv),dl=len3(d);Bl.p=add(piv,mul(d,L/dl));const n=mul(d,1/dl);Bl.v=sub(Bl.v,mul(n,dot(Bl.v,n)));
   for(let i=0;i<all.length;i++)for(let j=i+1;j<all.length;j++){const a=all[i],c=all[j],d3=sub(c.p,a.p),dd=len3(d3),m=a.r+c.r;if(dd<m&&dd>1e-4){const nn=mul(d3,1/dd),ia=1/a.m,ic=1/c.m,o=(m-dd)/(ia+ic);a.p=sub(a.p,mul(nn,o*ia));c.p=add(c.p,mul(nn,o*ic));const vr=dot(sub(c.v,a.v),nn);if(vr<0){const im=-1.3*vr/(ia+ic);a.v=sub(a.v,mul(nn,im*ia));c.v=add(c.v,mul(nn,im*ic));}}}}
  const ry=s.ry,rx=s.rx,sc=120,D=6,P=p=>pr(rot(p,ry,rx),sc,D);floorGrid(ctx,ry,rx,sc,D,1,5,.4);const pp=P(piv),bp=P(Bl.p);line(ctx,pp[0],pp[1],bp[0],bp[1],'#44403c',2.5);circle(ctx,pp[0],pp[1],5,'#44403c');
  const items=all.map(b=>{const q=P(b.p),fp=P([b.p[0],1,b.p[2]]);ctx.fillStyle='rgba(28,25,23,.12)';ctx.beginPath();ctx.ellipse(fp[0],fp[1],b.r*sc*fp[3],b.r*sc*fp[3]*.4,0,0,TAU);ctx.fill();return[q,rot(b.p,ry,rx)[2],b];});
  items.sort((a,b)=>a[1]-b[1]).forEach(([q,,b])=>b===Bl?sphere(ctx,q[0],q[1],b.r*sc*q[3],220,10,35):sphere(ctx,q[0],q[1],b.r*sc*q[3],b.h,75,60));cap(ctx,'new CANNON.PointToPointConstraint(anchor, pivotA, ball, pivotB)');},
 code:`const anchor=new CANNON.Body({mass:0,position:new CANNON.Vec3(-.2,6,0)});
const ball=new CANNON.Body({mass:12,shape:new CANNON.Sphere(.26),position:new CANNON.Vec3(-1.4,4,0)});
world.addConstraint(new CANNON.DistanceConstraint(anchor,ball,1.75));
pyramid.forEach(p=>world.addBody(new CANNON.Body({mass:1,shape:new CANNON.Sphere(.12),position:p})));`});
