/* ===================== Particles & Effects ===================== */
lib('tsparticles','tsParticles','fx','Configurable particle engine: links, interactivity, presets, emitters, absorbers and polygon masks from JSON.',{ik:'tsParticles'});
ex({t:'Linked network with repulse & attract',d:'Ninety particles with distance-based links; hovering repulses them, holding the button attracts them, and links reach toward the pointer.',hint:'Hover to repel · press and hold to attract.',int:1,
 controls:[{type:'range',k:'n',l:'Particles',min:20,max:200,v:90},{type:'range',k:'ld',l:'Link distance',min:60,max:180,v:115}],
 init(s){s.P=[];s.fill=()=>{while(s.P.length<s.p.n)s.P.push({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*44,vy:(Math.random()-.5)*44,c:PAL[s.P.length%5]});s.P.length=s.p.n;};s.fill();},onCtl(s){s.fill();},
 draw(ctx,s,t,dt){bg(ctx,'#fbfbff');const P=s.P,LD=s.p.ld;for(const p of P){p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.x<0||p.x>W)p.vx*=-1;if(p.y<0||p.y>H)p.vy*=-1;if(s.hover){const dx=p.x-s.mx,dy=p.y-s.my,d=Math.hypot(dx,dy);if(d<140&&d>1){const f=(s.down?-1:1)*(140-d)/140*170;p.x+=dx/d*f*dt;p.y+=dy/d*f*dt;}}}
  ctx.lineWidth=1.1;for(let i=0;i<P.length;i++){for(let j=i+1;j<P.length;j++){const d=Math.hypot(P[i].x-P[j].x,P[i].y-P[j].y);if(d<LD){ctx.strokeStyle='rgba(79,70,229,'+(1-d/LD)*.4+')';ctx.beginPath();ctx.moveTo(P[i].x,P[i].y);ctx.lineTo(P[j].x,P[j].y);ctx.stroke();}}
   if(s.hover){const d=Math.hypot(P[i].x-s.mx,P[i].y-s.my);if(d<180){ctx.strokeStyle='rgba(225,29,72,'+(1-d/180)*.55+')';ctx.beginPath();ctx.moveTo(P[i].x,P[i].y);ctx.lineTo(s.mx,s.my);ctx.stroke();}}}
  for(const p of P)circle(ctx,p.x,p.y,3.2,p.c);cap(ctx,'interactivity:{events:{onHover:{mode:"repulse"}, onClick:{mode:"attract"}}}');},
 code:`await tsParticles.load({id:'tsparticles',options:{background:{color:'#fbfbff'},
  particles:{number:{value:90},color:{value:['#4f46e5','#0d9488','#e11d48']},links:{enable:true,distance:115,color:'#4f46e5',opacity:.4},move:{enable:true,speed:1.2}},
  interactivity:{events:{onHover:{enable:true,mode:'repulse'},onClick:{enable:true,mode:'attract'}}}}});`});
ex({t:'Polygon / text mask: particles form a word',d:'Particles are seeded from the pixels of a word and spring back home; hovering scatters them like a shockwave.',hint:'Sweep the pointer through the letters.',controls:[{type:'select',k:'w',l:'Word',v:'PARTICLES',opts:['PARTICLES','OFFLINE','ATLAS','HELLO']}],
 init(s){s.mk=()=>{const c=document.createElement('canvas');c.width=W;c.height=H;const x=c.getContext('2d');x.fillStyle='#000';x.font='900 '+(s.p.w.length>7?118:150)+'px '+FONT;x.textAlign='center';x.textBaseline='middle';x.fillText(s.p.w,W/2,H/2);const d=x.getImageData(0,0,W,H).data;s.P=[];for(let y=0;y<H;y+=6)for(let xx=0;xx<W;xx+=6)if(d[(y*W+xx)*4+3]>128)s.P.push({hx:xx,hy:y,x:Math.random()*W,y:Math.random()*H,vx:0,vy:0,c:scale(['#4f46e5','#db2777','#f59e0b'],xx/W)});};s.mk();},onCtl(s){s.mk();},
 draw(ctx,s,t,dt){bg(ctx,'#fffdf9');for(const p of s.P){p.vx+=(p.hx-p.x)*.06;p.vy+=(p.hy-p.y)*.06;if(s.hover){const dx=p.x-s.mx,dy=p.y-s.my,d2=dx*dx+dy*dy;if(d2<9000){const f=1400/(d2+60);p.vx+=dx*f*.1;p.vy+=dy*f*.1;}}p.vx*=.82;p.vy*=.82;p.x+=p.vx;p.y+=p.vy;ctx.fillStyle=p.c;ctx.fillRect(p.x-2,p.y-2,4,4);}
  text(ctx,s.P.length+' particles',W-14,24,C.mut,12,'right',MONO);cap(ctx,'polygon:{enable:true, type:"inline", url:"word.svg", move:{type:"path"}}');},
 code:`await tsParticles.load({id:'tsp',options:{particles:{number:{value:0},move:{enable:true,speed:.5}},
  polygon:{enable:true,type:'inside',url:'assets/word.svg',move:{radius:10,type:'path'},inline:{arrangement:'equidistant'}},
  interactivity:{events:{onHover:{enable:true,mode:'bubble'}}}}});`});
ex({t:'Emitters & an absorber (black hole)',d:'Two emitters spray coloured particles; an absorber in the middle swallows them and grows. Drag the absorber around.',hint:'Drag the dark absorber.',int:1,
 init(s){s.P=[];s.ab={x:W/2,y:H/2,r:22};s.dg=false;s.onDown=(x,y)=>{if(Math.hypot(x-s.ab.x,y-s.ab.y)<s.ab.r+20)s.dg=true;};s.onMove=(x,y)=>{if(s.dg&&s.down){s.ab.x=x;s.ab.y=y;}};s.onUp=()=>{s.dg=false;};},
 draw(ctx,s,t,dt){bg(ctx,'#fbfaf8');const E=[[60,90,.35,'#4f46e5'],[W-60,H-90,Math.PI+.35,'#e11d48']];E.forEach(e=>{for(let i=0;i<3;i++){const a=e[2]+(Math.random()-.5)*.6+Math.sin(t*1.3)*.4;s.P.push({x:e[0],y:e[1],vx:Math.cos(a)*(150+Math.random()*90),vy:Math.sin(a)*(150+Math.random()*90),c:e[3],l:1});}circle(ctx,e[0],e[1],12,'#fff',e[3],3);});
  const A=s.ab;for(let i=s.P.length-1;i>=0;i--){const p=s.P[i],dx=A.x-p.x,dy=A.y-p.y,d=Math.hypot(dx,dy)||1;p.vx+=dx/d*9000/(d*d+900)*dt*60;p.vy+=dy/d*9000/(d*d+900)*dt*60;p.vx*=.995;p.vy*=.995;p.x+=p.vx*dt;p.y+=p.vy*dt;p.l-=dt*.15;if(d<A.r){s.P.splice(i,1);A.r=Math.min(70,A.r+.02);continue;}if(p.l<=0||p.x<-50||p.x>W+50||p.y<-50||p.y>H+50){s.P.splice(i,1);continue;}circle(ctx,p.x,p.y,2.4,rgba(p.c,.7*p.l+.2));}
  A.r=Math.max(18,A.r-dt*.6);const g=ctx.createRadialGradient(A.x,A.y,A.r*.3,A.x,A.y,A.r*2.2);g.addColorStop(0,'rgba(28,25,23,1)');g.addColorStop(.45,'rgba(28,25,23,.85)');g.addColorStop(1,'rgba(28,25,23,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(A.x,A.y,A.r*2.2,0,TAU);ctx.fill();
  text(ctx,s.P.length+' alive',W-14,24,C.mut,12,'right',MONO);cap(ctx,'emitters:[{position:{x:8,y:20}, rate:{quantity:3}}], absorbers:[{draggable:true}]');},
 code:`await tsParticles.load({id:'tsp',options:{
  emitters:[{position:{x:8,y:20},direction:'bottom-right',rate:{quantity:3,delay:.05}},{position:{x:92,y:80},direction:'top-left'}],
  absorbers:[{position:{x:50,y:50},size:{value:22,limit:70},draggable:true,orbits:true}]}});`});

lib('pixi','PixiJS','fx','The fastest 2D WebGL/WebGPU renderer: thousands of sprites, filters, masks, meshes and text at 60 fps.',{ik:'PixiJS'});
ex({t:'4,000 sprites around an attractor',d:'Twelve batched sprite groups orbit a moving attractor with inertia and screen wrapping.',hint:'Hover to move the attractor.',
 init(s){const r=rng(9);s.g=Array.from({length:12},(_,i)=>({c:hsl(225+i*11,75,52,.55),a:[]}));for(let i=0;i<4000;i++)s.g[i%12].a.push({x:r()*W,y:r()*H,vx:(r()-.5)*160,vy:(r()-.5)*160});},
 draw(ctx,s,t,dt){bg(ctx,'#fcfcff');const gx=s.hover?s.mx:W/2+Math.cos(t)*160,gy=s.hover?s.my:H/2+Math.sin(t*1.2)*100;
  for(const g of s.g){ctx.fillStyle=g.c;for(const p of g.a){const dx=gx-p.x,dy=gy-p.y,d=Math.hypot(dx,dy)+30;p.vx+=dx/d*260*dt;p.vy+=dy/d*260*dt;p.vx*=.995;p.vy*=.995;p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.x<0)p.x+=W;if(p.x>W)p.x-=W;if(p.y<0)p.y+=H;if(p.y>H)p.y-=H;ctx.fillRect(p.x,p.y,2.6,2.6);}}
  cap(ctx,'new PIXI.ParticleContainer({ dynamicProperties:{ position:true } })');},
 code:`const app=new PIXI.Application();await app.init({width:720,height:440,background:'#fcfcff'});
const container=new PIXI.ParticleContainer({dynamicProperties:{position:true}});
for(let i=0;i<4000;i++)container.addParticle(new PIXI.Particle({texture,x:Math.random()*720,y:Math.random()*440}));
app.stage.addChild(container);app.ticker.add(()=>step(container.particleChildren));`});
ex({t:'Displacement filter: water ripples',d:'A displacement map distorts the image underneath. Click to drop ripples; the scene keeps a gentle swell.',hint:'Click to make ripples.',int:1,
 init(s){const w=240,h=147;s.w=w;s.h=h;const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');const g=x.createLinearGradient(0,0,0,h);g.addColorStop(0,'#fde68a');g.addColorStop(.45,'#fca5a5');g.addColorStop(.46,'#0e7490');g.addColorStop(1,'#164e63');x.fillStyle=g;x.fillRect(0,0,w,h);x.fillStyle='#fff7ed';x.beginPath();x.arc(120,66,22,0,TAU);x.fill();x.fillStyle='#7c2d12';x.beginPath();x.moveTo(0,68);for(let i=0;i<=w;i+=6)x.lineTo(i,60-Math.abs(Math.sin(i*.05))*20);x.lineTo(w,68);x.fill();
  for(let i=0;i<20;i++){x.fillStyle='rgba(255,255,255,.45)';x.fillRect(90+Math.random()*60,72+i*3,10+Math.random()*30,1);}s.src=x.getImageData(0,0,w,h);s.out=document.createElement('canvas');s.out.width=w;s.out.height=h;s.R=[];s.onDown=(px,py)=>{s.R.push({x:px/W*w,y:py/H*h,t:s.t});if(s.R.length>5)s.R.shift();};},
 draw(ctx,s,t){const w=s.w,h=s.h,o=s.out.getContext('2d'),im=o.createImageData(w,h),S=s.src.data,D=im.data;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){let dx=0,dy=0;if(y>66){dx=Math.sin(y*.5+t*3)*1.2*(y-66)/80;dy=Math.sin(x*.3+t*2)*.6;}for(const R of s.R){const a=t-R.t,ddx=x-R.x,ddy=y-R.y,d=Math.hypot(ddx,ddy)+.01,wv=Math.sin(d*.7-a*9)*Math.exp(-a*1.1)*Math.exp(-Math.pow(d-a*28,2)/60)*5;dx+=ddx/d*wv;dy+=ddy/d*wv;}
   const sx=clamp(Math.round(x+dx),0,w-1),sy=clamp(Math.round(y+dy),0,h-1),i=(y*w+x)*4,j=(sy*w+sx)*4;D[i]=S[j];D[i+1]=S[j+1];D[i+2]=S[j+2];D[i+3]=255;}
  o.putImageData(im,0,0);ctx.imageSmoothingEnabled=true;ctx.drawImage(s.out,0,0,W,H);cap(ctx,'sprite.filters=[new PIXI.DisplacementFilter({sprite:map, scale:40})]',true);},
 code:`const map=PIXI.Sprite.from('assets/ripple-map.png');map.texture.source.addressMode='repeat';
const filter=new PIXI.DisplacementFilter({sprite:map,scale:40});
scene.filters=[filter];app.stage.addChild(map,scene);
app.ticker.add(()=>{map.x+=1;map.y+=.5;});`});
ex({t:'Bunnymark: how many sprites can you add?',d:'Click to add 500 bouncing sprites at a time. The counter and frame rate show how batching keeps it fast.',hint:'Click to add 500 sprites.',int:1,controls:[{type:'btn',l:'Add 500',pri:1,fn:s=>s.add(500)},{type:'btn',l:'Reset',fn:s=>{s.B=[];s.add(300);}}],
 init(s){s.B=[];s.add=n=>{for(let i=0;i<n;i++)s.B.push({x:30,y:30,vx:Math.random()*300+60,vy:Math.random()*200-100,c:Math.floor(Math.random()*6)});};s.add(300);s.onDown=()=>s.add(500);s.fps=60;},
 draw(ctx,s,t,dt){bg(ctx,'#f8fafc');s.fps=lerp(s.fps,1/dt,.05);const cols=['#4f46e5','#e11d48','#0d9488','#d97706','#7c3aed','#0284c7'];for(const b of s.B){b.vy+=900*dt;b.x+=b.vx*dt;b.y+=b.vy*dt;if(b.x>W-8){b.x=W-8;b.vx*=-1;}if(b.x<8){b.x=8;b.vx*=-1;}if(b.y>H-8){b.y=H-8;b.vy*=-.85;if(Math.random()<.5)b.vy-=Math.random()*400;}if(b.y<8){b.y=8;b.vy=0;}
  ctx.fillStyle=cols[b.c];ctx.fillRect(b.x-4,b.y-7,8,12);ctx.fillRect(b.x-4,b.y-11,2.5,5);ctx.fillRect(b.x+1.5,b.y-11,2.5,5);}
  ctx.fillStyle='rgba(255,255,255,.92)';rr(ctx,12,12,190,52,10);ctx.fill();text(ctx,s.B.length.toLocaleString()+' sprites',24,34,C.ink,16,'left',FONT,700);text(ctx,Math.round(s.fps)+' fps (this browser)',24,54,s.fps>50?C.teal:C.rose,12.5,'left',MONO);},
 code:`app.stage.on('pointerdown',()=>{for(let i=0;i<500;i++){const b=new PIXI.Sprite(bunnyTex);
  b.speedX=Math.random()*10;b.speedY=Math.random()*10-5;bunnies.push(b);container.addChild(b);}});
app.ticker.add(()=>bunnies.forEach(b=>{b.x+=b.speedX;b.y+=b.speedY;b.speedY+=.75;/* bounce */}));`});

lib('vanta','Vanta.js','fx','Animated 3D backgrounds for hero sections (waves, net, fog, topology) built on Three.js or p5.',{ik:'Vanta.js'});
ex({t:'WAVES',d:'Layered ocean waves in perspective, re-tinted for a light page. Pointer movement nudges the swell.',hint:'Move the pointer over the waves.',controls:[{type:'range',k:'h',l:'Wave height',min:.3,max:2,step:.1,v:1},{type:'select',k:'c',l:'Colour',v:'Indigo',opts:['Indigo','Teal','Rose']}],
 draw(ctx,s,t){const base={Indigo:230,Teal:178,Rose:345}[s.p.c];vgrad(ctx,hsl(base,60,97),hsl(base,50,88));const rows=34,cols=70,mx=s.hover?(s.mx/W-.5):0;
  for(let r=0;r<rows;r++){const k=.22+r/rows*1.1,by=H*.22+r/(rows-1)*H*.72,pts=[];for(let c=0;c<=cols;c++){const x=(c/cols-.5)*2.4,h=(Math.sin(x*3+t*1.2+r*.35+mx*3)*.12+Math.sin(x*7-t*.8+r*.6)*.06)*s.p.h;pts.push([W/2+x*k*W*.46,by-h*k*H*.55]);}
   ctx.beginPath();ctx.moveTo(pts[0][0],H);pts.forEach(p=>ctx.lineTo(p[0],p[1]));ctx.lineTo(pts[cols][0],H);ctx.closePath();ctx.fillStyle=hsl(base,45,96-r*.6);ctx.fill();ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.strokeStyle=hsl(base,65,75-r*1.2,.9);ctx.lineWidth=1+k;ctx.stroke();}
  text(ctx,'Hero section',40,90,hsl(base,50,25),40,'left','Georgia,serif',700);text(ctx,'VANTA.WAVES({ el:"#hero" })',40,118,hsl(base,30,45),14,'left',MONO);},
 code:`VANTA.WAVES({el:'#hero',THREE,mouseControls:true,touchControls:true,
  color:0xc7d2fe,shininess:30,waveHeight:15,waveSpeed:.8,zoom:.9});`});
ex({t:'NET',d:'A rotating 3D net of points connected by proximity, the classic Vanta NET effect, with the pointer bending the camera.',hint:'Move the pointer to tilt the net.',
 init(s){const r=rng(4);s.P=Array.from({length:130},()=>[(r()-.5)*4,(r()-.5)*2.4,(r()-.5)*2]);},
 draw(ctx,s,t){bg(ctx,'#fffbfb');const ry=t*.12+(s.hover?(s.mx/W-.5):0),rx=.2+(s.hover?(s.my/H-.5)*.6:0),R=s.P.map(p=>pr(rot(p,ry,rx),160,5));
  for(let i=0;i<R.length;i++)for(let j=i+1;j<R.length;j++){const d=Math.hypot(s.P[i][0]-s.P[j][0],s.P[i][1]-s.P[j][1],s.P[i][2]-s.P[j][2]);if(d<.8){ctx.strokeStyle='rgba(225,29,72,'+(1-d/.8)*.45*clamp((R[i][2]+2)/3,.2,1)+')';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(R[i][0],R[i][1]);ctx.lineTo(R[j][0],R[j][1]);ctx.stroke();}}
  R.forEach(p=>circle(ctx,p[0],p[1],2.4*p[3],'#e11d48'));cap(ctx,'VANTA.NET({ el:"#hero", color:0xe11d48, points:13, maxDistance:20 })');},
 code:`VANTA.NET({el:'#hero',THREE,color:0xe11d48,backgroundColor:0xfffbfb,points:13,maxDistance:20,spacing:16});`});
ex({t:'TOPOLOGY',d:'Flowing contour lines traced by thousands of particles over a moving noise field, like Vanta’s p5-based TOPOLOGY.',
 init(s){s.P=Array.from({length:1600},()=>({x:Math.random()*W,y:Math.random()*H}));s.clr=true;},
 draw(ctx,s,t){if(s.clr){bg(ctx,'#f7fdf9');s.clr=false;}ctx.fillStyle='rgba(247,253,249,.06)';ctx.fillRect(0,0,W,H);ctx.fillStyle='rgba(13,148,136,.35)';for(const p of s.P){const n=fbm(p.x*.006+t*.03,p.y*.006),a=n*TAU*3;p.x+=Math.cos(a)*1.3;p.y+=Math.sin(a)*1.3;if(p.x<0||p.x>W||p.y<0||p.y>H||Math.random()<.004){p.x=Math.random()*W;p.y=Math.random()*H;}ctx.fillRect(p.x,p.y,1.4,1.4);}
  text(ctx,'Topology',40,H-60,'#115e59',34,'left','Georgia,serif',700);},
 code:`VANTA.TOPOLOGY({el:'#hero',p5,color:0x0d9488,backgroundColor:0xf7fdf9});`});

lib('confetti','canvas-confetti','fx','A tiny, dependency-free confetti cannon: bursts, side cannons, stars, fireworks and custom shapes.',{isNew:true});
ex({t:'Confetti presets & click-to-burst',d:'Physics-based confetti with drift, tilt, wobble and gravity. Choose a preset, or click anywhere to fire from that spot.',hint:'Click anywhere · or press a preset.',int:1,
 controls:[{type:'btn',l:'🎉 Basic',pri:1,fn:s=>s.fire(W/2,H*.7,90,70,100)},{type:'btn',l:'Side cannons',fn:s=>{s.fire(0,H*.8,60,50,60);s.fire(W,H*.8,120,50,60);}},{type:'btn',l:'★ Stars',fn:s=>s.fire(W/2,H/2,90,360,70,'star')},{type:'btn',l:'Fireworks',fn:s=>{s.fw=3;}},{type:'btn',l:'School pride',fn:s=>{s.pride=2.5;}}],
 init(s){s.P=[];s.fw=0;s.pride=0;s.fire=(x,y,ang,spread,n,shape)=>{for(let i=0;i<n;i++){const a=(ang+(Math.random()-.5)*spread)*D2R,v=8+Math.random()*9;s.P.push({x,y,vx:Math.cos(a)*v,vy:-Math.sin(a)*v,c:PAL[Math.floor(Math.random()*8)],w:6+Math.random()*6,tilt:Math.random()*TAU,wob:Math.random()*TAU,l:1,sh:shape||(Math.random()<.5?'sq':'ci')});}};s.onDown=(x,y)=>s.fire(x,y,90,80,60);s.fire(W/2,H*.75,90,70,120);},
 draw(ctx,s,t,dt){paper(ctx);if(!s.hover&&s.P.length<5&&Math.random()<.02)s.fire(120+Math.random()*480,H*.75,90,70,90);if(s.fw>0){s.fw-=dt;if(Math.random()<.08)s.fire(80+Math.random()*560,120+Math.random()*150,90,360,50);}if(s.pride>0){s.pride-=dt;s.P.push({x:0,y:H*.6,vx:6+Math.random()*4,vy:-6-Math.random()*4,c:'#4f46e5',w:9,tilt:0,wob:0,l:1,sh:'sq'});s.P.push({x:W,y:H*.6,vx:-6-Math.random()*4,vy:-6-Math.random()*4,c:'#e11d48',w:9,tilt:0,wob:0,l:1,sh:'sq'});}
  for(let i=s.P.length-1;i>=0;i--){const p=s.P[i];p.vx*=.95;p.vy=p.vy*.95+.32;p.x+=p.vx;p.y+=p.vy;p.wob+=.12;p.tilt+=.1;p.l-=dt*.32;if(p.l<=0||p.y>H+20){s.P.splice(i,1);continue;}ctx.save();ctx.translate(p.x+Math.cos(p.wob)*3,p.y);ctx.rotate(p.tilt);ctx.scale(1,Math.cos(p.wob));ctx.globalAlpha=clamp(p.l*1.6,0,1);ctx.fillStyle=p.c;
   if(p.sh==='star'){ctx.beginPath();for(let k=0;k<10;k++){const a=k*Math.PI/5,r=k%2?p.w*.4:p.w;ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r);}ctx.fill();}else if(p.sh==='ci'){ctx.beginPath();ctx.arc(0,0,p.w/2,0,TAU);ctx.fill();}else ctx.fillRect(-p.w/2,-p.w/3,p.w,p.w*.66);ctx.restore();}
  text(ctx,s.P.length+' pieces',W-14,24,C.mut,12,'right',MONO);},
 code:`confetti({particleCount:100,spread:70,origin:{y:.7}});
confetti({particleCount:50,angle:60,spread:55,origin:{x:0}});            // left cannon
confetti({shapes:['star'],colors:['#FFE400','#FDFFB8'],spread:360,ticks:80});
canvas.onclick=e=>confetti({origin:{x:e.clientX/innerWidth,y:e.clientY/innerHeight}});`});
ex({t:'Continuous snow',d:'The same engine run continuously with gravity flipped low, drift and a tiny scalar for a calm snowfall over a winter card.',
 init(s){s.P=[];},
 draw(ctx,s,t,dt){vgrad(ctx,'#e0f2fe','#f8fafc');ctx.fillStyle='#ffffff';ctx.beginPath();ctx.moveTo(0,H);for(let x=0;x<=W;x+=20)ctx.lineTo(x,H-60-Math.sin(x*.012)*20);ctx.lineTo(W,H);ctx.fill();
  [[150,330],[560,320],[620,345]].forEach(([x,y])=>{poly(ctx,[[x,y-90],[x-36,y],[x+36,y]],'#0f766e');poly(ctx,[[x,y-110],[x-26,y-40],[x+26,y-40]],'#14b8a6');});text(ctx,'Season’s greetings',W/2,150,'#0c4a6e',38,'center','Georgia,serif',700);
  for(let i=0;i<2;i++)s.P.push({x:Math.random()*W,y:-10,r:1.5+Math.random()*3.5,v:20+Math.random()*40,ph:Math.random()*TAU});for(let i=s.P.length-1;i>=0;i--){const p=s.P[i];p.y+=p.v*dt;p.x+=Math.sin(t+p.ph)*.4;if(p.y>H){s.P.splice(i,1);continue;}circle(ctx,p.x,p.y,p.r,'rgba(255,255,255,.95)','rgba(14,116,144,.25)',.8);}},
 code:`(function frame(){confetti({particleCount:1,startVelocity:0,ticks:400,gravity:.3,
  origin:{x:Math.random(),y:Math.random()*.2-.2},colors:['#ffffff'],shapes:['circle'],scalar:.8,drift:.4});
  requestAnimationFrame(frame);})();`});

lib('granim','Granim.js','fx','Fluid, interactive gradient animations between named states, on their own or blended over images.',{isNew:true});
ex({t:'Gradient states with transitions',d:'Three named gradient states; the canvas cross-fades through each one, and the buttons jump to a state with an eased transition.',controls:[{type:'seg',k:'st',v:'default-state',opts:['default-state','dark-state','sunset-state']},{type:'toggle',k:'auto',l:'Loop',v:true}],
 init(s){s.S={'default-state':[['#ff9a9e','#fad0c4'],['#a1c4fd','#c2e9fb'],['#d4fc79','#96e6a1']],'dark-state':[['#4f46e5','#0ea5e9'],['#7c3aed','#db2777']],'sunset-state':[['#f97316','#fde68a'],['#e11d48','#f59e0b']]};s.i=0;s.k=0;s.from=null;s.cur=s.S['default-state'][0];},onCtl(s,k){if(k==='st'){s.i=0;s.k=0;s.from=s.cur;}},
 draw(ctx,s,t,dt){const L=s.S[s.p.st];if(s.p.auto)s.k+=dt/2.5;else s.k=Math.min(s.k+dt/1.2,1);if(s.k>=1&&s.p.auto){s.k=0;s.from=null;s.i=(s.i+1)%L.length;}const a=s.from||L[s.i],b=s.from?L[0]:L[(s.i+1)%L.length],e=ease(clamp(s.k,0,1));if(s.from&&s.k>=1){s.from=null;s.k=0;}
  const c0=mixHex(a[0],b[0],e),c1=mixHex(a[1],b[1],e);s.cur=[a[0],a[1]];const g=ctx.createLinearGradient(0,0,W,H);g.addColorStop(0,c0);g.addColorStop(1,c1);ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
  ctx.fillStyle='rgba(255,255,255,.22)';rr(ctx,W/2-200,H/2-80,400,160,24);ctx.fill();text(ctx,s.p.st,W/2,H/2-6,'#fff',30,'center',FONT,700);text(ctx,c0+' → '+c1,W/2,H/2+28,'rgba(255,255,255,.9)',14,'center',MONO);},
 code:`const granim=new Granim({element:'#canvas',direction:'diagonal',isPausedWhenNotInView:true,
  states:{'default-state':{gradients:[['#ff9a9e','#fad0c4'],['#a1c4fd','#c2e9fb']]},
          'dark-state':{gradients:[['#4f46e5','#0ea5e9'],['#7c3aed','#db2777']],transitionSpeed:1200}}});
button.onclick=()=>granim.changeState('dark-state');`});
ex({t:'Gradient blended over an image',d:'An animated radial gradient blended onto a photo with a choice of blending modes, as Granim does with its image option.',controls:[{type:'select',k:'bm',l:'Blend',v:'multiply',opts:['multiply','screen','overlay','color','soft-light','hue']}],
 init(s){const c=document.createElement('canvas');c.width=W;c.height=H;const x=c.getContext('2d');x.fillStyle='#e7e5e4';x.fillRect(0,0,W,H);for(let i=0;i<14;i++){const bx=i*55,bh=120+((i*73)%160);x.fillStyle=i%2?'#57534e':'#78716c';x.fillRect(bx,H-bh,50,bh);for(let w=0;w<bh/20;w++)for(let v=0;v<3;v++){x.fillStyle=Math.random()<.4?'#fde68a':'#a8a29e';x.fillRect(bx+6+v*15,H-bh+8+w*20,9,11);}}x.fillStyle='#d6d3d1';x.beginPath();x.arc(560,90,40,0,TAU);x.fill();s.img=c;},
 draw(ctx,s,t){ctx.drawImage(s.img,0,0);ctx.save();ctx.globalCompositeOperation=s.p.bm;const g=ctx.createRadialGradient(W/2+Math.cos(t*.5)*200,H/2+Math.sin(t*.7)*100,20,W/2,H/2,520);g.addColorStop(0,hsl((t*30)%360,90,60));g.addColorStop(1,hsl((t*30+140)%360,85,45));ctx.fillStyle=g;ctx.fillRect(0,0,W,H);ctx.restore();cap(ctx,'image:{source:"city.jpg", blendingMode:"'+s.p.bm+'"}');},
 code:`new Granim({element:'#canvas',direction:'radial',
  image:{source:'assets/city.jpg',blendingMode:'multiply',stretchMode:['stretch','stretch']},
  states:{'default-state':{gradients:[['#ef4444','#8b5cf6'],['#06b6d4','#f59e0b']]}}});`});
