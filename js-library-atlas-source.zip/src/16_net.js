/* ===================== Diagrams & Networks ===================== */
function forceStep(N,E,o){o=o||{};const rep=o.rep||5200,len=o.len||95,k=o.k||.03,cx=o.cx||W/2,cy=o.cy||H/2;for(let i=0;i<N.length;i++)for(let j=i+1;j<N.length;j++){const dx=N[j].x-N[i].x,dy=N[j].y-N[i].y,d2=dx*dx+dy*dy+80,d=Math.sqrt(d2),f=rep/d2;N[i].vx-=dx/d*f;N[i].vy-=dy/d*f;N[j].vx+=dx/d*f;N[j].vy+=dy/d*f;}
 for(const e of E){const a=N[e[0]],b=N[e[1]],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1,f=(d-len)*k;a.vx+=dx/d*f;a.vy+=dy/d*f;b.vx-=dx/d*f;b.vy-=dy/d*f;}
 N.forEach(n=>{if(n.fix)return;n.vx+=(cx-n.x)*.004;n.vy+=(cy-n.y)*.004;n.vx*=.82;n.vy*=.82;n.x=clamp(n.x+n.vx,30,W-30);n.y=clamp(n.y+n.vy,30,H-30);});}
function nodeBox(ctx,x,y,label,o){o=o||{};ctx.font=(o.w||500)+' 13.5px '+FONT;const w=Math.max(o.minW||0,ctx.measureText(label).width+28),h=o.h||36;ctx.save();ctx.shadowColor='rgba(0,0,0,.07)';ctx.shadowBlur=8;ctx.shadowOffsetY=2;ctx.fillStyle=o.fill||'#fff';rr(ctx,x-w/2,y-h/2,w,h,o.r===undefined?9:o.r);ctx.fill();ctx.restore();ctx.strokeStyle=o.stroke||C.line;ctx.lineWidth=o.lw||1.5;rr(ctx,x-w/2,y-h/2,w,h,o.r===undefined?9:o.r);ctx.stroke();text(ctx,label,x,y+5,o.col||C.ink,13.5,'center',FONT,o.w||500);return w;}

lib('mermaid','Mermaid.js','net','Diagrams from plain text: flowcharts, sequence, Gantt, state, class, ER, mind maps and Git graphs.',{ik:'Mermaid.js'});
ex({t:'Flowchart with data flowing along edges',d:'flowchart TD with a decision diamond and a loop back. Tokens travel along each edge to show execution flow.',
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const N={a:[360,40,'Start','p'],b:[360,112,'Load imagery','r'],c:[360,212,'Cloud < 20%?','d'],d:[360,314,'Compute NDVI','r'],e:[590,212,'Pick another scene','r'],f:[360,400,'Export map','p']};
  const E=[[[360,58],[360,94]],[[360,130],[360,172]],[[360,252],[360,296]],[[460,212],[512,212]],[[590,194],[590,112],[438,112]],[[360,332],[360,382]]];
  for(const e of E){ctx.strokeStyle='#a8a29e';ctx.lineWidth=2;ctx.beginPath();e.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.stroke();const a=e[e.length-1],b=e[e.length-2];arrow(ctx,b[0]+(a[0]-b[0])*.9,b[1]+(a[1]-b[1])*.9,a[0],a[1],'#a8a29e',2,9);}
  text(ctx,'yes',372,278,C.teal,13,'left',FONT,600);text(ctx,'no',474,202,C.rose,13,'left',FONT,600);
  for(const k in N){const[x,y,l,ty]=N[k];if(ty=='d'){poly(ctx,[[x,y-40],[x+100,y],[x,y+40],[x-100,y]],'#eef2ff','#6366f1',2);text(ctx,l,x,y+5,'#312e81',13.5,'center',FONT,600);}else nodeBox(ctx,x,y,l,{r:ty=='p'?18:8,fill:ty=='p'?'#ecfdf5':'#fff',stroke:ty=='p'?'#10b981':'#c7d2fe',minW:150});}
  E.forEach((e,i)=>{const q=polyPt(e,((t*.45+i*.17)%1));circle(ctx,q[0],q[1],4.5,'#f59e0b');});cap(ctx,'flowchart TD; A([Start])-->B[Load imagery]-->C{Cloud < 20%?}');},
 code:`<pre class="mermaid">
flowchart TD
  A([Start]) --> B[Load imagery]
  B --> C{Cloud < 20%?}
  C -- yes --> D[Compute NDVI] --> F([Export map])
  C -- no --> E[Pick another scene] --> B
</pre>
<script>mermaid.initialize({startOnLoad:true,theme:'neutral'});</script>`});
ex({t:'Sequence diagram, animated step by step',d:'Participants, lifelines, activation bars, sync and async messages and a note, revealed one message at a time.',controls:[{type:'btn',l:'↻ Replay',fn:s=>{s.t0=s.t;}}],
 init(s){s.t0=0;},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const P=['Browser','App','Worker','IndexedDB'],X=i=>110+i*167,M=[[0,1,'click "Analyse"',0],[1,2,'postMessage(scene)',1],[2,3,'get(tile)',0],[3,2,'ArrayBuffer',2],[2,1,'NDVI result',2],[1,0,'render chart',2]],T=t-s.t0,shown=Math.min(M.length,Math.floor(T/.9)+1);
  P.forEach((p,i)=>{line(ctx,X(i),62,X(i),H-40,'#d6d3cd',1.5,[5,5]);nodeBox(ctx,X(i),40,p,{w:600,minW:110,fill:'#eef2ff',stroke:'#a5b4fc'});});
  const act=[[1,0,5],[2,1,4],[3,2,3]];act.forEach(([p,a,b])=>{if(shown>a){const y0=88+a*52,y1=88+Math.min(b,shown-1)*52+10;ctx.fillStyle='#fff';ctx.strokeStyle='#818cf8';ctx.lineWidth=1.5;ctx.fillRect(X(p)-6,y0,12,y1-y0);ctx.strokeRect(X(p)-6,y0,12,y1-y0);}});
  M.slice(0,shown).forEach(([a,b,l,ty],i)=>{const y=96+i*52,k=i===shown-1?easeOut(clamp((T-i*.9)/.5,0,1)):1,x1=X(a)+(b>a?6:-6),x2=lerp(x1,X(b)+(b>a?-6:6),k);ctx.setLineDash(ty===2?[6,4]:[]);arrow(ctx,x1,y,x2,y,ty===1?C.teal:C.ink2,1.8,9);ctx.setLineDash([]);if(k>.6)text(ctx,l,(X(a)+X(b))/2,y-8,C.ink,12.5,'center',FONT,500);});
  if(shown>=4){ctx.fillStyle='#fef9c3';ctx.strokeStyle='#eab308';rr(ctx,X(2)+20,250,170,40,6);ctx.fill();ctx.stroke();text(ctx,'Note: runs off the main',X(2)+30,267,C.ink2,12);text(ctx,'thread, UI stays smooth',X(2)+30,283,C.ink2,12);}
  cap(ctx,'sequenceDiagram; Browser->>App: click; App-)Worker: postMessage');},
 code:`sequenceDiagram
  participant B as Browser
  B->>App: click "Analyse"
  activate App
  App-)Worker: postMessage(scene)
  Worker->>IndexedDB: get(tile)
  IndexedDB-->>Worker: ArrayBuffer
  Note right of Worker: runs off the main thread
  Worker-->>App: NDVI result
  App-->>B: render chart`});
ex({t:'Gantt chart with sections & milestones',d:'Tasks grouped in sections, dependencies, a critical task, milestones and a "today" marker.',hint:'Hover a task.',int:1,
 init(s){s.T=[['Research','Literature review',0,8,0],['Research','Field sampling',5,10,0],['Research','Data cleaning',12,6,0],['Build','Prototype viewer',14,12,1],['Build','Offline packaging',22,7,0],['Build','User testing',29,6,0],['Launch','Docs & tutorials',30,8,0],['Launch','Release',38,0,2]];},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const x0=180,x1=W-20,days=42,X=d=>x0+d/days*(x1-x0),secs=['Research','Build','Launch'],cols=['#6366f1','#0d9488','#e11d48'];
  for(let d=0;d<=days;d+=7){line(ctx,X(d),30,X(d),H-30,'#ece9e3',1);text(ctx,'Wk '+(d/7+1),X(d)+4,24,C.mut,11);}let hv=null;
  s.T.forEach((tk,i)=>{const y=46+i*44,si=secs.indexOf(tk[0]);if(i===0||s.T[i-1][0]!==tk[0]){ctx.fillStyle=rgba(cols[si],.05);ctx.fillRect(0,y-6,W,s.T.filter(q=>q[0]===tk[0]).length*44);text(ctx,tk[0],14,y+20,cols[si],12,'left',FONT,700);}
   text(ctx,tk[1],x0-10,y+20,C.ink2,12.5,'right');const g=easeOut(clamp(t/1.2-i*.06,0,1));if(tk[4]===2){ctx.save();ctx.translate(X(tk[2]),y+15);ctx.rotate(Math.PI/4);ctx.fillStyle=cols[si];ctx.fillRect(-8,-8,16,16);ctx.restore();return;}
   const bx=X(tk[2]),bw=(X(tk[2]+tk[3])-bx)*g;ctx.fillStyle=tk[4]?'#fff1f2':rgba(cols[si],.15);rr(ctx,bx,y,bw,30,6);ctx.fill();ctx.strokeStyle=tk[4]?'#e11d48':cols[si];ctx.lineWidth=tk[4]?2:1.2;rr(ctx,bx,y,bw,30,6);ctx.stroke();
   if(s.hover&&s.mx>bx&&s.mx<bx+bw&&s.my>y&&s.my<y+30)hv=tk;});
  const td=X(24);line(ctx,td,30,td,H-20,'#e11d48',1.5,[4,3]);badge(ctx,'today',td-24,H-34,'#ffe4e6','#be123c');if(hv)tooltip(ctx,s.mx,s.my,[hv[1],'day '+hv[2]+' → '+(hv[2]+hv[3])+(hv[4]?' · critical':'')]);},
 code:`gantt
  dateFormat YYYY-MM-DD
  section Research
    Literature review :a1, 2026-01-05, 8d
    Field sampling    :a2, after a1, 10d
  section Build
    Prototype viewer  :crit, b1, 2026-01-19, 12d
  section Launch
    Release           :milestone, m1, 2026-02-16, 0d`});
ex({t:'Git graph: branches, commits & merges',d:'main, develop and a feature branch with commits, a merge and a release tag, growing commit by commit.',controls:[{type:'btn',l:'↻ Replay',fn:s=>{s.t0=s.t;}}],
 init(s){s.t0=0;s.C=[[0,0,'init'],[1,0,'setup'],[2,1,'dev: api'],[3,2,'feat: map'],[4,1,'dev: ui'],[5,2,'feat: tiles'],[6,1,'merge feature',[2,5]],[7,0,'merge develop',[1,6]],[8,0,'v1.0',null,'tag'],[9,1,'dev: next']];s.br=['main','develop','feature/map'];},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const cols=['#4f46e5','#0d9488','#d97706'],Y=b=>90+b*100,X=i=>110+i*62,n=Math.min(s.C.length,Math.floor((t-s.t0)/.45)+1);s.br.forEach((b,i)=>text(ctx,b,14,Y(i)+5,cols[i],13,'left',MONO,700));
  const last={};const seg=(x1,y1,x2,y2,c)=>{ctx.strokeStyle=c;ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(x1,y1);if(y1===y2)ctx.lineTo(x2,y2);else ctx.bezierCurveTo((x1+x2)/2,y1,(x1+x2)/2,y2,x2,y2);ctx.stroke();};
  s.C.slice(0,n).forEach(([i,b,l,m,tag])=>{const x=X(i),y=Y(b);if(last[b]!==undefined)seg(X(last[b]),Y(b),x,y,cols[b]);else if(b>0){const pb=b-1,pi=last[pb]!==undefined?last[pb]:0;seg(X(pi),Y(pb),x,y,cols[b]);}if(m)seg(X(last[m[0]]!==undefined?last[m[0]]:i-1),Y(m[0]),x,y,cols[m[0]]);last[b]=i;});
  s.C.slice(0,n).forEach(([i,b,l,m,tag],k)=>{const x=X(i),y=Y(b),pop=k===n-1?backOut(clamp((t-s.t0-k*.45)/.35,0,1)):1;circle(ctx,x,y,10*pop,'#fff',cols[b],4);if(m)circle(ctx,x,y,4,cols[b]);ctx.save();ctx.translate(x+4,y+24);ctx.rotate(.5);text(ctx,l,0,0,C.mut,11.5,'left',MONO);ctx.restore();if(tag)badge(ctx,'🏷 '+l,x-24,y-42,'#fef3c7','#92400e');});},
 code:`gitGraph
  commit id:"init"
  commit id:"setup"
  branch develop
  commit id:"dev: api"
  branch feature/map
  commit id:"feat: map"
  checkout develop
  merge feature/map
  checkout main
  merge develop tag:"v1.0"`});

lib('cytoscape','Cytoscape.js','net','Graph theory and network visualisation: layouts, selectors, styles and built-in algorithms like Dijkstra and PageRank.',{ik:'Cytoscape.js'});
const GENES=['TP53','MDM2','ATM','CHEK2','BRCA1','BRCA2','RAD51','CDK2','CCNE1','RB1','E2F1','MYC','BAX','BCL2','CASP3','PTEN','AKT1','MTOR'],GEDGE=[[0,1],[0,2],[2,3],[3,0],[2,4],[4,5],[5,6],[4,6],[0,12],[12,14],[13,12],[0,7],[7,8],[7,9],[9,10],[10,11],[11,0],[15,16],[16,17],[15,0]];
ex({t:'Gene interaction network',d:'A force-directed (cose) layout of p53 pathway genes; node size encodes degree. Drag genes and hover to highlight neighbours.',hint:'Drag nodes · hover to highlight.',int:1,
 init(s){const r=rng(4);s.n=GENES.map(n=>({n,x:W/2+(r()-.5)*300,y:H/2+(r()-.5)*200,vx:0,vy:0,d:0}));GEDGE.forEach(e=>{s.n[e[0]].d++;s.n[e[1]].d++;});s.dr=-1;
  s.onDown=(x,y)=>{s.dr=s.n.findIndex(n=>Math.hypot(n.x-x,n.y-y)<26);if(s.dr>=0)s.n[s.dr].fix=true;};s.onMove=(x,y)=>{if(s.down&&s.dr>=0){s.n[s.dr].x=x;s.n[s.dr].y=y;}};s.onUp=()=>{if(s.dr>=0)s.n[s.dr].fix=false;s.dr=-1;};},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');forceStep(s.n,GEDGE);forceStep(s.n,GEDGE);const N=s.n;let hv=s.dr;if(hv<0&&s.hover)N.forEach((n,i)=>{if(Math.hypot(n.x-s.mx,n.y-s.my)<24)hv=i;});const nb=new Set([hv]);GEDGE.forEach(e=>{if(e[0]==hv)nb.add(e[1]);if(e[1]==hv)nb.add(e[0]);});
  for(const e of GEDGE){const on=hv<0||e[0]==hv||e[1]==hv;line(ctx,N[e[0]].x,N[e[0]].y,N[e[1]].x,N[e[1]].y,on?(hv>=0?'#4f46e5':'#c7c2ba'):'#f1efea',on&&hv>=0?3:1.8);}
  N.forEach((n,i)=>{const on=hv<0||nb.has(i);ctx.globalAlpha=on?1:.3;circle(ctx,n.x,n.y,12+n.d*2,hsl(250-n.d*22,65,62),'#fff',3);text(ctx,n.n,n.x,n.y+30+n.d*1.6,C.ink,12.5,'center',FONT,600);ctx.globalAlpha=1;});cap(ctx,'cy.layout({name:"cose"}).run(); cy.on("tap","node",…)');},
 code:`const cy=cytoscape({container:el,elements,
  style:[{selector:'node',style:{label:'data(id)',width:'mapData(degree,1,6,24,48)',height:'mapData(degree,1,6,24,48)','background-color':'#818cf8'}},
         {selector:'.faded',style:{opacity:.2}}],layout:{name:'cose'}});
cy.on('mouseover','node',e=>{cy.elements().addClass('faded');e.target.closedNeighborhood().removeClass('faded');});`});
ex({t:'Dijkstra shortest path',d:'A weighted graph of 20 stations. Click a start and an end station; cy.elements().dijkstra() finds the cheapest route and it lights up hop by hop.',hint:'Click two nodes: start, then end.',int:1,
 init(s){const r=rng(13);s.N=[];for(let i=0;i<20;i++)s.N.push({x:70+(i%5)*145+(r()-.5)*70,y:60+Math.floor(i/5)*105+(r()-.5)*50});s.E=[];s.N.forEach((a,i)=>{s.N.map((b,j)=>[j,Math.hypot(a.x-b.x,a.y-b.y)]).filter(q=>q[0]!==i).sort((x,y)=>x[1]-y[1]).slice(0,3).forEach(([j,d])=>{if(!s.E.some(e=>(e[0]===j&&e[1]===i)||(e[0]===i&&e[1]===j)))s.E.push([i,j,Math.round(d/10)]);});});
  s.src=0;s.dst=19;s.path=[];s.pt=0;s.calc=()=>{const D=s.N.map(()=>1e9),P=s.N.map(()=>-1),Q=new Set(s.N.map((_,i)=>i));D[s.src]=0;while(Q.size){let u=-1;Q.forEach(q=>{if(u<0||D[q]<D[u])u=q;});Q.delete(u);s.E.forEach(([a,b,w])=>{const v=a===u?b:b===u?a:-1;if(v>=0&&Q.has(v)&&D[u]+w<D[v]){D[v]=D[u]+w;P[v]=u;}});}const p=[];for(let v=s.dst;v>=0;v=P[v])p.unshift(v);s.path=p;s.cost=D[s.dst];s.pt=s.t;};s.calc();s.pick=0;
  s.onDown=(x,y)=>{const i=s.N.findIndex(n=>Math.hypot(n.x-x,n.y-y)<18);if(i<0)return;if(s.pick===0){s.src=i;s.path=[];s.pick=1;}else{s.dst=i;s.pick=0;s.calc();}};},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const on=new Set(),k=Math.floor((t-s.pt)/.18);s.path.forEach((v,i)=>{if(i<k&&i>0)on.add(Math.min(v,s.path[i-1])+'-'+Math.max(v,s.path[i-1]));});
  s.E.forEach(([a,b,w])=>{const A=s.N[a],B=s.N[b],o=on.has(Math.min(a,b)+'-'+Math.max(a,b));line(ctx,A.x,A.y,B.x,B.y,o?'#e11d48':'#d6d3cd',o?5:2);ctx.fillStyle='#fcfcfd';const mx=(A.x+B.x)/2,my=(A.y+B.y)/2;circle(ctx,mx,my,9,'#fcfcfd');text(ctx,String(w),mx,my+4,o?'#e11d48':C.mut,10.5,'center',MONO,600);});
  s.N.forEach((n,i)=>{const isS=i===s.src,isD=i===s.dst&&s.pick===0;circle(ctx,n.x,n.y,isS||isD?15:11,isS?'#4f46e5':isD?'#e11d48':s.path.includes(i)?'#fda4af':'#fff',isS||isD?'#fff':'#78716c',2.5);text(ctx,String.fromCharCode(65+i),n.x,n.y+4,isS||isD?'#fff':C.ink,11,'center',FONT,700);});
  ctx.fillStyle='rgba(255,255,255,.92)';rr(ctx,W-220,H-56,206,42,8);ctx.fill();text(ctx,s.pick?'now click the destination…':'route '+s.path.map(i=>String.fromCharCode(65+i)).join('→'),W-210,H-38,C.ink,12,'left',MONO);if(!s.pick)text(ctx,'total cost '+s.cost,W-210,H-21,'#e11d48',12,'left',MONO,700);},
 code:`const res=cy.elements().dijkstra({root:'#A',weight:e=>e.data('weight')});
const path=res.pathTo(cy.$('#T'));
path.addClass('highlighted');console.log('cost',res.distanceTo(cy.$('#T')));`});
ex({t:'Layout switcher (animated)',d:'The same 26-node tree laid out as grid, circle, concentric (by degree), breadth-first and cose, with animated transitions between them.',controls:[{type:'seg',k:'L',v:'cose',opts:['grid','circle','concentric','breadthfirst','cose']}],
 init(s){const r=rng(3);s.N=[{p:-1}];for(let i=1;i<26;i++)s.N.push({p:Math.floor(r()*Math.min(i,9))});s.N.forEach(n=>{n.d=0;n.x=W/2;n.y=H/2;});s.E=[];s.N.forEach((n,i)=>{if(n.p>=0){s.E.push([n.p,i]);s.N[n.p].d++;n.d++;}});
  const lay={};lay.grid=s.N.map((_,i)=>[70+(i%7)*96,60+Math.floor(i/7)*100]);lay.circle=s.N.map((_,i)=>[W/2+Math.cos(i/26*TAU)*190,H/2+Math.sin(i/26*TAU)*170]);
  const byd=s.N.map((n,i)=>[i,n.d]).sort((a,b)=>b[1]-a[1]);lay.concentric=new Array(26);byd.forEach(([i],k)=>{const ring=k<1?0:k<7?1:2,cnt=ring===0?1:ring===1?6:19,idx=ring===0?0:ring===1?k-1:k-7,R=[0,95,185][ring];lay.concentric[i]=[W/2+Math.cos(idx/cnt*TAU)*R,H/2+Math.sin(idx/cnt*TAU)*R*.92];});
  const lv=s.N.map(()=>0);s.N.forEach((n,i)=>{if(n.p>=0)lv[i]=lv[n.p]+1;});const byL={};lv.forEach((l,i)=>(byL[l]=byL[l]||[]).push(i));lay.breadthfirst=new Array(26);Object.keys(byL).forEach(l=>byL[l].forEach((i,k)=>{lay.breadthfirst[i]=[(k+1)*W/(byL[l].length+1),50+l*85];}));
  const F=s.N.map((_,i)=>({x:W/2+Math.cos(i)*100,y:H/2+Math.sin(i)*100,vx:0,vy:0}));for(let k=0;k<300;k++)forceStep(F,s.E,{rep:3000,len:60});lay.cose=F.map(f=>[f.x,f.y]);s.lay=lay;},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const T=s.lay[s.p.L];s.N.forEach((n,i)=>{n.x=lerp(n.x,T[i][0],.1);n.y=lerp(n.y,T[i][1],.1);});s.E.forEach(([a,b])=>line(ctx,s.N[a].x,s.N[a].y,s.N[b].x,s.N[b].y,'#c7c2ba',1.6));
  s.N.forEach((n,i)=>circle(ctx,n.x,n.y,7+n.d*1.6,i===0?'#e11d48':hsl(170+n.d*15,55,48),'#fff',2.5));cap(ctx,'cy.layout({ name:"'+s.p.L+'", animate:true, animationDuration:600 }).run()');},
 code:`document.querySelectorAll('[data-layout]').forEach(b=>b.onclick=()=>
  cy.layout({name:b.dataset.layout,animate:true,animationDuration:600,
    concentric:n=>n.degree(),roots:'#root'}).run());`});

lib('sigma','Sigma.js','net','WebGL rendering of very large graphs (with graphology): tens of thousands of nodes with smooth interaction.',{ik:'Sigma.js'});
ex({t:'2,400 nodes in six communities',d:'A large graph with 3,000 edges rendered in one pass, slowly rotating. Hover a node to see its label and neighbourhood.',hint:'Hover nodes · use the wheel to zoom.',int:1,
 init(s){const r=rng(13);s.N=[];const cen=[];for(let c=0;c<6;c++){const a=c/6*TAU;cen.push([Math.cos(a)*150,Math.sin(a)*105]);}for(let i=0;i<2400;i++){const c=i%6;s.N.push({c,x:cen[c][0]+gauss(r)*52,y:cen[c][1]+gauss(r)*40,d:0});}s.E=[];for(let i=0;i<3000;i++){const a=Math.floor(r()*2400),b=r()<.9?(Math.floor(r()*400)*6+s.N[a].c)%2400:Math.floor(r()*2400);s.E.push([a,b]);s.N[a].d++;s.N[b].d++;}s.z=1;s.onWheel=dy=>{s.z=clamp(s.z*(1-dy*.0015),.6,4);};},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const a=t*.05,co=Math.cos(a),si=Math.sin(a),X=new Float32Array(2400),Y=new Float32Array(2400);s.N.forEach((n,i)=>{X[i]=W/2+(n.x*co-n.y*si)*s.z;Y[i]=H/2+(n.x*si+n.y*co)*s.z;});
  let hv=-1;if(s.hover){let bd=8;for(let i=0;i<2400;i++){const d=Math.abs(X[i]-s.mx)+Math.abs(Y[i]-s.my);if(d<bd){bd=d;hv=i;}}}
  ctx.strokeStyle='rgba(120,113,108,.07)';ctx.lineWidth=1;ctx.beginPath();for(const e of s.E){ctx.moveTo(X[e[0]],Y[e[0]]);ctx.lineTo(X[e[1]],Y[e[1]]);}ctx.stroke();
  for(let c=0;c<6;c++){ctx.fillStyle=PAL[c];for(let i=c;i<2400;i+=6){const sz=(1.6+Math.min(4,s.N[i].d*.35))*Math.sqrt(s.z);ctx.fillRect(X[i]-sz/2,Y[i]-sz/2,sz,sz);}}
  if(hv>=0){s.E.forEach(e=>{if(e[0]===hv||e[1]===hv){line(ctx,X[e[0]],Y[e[0]],X[e[1]],Y[e[1]],PAL[s.N[hv].c],1.5);}});circle(ctx,X[hv],Y[hv],7,PAL[s.N[hv].c],'#fff',2);tooltip(ctx,X[hv],Y[hv],['node #'+hv,'community '+s.N[hv].c+' · degree '+s.N[hv].d]);}
  text(ctx,'zoom '+s.z.toFixed(2)+'×',W-14,24,C.mut,12,'right',MONO);cap(ctx,'new Sigma(graph, container, { renderEdgeLabels:false })');},
 code:`import Graph from 'graphology';import Sigma from 'sigma';
const graph=new Graph();nodes.forEach(n=>graph.addNode(n.id,{x:n.x,y:n.y,size:n.size,color:n.color,label:n.label}));
edges.forEach(e=>graph.addEdge(e.source,e.target));
const renderer=new Sigma(graph,document.getElementById('container'));
renderer.on('enterNode',({node})=>highlightNeighbours(node));`});
ex({t:'ForceAtlas2 layout converging live',d:'Three hundred nodes start at random and the ForceAtlas2-style layout pulls communities together over a few seconds.',controls:[{type:'btn',l:'↻ Randomise',pri:1,fn:s=>s.reset()},{type:'range',k:'g',l:'Gravity',min:.001,max:.02,step:.001,v:.006}],
 init(s){const r=rng(8);s.N=Array.from({length:300},(_,i)=>({c:i%5,x:0,y:0,vx:0,vy:0}));s.E=[];for(let i=0;i<300;i++){for(let k=0;k<2;k++){const j=r()<.92?(Math.floor(r()*60)*5+s.N[i].c)%300:Math.floor(r()*300);if(j!==i)s.E.push([i,j]);}}s.reset=()=>{s.N.forEach(n=>{n.x=40+Math.random()*(W-80);n.y=30+Math.random()*(H-60);});s.it=0;};s.reset();},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const N=s.N;for(let i=0;i<N.length;i++){const a=N[i];for(let j=i+1;j<N.length;j+=1){const b=N[j],dx=b.x-a.x,dy=b.y-a.y,d2=dx*dx+dy*dy+25;if(d2>25000)continue;const f=60/d2;a.vx-=dx*f;a.vy-=dy*f;b.vx+=dx*f;b.vy+=dy*f;}}
  s.E.forEach(([i,j])=>{const a=N[i],b=N[j],dx=b.x-a.x,dy=b.y-a.y;a.vx+=dx*.014;a.vy+=dy*.014;b.vx-=dx*.014;b.vy-=dy*.014;});N.forEach(n=>{n.vx+=(W/2-n.x)*s.p.g;n.vy+=(H/2-n.y)*s.p.g;n.vx*=.6;n.vy*=.6;n.x=clamp(n.x+n.vx,10,W-10);n.y=clamp(n.y+n.vy,10,H-10);});s.it++;
  ctx.strokeStyle='rgba(120,113,108,.12)';ctx.lineWidth=1;ctx.beginPath();s.E.forEach(([i,j])=>{ctx.moveTo(N[i].x,N[i].y);ctx.lineTo(N[j].x,N[j].y);});ctx.stroke();N.forEach(n=>circle(ctx,n.x,n.y,3.4,PAL[n.c]));text(ctx,'iteration '+s.it,W-14,24,C.mut,12,'right',MONO);cap(ctx,'forceAtlas2.assign(graph,{iterations:1, settings:{gravity:1}})');},
 code:`import forceAtlas2 from 'graphology-layout-forceatlas2';
import FA2Layout from 'graphology-layout-forceatlas2/worker';
const layout=new FA2Layout(graph,{settings:forceAtlas2.inferSettings(graph)});
layout.start();setTimeout(()=>layout.stop(),4000);`});

lib('fg3d','3D Force Graph','net','Force-directed graphs in 3D (Three.js + d3-force-3d) with particles on links and click-to-focus.',{ik:'3D Force Graph'});
function fg3dData(seed,n){const r=rng(seed);const N=[];for(let i=0;i<n;i++)N.push({p:[r()-.5,r()-.5,r()-.5],d:0,g:i%4});const E=[];for(let i=1;i<n;i++)E.push([i,Math.floor(r()*i)]);for(let i=0;i<Math.floor(n/3);i++)E.push([Math.floor(r()*n),Math.floor(r()*n)]);E.forEach(e=>{N[e[0]].d++;N[e[1]].d++;});
 for(let it=0;it<300;it++){const F=N.map(()=>[0,0,0]);for(let i=0;i<n;i++)for(let j=i+1;j<n;j++){const d3=sub(N[j].p,N[i].p),d=len3(d3)+.05,v=mul(d3,.0016/(d*d)/d);F[i]=sub(F[i],v);F[j]=add(F[j],v);}for(const e of E){const d3=sub(N[e[1]].p,N[e[0]].p),d=len3(d3)+.001,v=mul(d3,(d-.35)*.06/d);F[e[0]]=add(F[e[0]],v);F[e[1]]=sub(F[e[1]],v);}N.forEach((q,i)=>{q.p=add(q.p,add(F[i],mul(q.p,-.012)));});}
 let m=0;N.forEach(q=>{m=Math.max(m,len3(q.p));});N.forEach(q=>{q.p=mul(q.p,1.5/m);});return{N,E};}
ex({t:'Rotating 3D knowledge graph',d:'A 70-node graph laid out by a 3D force simulation; depth fades edges and scales nodes.',hint:'Drag to orbit.',orbit:{ry:0,rx:.3,auto:.35},
 init(s){Object.assign(s,fg3dData(8,70));},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const R=s.N.map(q=>rot(q.p,s.ry,s.rx));for(const e of s.E){const a=pr(R[e[0]],125),b=pr(R[e[1]],125);line(ctx,a[0],a[1],b[0],b[1],'rgba(120,113,108,'+clamp(.12+(R[e[0]][2]+R[e[1]][2])/2*.2+.15,.06,.5)+')',1.2);}
  s.N.map((q,i)=>[pr(R[i],125),q]).sort((a,b)=>a[0][2]-b[0][2]).forEach(([p,q])=>sphere(ctx,p[0],p[1],(4+Math.min(8,q.d*1.2))*p[3],[250,170,340,35][q.g],70,60));cap(ctx,'ForceGraph3D()(el).graphData({nodes, links}).nodeAutoColorBy("group")');},
 code:`ForceGraph3D()(document.getElementById('graph'))
  .graphData({nodes,links}).nodeAutoColorBy('group').nodeVal(n=>n.degree)
  .backgroundColor('#fcfcfd').linkOpacity(.35);`});
ex({t:'Directional particles & click-to-focus',d:'Particles stream along each link in its direction. Click a node and the camera eases to frame it.',hint:'Click a node to focus · drag to orbit.',orbit:{ry:.4,rx:.3,auto:.15},int:1,
 init(s){Object.assign(s,fg3dData(21,40));s.foc=null;s.cam=[0,0,0];s.zoom=1;s.onDown=(x,y)=>{const R=s.N.map(q=>pr(rot(sub(q.p,s.cam),s.ry,s.rx),125*s.zoom));const i=R.findIndex(p=>Math.hypot(p[0]-x,p[1]-y)<12);if(i>=0){s.foc=i;s.grab=true;}else s.foc=null;};},
 draw(ctx,s,t){bg(ctx,'#fbfbff');const tc=s.foc!==null?s.N[s.foc].p:[0,0,0],tz=s.foc!==null?1.8:1;s.cam=s.cam.map((v,i)=>lerp(v,tc[i],.06));s.zoom=lerp(s.zoom,tz,.06);const R=s.N.map(q=>pr(rot(sub(q.p,s.cam),s.ry,s.rx),125*s.zoom));
  s.E.forEach((e,k)=>{const a=R[e[0]],b=R[e[1]];line(ctx,a[0],a[1],b[0],b[1],'rgba(99,102,241,.22)',1.2);for(let j=0;j<2;j++){const u=((t*.5+k*.13+j*.5)%1);circle(ctx,lerp(a[0],b[0],u),lerp(a[1],b[1],u),2.2,'#e11d48');}});
  R.map((p,i)=>[p,i]).sort((a,b)=>a[0][2]-b[0][2]).forEach(([p,i])=>{sphere(ctx,p[0],p[1],(5+Math.min(7,s.N[i].d))*p[3],i===s.foc?350:240,70,60);if(i===s.foc)text(ctx,'node '+i,p[0]+14,p[1]-10,C.ink,13,'left',FONT,600);});cap(ctx,'.linkDirectionalParticles(2).onNodeClick(n=>graph.cameraPosition(…, n, 1000))');},
 code:`const g=ForceGraph3D()(el).graphData(data).linkDirectionalParticles(2).linkDirectionalParticleSpeed(.006)
  .onNodeClick(node=>{const d=1+60/Math.hypot(node.x,node.y,node.z);
    g.cameraPosition({x:node.x*d,y:node.y*d,z:node.z*d},node,1000);});`});

lib('g6','AntV G6','net','Graph visualisation and analysis: mind maps, trees, dagre flows, combos and rich behaviours.',{ik:'AntV G6'});
ex({t:'Mind map that grows in',d:'An Earth-observation mind map with a horizontal tree layout and cubic edges. Hover a node to highlight its branch.',hint:'Hover a node.',int:1,
 init(s){const T={n:'Earth Observation',c:[{n:'Optical',c:[{n:'Landsat'},{n:'Sentinel-2'},{n:'MODIS'}]},{n:'Radar (SAR)',c:[{n:'Sentinel-1'},{n:'ALOS-2'}]},{n:'Analysis',c:[{n:'NDVI'},{n:'Classification'},{n:'Change detection'}]}]};s.nodes=[];let leaf=0;const gap=(H-50)/8,xs=[20,235,465];
  const walk=(o,dep,par)=>{const nd={n:o.n,dep,par,x:xs[dep]};s.nodes.push(nd);if(o.c){const ys=o.c.map(c=>walk(c,dep+1,nd).y);nd.y=ys.reduce((a,b)=>a+b,0)/ys.length;}else{nd.y=25+(leaf+.5)*gap;leaf++;}return nd;};walk(T,0,null);},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const cyc=t%14,fade=clamp((14-cyc)/.6,0,1);ctx.font='600 14px '+FONT;s.nodes.forEach(n=>{n.w=ctx.measureText(n.n).width+30;});
  let hv=null;if(s.hover)s.nodes.forEach(n=>{if(s.mx>n.x&&s.mx<n.x+n.w&&Math.abs(s.my-n.y)<16)hv=n;});const path=new Set();for(let q=hv;q;q=q.par)path.add(q);const rev=n=>clamp((cyc-n.dep*.4)/.4,0,1)*fade,cols=['#4f46e5','#0d9488','#d97706'];
  for(const n of s.nodes){if(!n.par)continue;ctx.globalAlpha=rev(n);const x0=n.par.x+n.par.w,y0=n.par.y,x1=n.x,y1=n.y,on=path.has(n);ctx.strokeStyle=on?'#e11d48':'#d6d3cd';ctx.lineWidth=on?3:2;ctx.beginPath();ctx.moveTo(x0,y0);ctx.bezierCurveTo((x0+x1)/2,y0,(x0+x1)/2,y1,x1,y1);ctx.stroke();}
  for(const n of s.nodes){ctx.globalAlpha=rev(n);const on=path.has(n),c=cols[n.dep];rr(ctx,n.x,n.y-16,n.w,32,16);ctx.fillStyle=n.dep===0?c:n.dep===1?mixHex(c,'#ffffff',.85):'#fff';ctx.fill();ctx.strokeStyle=on?'#e11d48':c;ctx.lineWidth=on?2.5:1.5;ctx.stroke();text(ctx,n.n,n.x+n.w/2,n.y+5,n.dep===0?'#fff':C.ink,14,'center',FONT,600);}
  ctx.globalAlpha=1;cap(ctx,'new Graph({ layout:{type:"mindmap", direction:"H"} })');},
 code:`const graph=new Graph({container:'mm',data:treeToGraphData(tree),
  node:{type:'rect',style:{radius:16,labelText:d=>d.id}},edge:{type:'cubic-horizontal'},
  layout:{type:'mindmap',direction:'H',getHGap:()=>60,getVGap:()=>12},
  behaviors:['drag-canvas','zoom-canvas','collapse-expand']});graph.render();`});
ex({t:'Org chart with collapse / expand',d:'A tidy top-down tree. Click a node with a ± badge to collapse or expand its subtree; the layout re-flows with animation.',hint:'Click nodes with a ± badge.',int:1,
 init(s){const T={n:'CEO',c:[{n:'CTO',c:[{n:'Platform'},{n:'Data',c:[{n:'GIS'},{n:'ML'}]},{n:'Web'}]},{n:'CFO',c:[{n:'Finance'},{n:'Legal'}]},{n:'COO',c:[{n:'Ops'},{n:'Support',c:[{n:'EMEA'},{n:'APAC'}]}]}]};s.root=T;const init=(o,d)=>{o.open=true;o.d=d;o.x=W/2;o.y=40;(o.c||[]).forEach(c=>init(c,d+1));};init(T,0);
  s.lay=()=>{let leaf=0;const L=[];const w=(o)=>{o.vis=true;L.push(o);if(o.c&&o.open){o.c.forEach(w);o.tx=(o.c[0].tx+o.c[o.c.length-1].tx)/2;}else{o.tx=leaf++;}o.ty=40+o.d*92;};w(T);const sc=(W-80)/Math.max(1,leaf-1);L.forEach(o=>o.tx=40+o.tx*sc);s.L=L;};s.lay();
  const hide=o=>{o.vis=false;(o.c||[]).forEach(hide);};s.onDown=(x,y)=>{const o=s.L.find(o=>Math.abs(o.x-x)<44&&Math.abs(o.y-y)<18);if(o&&o.c){o.open=!o.open;if(!o.open)o.c.forEach(c=>{hide(c);c.x=o.x;c.y=o.y;});s.lay();}};},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');s.L.forEach(o=>{o.x=lerp(o.x,o.tx,.14);o.y=lerp(o.y,o.ty,.14);});s.L.forEach(o=>{if(o.c&&o.open)o.c.forEach(c=>{ctx.strokeStyle='#c7c2ba';ctx.lineWidth=1.8;ctx.beginPath();ctx.moveTo(o.x,o.y+16);ctx.lineTo(o.x,(o.y+c.y)/2);ctx.lineTo(c.x,(o.y+c.y)/2);ctx.lineTo(c.x,c.y-16);ctx.stroke();});});
  s.L.forEach(o=>{nodeBox(ctx,o.x,o.y,o.n,{minW:78,h:32,fill:o.d===0?'#1c1917':'#fff',col:o.d===0?'#fff':C.ink,stroke:o.d===0?'#1c1917':PAL[o.d]});if(o.c){circle(ctx,o.x+40,o.y-14,9,'#fff',C.ink2,1.5);text(ctx,o.open?'−':'+',o.x+40,o.y-9.5,C.ink,13,'center',FONT,700);}});cap(ctx,'behaviors:["collapse-expand"], layout:{type:"compact-box", direction:"TB"}');},
 code:`const graph=new Graph({container:'org',data,
  node:{type:'rect',style:{labelText:d=>d.data.title,radius:8}},edge:{type:'polyline'},
  layout:{type:'compact-box',direction:'TB',getVGap:()=>40,getHGap:()=>20},
  behaviors:[{type:'collapse-expand',trigger:'click',animation:true}]});graph.render();`});

lib('visnet','vis-network','net','Interactive network graphs with built-in physics, stabilisation, clustering and editing.',{isNew:true,info:{lv:'Beginner',r:'Canvas',s:'≈ 0.5 MB',u:'visjs.github.io/vis-network',t:['Physics-based network diagrams','Clustering and expanding large graphs','Editable diagrams (add/remove nodes and edges)','Hierarchical layouts'],c:['Nodes with shapes, images and labels, edges with arrows and smooth curves','Barnes-Hut / repulsion physics with stabilisation events','Clustering API (by connection, by attribute), manipulation toolbar','Navigation buttons, keyboard, hover and selection events'],l:['Canvas performance drops beyond a few thousand nodes','Styling is less flexible than Cytoscape'],o:'Fully offline with the standalone UMD build.',k:`const network=new vis.Network(container,{nodes:new vis.DataSet(nodes),edges:new vis.DataSet(edges)},
  {physics:{solver:'barnesHut',stabilization:{iterations:200}},edges:{arrows:'to',smooth:true}});
network.on('click',p=>{if(network.isCluster(p.nodes[0]))network.openCluster(p.nodes[0]);});`,a:'Cytoscape.js, Sigma.js, AntV G6'}});
ex({t:'Physics network with drag & stabilisation',d:'Barnes-Hut style physics with springs and arrows. Drag a node and watch the network wobble and re-stabilise.',hint:'Drag any node.',int:1,
 init(s){const r=rng(31),labels=['Home','Docs','Blog','API','Login','Store','Cart','Pay','Help','FAQ','Team','Jobs','News','Status','Search','Admin'];s.N=labels.map((l,i)=>({l,x:W/2+(r()-.5)*200,y:H/2+(r()-.5)*150,vx:0,vy:0,shape:i%3}));s.E=[[0,1],[0,2],[0,5],[0,8],[1,3],[1,14],[5,6],[6,7],[8,9],[0,10],[10,11],[2,12],[3,13],[4,15],[0,4],[7,4],[9,14]];s.dr=-1;
  s.onDown=(x,y)=>{s.dr=s.N.findIndex(n=>Math.hypot(n.x-x,n.y-y)<24);if(s.dr>=0)s.N[s.dr].fix=true;};s.onMove=(x,y)=>{if(s.down&&s.dr>=0){s.N[s.dr].x=x;s.N[s.dr].y=y;}};s.onUp=()=>{if(s.dr>=0)s.N[s.dr].fix=false;s.dr=-1;};},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');forceStep(s.N,s.E,{rep:6000,len:90,k:.02});const N=s.N;let en=0;N.forEach(n=>en+=Math.abs(n.vx)+Math.abs(n.vy));
  s.E.forEach(([a,b])=>{const A=N[a],B=N[b],d=Math.hypot(B.x-A.x,B.y-A.y)||1,ux=(B.x-A.x)/d,uy=(B.y-A.y)/d;const mx=(A.x+B.x)/2+uy*14,my=(A.y+B.y)/2-ux*14;ctx.strokeStyle='#a8a29e';ctx.lineWidth=1.6;ctx.beginPath();ctx.moveTo(A.x,A.y);ctx.quadraticCurveTo(mx,my,B.x-ux*24,B.y-uy*24);ctx.stroke();const ang=Math.atan2(B.y-uy*24-my,B.x-ux*24-mx);arrow(ctx,B.x-ux*24-Math.cos(ang)*2,B.y-uy*24-Math.sin(ang)*2,B.x-ux*22,B.y-uy*22,'#a8a29e',1.6,9);});
  N.forEach((n,i)=>{const c=PAL[n.shape*2];if(n.shape===0)circle(ctx,n.x,n.y,20,mixHex(c,'#ffffff',.8),c,2);else if(n.shape===1){ctx.fillStyle=mixHex(c,'#ffffff',.8);rr(ctx,n.x-28,n.y-15,56,30,7);ctx.fill();ctx.strokeStyle=c;ctx.lineWidth=2;ctx.stroke();}else{poly(ctx,[[n.x,n.y-22],[n.x+22,n.y],[n.x,n.y+22],[n.x-22,n.y]],mixHex(c,'#ffffff',.8),c,2);}text(ctx,n.l,n.x,n.y+4,C.ink,11.5,'center',FONT,600);});
  badge(ctx,en<6?'stabilized ✓':'stabilizing… '+Math.round(en),14,12,en<6?'#dcfce7':'#fef3c7',en<6?'#15803d':'#92400e');},
 code:`const network=new vis.Network(el,{nodes,edges},{physics:{barnesHut:{gravitationalConstant:-4000,springLength:90}},
  edges:{arrows:'to',smooth:{type:'curvedCW',roundness:.2}}});
network.on('stabilized',()=>status.textContent='stabilized');`});
ex({t:'Clustering: open and close groups',d:'Five clusters start collapsed into single nodes sized by member count. Click a cluster to open it; click a member to close its cluster again.',hint:'Click a big cluster node · click a member to collapse it.',int:1,
 init(s){const r=rng(41),names=['Imagery','Vectors','Models','Reports','Users'];s.G=names.map((n,g)=>({n,g,open:false,x:W/2+Math.cos(g/5*TAU)*170,y:H/2+Math.sin(g/5*TAU)*130,m:Array.from({length:5+Math.floor(r()*6)},(_,k)=>({x:0,y:0,vx:0,vy:0,l:n[0]+(k+1)}))}));s.G.forEach(G=>G.m.forEach(m=>{m.x=G.x;m.y=G.y;}));
  s.onDown=(x,y)=>{for(const G of s.G){if(!G.open&&Math.hypot(x-G.x,y-G.y)<20+G.m.length*2){G.open=true;G.m.forEach(m=>{m.x=G.x+(Math.random()-.5)*10;m.y=G.y+(Math.random()-.5)*10;});return;}if(G.open&&G.m.some(m=>Math.hypot(x-m.x,y-m.y)<12)){G.open=false;return;}}};},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const all=[];s.G.forEach(G=>{if(G.open)G.m.forEach(m=>all.push(Object.assign(m,{G})));else all.push(G);});
  for(let i=0;i<all.length;i++)for(let j=i+1;j<all.length;j++){const a=all[i],b=all[j],dx=b.x-a.x,dy=b.y-a.y,d2=dx*dx+dy*dy+50,f=900/d2;if(a.m===undefined){a.vx=(a.vx||0)-dx*f*.02;a.vy=(a.vy||0)-dy*f*.02;}if(b.m===undefined){b.vx=(b.vx||0)+dx*f*.02;b.vy=(b.vy||0)+dy*f*.02;}}
  s.G.forEach(G=>{const hx=W/2+Math.cos(G.g/5*TAU)*170,hy=H/2+Math.sin(G.g/5*TAU)*130;if(!G.open){G.x=lerp(G.x,hx,.08);G.y=lerp(G.y,hy,.08);}else G.m.forEach(m=>{m.vx+=(hx-m.x)*.02;m.vy+=(hy-m.y)*.02;m.vx*=.8;m.vy*=.8;m.x+=m.vx;m.y+=m.vy;});});
  s.G.forEach((G,gi)=>{s.G.forEach((H2,hi)=>{if(hi===(gi+1)%5){const a=G.open?G.m[0]:G,b=H2.open?H2.m[0]:H2;line(ctx,a.x,a.y,b.x,b.y,'#e7e5e4',2);}});if(G.open)G.m.forEach((m,k)=>{if(k)line(ctx,G.m[0].x,G.m[0].y,m.x,m.y,rgba(PAL[gi],.4),1.5);});});
  s.G.forEach((G,gi)=>{if(G.open)G.m.forEach(m=>{circle(ctx,m.x,m.y,11,'#fff',PAL[gi],2.5);text(ctx,m.l,m.x,m.y+4,C.ink,9.5,'center',FONT,700);});else{const r=20+G.m.length*2;circle(ctx,G.x,G.y,r,PAL[gi],'#fff',4);text(ctx,G.n,G.x,G.y-2,'#fff',12,'center',FONT,700);text(ctx,G.m.length+' nodes',G.x,G.y+13,'rgba(255,255,255,.85)',10.5,'center');}});
  cap(ctx,'network.cluster({ joinCondition:n=>n.group===g, clusterNodeProperties:{label} })');},
 code:`groups.forEach(g=>network.cluster({joinCondition:n=>n.group===g,
  clusterNodeProperties:{id:'cluster:'+g,label:g,shape:'dot',size:20+count[g]*2}}));
network.on('selectNode',p=>{const id=p.nodes[0];if(network.isCluster(id))network.openCluster(id);});`});

lib('frappe','Frappe Gantt','net','A simple, interactive SVG Gantt chart: drag to reschedule, resize to change duration, dependencies and progress.',{isNew:true,info:{lv:'Beginner',r:'SVG',s:'≈ 50 KB',u:'frappe.io/gantt',t:['Project schedules with draggable tasks','Dependencies between tasks','Progress tracking per task','Day / week / month views'],c:['Drag bars to move, drag the end to resize, drag the progress handle','Dependency arrows, custom popups, view modes','Events: on_click, on_date_change, on_progress_change'],l:['No built-in resource planning or critical-path calculation'],o:'Fully offline (JS + CSS).',k:`const gantt=new Gantt('#gantt',[{id:'1',name:'Design',start:'2026-03-01',end:'2026-03-06',progress:60},
  {id:'2',name:'Build',start:'2026-03-07',end:'2026-03-18',progress:20,dependencies:'1'}],
  {view_mode:'Day',on_date_change:(task,start,end)=>save(task,start,end)});`,a:'Mermaid.js (gantt), DHTMLX Gantt, vis-timeline'}});
ex({t:'Drag to reschedule, resize, set progress',d:'Drag a bar to move it, drag its right edge to change its length, and drag the small handle to change progress. Dependency arrows follow.',hint:'Drag bars, their right edge, or the progress handle.',int:1,
 init(s){s.T=[['Design',0,5,.6],['Prototype',5,6,.3,0],['Field test',11,5,.1,1],['Docs',8,7,.5,1],['Release',17,3,0,2]].map(a=>({n:a[0],s:a[1],d:a[2],p:a[3],dep:a[4]}));s.dg=null;const X=d=>130+d*28;s.Xf=X;
  s.onDown=(x,y)=>{s.T.forEach((tk,i)=>{const by=60+i*64,bx=X(tk.s),bw=tk.d*28;if(y>by&&y<by+30){if(Math.abs(x-(bx+bw*tk.p))<8&&y>by+18)s.dg=[tk,'p'];else if(Math.abs(x-(bx+bw))<9)s.dg=[tk,'r'];else if(x>bx&&x<bx+bw)s.dg=[tk,'m',x-bx];}});};
  s.onMove=(x)=>{if(!s.dg||!s.down)return;const[tk,m,o]=s.dg;if(m==='m')tk.s=clamp(Math.round((x-o-130)/28),0,21-tk.d);if(m==='r')tk.d=clamp(Math.round((x-X(tk.s))/28),1,21-tk.s);if(m==='p')tk.p=clamp((x-X(tk.s))/(tk.d*28),0,1);};s.onUp=()=>{s.dg=null;};},
 draw(ctx,s,t){bg(ctx);const X=s.Xf;for(let d=0;d<=21;d++){line(ctx,X(d),30,X(d),H-20,d%7===0?'#e7e5e4':'#f5f3ef',1);if(d<21)text(ctx,String(d+1),X(d)+14,24,C.mut,10.5,'center');}ctx.fillStyle='rgba(225,29,72,.06)';ctx.fillRect(X(9),30,28,H-50);
  s.T.forEach((tk,i)=>{if(tk.dep===undefined)return;const a=s.T[tk.dep],ai=tk.dep,ax=X(a.s+a.d),ay=60+ai*64+15,bx=X(tk.s),by=60+i*64+15;ctx.strokeStyle='#a8a29e';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(ax,ay);ctx.lineTo(ax+10,ay);ctx.lineTo(ax+10,(ay+by)/2);ctx.lineTo(bx-12,(ay+by)/2);ctx.lineTo(bx-12,by);ctx.lineTo(bx-2,by);ctx.stroke();arrow(ctx,bx-8,by,bx-1,by,'#a8a29e',1.5,7);});
  s.T.forEach((tk,i)=>{const by=60+i*64,bx=X(tk.s),bw=tk.d*28,late=tk.dep!==undefined&&tk.s<s.T[tk.dep].s+s.T[tk.dep].d;text(ctx,tk.n,12,by+20,C.ink2,13,'left',FONT,600);ctx.fillStyle=late?'#fecaca':'#e0e7ff';rr(ctx,bx,by,bw,30,7);ctx.fill();ctx.fillStyle=late?'#ef4444':'#6366f1';rr(ctx,bx,by,bw*tk.p,30,7);ctx.fill();
   text(ctx,Math.round(tk.p*100)+'%',bx+8,by+20,tk.p>.2?'#fff':C.ink,11.5,'left',FONT,600);ctx.fillStyle='#fff';ctx.strokeStyle='#6366f1';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(bx+bw*tk.p,by+22);ctx.lineTo(bx+bw*tk.p+6,by+32);ctx.lineTo(bx+bw*tk.p-6,by+32);ctx.closePath();ctx.fill();ctx.stroke();line(ctx,bx+bw-4,by+9,bx+bw-4,by+21,'rgba(255,255,255,.9)',2);});
  if(s.T.some((tk,i)=>tk.dep!==undefined&&tk.s<s.T[tk.dep].s+s.T[tk.dep].d))badge(ctx,'⚠ dependency conflict',W-14,H-40,'#fee2e2','#b91c1c','right');},
 code:`new Gantt('#gantt',tasks,{view_mode:'Day',bar_height:30,
  on_date_change:(task,start,end)=>console.log(task.name,start,end),
  on_progress_change:(task,progress)=>console.log(task.name,progress)});`});
