/* ===================== 3D & WebGL (all rendered with the GLX physically based renderer) ===================== */
const _GM={};function GM(k,f){return _GM[k]||(_GM[k]=f());}
function lav(ctx,a,b){const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,a||'#fdfbff');g.addColorStop(1,b||'#ede4f9');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);const r=ctx.createRadialGradient(W*.5,H*.32,10,W*.5,H*.4,W*.62);r.addColorStop(0,'rgba(255,255,255,.95)');r.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=r;ctx.fillRect(0,0,W,H);}
function pxs(G,w){return(G.h/2)/Math.tan(G.state().fov*D2R/2)/w;}
function gShadow(ctx,G,p,r,a,sq){const q=G.project(p);if(q[3]<=0)return;const s=pxs(G,q[3])*r;softShadow(ctx,q[0],q[1],s,s*(sq||.32),a||.25);}
function pip(x,y,P){let c=false;for(let i=0,j=P.length-1;i<P.length;j=i++){if((P[i][1]>y)!=(P[j][1]>y)&&x<(P[j][0]-P[i][0])*(y-P[i][1])/(P[j][1]-P[i][1])+P[i][0])c=!c;}return c;}
function raySphere(r,c,rad){const oc=sub(r.o,c),b=dot(oc,r.d),cc=dot(oc,oc)-rad*rad,h=b*b-cc;if(h<0)return -1;return -b-Math.sqrt(h);}
function hud(ctx,lines,x,y,o){o=o||{};ctx.font='12px '+MONO;let w=0;lines.forEach(l=>w=Math.max(w,ctx.measureText(l).width));w+=22;const h=lines.length*18+12;ctx.save();ctx.shadowColor='rgba(91,33,182,.12)';ctx.shadowBlur=16;ctx.fillStyle='rgba(255,255,255,.78)';rr(ctx,x,y,w,h,10);ctx.fill();ctx.restore();ctx.strokeStyle='rgba(124,58,237,.18)';ctx.lineWidth=1;rr(ctx,x,y,w,h,10);ctx.stroke();lines.forEach((l,i)=>text(ctx,l,x+11,y+21+i*18,i===0&&o.title!==false?'#140E29':'#4C4369',12,'left',MONO,i===0&&o.title!==false?700:400));}
const KNOT=(p,q,R,r)=>GM('knot'+p+q,()=>GEO.tube(u=>{const a=u*TAU;return[(2+Math.cos(q*a))*Math.cos(p*a)*R,Math.sin(q*a)*R,(2+Math.cos(q*a))*Math.sin(p*a)*R];},true,r,520,40));
const SMALLKNOT=()=>GM('knot23s',()=>GEO.tube(u=>{const a=u*TAU;return[(2+Math.cos(3*a))*Math.cos(2*a)*.15,Math.sin(3*a)*.15,(2+Math.cos(3*a))*Math.sin(2*a)*.15];},true,.06,300,20));
const SPH=()=>GM('sph',()=>GEO.sphere(1,64,40));
const FLOOR=(k,s,y)=>GM('floor'+k,()=>GEO.grid(1,1,(u,v)=>[(u-.5)*s,y,(v-.5)*s],()=>[0,1,0]));
function gridLines(G,y,n,step,col){const L=[];for(let i=-n;i<=n;i++)L.push(i*step,y,-n*step,i*step,y,n*step,-n*step,y,i*step,n*step,y,i*step);G.lines(new Float32Array(L),new Float32Array(L.length/3*4).map((_,i)=>col[i%4]));}

lib('three','Three.js','c3d','The standard WebGL engine: scene graph, physically based materials, loaders, instancing, raycasting and post-processing.');
ex({t:'MeshPhysicalMaterial studio: five finishes',d:'A 21,000-vertex torus knot with smooth normals under a three-light studio rig and ACES tone mapping. Switch between iridescent, mirror chrome, clear-coated lacquer, frosted glass and velvet.',hint:'Drag to orbit · double-click to reset.',orbit:{ry:.5,rx:.25,auto:.35},
 controls:[{type:'seg',k:'mat',v:'Iridescent',opts:['Iridescent','Chrome','Lacquer','Glass','Velvet']},{type:'select',k:'knot',l:'Knot',v:'(2,3)',opts:['(2,3)','(3,5)','(2,5)','(3,7)']}],
 draw(ctx,s,t){const G=G3();if(!G.ok)return glFail(ctx);const[p,q]=s.p.knot.match(/\d/g).map(Number),geo=KNOT(p,q,.42,.16);G.begin({eye:orbitEye(s,5.4),fov:36});lav(ctx);gShadow(ctx,G,[0,-1.25,0],1.5,.22,.2);
  const M={Iridescent:{color:'#c4b5fd',iri:.85,rough:.18,clear:1},Chrome:{color:'#e9e6f2',metal:1,rough:.08},Lacquer:{color:'#e11d48',rough:.45,clear:1},Glass:{color:'#c7d2fe',op:.3,rough:.05,clear:1,rim:'#7c3aed',rimK:.6,glass:.65},Velvet:{color:'#5b21b6',rough:.9,sheen:1.1}}[s.p.mat];
  G.draw(geo,Object.assign({m:M4.RY(t*.25)},M));G.end(ctx);hud(ctx,['MeshPhysicalMaterial',s.p.mat.toLowerCase()+' · '+(geo.P.length/3).toLocaleString()+' verts'],14,14);cap(ctx,'new THREE.Mesh(new TorusKnotGeometry(1,.35,512,40), new MeshPhysicalMaterial({...}))');},
 code:`import * as THREE from './libs/three.module.js';
const renderer=new THREE.WebGLRenderer({antialias:true});renderer.toneMapping=THREE.ACESFilmicToneMapping;
const knot=new THREE.Mesh(new THREE.TorusKnotGeometry(1,.38,512,40,2,3),
  new THREE.MeshPhysicalMaterial({color:0xc4b5fd,roughness:.18,clearcoat:1,iridescence:1,iridescenceIOR:1.3}));
scene.add(knot,new THREE.HemisphereLight(0xf5efff,0xe9dcf3,.9),key,rimTeal,rimViolet);
renderer.setAnimationLoop(()=>{knot.rotation.y+=.004;renderer.render(scene,camera);});`});
ex({t:'PBR material grid: roughness × metalness',d:'The classic physically based rendering test: 35 spheres, roughness rising left to right and metalness bottom to top, all lit by the same environment.',hint:'Drag to orbit · hover a sphere to read its parameters.',orbit:{ry:0,rx:.05,auto:0},int:1,
 draw(ctx,s,t){const G=G3();if(!G.ok)return glFail(ctx);G.begin({eye:orbitEye(s,8.4),fov:40});lav(ctx,'#fefcff','#eee6f8');const sp=SPH();let hv=null;const ray=s.hover?G.ray(s.mx,s.my):null;
  for(let j=0;j<5;j++)for(let i=0;i<7;i++){const c=[(i-3)*1.05,(j-2)*1.05,0],ro=.05+i/6*.95,me=j/4;if(ray&&raySphere(ray,c,.44)>0)hv=[ro,me,c];G.draw(sp,{m:M4.mul(M4.T(...c),M4.S(.44)),color:j>2?'#fbbf24':'#7c3aed',rough:ro,metal:me});}
  G.end(ctx);for(let i=0;i<7;i++)text(ctx,(.05+i/6*.95).toFixed(2),G.project([(i-3)*1.05,-2.75,0])[0],H-20,C.mut,11,'center',MONO);text(ctx,'roughness →',W/2,H-5,'#4C4369',11.5,'center');text(ctx,'metalness ↑',12,H/2,'#4C4369',11.5);
  if(hv){const q=G.project(hv[2]);tooltip(ctx,q[0],q[1]-30,['roughness '+hv[0].toFixed(2),'metalness '+hv[1].toFixed(2)]);}},
 code:`for(let j=0;j<5;j++)for(let i=0;i<7;i++){
  const m=new THREE.Mesh(sphereGeo,new THREE.MeshStandardMaterial({color:0x7c3aed,roughness:i/6,metalness:j/4}));
  m.position.set((i-3)*1.05,(j-2)*1.05,0);scene.add(m);}
scene.environment=pmrem.fromScene(new RoomEnvironment()).texture;`});
ex({t:'Liquid metal blob (vertex displacement)',d:'A 9,800-vertex sphere displaced every frame by layered noise with normals recomputed, so the liquid stays perfectly smooth. The pointer pushes a dent into it.',hint:'Move the pointer over the blob.',orbit:{ry:0,rx:.15,auto:.2},int:1,controls:[{type:'seg',k:'mat',v:'Mercury',opts:['Mercury','Opal','Ink']},{type:'range',k:'amp',l:'Turbulence',min:0,max:.5,step:.01,v:.22}],
 init(s){s.g=GEO.sphere(1,120,80);s.base=s.g.P.slice();},
 draw(ctx,s,t){const G=G3();if(!G.ok)return glFail(ctx);G.begin({eye:orbitEye(s,4.6),fov:36});lav(ctx);gShadow(ctx,G,[0,-1.35,0],1.2,.2,.22);
  const g=s.g,B=s.base,a=s.p.amp,ray=s.hover?G.ray(s.mx,s.my):null;let hp=null;if(ray){const d=raySphere(ray,[0,0,0],1.05);if(d>0)hp=norm(M4.xf(M4.RY(-t*.2),add(ray.o,mul(ray.d,d))));}
  for(let i=0;i<B.length;i+=3){const x=B[i],y=B[i+1],z=B[i+2];let k=1+a*(noise(x*1.6+t*.6,y*1.6+z*1.1)-.5)*1.4+a*.45*Math.sin(x*4+t*1.7)*Math.cos(z*3.4-t*1.2);if(hp){const d=Math.hypot(x-hp[0],y-hp[1],z-hp[2]);k-=.22*Math.exp(-d*d*9);}g.P[i]=x*k;g.P[i+1]=y*k;g.P[i+2]=z*k;}
  const U=120,V=80,P=g.P;for(let j=0;j<=V;j++)for(let i=0;i<=U;i++){const id=j*(U+1)+i,ip=j*(U+1)+(i+1>U?1:i+1),im=j*(U+1)+(i-1<0?U-1:i-1),jp=Math.min(V,j+1)*(U+1)+i,jm=Math.max(0,j-1)*(U+1)+i;const du=[P[ip*3]-P[im*3],P[ip*3+1]-P[im*3+1],P[ip*3+2]-P[im*3+2]],dv=[P[jp*3]-P[jm*3],P[jp*3+1]-P[jm*3+1],P[jp*3+2]-P[jm*3+2]];let n=norm(cross(dv,du));if(j===0||j===V||!isFinite(n[0]))n=norm([P[id*3],P[id*3+1],P[id*3+2]]);if(dot(n,[P[id*3],P[id*3+1],P[id*3+2]])<0)n=mul(n,-1);g.N[id*3]=n[0];g.N[id*3+1]=n[1];g.N[id*3+2]=n[2];}
  G.upd(g);const M={Mercury:{color:'#e8e4f0',metal:1,rough:.12},Opal:{color:'#ede9fe',iri:.7,rough:.15,clear:1},Ink:{color:'#1e1b4b',rough:.25,clear:1,rim:'#a78bfa',rimK:.8}}[s.p.mat];G.draw(g,Object.assign({m:M4.RY(t*.2)},M));G.end(ctx);cap(ctx,'geometry.attributes.position.needsUpdate = true; geometry.computeVertexNormals()');},
 code:`const geo=new THREE.SphereGeometry(1,120,80),base=geo.attributes.position.array.slice();
function tick(t){const p=geo.attributes.position;
  for(let i=0;i<p.count;i++){const v=new THREE.Vector3().fromArray(base,i*3);
    v.multiplyScalar(1+.22*(noise(v.x*1.6+t,v.y*1.6+v.z)-.5));p.setXYZ(i,v.x,v.y,v.z);}
  p.needsUpdate=true;geo.computeVertexNormals();}`});
ex({t:'InstancedMesh: 576 rounded blocks in one draw call',d:'A 24×24 field of rounded-box instances; height and colour of every instance update each frame from interfering waves. Click to drop extra ripples.',hint:'Drag to orbit · click to send a ripple.',orbit:{ry:.75,rx:.62,auto:.1},int:1,controls:[{type:'range',k:'amp',l:'Amplitude',min:.1,max:1.2,step:.05,v:.7},{type:'select',k:'pal',l:'Palette',v:'Aurora',opts:['Aurora','Magma','Viridis','Spectral']}],
 init(s){s.rip=[];s.onDown=()=>{s.rip.push({x:(Math.random()-.5)*3,z:(Math.random()-.5)*3,t:s.t});if(s.rip.length>5)s.rip.shift();};},
 draw(ctx,s,t){const G=G3();if(!G.ok)return glFail(ctx);G.begin({eye:orbitEye(s,7.4,[0,.2,0]),fov:36});lav(ctx);const n=24,sp=.165,box=GM('rbox',()=>GEO.superq(1,1,1,.22,40,28)),D=new Float32Array(n*n*9),pal=s.p.pal==='Magma'?MAGMA:s.p.pal==='Viridis'?VIRIDIS:s.p.pal==='Spectral'?SPECT:['#312e81','#6d28d9','#a855f7','#ec4899','#fbbf24','#fef3c7'];let k=0;
  for(let i=0;i<n;i++)for(let j=0;j<n;j++){const x=(i-n/2+.5)*sp,z=(j-n/2+.5)*sp,r=Math.hypot(x,z);let h=.5+.5*Math.sin(r*4.2-t*2.2);for(const R of s.rip){const d=Math.hypot(x-R.x,z-R.z),a=t-R.t;h+=Math.exp(-a*.7)*Math.sin(d*7-a*6)*Math.exp(-Math.pow(d-a*.9,2)*2)*1.3;}
   const ht=.04+clamp(h,0,2.2)*s.p.amp*.55,c=hexv(hex2rgb2(scale(pal,clamp(h/1.6,0,1))));D.set([x,ht/2-.6,z,sp*.43,ht/2,sp*.43,c[0],c[1],c[2]],k*9);k++;}
  G.inst(box,D,n*n,{rough:.3,clear:.6});G.end(ctx);hud(ctx,['InstancedMesh',n*n+' instances · 1 draw call'],14,14);},
 code:`const mesh=new THREE.InstancedMesh(new RoundedBoxGeometry(1,1,1,4,.2),new THREE.MeshPhysicalMaterial({clearcoat:.6}),576);
const m=new THREE.Matrix4(),c=new THREE.Color();
for(let i=0;i<576;i++){m.compose(pos[i],quat,new THREE.Vector3(.07,h[i],.07));mesh.setMatrixAt(i,m);mesh.setColorAt(i,c.set(pal(h[i])));}
mesh.instanceMatrix.needsUpdate=mesh.instanceColor.needsUpdate=true;`});
ex({t:'Points: 60,000-particle strange attractor',d:'A THREE.Points cloud of the Aizawa attractor drawn on the GPU: soft round sprites, colour by speed and depth-attenuated size.',hint:'Drag to orbit.',orbit:{ry:.2,rx:.9,auto:.18},
 init(s){let x=.1,y=0,z=0;const N=60000,P=new Float32Array(N*3),Cc=new Float32Array(N*4);const a=.95,b=.7,c=.6,d=3.5,e=.25,f=.1;let k=0;for(let i=0;i<N+300;i++){const dx=(z-b)*x-d*y,dy=d*x+(z-b)*y,dz=c+a*z-z*z*z/3-(x*x+y*y)*(1+e*z)+f*z*x*x*x,dt=.008;x+=dx*dt;y+=dy*dt;z+=dz*dt;if(i>=300){P[k*3]=x;P[k*3+1]=z-.8;P[k*3+2]=y;const sp=clamp(Math.hypot(dx,dy,dz)/2.2,0,1),cc=hexv(hex2rgb2(scale(['#4c1d95','#7c3aed','#db2777','#f59e0b'],sp)));Cc.set([cc[0],cc[1],cc[2],.55],k*4);k++;}}s.P=P;s.C=Cc;},
 draw(ctx,s,t){const G=G3();if(!G.ok)return glFail(ctx);G.begin({eye:orbitEye(s,4.2),fov:40});lav(ctx,'#fffdfd','#f1e9fb');const n=Math.min(60000,Math.floor(6000+t*9000));G.points(s.P.subarray(0,n*3),s.C.subarray(0,n*4),null,{size:1.1,soft:.45});G.end(ctx);hud(ctx,['THREE.Points',n.toLocaleString()+' particles'],14,14);},
 code:`const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(positions,3));
g.setAttribute('color',new THREE.BufferAttribute(colors,3));
scene.add(new THREE.Points(g,new THREE.PointsMaterial({size:.012,vertexColors:true,transparent:true,opacity:.55,map:discTexture})));`});
ex({t:'Raycaster: hover, select, inspect',d:'Six smooth primitives over a glossy stage. The raycaster finds the nearest hit; hovered objects glow, clicked ones get a selection ring, and an inspector reports the distance.',hint:'Hover objects · click to select · drag empty space to orbit.',orbit:{ry:.5,rx:.42,auto:.08},int:1,
 init(s){s.O=[['Sphere',[-1.5,.05,-.3],'#7c3aed',.45,()=>SPH(),.45],['Rounded box',[-.3,.05,-.6],'#0284c7',.45,()=>GM('rbox2',()=>GEO.superq(.4,.4,.4,.3,40,28)),1],['Torus',[1.2,-.1,.4],'#e11d48',.6,()=>GM('tor',()=>GEO.torus(.42,.15,96,32)),1],['Capsule',[.25,.15,.8],'#0d9488',.55,()=>GM('caps',()=>GEO.superq(.25,.55,.25,.75,40,32)),1],['Knot',[1.6,.2,-1],'#d97706',.6,SMALLKNOT,1],['Gem',[-1.3,.1,1],'#db2777',.45,()=>GM('gem',()=>GEO.superq(.38,.48,.38,1.8,8,6)),1]];
  s.sel=new Set();s.hv=-1;s.onDown=()=>{if(s.hv>=0){s.grab=true;s.sel.has(s.hv)?s.sel.delete(s.hv):s.sel.add(s.hv);}};},
 draw(ctx,s,t){const G=G3();if(!G.ok)return glFail(ctx);G.begin({eye:orbitEye(s,5.6),fov:38});lav(ctx);const ray=s.hover?G.ray(s.mx,s.my):null;let best=1e9;s.hv=-1;
  s.O.forEach((o,i)=>{const c=[o[1][0],o[1][1]+Math.sin(t*1.4+i)*.06,o[1][2]];o.c=c;gShadow(ctx,G,[c[0],-.55,c[2]],o[3]*1.1,.22,.35);if(ray){const d=raySphere(ray,c,o[3]);if(d>0&&d<best){best=d;s.hv=i;}}});
  G.draw(FLOOR('a',7,-.56),{color:'#f5f0fb',rough:.2,clear:.8,op:.55,glass:0});
  s.O.forEach((o,i)=>{const hv=i===s.hv,sel=s.sel.has(i);G.draw(o[4](),{m:M4.chain(M4.T(...o.c),M4.RY(t*.5+i),M4.RX(i*.4),M4.S(o[5])),color:o[2],rough:.22,clear:1,rim:'#ffffff',rimK:hv?1.2:sel?.7:0,rimP:2.2});});G.end(ctx);
  s.O.forEach((o,i)=>{if(!s.sel.has(i))return;const q=G.project(o.c),r=pxs(G,q[3])*o[3]*1.25;ctx.setLineDash([5,4]);circle(ctx,q[0],q[1],r,null,'#7c3aed',2);ctx.setLineDash([]);});
  if(s.stage)s.stage.style.cursor=s.hv>=0?'pointer':'grab';if(s.hv>=0){const o=s.O[s.hv],q=G.project(o.c);tooltip(ctx,q[0],q[1]-pxs(G,q[3])*o[3],[o[0],'distance '+best.toFixed(2)+' · '+(s.sel.has(s.hv)?'selected':'click to select')]);}
  hud(ctx,['raycaster.intersectObjects()','selected: '+([...s.sel].map(i=>s.O[i][0]).join(', ')||'none')],14,14);},
 code:`const ray=new THREE.Raycaster(),ptr=new THREE.Vector2();
canvas.addEventListener('pointermove',e=>ptr.set(e.offsetX/w*2-1,-(e.offsetY/h)*2+1));
function tick(){ray.setFromCamera(ptr,camera);const hit=ray.intersectObjects(objects)[0];
  objects.forEach(o=>o.material.emissiveIntensity=o===hit?.object?.5:0);}`});

lib('babylon','Babylon.js','c3d','A complete 3D engine: PBR, physics, GUI, particles, node materials, WebXR and an inspector, all built in.');
ex({t:'Studio scene: PBR cubes, bouncing sphere, contact shadows',d:'An ArcRotateCamera orbits rounded PBR boxes on a glossy floor; a clear-coated sphere bounces with squash-and-stretch and its contact shadow tightens as it lands.',hint:'Drag to orbit.',orbit:{ry:.6,rx:.5,auto:.15},
 init(s){s.cubes=[[-1.3,-.7,.55,'#7c3aed'],[0,.85,.7,'#e11d48'],[1.4,-.35,.5,'#0284c7'],[-.25,-1.55,.42,'#0d9488'],[1,1.35,.45,'#d97706']];},
 draw(ctx,s,t){const G=G3();if(!G.ok)return glFail(ctx);G.begin({eye:orbitEye(s,7.2,[0,.3,0]),fov:36});lav(ctx);const box=GM('rb3',()=>GEO.superq(1,1,1,.16,40,28)),sp=SPH(),hh=Math.abs(Math.sin(t*2.2));
  s.cubes.forEach(c=>gShadow(ctx,G,[c[0],-.6,c[1]],c[2]*1.5,.25,.38));const by=-.6+.3+hh*1.6;gShadow(ctx,G,[.2,-.6,-.2],.35*(1.2+hh),.32*(1-hh*.55),.38);
  G.draw(FLOOR('b',8,-.6),{color:'#f6f1fc',rough:.15,clear:1,op:.5,glass:0});gridLines(G,-.595,8,.5,[.55,.4,.9,.16]);
  s.cubes.forEach(c=>G.draw(box,{m:M4.chain(M4.T(c[0],-.6+c[2],c[1]),M4.S(c[2])),color:c[3],rough:.3,clear:.8}));const sq=hh<.12?1-(.12-hh)*1.2:1;G.draw(sp,{m:M4.chain(M4.T(.2,by,-.2),M4.S(.3/Math.sqrt(sq),.3*sq,.3/Math.sqrt(sq))),color:'#fbbf24',rough:.15,clear:1});G.end(ctx);cap(ctx,'new BABYLON.ShadowGenerator(1024, sun); scene.createDefaultEnvironment()');},
 code:`const scene=new BABYLON.Scene(engine);scene.createDefaultEnvironment({createGround:true});
const cam=new BABYLON.ArcRotateCamera('cam',-Math.PI/2,1.1,9,BABYLON.Vector3.Zero(),scene);cam.attachControl(canvas,true);
const sun=new BABYLON.DirectionalLight('sun',new BABYLON.Vector3(-1,-2,-1),scene),shadows=new BABYLON.ShadowGenerator(1024,sun);
const ball=BABYLON.MeshBuilder.CreateSphere('ball',{diameter:.6,segments:64},scene);ball.material=new BABYLON.PBRMaterial('m',scene);
shadows.addShadowCaster(ball);`});
ex({t:'GUI sliders rebuilding a fluted, twisted column',d:'Babylon GUI sliders regenerate a 20,000-vertex lathed mesh live: number of flutes, twist, bulge and hue, smooth-shaded with clear-coat.',hint:'Use the sliders · drag to orbit.',orbit:{ry:.3,rx:.28,auto:.4},
 controls:[{type:'range',k:'fl',l:'Flutes',min:3,max:16,v:8},{type:'range',k:'tw',l:'Twist',min:0,max:4,step:.1,v:1.6},{type:'range',k:'bu',l:'Bulge',min:0,max:1,step:.05,v:.45},{type:'range',k:'hue',l:'Hue',min:0,max:360,v:270}],
 draw(ctx,s,t){const G=G3();if(!G.ok)return glFail(ctx);G.begin({eye:orbitEye(s,6.2),fov:36});lav(ctx);gShadow(ctx,G,[0,-1.25,0],1.3,.28,.3);const key=[s.p.fl,s.p.tw,s.p.bu].join();if(s.key!==key){s.key=key;const fl=s.p.fl,tw=s.p.tw,bu=s.p.bu;s.g=GEO.grid(220,90,(u,v)=>{const a=u*TAU+v*tw,y=1.2-v*2.4,r=(.55+bu*.45*Math.sin(v*Math.PI)-.12*v)*(1+.09*Math.cos(u*TAU*fl));return[Math.cos(a)*r,y,Math.sin(a)*r];});}
  G.draw(s.g,{color:hexv(hex2rgb2(hsl(s.p.hue,65,58))),rough:.28,clear:1});G.end(ctx);
  ctx.fillStyle='rgba(20,14,41,.82)';rr(ctx,W-200,16,184,98,12);ctx.fill();text(ctx,'GUI.AdvancedDynamicTexture',W-188,36,'#e9d5ff',11,'left',MONO);[['flutes',s.p.fl,3,16],['twist',s.p.tw,0,4],['bulge',s.p.bu,0,1]].forEach((r,i)=>{const y=56+i*20;text(ctx,r[0],W-188,y+4,'#c4b5fd',11.5);ctx.fillStyle='#3b3355';rr(ctx,W-128,y-3,98,6,3);ctx.fill();ctx.fillStyle=hsl(s.p.hue,85,72);rr(ctx,W-128,y-3,98*(r[1]-r[2])/(r[3]-r[2]),6,3);ctx.fill();});},
 code:`const ui=BABYLON.GUI.AdvancedDynamicTexture.CreateFullscreenUI('ui');
const twist=new BABYLON.GUI.Slider();twist.minimum=0;twist.maximum=4;ui.addControl(twist);
twist.onValueChangedObservable.add(v=>{column.dispose();
  column=BABYLON.MeshBuilder.CreateLathe('c',{shape,tessellation:220,sideOrientation:BABYLON.Mesh.DOUBLESIDE},scene);});`});
ex({t:'GPU particle fountain with colour-over-life',d:'Particles emitted in a cone with gravity, floor bounce, colour and size over life, drawn as soft depth-tested sprites around a chrome nozzle.',hint:'Drag to orbit · adjust rate and power.',orbit:{ry:.4,rx:.3,auto:.12},
 controls:[{type:'range',k:'rate',l:'Emit rate',min:100,max:1500,step:10,v:800},{type:'range',k:'pw',l:'Power',min:2,max:7,step:.1,v:4.6},{type:'select',k:'cg',l:'Gradient',v:'Sunset',opts:['Sunset','Lagoon','Aurora']}],
 init(s){s.P=[];s.acc=0;},
 draw(ctx,s,t,dt){const G=G3();if(!G.ok)return glFail(ctx);G.begin({eye:orbitEye(s,7.5,[0,.6,0]),fov:38});lav(ctx);s.acc+=dt*s.p.rate;while(s.acc>1){s.acc--;const a=Math.random()*TAU,sp=.3+Math.random()*.5;s.P.push({p:[0,-.45,0],v:[Math.cos(a)*sp,s.p.pw*(.8+Math.random()*.25),Math.sin(a)*sp],l:0});}
  const grad={Sunset:['#fde68a','#f97316','#db2777','#7c3aed'],Lagoon:['#cffafe','#06b6d4','#0284c7','#4338ca'],Aurora:['#bbf7d0','#14b8a6','#8b5cf6','#ec4899']}[s.p.cg];
  for(let i=s.P.length-1;i>=0;i--){const q=s.P[i];q.v[1]-=5.5*dt;q.p=add(q.p,mul(q.v,dt));q.l+=dt;if(q.p[1]<-.6){q.p[1]=-.6;q.v[1]*=-.35;q.v[0]*=.7;q.v[2]*=.7;}if(q.l>2.6)s.P.splice(i,1);}
  const n=s.P.length,pos=new Float32Array(n*3),col=new Float32Array(n*4),sz=new Float32Array(n);s.P.forEach((q,i)=>{const u=q.l/2.6,c=hexv(hex2rgb2(scale(grad,u)));pos.set(q.p,i*3);col.set([c[0],c[1],c[2],(1-u)*.85],i*4);sz[i]=1.5+u*4;});
  G.draw(FLOOR('c',6,-.62),{color:'#f6f1fc',rough:.3,op:.45,glass:0});G.draw(GM('nozz',()=>GEO.superq(.18,.12,.18,.6,32,20)),{m:M4.T(0,-.55,0),color:'#d6d3e0',metal:1,rough:.15});
  G.points(pos,col,sz,{size:3.2,soft:.5});G.end(ctx);hud(ctx,['ParticleSystem',n+' live particles'],14,14);},
 code:`const ps=new BABYLON.ParticleSystem('fountain',2000,scene);ps.particleTexture=new BABYLON.Texture('assets/flare.png');
ps.createConeEmitter(.4,Math.PI/6);ps.emitRate=800;ps.gravity=new BABYLON.Vector3(0,-9.8,0);
ps.addColorGradient(0,new BABYLON.Color4(1,.9,.5,1));ps.addColorGradient(1,new BABYLON.Color4(.5,.2,.9,0));
ps.addSizeGradient(0,.05);ps.addSizeGradient(1,.25);ps.start();`});

lib('playcanvas','PlayCanvas','c3d','Entity-component 3D engine with a visual editor; ideal for product configurators and lightweight 3D apps.');
ex({t:'Product configurator: ceramic mug',d:'A lathed mug with rolled rim, glazed interior, base and swept handle. Switch glaze and the clear-coated ceramic material updates instantly.',hint:'Drag to orbit · choose a glaze.',orbit:{ry:-.6,rx:.32,auto:.28},controls:[{type:'seg',k:'g',v:'Lavender',opts:['Lavender','Sage','Coral','Midnight','Butter','Chrome']}],
 init(s){s.body=GM('mugb',()=>GEO.grid(120,60,(u,v)=>{const a=u*TAU;let r,y;if(v<.86){const w=v/.86;r=.62+.035*Math.sin(w*Math.PI)+.02*w;y=-.78+w*1.56;}else{const w=(v-.86)/.14;r=.66-.06*w;y=.78+.035*Math.sin(w*Math.PI);}return[Math.cos(a)*r,y,Math.sin(a)*r];}));
  s.inner=GM('mugi',()=>GEO.grid(100,30,(u,v)=>{const a=u*TAU,r=.585-.03*v*v,y=.79-v*1.44;return[Math.cos(a)*r,y,Math.sin(a)*r];}));s.base=GM('mugbase',()=>GEO.grid(80,8,(u,v)=>{const a=u*TAU,r=.62*(1-v);return[Math.cos(a)*r,-.78,Math.sin(a)*r];},()=>[0,-1,0]));
  s.handle=GM('mugh',()=>GEO.tube(u=>{const a=-1.25+u*2.5;return[.62+.34*Math.cos(a),.42*Math.sin(a),0];},false,[.075,.05],120,24));},
 draw(ctx,s,t){const G=G3();if(!G.ok)return glFail(ctx);G.begin({eye:orbitEye(s,4.6,[0,-.05,0]),fov:34});lav(ctx,'#fffdfb','#efe7f6');gShadow(ctx,G,[0,-.8,0],.95,.3,.34);const Gz={Lavender:['#a78bfa',.3],Sage:['#86a789',.35],Coral:['#fb7185',.32],Midnight:['#1e1b4b',.25],Butter:['#fde68a',.3],Chrome:['#e5e7eb',.08]}[s.p.g],mt={color:Gz[0],rough:Gz[1],clear:1,metal:s.p.g==='Chrome'?1:0};
  [s.body,s.handle,s.base].forEach(g=>G.draw(g,mt));G.draw(s.inner,{color:'#fbf8f3',rough:.25,clear:.6});G.end(ctx);
  text(ctx,'Glaze · '+s.p.g,22,38,'#140E29',19,'left','"Space Grotesk",'+FONT,700);text(ctx,'Stoneware mug · 350 ml · $24',22,60,'#4C4369',13);cap(ctx,'entity.render.meshInstances[0].material = glazes[name]');},
 code:`const mug=app.root.findByName('Mug');
swatches.forEach(b=>b.onclick=()=>{const mat=mug.render.meshInstances[0].material;
  mat.diffuse.fromString(b.dataset.color);mat.clearCoat=1;mat.gloss=.7;mat.update();});`});
ex({t:'Entity hierarchy: inherited transforms',d:'A sun entity spins; its child pivot carries a planet whose own child carries a moon. Fading orbit trails and the live entity tree show how transforms compose.',hint:'Drag to orbit.',orbit:{ry:.2,rx:.55,auto:0},
 init(s){s.tr=[];s.tm=[];},
 draw(ctx,s,t){const G=G3();if(!G.ok)return glFail(ctx);G.begin({eye:orbitEye(s,8),fov:36});lav(ctx);const sp=SPH(),box=GM('rb3',()=>GEO.superq(1,1,1,.16,40,28));
  const a1=t*.6,pl=[Math.cos(a1)*2.2,0,Math.sin(a1)*2.2],a2=t*2.2,mo=add(pl,[Math.cos(a2)*.6,.05,Math.sin(a2)*.6]);s.tr.push(...pl);s.tm.push(...mo);if(s.tr.length>600*3)s.tr.splice(0,3);if(s.tm.length>300*3)s.tm.splice(0,3);
  const lc=(arr,c)=>{const n=arr.length/3,Cc=new Float32Array(n*4);for(let i=0;i<n;i++)Cc.set([c[0],c[1],c[2],i/n*.7],i*4);return Cc;};G.lines(new Float32Array(s.tr),lc(s.tr,[.49,.23,.93]),{strip:true});G.lines(new Float32Array(s.tm),lc(s.tm,[.86,.15,.47]),{strip:true});
  G.draw(sp,{m:M4.chain(M4.RY(t*.5),M4.S(.55)),color:'#fbbf24',em:[.35,.22,.02],rough:.6});G.draw(box,{m:M4.chain(M4.T(...pl),M4.RY(t*1.4),M4.S(.24)),color:'#0284c7',rough:.25,clear:1});G.draw(sp,{m:M4.chain(M4.T(...mo),M4.S(.1)),color:'#db2777',rough:.3});G.end(ctx);
  hud(ctx,['Root','└ Sun        rot  '+((t*.5/D2R)%360).toFixed(0)+'°','   └ Pivot    rot  '+((a1/D2R)%360).toFixed(0)+'°','      └ Planet  pos  '+pl.map(v=>v.toFixed(1)).join(','),'         └ Moon orbit '+((a2/D2R)%360).toFixed(0)+'°'],14,14);},
 code:`const sun=new pc.Entity('Sun');sun.addComponent('render',{type:'sphere'});app.root.addChild(sun);
const pivot=new pc.Entity();sun.addChild(pivot);
const planet=new pc.Entity('Planet');planet.addComponent('render',{type:'box'});planet.setLocalPosition(2.2,0,0);pivot.addChild(planet);
app.on('update',dt=>{sun.rotate(0,30*dt,0);pivot.rotate(0,34*dt,0);});`});

lib('cesium','CesiumJS','c3d','True-scale 3D Earth: terrain, imagery, satellites, time-dynamic data and 3D Tiles digital twins.');
ex({t:'Photoreal Earth: satellite orbit & ground track',d:'A shaded Earth (traced continents, biomes, ocean glint, clouds, atmosphere) with an ISS-like orbit at 51.6°; its sub-satellite track is painted onto the surface live.',hint:'Drag to rotate · hover the globe for latitude/longitude.',orbit:{ry:.4,rx:.35,auto:.06},int:1,
 init(s){s.tr=[];},
 draw(ctx,s,t){const G=G3();if(!G.ok)return glFail(ctx);G.begin({eye:orbitEye(s,3.9),fov:36});lav(ctx,'#fbf9ff','#ebe3f7');const spin=t*.05,EM=M4.RY(spin);
  G.globe({m:EM,t,sun:[.9,.35,.75]});const inc=51.6*D2R,orb=1.24,a=t*.55,sat=u=>[Math.cos(u)*orb,Math.sin(u)*Math.sin(inc)*orb,-Math.sin(u)*Math.cos(inc)*orb];
  const ring=[];for(let i=0;i<=200;i++)ring.push(...sat(i/200*TAU));const rc=new Float32Array(201*4);for(let i=0;i<=200;i++)rc.set([.85,.47,.04,.6],i*4);G.lines(new Float32Array(ring),rc,{strip:true});
  const sp=sat(a),gp=M4.xf(M4.RY(-spin),norm(sp));s.tr.push(gp);if(s.tr.length>420)s.tr.shift();const TP=[],TC=[];s.tr.forEach((g,i)=>{TP.push(...M4.xf(EM,mul(g,1.004)));TC.push(.88,.11,.28,i/s.tr.length);});G.lines(new Float32Array(TP),new Float32Array(TC),{strip:true});
  G.draw(SPH(),{m:M4.chain(M4.T(...sp),M4.S(.035)),color:'#fbbf24',em:[.8,.5,.1]});G.end(ctx);
  const q=G.project(sp);text(ctx,'ISS-like · 408 km',q[0]+12,q[1]-10,'#140E29',12.5,'left',FONT,700);
  if(s.hover){const r=G.ray(s.mx,s.my),d=raySphere(r,[0,0,0],1);if(d>0){const w=M4.xf(M4.RY(-spin),add(r.o,mul(r.d,d))),la=Math.asin(clamp(w[1],-1,1))/D2R,lo=Math.atan2(-w[2],w[0])/D2R;tooltip(ctx,s.mx,s.my,[Math.abs(la).toFixed(2)+'°'+(la>=0?'N':'S')+'  '+Math.abs(lo).toFixed(2)+'°'+(lo>=0?'E':'W'),EARTH().isLand(la,lo)?'land':'ocean']);}}
  hud(ctx,['inclination 51.6°','period 92.7 min','alt 408 km'],14,14);},
 code:`const viewer=new Cesium.Viewer('cesium',{baseLayer:Cesium.ImageryLayer.fromProviderAsync(
  Cesium.TileMapServiceImageryProvider.fromUrl(Cesium.buildModuleUrl('Assets/Textures/NaturalEarthII')))});
const pos=new Cesium.SampledPositionProperty();samples.forEach(s=>pos.addSample(s.time,Cesium.Cartesian3.fromDegrees(s.lon,s.lat,408000)));
viewer.entities.add({position:pos,point:{pixelSize:10,color:Cesium.Color.ORANGE},path:{leadTime:0,trailTime:3600,width:2}});`});
ex({t:'Clock & timeline: day/night terminator with city lights',d:'Scrub the clock: the subsolar point is computed from UTC hour and day of year, lighting the globe; the night side glows with city lights as the terminator sweeps across.',hint:'Drag the sliders · drag the globe.',orbit:{ry:-.2,rx:.3,auto:0},
 controls:[{type:'range',k:'hr',l:'UTC hour',min:0,max:24,step:.05,v:18,fmt:v=>(+v).toFixed(1)+'h'},{type:'range',k:'doy',l:'Day of year',min:1,max:365,v:172},{type:'toggle',k:'play',l:'Animate',v:true}],
 draw(ctx,s,t,dt){const G=G3();if(!G.ok)return glFail(ctx);if(s.p.play)s.p.hr=(s.p.hr+dt*.9)%24;const dec=-23.44*Math.cos(TAU*(s.p.doy+10)/365),sl=-(s.p.hr-12)*15,sun=llv(dec,sl);G.begin({eye:orbitEye(s,3.7),fov:36});lav(ctx,'#f7f4fd','#e4dcf2');G.globe({sun,t,night:1.4,exp:1.15});G.end(ctx);
  const d=new Date(Date.UTC(2026,0,s.p.doy,Math.floor(s.p.hr),(s.p.hr%1)*60));hud(ctx,[d.toISOString().slice(0,16).replace('T',' ')+' UTC','subsolar '+dec.toFixed(1)+'°, '+(((sl+540)%360)-180).toFixed(1)+'°'],14,14);cap(ctx,'viewer.scene.globe.enableLighting = true; viewer.clock.multiplier = 3600');},
 code:`viewer.scene.globe.enableLighting=true;viewer.scene.globe.showGroundAtmosphere=true;
viewer.clock.currentTime=Cesium.JulianDate.fromIso8601('2026-06-21T18:00Z');
viewer.clock.multiplier=3600;viewer.clock.shouldAnimate=true;   // one hour per second`});
ex({t:'3D Tiles digital twin: a city district',d:'Hundreds of extruded, rounded buildings on a street grid, coloured by height, with a river and park under depth fog. Fly the camera between presets.',hint:'Drag to orbit · press a fly-to preset.',orbit:{ry:.7,rx:.62,auto:.05},
 controls:[{type:'btn',l:'✈ Overview',fn:s=>s.fly=[.7,.62,8]},{type:'btn',l:'✈ Street level',fn:s=>s.fly=[2.1,.12,4.4]},{type:'btn',l:'✈ Top-down',fn:s=>s.fly=[0,1.4,7.5]},{type:'toggle',k:'h',l:'Colour by height',v:true}],
 init(s){const r=rng(9),B=[];s.dist=8;for(let i=-10;i<10;i++)for(let j=-10;j<10;j++){if(i===0||j===-2||(j>=3&&j<=4))continue;if((i-5)*(i-5)+(j+6)*(j+6)<6)continue;const cx=i*.24+.12,cz=j*.24+.12,f=Math.exp(-(i*i+j*j)/50),h=.04+Math.pow(r(),2.4)*1.3*f+.03,w=.075+r()*.025;B.push([cx,h,cz,w,h]);}s.B=B;},
 draw(ctx,s,t){const G=G3();if(!G.ok)return glFail(ctx);if(s.fly){s.ry=lerp(s.ry,s.fly[0],.06);s.rx=lerp(s.rx,s.fly[1],.06);s.dist=lerp(s.dist,s.fly[2],.06);if(Math.abs(s.ry-s.fly[0])<.005)s.fly=null;}G.begin({eye:orbitEye(s,s.dist,[0,.1,0]),fov:36,fogD:.06,fog:hexv('#f1ebfa')});lav(ctx,'#f8f5fe','#e7dff4');
  const box=GM('rb4',()=>GEO.superq(1,1,1,.1,24,16)),D=new Float32Array(s.B.length*9);s.B.forEach((b,k)=>{const c=s.p.h?hexv(hex2rgb2(scale(['#e9d5ff','#a78bfa','#7c3aed','#4c1d95'],clamp(b[4]/.9,0,1)))):[.92,.9,.95];D.set([b[0],b[1]/2,b[2],b[3],b[1]/2,b[3],c[0],c[1],c[2]],k*9);});
  G.draw(GM('city0',()=>GEO.superq(2.5,.03,2.5,.12,40,12)),{m:M4.T(0,-.03,0),color:'#ece6f4',rough:.6});G.draw(GM('river',()=>GEO.grid(1,1,(u,v)=>[(u-.5)*5,.002,.84+(v-.5)*.38],()=>[0,1,0])),{color:'#38bdf8',rough:.05,clear:1,metal:.2});G.draw(GM('park',()=>GEO.superq(.5,.02,.5,.4,32,10)),{m:M4.T(1.32,.01,-1.32),color:'#86efac',rough:.8});
  G.inst(box,D,s.B.length,{rough:.35,clear:.7});G.end(ctx);hud(ctx,['Cesium3DTileset · '+s.B.length+' features','tallest '+Math.max(...s.B.map(b=>b[4]*120)).toFixed(0)+' m'],14,14);},
 code:`const city=await Cesium.Cesium3DTileset.fromUrl('tiles/tileset.json');viewer.scene.primitives.add(city);
city.style=new Cesium.Cesium3DTileStyle({color:{conditions:[['\${height} > 120','color("#4c1d95")'],['\${height} > 40','color("#a78bfa")'],['true','color("#e9d5ff")']]}});
viewer.camera.flyTo({destination:Cesium.Cartesian3.fromDegrees(-74.01,40.70,600),orientation:{pitch:-.5},duration:2});`});
