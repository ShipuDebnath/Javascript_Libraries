/* ===================== Biology & Chemistry ===================== */
const ELC={C:'#57534e',H:'#e7e5e4',O:'#ef4444',N:'#3b82f6',S:'#eab308',P:'#f97316',Cl:'#22c55e'},ELR={C:.7,H:.38,O:.66,N:.65,S:.9,P:.9,Cl:.9},ELH={C:30,H:0,O:0,N:220,S:50,P:25,Cl:130};
function mol2D(name){const A=[],B=[],at=(x,y,e)=>{A.push([x,y,e]);return A.length-1;},bd=(a,b,o)=>B.push([a,b,o||1]);const hex=(cx,cy,r)=>Array.from({length:6},(_,k)=>[cx+r*Math.cos((-90+60*k)*D2R),cy+r*Math.sin((-90+60*k)*D2R)]);
 if(name==='Benzene'){const v=hex(0,0,1);v.forEach(p=>at(p[0],p[1],'C'));for(let k=0;k<6;k++)bd(k,(k+1)%6,k%2?1:2);}
 else if(name==='Ethanol'){at(-1.3,.4,'C');at(0,-.35,'C');at(1.3,.4,'O');bd(0,1);bd(1,2);}
 else if(name==='Caffeine'){const v=hex(0,0,1),el=['C','C','C','N','C','N'];v.forEach((p,k)=>at(p[0],p[1],el[k]));bd(0,1,1);bd(1,2,2);bd(2,3);bd(3,4);bd(4,5);bd(5,0);
  const p1=v[1],p2=v[2],mid=[(p1[0]+p2[0])/2,(p1[1]+p2[1])/2],c=[mid[0]+.688,mid[1]],a0=Math.atan2(p1[1]-c[1],p1[0]-c[0]),R=Math.hypot(p1[0]-c[0],p1[1]-c[1]);const pv=[1,2,3].map(k=>[c[0]+R*Math.cos(a0+k*72*D2R),c[1]+R*Math.sin(a0+k*72*D2R)]);
  const n7=at(pv[0][0],pv[0][1],'N'),c8=at(pv[1][0],pv[1][1],'C'),n9=at(pv[2][0],pv[2][1],'N');bd(1,n7);bd(n7,c8);bd(c8,n9,2);bd(n9,2);
  const o1=at(v[0][0],v[0][1]-1,'O');bd(0,o1,2);const o2=at(v[4][0]-.87,v[4][1]+.5,'O');bd(4,o2,2);const m1=at(v[5][0]-.87,v[5][1]-.5,'C');bd(5,m1);const m3=at(v[3][0],v[3][1]+1,'C');bd(3,m3);const m7=at(pv[0][0]+.3,pv[0][1]-.95,'C');bd(n7,m7);}
 else if(name==='Aspirin'){const v=hex(0,0,1);v.forEach(p=>at(p[0],p[1],'C'));for(let k=0;k<6;k++)bd(k,(k+1)%6,k%2?2:1);const c7=at(v[0][0],v[0][1]-1,'C');bd(0,c7);const o8=at(c7[0]-.87,-1.5-.5,'O');A[o8][0]=v[0][0]-.87;A[o8][1]=v[0][1]-1.5;bd(c7,o8,2);const o9=at(v[0][0]+.87,v[0][1]-1.5,'O');bd(c7,o9);
  const o10=at(v[1][0]+.87,v[1][1]-.5,'O');bd(1,o10);const c11=at(v[1][0]+1.74,v[1][1],'C');bd(o10,c11);const o12=at(v[1][0]+1.74,v[1][1]+1,'O');bd(c11,o12,2);const c13=at(v[1][0]+2.61,v[1][1]-.5,'C');bd(c11,c13);}
 return{A,B};}
function molFormula(m){const cnt={},val={C:4,N:3,O:2,S:2,Cl:1};m.A.forEach((a,i)=>{cnt[a[2]]=(cnt[a[2]]||0)+1;let b=0;m.B.forEach(x=>{if(x[0]===i||x[1]===i)b+=x[2];});const h=Math.max(0,(val[a[2]]||0)-b);if(a[2]!=='H')cnt.H=(cnt.H||0)+h;});return cnt;}
const MW={C:12.011,H:1.008,N:14.007,O:15.999,S:32.06,P:30.974,Cl:35.45,F:18.998,Br:79.904,I:126.9,B:10.81};
function mol3D(name){const m=mol2D(name),cnt={};const A=m.A.map(a=>({p:[a[0]*.75,a[1]*.75,0],e:a[2]})),B=m.B.slice();const val={C:4,N:3,O:2};
 m.A.forEach((a,i)=>{let b=0,nb=[];m.B.forEach(x=>{if(x[0]===i){b+=x[2];nb.push(x[1]);}if(x[1]===i){b+=x[2];nb.push(x[0]);}});const h=Math.max(0,(val[a[2]]||0)-b);if(!h)return;const p=A[i].p;let dir=[0,0,0];nb.forEach(j=>{dir=add(dir,norm(sub(p,A[j].p)));});dir=norm(len3(dir)>.01?dir:[1,0,0]);
  for(let k=0;k<h;k++){let d;if(h===1)d=dir;else if(h===2)d=norm(add(dir,[0,0,k?.9:-.9]));else{const a=k/3*TAU;d=norm(add(mul(dir,.55),[-dir[1]*Math.cos(a)*.7,dir[0]*Math.cos(a)*.7,Math.sin(a)*.8]));}A.push({p:add(p,mul(d,.8)),e:'H'});B.push([i,A.length-1,1]);}});return{A,B};}
function drawMol3D(ctx,M,ry,rx,sc,style,cx,cy){const R=M.A.map(a=>rot(a.p,ry,rx)),P=R.map(p=>pr(p,sc,6,cx,cy)),items=[];const rad=e=>style==='Spacefill'?ELR[e]*1.5:style==='Ball & stick'?ELR[e]*.45:style==='Stick'?.12:0;
 if(style!=='Spacefill')M.B.forEach(([a,b,o])=>{items.push({z:(R[a][2]+R[b][2])/2-.02,fn:()=>{const A=P[a],Bp=P[b],mx=(A[0]+Bp[0])/2,my=(A[1]+Bp[1])/2,w=(style==='Line'?2.2:style==='Stick'?9:6)*(A[3]+Bp[3])/2;ctx.lineCap='round';const dx=Bp[0]-A[0],dy=Bp[1]-A[1],l=Math.hypot(dx,dy)||1,nx=-dy/l,ny=dx/l,offs=o===2&&style!=='Stick'?[-3.5,3.5]:[0];
  offs.forEach(of=>{ctx.lineWidth=o===2&&style!=='Stick'?w*.6:w;ctx.strokeStyle=ELC[M.A[a].e];ctx.beginPath();ctx.moveTo(A[0]+nx*of,A[1]+ny*of);ctx.lineTo(mx+nx*of,my+ny*of);ctx.stroke();ctx.strokeStyle=ELC[M.A[b].e];ctx.beginPath();ctx.moveTo(mx+nx*of,my+ny*of);ctx.lineTo(Bp[0]+nx*of,Bp[1]+ny*of);ctx.stroke();});}});});
 if(style!=='Line')M.A.forEach((a,i)=>items.push({z:R[i][2],fn:()=>{const e=a.e,r=rad(e)*sc*P[i][3];if(e==='H')sphere(ctx,P[i][0],P[i][1],r,0,0,93);else sphere(ctx,P[i][0],P[i][1],r,ELH[e],e==='C'?6:75,e==='C'?40:55);}}));
 items.sort((a,b)=>a.z-b.z).forEach(it=>it.fn());return{R,P};}

lib('3dmol','3Dmol.js','bio','Molecular visualisation in the browser: PDB/SDF/MOL2 models with stick, sphere, cartoon and surface styles.',{ik:'3Dmol.js'});
ex({t:'Caffeine with representation styles',d:'C₈H₁₀N₄O₂ with CPK colours. Switch between line, stick, ball-and-stick and spacefill, as setStyle() does.',hint:'Drag to rotate · switch styles.',orbit:{ry:.3,rx:.4,auto:.4},controls:[{type:'seg',k:'st',v:'Ball & stick',opts:['Line','Stick','Ball & stick','Spacefill']}],
 init(s){s.M=mol3D('Caffeine');const c=s.M.A.reduce((a,b)=>add(a,b.p),[0,0,0]);s.M.A.forEach(a=>a.p=sub(a.p,mul(c,1/s.M.A.length)));},
 draw(ctx,s,t){vgrad(ctx,'#ffffff','#f3f1ec');softShadow(ctx,W/2,H-60,180,22,.12);drawMol3D(ctx,s.M,s.ry,s.rx,110,s.p.st);const L=[['C','#57534e'],['N','#3b82f6'],['O','#ef4444'],['H','#d6d3d1']];L.forEach(([e,c],i)=>{circle(ctx,24,30+i*22,7,c);text(ctx,e,38,35+i*22,C.ink2,12.5,'left',FONT,600);});text(ctx,'Caffeine · C₈H₁₀N₄O₂ · 194.19 g/mol',W-16,28,C.ink2,13,'right');cap(ctx,'viewer.setStyle({},{stick:{radius:.15},sphere:{scale:.3}})');},
 code:`const viewer=$3Dmol.createViewer('mol',{backgroundColor:'white'});
viewer.addModel(sdfText,'sdf');                      // local file, no network
viewer.setStyle({},{stick:{radius:.15},sphere:{scale:.3}});   // or {sphere:{}} / {line:{}}
viewer.zoomTo();viewer.spin('y',1);viewer.render();`});
ex({t:'Benzene: aromatic ring with surface dots',d:'A ball-and-stick benzene ring (C₆H₆) with alternating double bonds and a dotted van der Waals surface around it.',hint:'Drag to rotate · toggle the surface.',orbit:{ry:.2,rx:.9,auto:.5},controls:[{type:'toggle',k:'sf',l:'VDW surface',v:true}],
 init(s){s.M=mol3D('Benzene');const r=rng(2);s.dots=[];s.M.A.forEach(a=>{const R=ELR[a.e]*1.5;for(let k=0;k<70;k++){const z=r()*2-1,ph=r()*TAU,rr2=Math.sqrt(1-z*z),p=add(a.p,mul([rr2*Math.cos(ph),z,rr2*Math.sin(ph)],R));if(s.M.A.every(b=>b===a||len3(sub(p,b.p))>=ELR[b.e]*1.5-.01))s.dots.push(p);}});},
 draw(ctx,s,t){vgrad(ctx,'#ffffff','#f3f1ec');drawMol3D(ctx,s.M,s.ry,s.rx,120,'Ball & stick');if(s.p.sf)s.dots.forEach(p=>{const r=rot(p,s.ry,s.rx),q=pr(r,120);ctx.fillStyle='rgba(79,70,229,'+clamp(.15+r[2]*.3,.05,.6)+')';ctx.fillRect(q[0]-1.2,q[1]-1.2,2.4,2.4);});cap(ctx,'viewer.addSurface($3Dmol.SurfaceType.VDW,{opacity:.6, color:"#4f46e5"})');},
 code:`viewer.addModel(benzeneSdf,'sdf');
viewer.setStyle({},{stick:{},sphere:{scale:.3}});
viewer.addSurface($3Dmol.SurfaceType.VDW,{opacity:.6,color:'#4f46e5'});viewer.zoomTo();viewer.render();`});

function helixBundle(){const ch=[];for(let k=0;k<3;k++){const a=k/3*TAU,cx=Math.cos(a)*1.0,cz=Math.sin(a)*1.0,up=k%2==0;for(let i=0;i<22;i++){const y=(up?-1:1)*(-2+i*.19),ph=i*1.75+k;ch.push({p:[cx+.42*Math.cos(ph),y,cz+.42*Math.sin(ph)],loop:0});}
 if(k<2){const nx=Math.cos((k+1)/3*TAU),nz=Math.sin((k+1)/3*TAU),endY=(up?-1:1)*(-2+21*.19),dy=up?-1:1;for(let i=1;i<=5;i++){const f=i/6;ch.push({p:[lerp(cx,nx,f)*(1+.5*Math.sin(f*Math.PI)),endY+dy*.5*Math.sin(f*Math.PI),lerp(cz,nz,f)*(1+.5*Math.sin(f*Math.PI))],loop:1});}}}return ch;}
lib('molstar','Mol*','bio','Publication-quality macromolecular visualisation: cartoons, surfaces, density maps, huge assemblies and a sequence panel.',{ik:'Mol*'});
ex({t:'Three-helix bundle (cartoon)',d:'A ribbon cartoon coloured from N- to C-terminus with loops thinner than helices, the default Mol* look.',hint:'Drag to rotate.',orbit:{ry:0,rx:.2,auto:.45},
 init(s){s.ch=helixBundle();},
 draw(ctx,s,t){vgrad(ctx,'#ffffff','#f3f1ec');const R=s.ch.map(c=>rot(c.p,s.ry,s.rx)),L=[];for(let i=0;i<R.length-1;i++){const a=pr(R[i],95),b=pr(R[i+1],95),c=s.ch[i+1],hue=250-i/R.length*250,w=(c.loop?5:14)*(a[3]+b[3])/2;L.push({z:(R[i][2]+R[i+1][2])/2,fn:()=>{ctx.lineCap='round';ctx.strokeStyle=hsl(hue,c.loop?10:70,c.loop?60:48);ctx.lineWidth=w;line(ctx,a[0],a[1],b[0],b[1],ctx.strokeStyle,w);line(ctx,a[0]-1,a[1]-2,b[0]-1,b[1]-2,hsl(hue,c.loop?10:85,c.loop?80:72,.7),w*.35);}});}
  L.sort((a,b)=>a.z-b.z).forEach(x=>x.fn());badge(ctx,'N-term',14,14,'#ede9fe','#6d28d9');badge(ctx,'C-term',84,14,'#fee2e2','#b91c1c');cap(ctx,'plugin.builders.structure.representation.addRepresentation(s,{type:"cartoon"})');},
 code:`const viewer=await molstar.Viewer.create('app',{layoutIsExpanded:false,layoutShowControls:false});
await viewer.loadStructureFromData(pdbText,'pdb');          // offline: data, not URL
// cartoon coloured by sequence-id is the default preset`});
ex({t:'Sequence panel linked to the 3D view',d:'Hovering a residue in the sequence strip highlights it in 3D, and hovering the structure highlights the residue letter.',hint:'Hover the letters or the structure.',int:1,orbit:{ry:.6,rx:.25,auto:.12},
 init(s){s.ch=helixBundle();const aa='MKTAYIAKQRQISFVKSHFSRQLEERLGLIEVQAPILSRVGDGTQDNLSGAEKAVQVKVKALPDAQFEVVHSLAKWKRQTLGQHDFSAGEGLYTHMKALRPDEDRLSPLHSVYVDQWDWERVMGDGERQFSTLKSTVEAIWAGIKATEAAVSEEFGLAPFLPDQIHFVHSQELLSRYPDLDAKGRERAIAKDLGAVFLVGIGGKLSDGHRHDVRAPDYDDWSTPSELGHAGLNGDILVWNPVLEDAFELSSMGIRVDADTLKHQLALTGDEDRLELEWHQALLRGEMPQTIGGGIGQSRLTMLLLQLPHIGQVQAGVWPAAVRESVPALL';s.seq=aa.slice(0,s.ch.length);s.hv=-1;},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const n=s.ch.length,cw=(W-28)/Math.ceil(n/2);let hs=-1;ctx.fillStyle='#f5f3ef';rr(ctx,10,8,W-20,60,8);ctx.fill();
  for(let i=0;i<n;i++){const row=i<n/2?0:1,col=row?i-Math.ceil(n/2):i,x=14+col*cw,y=30+row*24;if(s.hover&&s.my<70&&Math.abs(s.mx-x-cw/2)<cw/2&&Math.abs(s.my-y+5)<11)hs=i;const on=i===s.hv;if(on){ctx.fillStyle='#e11d48';rr(ctx,x,y-14,cw,19,3);ctx.fill();}text(ctx,s.seq[i],x+cw/2,y,on?'#fff':s.ch[i].loop?C.mut:hsl(250-i/n*250,60,40),11,'center',MONO,600);}
  const R=s.ch.map(c=>rot(c.p,s.ry,s.rx)),P=R.map(p=>pr(p,72,6,W/2,H/2+40));let h3=-1;if(s.hover&&s.my>80){let bd=14;P.forEach((p,i)=>{const d=Math.hypot(p[0]-s.mx,p[1]-s.my);if(d<bd){bd=d;h3=i;}});}s.hv=hs>=0?hs:h3;
  const L=[];for(let i=0;i<n-1;i++){const a=P[i],b=P[i+1],hue=250-i/n*250,w=(s.ch[i+1].loop?4:10)*(a[3]+b[3])/2;L.push({z:(R[i][2]+R[i+1][2])/2,fn:()=>{ctx.lineCap='round';line(ctx,a[0],a[1],b[0],b[1],hsl(hue,s.ch[i+1].loop?10:65,s.ch[i+1].loop?65:55),w);}});}
  L.sort((a,b)=>a.z-b.z).forEach(x=>x.fn());if(s.hv>=0){const p=P[s.hv];circle(ctx,p[0],p[1],11,'rgba(225,29,72,.25)','#e11d48',2.5);tooltip(ctx,p[0],p[1]-8,[s.seq[s.hv]+(s.hv+1),s.ch[s.hv].loop?'loop':'α-helix']);}},
 code:`// Mol* syncs selection between the sequence panel and 3D automatically:
const viewer=await molstar.Viewer.create('app',{layoutShowSequence:true});
await viewer.loadStructureFromData(pdbText,'pdb');
viewer.plugin.managers.interactivity.lociHighlights.highlightOnly({loci});   // programmatic highlight`});

lib('ngl','NGL Viewer','bio','WebGL viewer for large molecular assemblies and molecular-dynamics trajectories.',{ik:'NGL Viewer'});
ex({t:'DNA double helix with base pairs',d:'Two sugar-phosphate backbones and colour-coded base pairs (A–T red/blue, G–C green/amber) rotating as one assembly.',hint:'Drag to rotate.',orbit:{ry:0,rx:.15,auto:.7},
 draw(ctx,s,t){vgrad(ctx,'#ffffff','#f3f1ec');const n=26,sc=72,L=[],seq=[0,1,1,0,1,0,0,1,1,1,0,0,1,0,1,1,0,1,0,0,1,0,1,1,0,0],pa=[],pb=[];for(let i=0;i<n;i++){const y=(i-12.5)*.2,th=i*.62;pa.push(rot([Math.cos(th)*1.05,y,Math.sin(th)*1.05],s.ry,s.rx));pb.push(rot([Math.cos(th+Math.PI)*1.05,y,Math.sin(th+Math.PI)*1.05],s.ry,s.rx));}
  for(let i=0;i<n;i++){const A=pr(pa[i],sc),B=pr(pb[i],sc),M=[(A[0]+B[0])/2,(A[1]+B[1])/2],gc=seq[i],c1=gc?'#10b981':'#ef4444',c2=gc?'#f59e0b':'#3b82f6';
   L.push({z:(pa[i][2]+pb[i][2])/2,fn:()=>{ctx.lineCap='round';line(ctx,A[0],A[1],M[0],M[1],c1,6*(A[3]+B[3])/2);line(ctx,M[0],M[1],B[0],B[1],c2,6*(A[3]+B[3])/2);}});L.push({z:pa[i][2]+.02,fn:()=>sphere(ctx,A[0],A[1],9*A[3],270,55,62)});L.push({z:pb[i][2]+.02,fn:()=>sphere(ctx,B[0],B[1],9*B[3],200,55,62)});
   if(i<n-1){const A2=pr(pa[i+1],sc),B2=pr(pb[i+1],sc);L.push({z:(pa[i][2]+pa[i+1][2])/2,fn:()=>line(ctx,A[0],A[1],A2[0],A2[1],'#a78bfa',5*A[3])});L.push({z:(pb[i][2]+pb[i+1][2])/2,fn:()=>line(ctx,B[0],B[1],B2[0],B2[1],'#7dd3fc',5*B[3])});}}
  L.sort((a,b)=>a.z-b.z).forEach(x=>x.fn());[['A–T','#ef4444'],['G–C','#10b981']].forEach(([l,c],i)=>badge(ctx,l,14+i*60,14,rgba(c,.12),c));cap(ctx,'stage.loadFile("1bna.pdb").then(o=>o.addRepresentation("licorice"))');},
 code:`const stage=new NGL.Stage('viewport',{backgroundColor:'white'});
stage.loadFile('data/1bna.pdb').then(o=>{o.addRepresentation('cartoon',{color:'chainid'});
  o.addRepresentation('base',{color:'resname'});o.autoView();});`});
ex({t:'MD trajectory playback with RMSD',d:'A 60-residue chain wobbling through 200 frames of a simulated trajectory; the RMSD-vs-frame plot tracks the deviation from frame 0.',hint:'Drag the frame slider · drag to rotate.',orbit:{ry:.3,rx:.3,auto:.1},controls:[{type:'range',k:'f',l:'Frame',min:0,max:199,v:0},{type:'toggle',k:'play',l:'Play',v:true}],
 init(s){const n=60;s.base=Array.from({length:n},(_,i)=>{const a=i*.55;return[Math.cos(a)*(.6+.25*Math.sin(i*.3)),(i-30)*.05,Math.sin(a)*(.6+.25*Math.sin(i*.3))];});s.fr=t=>s.base.map((p,i)=>add(p,[Math.sin(t*.09+i*.4)*.12*Math.sin(t*.02),Math.cos(t*.07+i*.3)*.1*Math.sin(t*.025),Math.sin(t*.05+i*.6)*.12*Math.sin(t*.02)]));s.rmsd=Array.from({length:200},(_,f)=>{const P=s.fr(f);return Math.sqrt(P.reduce((a,p,i)=>a+Math.pow(len3(sub(p,s.base[i])),2),0)/P.length);});s.f=0;},onCtl(s,k){if(k==='f')s.f=s.p.f;},
 draw(ctx,s,t,dt){bg(ctx,'#fcfcfd');if(s.p.play)s.f=(s.f+dt*30)%200;const P=s.fr(s.f),R=P.map(p=>rot(p,s.ry,s.rx)),Q=R.map(p=>pr(p,110,6,250,H/2));const L=[];for(let i=0;i<P.length-1;i++)L.push({z:(R[i][2]+R[i+1][2])/2,fn:()=>{line(ctx,Q[i][0],Q[i][1],Q[i+1][0],Q[i+1][1],hsl(220-i*3,65,50),7*Q[i][3]);ctx.lineCap='round';}});L.sort((a,b)=>a.z-b.z).forEach(x=>x.fn());
  const gx=470,gy=330,gw=230,gh=180;ctx.fillStyle='#fff';ctx.strokeStyle=C.grid;rr(ctx,gx-10,gy-gh-20,gw+20,gh+50,10);ctx.fill();ctx.stroke();const mx=Math.max(...s.rmsd);ctx.strokeStyle='#4f46e5';ctx.lineWidth=1.8;ctx.beginPath();s.rmsd.forEach((v,i)=>{const x=gx+i/199*gw,y=gy-v/mx*gh*.9;i?ctx.lineTo(x,y):ctx.moveTo(x,y);});ctx.stroke();const fx=gx+s.f/199*gw;line(ctx,fx,gy-gh,fx,gy,'#e11d48',1.5);
  text(ctx,'RMSD (nm) vs frame',gx,gy-gh-4,C.ink2,12,'left',FONT,600);text(ctx,s.rmsd[Math.floor(s.f)].toFixed(3),fx+4,gy-gh+12,'#e11d48',11.5,'left',MONO);text(ctx,'frame '+Math.floor(s.f)+' / 200',16,26,C.ink2,13,'left',MONO);},
 code:`stage.loadFile('protein.pdb').then(o=>{o.addRepresentation('cartoon');
  NGL.autoLoad('traj.dcd').then(frames=>{const traj=o.addTrajectory(frames);
    const player=new NGL.TrajectoryPlayer(traj.trajectory,{step:1,timeout:50,mode:'loop'});player.play();});});`});

lib('ideogram','Ideogram.js','bio','Chromosome ideograms with cytogenetic bands, annotation tracks, histograms and genome-wide overlays.',{ik:'Ideogram.js'});
ex({t:'Karyotype with Giemsa banding',d:'Twelve chromosome ideograms with banding (illustrative pattern) and centromeres; hover one for its size.',hint:'Hover a chromosome.',int:1,
 init(s){const r=rng(31),mb=[248,242,198,190,181,171,159,145,138,134,135,133];s.c=mb.map((m,i)=>{const h=m*1.15,bands=[];let y=0;while(y<h){const l=4+r()*14;bands.push([y,Math.min(l,h-y),Math.floor(r()*5)]);y+=l;}return{m,h,bands,cen:.3+r()*.25,x:52+i*54};});},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const top=50;let hv=-1;if(s.hover)s.c.forEach((c,i)=>{if(Math.abs(s.mx-c.x)<18&&s.my>top&&s.my<top+c.h)hv=i;});
  s.c.forEach((c,i)=>{const w=24,x=c.x-w/2;ctx.save();rr(ctx,x,top,w,c.h,12);ctx.clip();ctx.fillStyle='#fff';ctx.fillRect(x,top,w,c.h);const sh=['#fafaf9','#d6d3d1','#a8a29e','#78716c','#292524'];for(const b of c.bands){ctx.fillStyle=sh[b[2]];ctx.fillRect(x,top+b[0],w,b[1]+.5);}const cy=top+c.h*c.cen;ctx.fillStyle='#e11d48';ctx.fillRect(x,cy-3,w,6);ctx.restore();
   ctx.fillStyle='#fcfcfd';ctx.beginPath();ctx.moveTo(x-1,cy-6);ctx.lineTo(x+5,cy);ctx.lineTo(x-1,cy+6);ctx.fill();ctx.beginPath();ctx.moveTo(x+w+1,cy-6);ctx.lineTo(x+w-5,cy);ctx.lineTo(x+w+1,cy+6);ctx.fill();rr(ctx,x,top,w,c.h,12);ctx.strokeStyle=i==hv?'#4f46e5':'#a8a29e';ctx.lineWidth=i==hv?2.5:1.3;ctx.stroke();text(ctx,String(i+1),c.x,top+c.h+22,i==hv?C.indigo:C.mut,14,'center',FONT,600);});
  if(hv>=0)tooltip(ctx,s.mx,s.my,['chr'+(hv+1),s.c[hv].m+' Mb (illustrative banding)']);cap(ctx,'new Ideogram({ organism:"human", chromosomes:["1",…,"12"] })');},
 code:`new Ideogram({organism:'human',container:'#ideo',dataDir:'data/bands/',   // local band files
  chromosomes:['1','2','3','4','5','6','7','8','9','10','11','12'],chrHeight:300,
  onDidRotate:c=>console.log(c),showBandLabels:false});`});
ex({t:'Annotation tracks on chromosome 17',d:'A single chromosome laid horizontally with three annotation tracks (genes, variants, eQTLs) and a density histogram above. Hover an annotation.',hint:'Hover the tick marks.',int:1,
 init(s){const r=rng(17);s.bands=[];let x=0;while(x<1){const l=.01+r()*.04;s.bands.push([x,Math.min(l,1-x),Math.floor(r()*5)]);x+=l;}const names=['BRCA1','TP53','ERBB2','NF1','STAT3','CDK12','RARA','TOP2A','KRT10','SOX9','MAP2K3','HOXB13','PIK3R5','AXIN2','SUZ12','CCL2'];
  s.A=names.map((n,i)=>({n,x:r(),tr:i%3}));for(let i=0;i<60;i++)s.A.push({n:'rs'+Math.floor(r()*9e6),x:Math.pow(r(),1.3),tr:1+Math.floor(r()*2)});s.hist=Array.from({length:60},(_,i)=>s.A.filter(a=>Math.floor(a.x*60)===i).length);},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const x0=40,x1=W-30,X=u=>x0+u*(x1-x0),cy=220,mx=Math.max(...s.hist);
  s.hist.forEach((v,i)=>{const h=v/mx*70;ctx.fillStyle='rgba(79,70,229,.6)';ctx.fillRect(X(i/60)+1,150-h,(x1-x0)/60-2,h);});text(ctx,'annotation density',x0,70,C.mut,12);
  ctx.save();rr(ctx,x0,cy-14,x1-x0,28,14);ctx.clip();const sh=['#fafaf9','#d6d3d1','#a8a29e','#78716c','#292524'];s.bands.forEach(b=>{ctx.fillStyle=sh[b[2]];ctx.fillRect(X(b[0]),cy-14,(x1-x0)*b[1]+.5,28);});ctx.restore();ctx.strokeStyle='#78716c';rr(ctx,x0,cy-14,x1-x0,28,14);ctx.stroke();text(ctx,'chr17',x0,cy-22,C.ink,13,'left',FONT,700);
  const tc=['#4f46e5','#e11d48','#0d9488'],tn=['genes','variants','eQTLs'];let hv=null;tn.forEach((n,k)=>text(ctx,n,x1,268+k*40,tc[k],11.5,'right',FONT,600));
  s.A.forEach(a=>{const x=X(a.x),y=258+a.tr*40;line(ctx,x,y,x,y+22,tc[a.tr],a.tr===0?3:1.6);if(a.tr===0)poly(ctx,[[x-5,y],[x+5,y],[x,y-7]],tc[0]);if(s.hover&&Math.abs(s.mx-x)<4&&Math.abs(s.my-y-11)<14)hv=a;});
  if(hv)tooltip(ctx,X(hv.x),258+hv.tr*40,[hv.n,tn[hv.tr]+' · '+(hv.x*83.3).toFixed(1)+' Mb']);cap(ctx,'annotations:[{name:"BRCA1", chr:"17", start, stop}], annotationsLayout:"tracks"');},
 code:`new Ideogram({organism:'human',chromosome:'17',orientation:'horizontal',chrHeight:640,dataDir:'data/bands/',
  annotationsLayout:'tracks',annotationTracks:[{id:'genes',color:'#4f46e5'},{id:'variants',color:'#e11d48'},{id:'eqtl',color:'#0d9488'}],
  annotations:myAnnotations,annotationHeight:22});`});

lib('igv','IGV.js','bio','An embeddable genome browser: alignments, variants, coverage, gene annotations and many track formats.',{ik:'IGV.js'});
ex({t:'Genome tracks: coverage, genes, reads',d:'Ruler, coverage histogram, a gene track with exons and aligned reads with mismatches coloured by base (synthetic data).',hint:'Drag left/right to pan along the genome.',int:1,
 init(s){const r=rng(17),ends=[],S=[];for(let i=0;i<460;i++)S.push({a:Math.floor(r()*3800),l:70+Math.floor(r()*40)});S.sort((a,b)=>a.a-b.a);s.reads=[];for(const q of S){let row=0;while(ends[row]!==undefined&&ends[row]>q.a-3)row++;ends[row]=q.a+q.l;q.row=row;q.mm=[];const n=Math.floor(r()*3.2);for(let k=0;k<n;k++)q.mm.push([Math.floor(r()*q.l),Math.floor(r()*4)]);s.reads.push(q);}
  s.cov=new Array(4000).fill(0);for(const q of s.reads)for(let k=0;k<q.l&&q.a+k<4000;k++)s.cov[q.a+k]++;s.mc=Math.max(...s.cov);s.off=0;s.auto=true;s.genes=[{ex:[[300,380],[500,560],[700,760],[850,900]],n:'GENE1'},{ex:[[1500,1600],[1800,1900],[2200,2300]],n:'GENE2'},{ex:[[2900,3000],[3150,3220],[3400,3500]],n:'GENE3'}];let lx=0;s.onDown=x=>{lx=x;s.auto=false;};s.onMove=x=>{if(s.down){s.off=clamp(s.off-(x-lx)*(700/W),0,3300);lx=x;}};},
 draw(ctx,s,t,dt){bg(ctx);if(s.auto)s.off=(s.off+dt*40)%3300;const o=s.off,vw=700,X=bp=>(bp-o)/vw*W;ctx.fillStyle='#faf9f6';ctx.fillRect(0,0,W,38);
  for(let bp=Math.ceil(o/100)*100;bp<o+vw;bp+=100){const x=X(bp);line(ctx,x,28,x,38,'#a8a29e',1);text(ctx,'chr1:'+(bp*1000+1000000).toLocaleString(),x,22,C.mut,11,'center');}
  text(ctx,'Coverage',8,58,C.mut,11);for(let bp=Math.floor(o);bp<o+vw;bp+=3){const h=s.cov[bp]/s.mc*60;ctx.fillStyle='#a5b4fc';ctx.fillRect(X(bp),120-h,W/vw*3+.5,h);}line(ctx,0,126,W,126,'#e7e5e4',1);
  for(const g of s.genes){const a=g.ex[0][0],b=g.ex[g.ex.length-1][1];line(ctx,X(a),150,X(b),150,'#0284c7',2);for(const e of g.ex){ctx.fillStyle='#0284c7';ctx.fillRect(X(e[0]),138,Math.max(2,X(e[1])-X(e[0])),24);}text(ctx,g.n+' ›',X(a),132,'#0369a1',12,'left',FONT,600);}
  const cl=['#16a34a','#2563eb','#d97706','#dc2626'];for(const q of s.reads){if(q.row>17||q.a+q.l<o||q.a>o+vw)continue;const y=178+q.row*14;ctx.fillStyle='#d6d3d1';ctx.fillRect(X(q.a),y,X(q.a+q.l)-X(q.a)-1,9);for(const m of q.mm){ctx.fillStyle=cl[m[1]];ctx.fillRect(X(q.a+m[0]),y,Math.max(2,W/vw),9);}}},
 code:`igv.createBrowser(document.getElementById('igv'),{
  reference:{id:'local',fastaURL:'data/ref.fa',indexURL:'data/ref.fa.fai'},locus:'chr1:1,000,000-1,700,000',
  tracks:[{name:'Reads',type:'alignment',format:'bam',url:'data/sample.bam',indexURL:'data/sample.bam.bai'},
          {name:'Genes',type:'annotation',format:'bed',url:'data/genes.bed'}]});`});
ex({t:'Variant track: mutation lollipop plot',d:'Mutations along the TP53 protein (393 aa) as lollipops whose height is the number of observed cases, over the protein’s domains (illustrative counts).',hint:'Hover a lollipop.',int:1,
 init(s){const r=rng(53);s.M=[[175,62,'R175H'],[248,55,'R248Q'],[273,48,'R273H'],[245,30,'G245S'],[249,26,'R249S'],[282,22,'R282W'],[220,18,'Y220C'],[158,12,'R158H'],[132,10,'K132N'],[337,6,'R337H'],[72,5,'P72R']];for(let i=0;i<25;i++){const p=100+Math.floor(r()*200);s.M.push([p,1+Math.floor(r()*5),'p.'+p]);}},
 draw(ctx,s,t){bg(ctx,'#fcfcfd');const x0=40,x1=W-24,X=a=>x0+a/393*(x1-x0),base=330,g=easeOut(clamp(t/1.4,0,1));let hv=null;
  s.M.forEach(([p,c,l])=>{const x=X(p),y=base-24-c*3.6*g;line(ctx,x,base-12,x,y,'#a8a29e',1.4);const isH=s.hover&&Math.hypot(s.mx-x,s.my-y)<9;if(isH)hv=[p,c,l,x,y];circle(ctx,x,y,4+Math.sqrt(c)*.9,c>20?'#e11d48':c>8?'#f59e0b':'#0d9488','#fff',1.5);if(c>20)text(ctx,l,x,y-12,C.ink,11,'center',FONT,600);});
  ctx.fillStyle='#e7e5e4';rr(ctx,x0,base-12,x1-x0,16,4);ctx.fill();[[1,61,'TAD','#c7d2fe'],[94,292,'DNA-binding','#bbf7d0'],[318,358,'Tet','#fde68a']].forEach(([a,b,n,c])=>{ctx.fillStyle=c;rr(ctx,X(a),base-17,X(b)-X(a),26,6);ctx.fill();text(ctx,n,(X(a)+X(b))/2,base,C.ink2,12,'center',FONT,600);});
  for(let a=0;a<=393;a+=50)text(ctx,String(a),X(a),base+34,C.mut,11,'center');text(ctx,'TP53 · amino acid',x0,base+54,C.mut,11.5);if(hv)tooltip(ctx,hv[3],hv[4],[hv[2],hv[1]+' cases · residue '+hv[0]]);},
 code:`igv.createBrowser(el,{genome:'hg38-local',locus:'TP53',
  tracks:[{type:'variant',format:'vcf',url:'data/tp53.vcf.gz',indexURL:'data/tp53.vcf.gz.tbi',
    displayMode:'EXPANDED',color:v=>v.info.COUNT>20?'#e11d48':'#0d9488'}]});`});

lib('smiles','SmilesDrawer','bio','Draws 2D skeletal structure diagrams of molecules from SMILES strings, with no server.',{isNew:true,info:{lv:'Beginner',r:'Canvas / SVG',s:'≈ 0.2 MB',u:'github.com/reymond-group/smilesDrawer',t:['Skeletal formulas from SMILES in chemistry pages','Molecule thumbnails in tables and search results','Highlighting atoms or substructures','Chemistry teaching material'],c:['Parses SMILES and computes a 2D layout (rings, chains, stereo)','Themes, atom colouring, explicit hydrogens, compact drawing','SVG or canvas output; reaction drawing in v2'],l:['2D only; complex macrocycles can lay out awkwardly'],o:'Fully offline.',k:`const drawer=new SmilesDrawer.SmiDrawer({width:400,height:300},{});
drawer.draw('CN1C=NC2=C1C(=O)N(C(=O)N2C)C','#caffeine','light');   // caffeine`,a:'RDKit.js (WASM), Kekule.js, 3Dmol.js for 3D'}});
ex({t:'Skeletal formulas: benzene, ethanol, caffeine, aspirin',d:'2D skeletal structures with carbon vertices implied, heteroatoms labelled in CPK colours and double bonds drawn inside the rings. The formula and molar mass are computed from the graph.',controls:[{type:'seg',k:'m',v:'Caffeine',opts:['Benzene','Ethanol','Caffeine','Aspirin']}],
 draw(ctx,s,t){bg(ctx,'#fffefb');const m=mol2D(s.p.m),xs=m.A.map(a=>a[0]),ys=m.A.map(a=>a[1]),cx=(Math.min(...xs)+Math.max(...xs))/2,cy=(Math.min(...ys)+Math.max(...ys))/2,sc=58,P=m.A.map(a=>[W/2-70+(a[0]-cx)*sc,H/2+(a[1]-cy)*sc]),g=easeOut(clamp((t%9)/1.2,0,1));
  const cen=[P.reduce((a,p)=>a+p[0],0)/P.length,P.reduce((a,p)=>a+p[1],0)/P.length];ctx.lineCap='round';
  m.B.forEach(([a,b,o],k)=>{if(k/m.B.length>g)return;let A=P[a],B=P[b];const la=m.A[a][2]!=='C',lb=m.A[b][2]!=='C',dx=B[0]-A[0],dy=B[1]-A[1],l=Math.hypot(dx,dy),ux=dx/l,uy=dy/l;const A2=[A[0]+ux*(la?13:0),A[1]+uy*(la?13:0)],B2=[B[0]-ux*(lb?13:0),B[1]-uy*(lb?13:0)];line(ctx,A2[0],A2[1],B2[0],B2[1],C.ink,2.6);
   if(o===2){let nx=-uy,ny=ux;const mx=(A[0]+B[0])/2,my=(A[1]+B[1])/2;if((cen[0]-mx)*nx+(cen[1]-my)*ny<0){nx=-nx;ny=-ny;}line(ctx,A2[0]+nx*8+ux*6,A2[1]+ny*8+uy*6,B2[0]+nx*8-ux*6,B2[1]+ny*8-uy*6,C.ink,2.6);}});
  m.A.forEach((a,i)=>{if(a[2]==='C')return;text(ctx,a[2],P[i][0],P[i][1]+7,ELC[a[2]],21,'center',FONT,700);});
  const f=molFormula(m),order=['C','H','N','O'].filter(e=>f[e]),mw=order.reduce((a,e)=>a+MW[e]*f[e],0),sub=n=>String(n).split('').map(d=>'₀₁₂₃₄₅₆₇₈₉'[d]).join('');ctx.fillStyle='#faf9f6';rr(ctx,W-210,40,190,120,12);ctx.fill();text(ctx,s.p.m,W-196,68,C.ink,17,'left',FONT,700);text(ctx,order.map(e=>e+(f[e]>1?sub(f[e]):'')).join(''),W-196,98,C.indigo,20,'left',FONT,600);text(ctx,mw.toFixed(2)+' g/mol',W-196,124,C.mut,13,'left',MONO);text(ctx,m.A.length+' heavy atoms',W-196,144,C.mut,12,'left',MONO);
  cap(ctx,'drawer.draw("'+{Benzene:'c1ccccc1',Ethanol:'CCO',Caffeine:'CN1C=NC2=C1C(=O)N(C(=O)N2C)C',Aspirin:'CC(=O)OC1=CC=CC=C1C(=O)O'}[s.p.m]+'", "#c")');},
 code:`const drawer=new SmilesDrawer.SmiDrawer({width:500,height:320,bondThickness:1.6},{});
drawer.draw('CC(=O)OC1=CC=CC=C1C(=O)O','#aspirin','light');`});
ex({t:'SMILES parser: formula & molar mass',d:'Type any SMILES string: atoms, branches, ring closures, bond orders and implicit hydrogens are parsed into a molecular formula, molar mass and composition.',hint:'Edit the SMILES or pick an example.',
 dom(el,s){el.innerHTML='<div class="pad dk"><div class="row"><input class="sm" value="CN1C=NC2=C1C(=O)N(C(=O)N2C)C" style="font-family:var(--mono);flex:1"></div><div class="row exr"></div><div class="out" style="display:grid;grid-template-columns:1fr 160px;gap:14px;align-items:center"></div></div>';
  const ex_={Caffeine:'CN1C=NC2=C1C(=O)N(C(=O)N2C)C',Aspirin:'CC(=O)OC1=CC=CC=C1C(=O)O',Glucose:'OCC1OC(O)C(O)C(O)C1O',Ibuprofen:'CC(C)Cc1ccc(cc1)C(C)C(=O)O',Paracetamol:'CC(=O)Nc1ccc(O)cc1',Ethanol:'CCO'};const exd=el.querySelector('.exr');Object.keys(ex_).forEach(k=>{const b=document.createElement('button');b.className='chipbtn';b.textContent=k;b.onclick=()=>{inp.value=ex_[k];run();};exd.appendChild(b);});
  const inp=el.querySelector('.sm'),out=el.querySelector('.out');
  const parse=sm=>{const atoms=[],bo=[];let prev=-1,order=1;const stack=[],ring={};const re=/(\[[^\]]+\]|Br|Cl|[BCNOPSFI]|[bcnops]|\(|\)|=|#|-|%\d\d|\d|\/|\\|\.)/g;let m;
   while((m=re.exec(sm))){const tk=m[0];if(tk==='('){stack.push(prev);continue;}if(tk===')'){prev=stack.pop();continue;}if(tk==='='){order=2;continue;}if(tk==='#'){order=3;continue;}if(tk==='-'||tk==='/'||tk==='\\'){continue;}if(tk==='.'){prev=-1;continue;}
    if(/^%?\d+$/.test(tk)){const k=tk.replace('%','');if(ring[k]!==undefined){bo[prev]+=order;bo[ring[k][0]]+=order;delete ring[k];}else ring[k]=[prev];order=1;continue;}
    let el,ar=false,hx=null;if(tk[0]==='['){const mm=tk.match(/\[(\d*)([A-Z][a-z]?|[a-z])(@*)(H(\d*))?/);el=mm[2];if(el===el.toLowerCase()){ar=true;el=el.toUpperCase();}hx=mm[4]?(+mm[5]||1):0;}else{el=tk;if(el===el.toLowerCase()){ar=true;el=el.toUpperCase();}}
    atoms.push({el,ar,hx});bo.push(0);const i=atoms.length-1;if(prev>=0){const o=atoms[prev].ar&&ar&&order===1?1.5:order;bo[prev]+=o;bo[i]+=o;}prev=i;order=1;}
   const V={C:4,N:3,O:2,S:2,P:3,B:3,F:1,Cl:1,Br:1,I:1},cnt={};atoms.forEach((a,i)=>{cnt[a.el]=(cnt[a.el]||0)+1;let h=a.hx!==null?a.hx:Math.max(0,(V[a.el]||0)-Math.round(bo[i]+(a.ar?0:0)));if(a.ar&&a.hx===null)h=Math.max(0,(V[a.el]||0)-Math.ceil(bo[i]));cnt.H=(cnt.H||0)+h;});return cnt;};
  const run=()=>{try{const c=parse(inp.value.trim()),order=['C','H'].concat(Object.keys(c).filter(e=>e!=='C'&&e!=='H').sort()).filter(e=>c[e]),mw=order.reduce((a,e)=>a+(MW[e]||0)*c[e],0),tot=order.reduce((a,e)=>a+(MW[e]||0)*c[e],0);
   let sv='<svg viewBox="0 0 100 100" width="150">';let a=-Math.PI/2;order.forEach(e=>{const f=(MW[e]||0)*c[e]/tot,a2=a+f*TAU,lg=f>.5?1:0;sv+='<path d="M50 50 L'+(50+45*Math.cos(a))+' '+(50+45*Math.sin(a))+' A45 45 0 '+lg+' 1 '+(50+45*Math.cos(a2))+' '+(50+45*Math.sin(a2))+' Z" fill="'+(ELC[e]||'#a855f7')+'" stroke="#fff" stroke-width="1.5"/>';a=a2;});sv+='<circle cx="50" cy="50" r="22" fill="#fff"/></svg>';
   out.innerHTML='<div><div style="font:600 30px var(--sans)">'+order.map(e=>e+(c[e]>1?'<sub>'+c[e]+'</sub>':'')).join('')+'</div><div style="color:var(--mut);font:14px var(--mono);margin:4px 0 10px">'+mw.toFixed(3)+' g/mol</div><table class="tbl" style="font-size:12.5px"><tr><th>Element</th><th>Count</th><th>Mass %</th></tr>'+order.map(e=>'<tr><td><b style="color:'+(ELC[e]||'#a855f7')+'">'+e+'</b></td><td>'+c[e]+'</td><td>'+((MW[e]||0)*c[e]/tot*100).toFixed(1)+'%</td></tr>').join('')+'</table></div><div style="text-align:center">'+sv+'<div style="font-size:12px;color:var(--mut)">mass composition</div></div>';}catch(e){out.innerHTML='<p class="warn">Could not parse that SMILES.</p>';}};inp.addEventListener('input',run);run();},
 code:`const tree=SmilesDrawer.Parser.parse('CC(=O)Nc1ccc(O)cc1');          // paracetamol
const mol=new SmilesDrawer.Drawer({}).graph;   // after draw(): atoms, bonds, rings
// formula: count element symbols + implicit hydrogens from valence`});
