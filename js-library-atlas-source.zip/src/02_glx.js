/* ===================== GLX: compact physically-based WebGL renderer (shared context) ===================== */
const M4={
 id:()=>new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]),
 mul(a,b){const o=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++){let s=0;for(let k=0;k<4;k++)s+=a[k*4+r]*b[c*4+k];o[c*4+r]=s;}return o;},
 persp(f,asp,n,fa){const t=1/Math.tan(f/2),o=new Float32Array(16);o[0]=t/asp;o[5]=t;o[10]=(fa+n)/(n-fa);o[11]=-1;o[14]=2*fa*n/(n-fa);return o;},
 look(e,c,u){const z=norm(sub(e,c)),x=norm(cross(u,z)),y=cross(z,x);return new Float32Array([x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,e),-dot(y,e),-dot(z,e),1]);},
 T(x,y,z){const o=M4.id();o[12]=x;o[13]=y;o[14]=z;return o;},S(x,y,z){const o=M4.id();o[0]=x;o[5]=y===undefined?x:y;o[10]=z===undefined?x:z;return o;},
 RX(a){const c=Math.cos(a),s=Math.sin(a),o=M4.id();o[5]=c;o[6]=s;o[9]=-s;o[10]=c;return o;},RY(a){const c=Math.cos(a),s=Math.sin(a),o=M4.id();o[0]=c;o[2]=-s;o[8]=s;o[10]=c;return o;},RZ(a){const c=Math.cos(a),s=Math.sin(a),o=M4.id();o[0]=c;o[1]=s;o[4]=-s;o[5]=c;return o;},
 chain(...ms){return ms.reduce((a,b)=>M4.mul(a,b));},
 xf(m,p){return[m[0]*p[0]+m[4]*p[1]+m[8]*p[2]+m[12],m[1]*p[0]+m[5]*p[1]+m[9]*p[2]+m[13],m[2]*p[0]+m[6]*p[1]+m[10]*p[2]+m[14]];},
 basis(t,n){/* rotation taking +Y to direction n, positioned at t */const y=norm(n),a=Math.abs(y[1])<.95?[0,1,0]:[1,0,0],x=norm(cross(a,y)),z=cross(x,y);return new Float32Array([x[0],x[1],x[2],0,y[0],y[1],y[2],0,z[0],z[1],z[2],0,t[0],t[1],t[2],1]);}};
const hexv=h=>{const c=hex2rgb(h);return[c[0]/255,c[1]/255,c[2]/255];};

/* ---------- geometry ---------- */
const GEO={
 grid(U,V,fn,nfn){/* fn(u,v)->[x,y,z]; optional nfn(u,v,p)->normal */const P=[],N=[],T=[],I=[];const e=1e-4;
  for(let j=0;j<=V;j++)for(let i=0;i<=U;i++){const u=i/U,v=j/V,p=fn(u,v);P.push(p[0],p[1],p[2]);T.push(u,v);let n;if(nfn)n=nfn(u,v,p);else{const du=sub(fn(Math.min(1,u+e),v),fn(Math.max(0,u-e),v)),dv=sub(fn(u,Math.min(1,v+e)),fn(u,Math.max(0,v-e)));n=norm(cross(dv,du));if(!isFinite(n[0])||len3(cross(dv,du))<1e-12)n=norm(p);}N.push(n[0],n[1],n[2]);}
  for(let j=0;j<V;j++)for(let i=0;i<U;i++){const a=j*(U+1)+i,b=a+1,c=a+U+1,d=c+1;I.push(a,c,b,b,c,d);}return{P,N,T,I};},
 sphere(r,U,V){return GEO.grid(U||64,V||40,(u,v)=>{const lo=u*TAU-Math.PI,la=Math.PI/2-v*Math.PI;return[r*Math.cos(la)*Math.cos(lo),r*Math.sin(la),-r*Math.cos(la)*Math.sin(lo)];},(u,v,p)=>norm(p));},
 torus(R,r,U,V){return GEO.grid(U||96,V||32,(u,v)=>{const a=u*TAU,b=v*TAU;return[(R+r*Math.cos(b))*Math.cos(a),r*Math.sin(b),(R+r*Math.cos(b))*Math.sin(a)];},(u,v)=>{const a=u*TAU,b=v*TAU;return[Math.cos(b)*Math.cos(a),Math.sin(b),Math.cos(b)*Math.sin(a)];});},
 tube(path,closed,rad,U,V){/* path(t)->p ; rad number or fn(t) */U=U||200;V=V||16;const pts=[];for(let i=0;i<=U;i++)pts.push(path(closed?i/U:i/U));const Tn=pts.map((p,i)=>{const a=pts[Math.max(0,i-1)],b=pts[Math.min(U,i+1)];return norm(sub(closed&&i===0?pts[1]:b,closed&&i===0?pts[U-1]:a));});
  let n=norm(cross(Tn[0],Math.abs(Tn[0][1])<.9?[0,1,0]:[1,0,0]));const Nn=[],Bn=[];for(let i=0;i<=U;i++){n=norm(sub(n,mul(Tn[i],dot(n,Tn[i]))));Nn.push(n);Bn.push(cross(Tn[i],n));}
  if(closed){const tw=Math.atan2(dot(cross(Nn[U],Nn[0]),Tn[0]),dot(Nn[U],Nn[0]));for(let i=0;i<=U;i++){const a=-tw*i/U,c=Math.cos(a),s=Math.sin(a),N0=Nn[i],B0=Bn[i];Nn[i]=add(mul(N0,c),mul(B0,s));Bn[i]=add(mul(N0,-s),mul(B0,c));}}
  const P=[],N=[],T=[],I=[];for(let i=0;i<=U;i++){let r=typeof rad==='function'?rad(i/U):rad;const rx=Array.isArray(r)?r[0]:r,ry=Array.isArray(r)?r[1]:r;for(let j=0;j<=V;j++){const a=j/V*TAU,ca=Math.cos(a),sa=Math.sin(a),off=add(mul(Nn[i],ca*rx),mul(Bn[i],sa*ry)),d=norm(add(mul(Nn[i],ca*ry),mul(Bn[i],sa*rx)));const p=add(pts[i],off);P.push(p[0],p[1],p[2]);N.push(d[0],d[1],d[2]);T.push(i/U,j/V);}}
  for(let i=0;i<U;i++)for(let j=0;j<V;j++){const a=i*(V+1)+j,b=a+1,c=a+V+1,d=c+1;I.push(a,b,c,b,d,c);}return{P,N,T,I};},
 superq(sx,sy,sz,e,U,V){/* smooth rounded box (superellipsoid) */const f=(w,m)=>Math.sign(w)*Math.pow(Math.abs(w),m);return GEO.grid(U||48,V||32,(u,v)=>{const lo=u*TAU-Math.PI,la=Math.PI/2-v*Math.PI;return[sx*f(Math.cos(la),e)*f(Math.cos(lo),e),sy*f(Math.sin(la),e),-sz*f(Math.cos(la),e)*f(Math.sin(lo),e)];});},
 cyl(r,h,U,cap){const g=GEO.grid(U||48,1,(u,v)=>[r*Math.cos(u*TAU),h/2-v*h,r*Math.sin(u*TAU)],(u)=>[Math.cos(u*TAU),0,Math.sin(u*TAU)]);return g;},
 merge(...gs){const o={P:[],N:[],T:[],I:[]};let off=0;gs.forEach(g=>{o.P.push(...g.P);o.N.push(...g.N);o.T.push(...(g.T||new Array(g.P.length/3*2).fill(0)));g.I.forEach(i=>o.I.push(i+off));off+=g.P.length/3;});return o;},
 xform(g,m){const o={P:[],N:g.N.slice(),T:g.T,I:g.I};for(let i=0;i<g.P.length;i+=3){const p=M4.xf(m,[g.P[i],g.P[i+1],g.P[i+2]]);o.P.push(p[0],p[1],p[2]);const n=norm([m[0]*g.N[i]+m[4]*g.N[i+1]+m[8]*g.N[i+2],m[1]*g.N[i]+m[5]*g.N[i+1]+m[9]*g.N[i+2],m[2]*g.N[i]+m[6]*g.N[i+1]+m[10]*g.N[i+2]]);o.N[i]=n[0];o.N[i+1]=n[1];o.N[i+2]=n[2];}return o;},
 icoEdges(r,detail){/* unique edges + verts of a subdivided icosahedron for wireframes */const t=(1+Math.sqrt(5))/2;let V=[[-1,t,0],[1,t,0],[-1,-t,0],[1,-t,0],[0,-1,t],[0,1,t],[0,-1,-t],[0,1,-t],[t,0,-1],[t,0,1],[-t,0,-1],[-t,0,1]].map(norm);let F=[[0,11,5],[0,5,1],[0,1,7],[0,7,10],[0,10,11],[1,5,9],[5,11,4],[11,10,2],[10,7,6],[7,1,8],[3,9,4],[3,4,2],[3,2,6],[3,6,8],[3,8,9],[4,9,5],[2,4,11],[6,2,10],[8,6,7],[9,8,1]];
  for(let d=0;d<detail;d++){const cache={},mid=(a,b)=>{const k=a<b?a+'_'+b:b+'_'+a;if(cache[k]!==undefined)return cache[k];V.push(norm(mul(add(V[a],V[b]),.5)));return cache[k]=V.length-1;};const nf=[];F.forEach(([a,b,c])=>{const ab=mid(a,b),bc=mid(b,c),ca=mid(c,a);nf.push([a,ab,ca],[b,bc,ab],[c,ca,bc],[ab,bc,ca]);});F=nf;}
  const E=new Set();F.forEach(([a,b,c])=>[[a,b],[b,c],[c,a]].forEach(([x,y])=>E.add(x<y?x+'_'+y:y+'_'+x)));return{V:V.map(v=>mul(v,r)),E:[...E].map(k=>k.split('_').map(Number)),F};}};

/* ---------- renderer factory ---------- */
function makeGLX(cw,ch){const R={ok:false};const cv=document.createElement('canvas');let dpr=Math.min(2,Math.max(1,window.devicePixelRatio||1));R.dpr=dpr;R.cv=cv;R.setDpr=d=>{if(d===dpr)return;dpr=d;R.dpr=d;R.size(R.w,R.h);};
 let gl;try{gl=cv.getContext('webgl',{antialias:true,alpha:true,premultipliedAlpha:true,preserveDrawingBuffer:true});}catch(e){}if(!gl)return R;R.gl=gl;R.ok=true;
 const ext={i:gl.getExtension('ANGLE_instanced_arrays'),u:gl.getExtension('OES_element_index_uint'),a:gl.getExtension('EXT_texture_filter_anisotropic')||gl.getExtension('WEBKIT_EXT_texture_filter_anisotropic'),d:gl.getExtension('OES_standard_derivatives')};
 const comp=(vs,fs)=>{const mk=(t,s)=>{const o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);if(!gl.getShaderParameter(o,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(o));return o;};const p=gl.createProgram();gl.attachShader(p,mk(gl.VERTEX_SHADER,vs));gl.attachShader(p,mk(gl.FRAGMENT_SHADER,fs));gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(p));
  const n=gl.getProgramParameter(p,gl.ACTIVE_UNIFORMS),U={},A={};for(let i=0;i<n;i++){const k=gl.getActiveUniform(p,i).name;U[k.replace('[0]','')]=gl.getUniformLocation(p,k);}const na=gl.getProgramParameter(p,gl.ACTIVE_ATTRIBUTES);for(let i=0;i<na;i++){const k=gl.getActiveAttrib(p,i).name;A[k]=gl.getAttribLocation(p,k);}return{p,U,A};};
 const STDV=`attribute vec3 aP;attribute vec3 aN;attribute vec3 aVC;
#ifdef INST
attribute vec3 aI;attribute vec3 aIS;attribute vec3 aIC;
#endif
uniform mat4 uM,uV,uP;varying vec3 vW,vN,vC;varying float vY;
void main(){vec3 p=aP;vec3 c=aVC;
#ifdef INST
p=p*aIS+aI;c=aIC;
#endif
vec3 nn=aN;
#ifdef INST
nn=aN/aIS;
#endif
vec4 w=uM*vec4(p,1.);vW=w.xyz;vN=mat3(uM)*nn;vC=c;vY=aP.y;gl_Position=uP*uV*w;}`;
 const STDF=`precision highp float;uniform vec3 uCol,uCam,uSky,uGround,uRim,uEm,uFog,uL0,uC0,uL1,uC1,uL2,uC2;uniform float uRough,uMetal,uClear,uOp,uRimP,uFogD,uVC,uExp,uRimK,uIri,uSheen,uGlass;varying vec3 vW,vN,vC;varying float vY;
float Dg(float nh,float a){float a2=a*a;float d=nh*nh*(a2-1.)+1.;return a2/(3.14159*d*d+1e-5);}
vec3 Fs(vec3 f0,float c){return f0+(1.-f0)*pow(1.-c,5.);}
vec3 Lt(vec3 N,vec3 V,vec3 L,vec3 lc,vec3 alb,vec3 f0,float r){float nl=max(dot(N,L),0.);if(nl<=0.)return vec3(0.);vec3 H=normalize(L+V);float nh=max(dot(N,H),0.),nv=max(dot(N,V),1e-3),vh=max(dot(V,H),0.);float k=(r+1.)*(r+1.)/8.;float G=nv/(nv*(1.-k)+k)*nl/(nl*(1.-k)+k);vec3 f=Fs(f0,vh);vec3 sp=Dg(nh,r*r)*f*G/(4.*nv*nl+1e-4);vec3 kd=(1.-f)*(1.-uMetal);return(kd*alb/3.14159+sp)*lc*nl*3.14159;}
vec3 aces(vec3 x){return clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.);}
vec3 iri(float t){return .5+.5*cos(6.2832*(t+vec3(0.,.33,.67)));}
void main(){vec3 N=normalize(vN);vec3 V=normalize(uCam-vW);if(dot(N,V)<0.&&!gl_FrontFacing)N=-N;
vec3 alb=mix(uCol,vC,uVC);alb=pow(max(alb,vec3(0.)),vec3(2.2));float nv=max(dot(N,V),0.);
if(uIri>0.)alb=mix(alb,pow(iri(nv*.9+vY*.15),vec3(2.2)),uIri);
vec3 f0=mix(vec3(.04),alb,uMetal);float r=clamp(uRough,.045,1.);
vec3 c=Lt(N,V,normalize(uL0),uC0,alb,f0,r)+Lt(N,V,normalize(uL1),uC1,alb,f0,r)+Lt(N,V,normalize(uL2),uC2,alb,f0,r);
vec3 hemi=mix(uGround,uSky,N.y*.5+.5);c+=hemi*alb*(1.-uMetal)*.85;
vec3 R=reflect(-V,N);vec3 env=mix(uGround,uSky*1.15,smoothstep(-.35,.7,R.y));env+=vec3(1.)*pow(max(dot(R,normalize(uL0)),0.),64.)*(1.-r)*.6;
c+=env*Fs(f0,nv)*(1.-r*.75);
if(uClear>0.){vec3 H=normalize(normalize(uL0)+V);float nh=max(dot(N,H),0.);c+=uClear*(Dg(nh,.0049)*.045*uC0*max(dot(N,normalize(uL0)),0.)+env*Fs(vec3(.04),nv)*.55);}
if(uSheen>0.)c+=uSheen*pow(1.-nv,2.)*hemi*1.2;
float fr=pow(1.-nv,uRimP);c+=uRim*fr*uRimK;c+=uEm;
c=aces(c*uExp);c=pow(c,vec3(1./2.2));
float d=length(uCam-vW);float fg=1.-exp(-uFogD*uFogD*d*d);c=mix(c,uFog,clamp(fg,0.,1.));
float a=uOp<.999?clamp(uOp+fr*uGlass,0.,1.):1.;gl_FragColor=vec4(c*a,a);}`;
 const P={std:comp(STDV,STDF)};if(ext.i)P.inst=comp('#define INST\n'+STDV,STDF);
 P.pts=comp(`attribute vec3 aP;attribute vec4 aC;attribute float aS;uniform mat4 uM,uV,uP;uniform float uSz,uDpr;varying vec4 vC;void main(){vec4 v=uV*uM*vec4(aP,1.);gl_Position=uP*v;gl_PointSize=max(1.,aS*uSz*uDpr*(8./max(.1,-v.z)));vC=aC;}`,
  `precision mediump float;varying vec4 vC;uniform float uSoft;void main(){float d=length(gl_PointCoord-.5);float a=1.-smoothstep(.5-uSoft,.5,d);if(a<=.003)discard;gl_FragColor=vec4(vC.rgb*vC.a*a,vC.a*a);}`);
 P.ln=comp(`attribute vec3 aP;attribute vec4 aC;uniform mat4 uM,uV,uP;varying vec4 vC;varying float vZ;void main(){vec4 v=uV*uM*vec4(aP,1.);vZ=-v.z;gl_Position=uP*v;vC=aC;}`,`precision mediump float;varying vec4 vC;varying float vZ;uniform float uFogD;uniform vec3 uFog;void main(){float f=1.-exp(-uFogD*uFogD*vZ*vZ);vec3 c=mix(vC.rgb,uFog,clamp(f,0.,1.));gl_FragColor=vec4(c*vC.a,vC.a);}`);
 P.globe=comp(`attribute vec3 aP;attribute vec3 aN;attribute vec2 aT;uniform mat4 uM,uV,uP;varying vec3 vW,vN;varying vec2 vT;void main(){vec4 w=uM*vec4(aP,1.);vW=w.xyz;vN=mat3(uM)*aN;vT=aT;gl_Position=uP*uV*w;}`,
  `precision highp float;uniform sampler2D tD,tA;uniform vec3 uCam,uSun,uAtm;uniform float uT,uCloud,uNight,uExp,uMode,uDim;varying vec3 vW,vN;varying vec2 vT;
vec3 aces(vec3 x){return clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.);}
void main(){vec3 N=normalize(vN),V=normalize(uCam-vW),L=normalize(uSun);float nl=dot(N,L),nv=max(dot(N,V),0.);
vec3 day=pow(texture2D(tD,vT).rgb,vec3(2.2));vec4 ax=texture2D(tA,vT);float ocean=ax.r;float lights=ax.g;
float cl=texture2D(tA,vec2(fract(vT.x+uT*.004),vT.y)).b*uCloud;
float lit=smoothstep(-.18,.28,nl);vec3 c=day*(.05+1.1*max(nl,0.))*mix(.35,1.,lit);
vec3 H=normalize(L+V);float sp=pow(max(dot(N,H),0.),1400.)*ocean*.55+pow(max(dot(N,H),0.),60.)*ocean*.035;c+=vec3(1.,.95,.85)*sp*lit;
c=mix(c,vec3(.96,.97,1.)*(.05+.82*max(nl,0.)),cl*.85);
c+=vec3(1.,.72,.38)*lights*(1.-lit)*(1.-cl*.8)*uNight*1.6;
float fr=pow(1.-nv,4.);vec3 atm=uAtm*(fr*1.2)*(.25+.9*max(dot(N,L)+.25,0.));c+=atm;
c=aces(c*uExp);c=pow(c,vec3(1./2.2));c=mix(c,vec3(.97,.96,.99),uDim);gl_FragColor=vec4(c,1.);}`);
 P.atm=comp(`attribute vec3 aP;attribute vec3 aN;uniform mat4 uM,uV,uP;varying vec3 vW,vN;void main(){vec4 w=uM*vec4(aP,1.);vW=w.xyz;vN=mat3(uM)*aN;gl_Position=uP*uV*w;}`,
  `precision mediump float;uniform vec3 uCam,uSun,uAtm;uniform float uK;varying vec3 vW,vN;void main(){vec3 N=normalize(vN),V=normalize(uCam-vW);float nv=dot(N,V);float g=pow(clamp(1.-abs(nv),0.,1.),2.2)*smoothstep(-.1,.35,-nv+.6);float l=.35+.65*max(dot(N,normalize(uSun))+.3,0.);float a=clamp(g*uK*l,0.,1.);gl_FragColor=vec4(uAtm*a,a);}`);
 const meshes=new WeakMap();
 R.mesh=g=>{if(g._m)return g._m;const m={n:g.I.length,big:g.P.length/3>65535};const b=d=>{const x=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,x);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(d),gl.STATIC_DRAW);return x;};m.p=b(g.P);m.nr=b(g.N);m.t=b(g.T||new Array(g.P.length/3*2).fill(0));if(g.C)m.c=b(g.C);m.i=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,m.i);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,m.big?new Uint32Array(g.I):new Uint16Array(g.I),gl.STATIC_DRAW);g._m=m;return m;};
 const dyn={};const dbuf=(k,data)=>{let b=dyn[k];if(!b){b=dyn[k]=gl.createBuffer();}gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,data,gl.DYNAMIC_DRAW);return b;};
 const attr=(pr,name,buf,size,div)=>{const l=pr.A[name];if(l===undefined||l<0)return;gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.enableVertexAttribArray(l);gl.vertexAttribPointer(l,size,gl.FLOAT,false,0,0);if(ext.i)ext.i.vertexAttribDivisorANGLE(l,div||0);};
 const off=(pr)=>{for(const k in pr.A){const l=pr.A[k];gl.disableVertexAttribArray(l);if(ext.i)ext.i.vertexAttribDivisorANGLE(l,0);}};
 let S={};R.w=cw;R.h=ch;
 R.size=(w,h)=>{R.w=w;R.h=h;const W2=Math.round(w*dpr),H2=Math.round(h*dpr);if(cv.width!==W2||cv.height!==H2){cv.width=W2;cv.height=H2;}};R.size(cw,ch);
 R.begin=o=>{o=o||{};S=Object.assign({fov:38,eye:[0,0,6],target:[0,0,0],up:[0,1,0],sky:hexv('#f5efff'),ground:hexv('#e9dcf3'),fog:hexv('#f6f1fb'),fogD:0,exp:1.05,
   L0:[.55,.8,.65],C0:[2.1,2,1.95],L1:[-.8,-.2,-.5],C1:[.25,.85,.8],L2:[.9,-.35,-.6],C2:[.7,.4,1.1]},o);if(o.w)R.size(o.w,o.h);
  S.V=M4.look(S.eye,S.target,S.up);S.P=M4.persp(S.fov*D2R,R.w/R.h,o.near||.05,o.far||200);S.VP=M4.mul(S.P,S.V);
  gl.viewport(0,0,cv.width,cv.height);gl.clearColor(0,0,0,0);gl.depthMask(true);gl.colorMask(true,true,true,true);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE_MINUS_SRC_ALPHA);gl.disable(gl.CULL_FACE);gl.depthMask(true);return R;};
 const common=(pr,m)=>{const U=pr.U;gl.uniformMatrix4fv(U.uM,false,m||M4.id());gl.uniformMatrix4fv(U.uV,false,S.V);gl.uniformMatrix4fv(U.uP,false,S.P);};
 const mat=(pr,o)=>{const U=pr.U,f3=(k,v)=>{if(U[k])gl.uniform3fv(U[k],v);},f1=(k,v)=>{if(U[k])gl.uniform1f(U[k],v);};
  f3('uCol',typeof o.color==='string'?hexv(o.color):(o.color||[.6,.55,.9]));f3('uCam',S.eye);f3('uSky',S.sky);f3('uGround',S.ground);f3('uFog',S.fog);f3('uRim',typeof o.rim==='string'?hexv(o.rim):(o.rim||[0,0,0]));f3('uEm',typeof o.em==='string'?hexv(o.em):typeof o.em==='number'?(typeof o.color==='string'?hexv(o.color):(o.color||[.6,.55,.9])).map(v=>v*o.em):(o.em||[0,0,0]));
  ['L0','C0','L1','C1','L2','C2'].forEach(k=>f3('u'+k,S[k]));f1('uRough',o.rough===undefined?.35:o.rough);f1('uMetal',o.metal||0);f1('uClear',o.clear||0);f1('uOp',o.op===undefined?1:o.op);f1('uRimP',o.rimP||3);f1('uRimK',o.rimK===undefined?1:o.rimK);f1('uFogD',S.fogD);f1('uVC',o.vcol?1:0);f1('uExp',S.exp);f1('uIri',o.iri||0);f1('uSheen',o.sheen||0);f1('uGlass',o.glass===undefined?.55:o.glass);};
 const blendFor=o=>{if(o.op!==undefined&&o.op<.999||o.add){gl.depthMask(!!o.zwrite);if(o.add)gl.blendFunc(gl.ONE,gl.ONE);else gl.blendFunc(gl.ONE,gl.ONE_MINUS_SRC_ALPHA);}else{gl.depthMask(true);gl.blendFunc(gl.ONE,gl.ONE_MINUS_SRC_ALPHA);}if(o.cull){gl.enable(gl.CULL_FACE);gl.cullFace(o.cull==='front'?gl.FRONT:gl.BACK);}else gl.disable(gl.CULL_FACE);};
 R.draw=(g,o)=>{o=o||{};const m=R.mesh(g),pr=P.std;gl.useProgram(pr.p);off(pr);common(pr,o.m);mat(pr,o);blendFor(o);attr(pr,'aP',m.p,3);attr(pr,'aN',m.nr,3);if(m.c&&o.vcol)attr(pr,'aVC',m.c,3);else if(pr.A.aVC!==undefined){gl.disableVertexAttribArray(pr.A.aVC);gl.vertexAttrib3f(pr.A.aVC,1,1,1);}
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,m.i);gl.drawElements(gl.TRIANGLES,m.n,m.big?gl.UNSIGNED_INT:gl.UNSIGNED_SHORT,0);};
 R.inst=(g,data,count,o)=>{/* data: Float32Array [x,y,z, sx,sy,sz, r,g,b] * count */o=o||{};if(!P.inst)return;const m=R.mesh(g),pr=P.inst;gl.useProgram(pr.p);off(pr);common(pr,o.m);mat(pr,o);blendFor(o);attr(pr,'aP',m.p,3);attr(pr,'aN',m.nr,3);
  const I=new Float32Array(count*3),Sc=new Float32Array(count*3),Cc=new Float32Array(count*3);for(let k=0;k<count;k++){for(let j=0;j<3;j++){I[k*3+j]=data[k*9+j];Sc[k*3+j]=data[k*9+3+j];Cc[k*3+j]=data[k*9+6+j];}}
  attr(pr,'aI',dbuf('inI',I),3,1);attr(pr,'aIS',dbuf('inS',Sc),3,1);attr(pr,'aIC',dbuf('inC',Cc),3,1);gl.uniform1f(pr.U.uVC,1);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,m.i);ext.i.drawElementsInstancedANGLE(gl.TRIANGLES,m.n,m.big?gl.UNSIGNED_INT:gl.UNSIGNED_SHORT,0,count);off(pr);};
 R.upd=g=>{const m=R.mesh(g);gl.bindBuffer(gl.ARRAY_BUFFER,m.p);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(g.P),gl.DYNAMIC_DRAW);gl.bindBuffer(gl.ARRAY_BUFFER,m.nr);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(g.N),gl.DYNAMIC_DRAW);if(g.C&&m.c){gl.bindBuffer(gl.ARRAY_BUFFER,m.c);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(g.C),gl.DYNAMIC_DRAW);}};
 R.points=(pos,col,size,o)=>{o=o||{};const pr=P.pts;gl.useProgram(pr.p);off(pr);common(pr,o.m);gl.uniform1f(pr.U.uSz,o.size||1);gl.uniform1f(pr.U.uDpr,dpr);gl.uniform1f(pr.U.uSoft,o.soft===undefined?.18:o.soft);gl.depthMask(false);gl.blendFunc(gl.ONE,o.add?gl.ONE:gl.ONE_MINUS_SRC_ALPHA);if(o.nodepth)gl.disable(gl.DEPTH_TEST);
  attr(pr,'aP',dbuf('pp',pos),3);attr(pr,'aC',dbuf('pc',col),4);if(size)attr(pr,'aS',dbuf('ps',size),1);else{gl.disableVertexAttribArray(pr.A.aS);gl.vertexAttrib1f(pr.A.aS,1);}gl.drawArrays(gl.POINTS,0,pos.length/3);gl.enable(gl.DEPTH_TEST);gl.depthMask(true);gl.blendFunc(gl.ONE,gl.ONE_MINUS_SRC_ALPHA);};
 R.lines=(pos,col,o)=>{o=o||{};const pr=P.ln;gl.useProgram(pr.p);off(pr);common(pr,o.m);gl.uniform1f(pr.U.uFogD,S.fogD);gl.uniform3fv(pr.U.uFog,S.fog);gl.depthMask(false);gl.blendFunc(gl.ONE,o.add?gl.ONE:gl.ONE_MINUS_SRC_ALPHA);attr(pr,'aP',dbuf('lp',pos),3);attr(pr,'aC',dbuf('lc',col),4);gl.drawArrays(o.strip?gl.LINE_STRIP:gl.LINES,0,pos.length/3);gl.depthMask(true);gl.blendFunc(gl.ONE,gl.ONE_MINUS_SRC_ALPHA);};
 const texCache=new Map();R.tex=(canvas)=>{let t=texCache.get(canvas);if(t)return t;t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,false);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,canvas);gl.generateMipmap(gl.TEXTURE_2D);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.REPEAT);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);if(ext.a)gl.texParameterf(gl.TEXTURE_2D,ext.a.TEXTURE_MAX_ANISOTROPY_EXT,8);texCache.set(canvas,t);return t;};
 R.globe=(o)=>{const E=EARTH(),g=E.geo,m=R.mesh(g),pr=P.globe;gl.useProgram(pr.p);off(pr);common(pr,o.m);gl.depthMask(true);gl.blendFunc(gl.ONE,gl.ONE_MINUS_SRC_ALPHA);gl.disable(gl.CULL_FACE);
  attr(pr,'aP',m.p,3);attr(pr,'aN',m.nr,3);attr(pr,'aT',m.t,2);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,R.tex(E.day));gl.uniform1i(pr.U.tD,0);gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,R.tex(E.aux));gl.uniform1i(pr.U.tA,1);
  gl.uniform3fv(pr.U.uCam,S.eye);gl.uniform3fv(pr.U.uSun,o.sun||[1,.3,.6]);gl.uniform3fv(pr.U.uAtm,o.atm||[.35,.6,1]);gl.uniform1f(pr.U.uT,o.t||0);gl.uniform1f(pr.U.uCloud,o.clouds===undefined?1:o.clouds);gl.uniform1f(pr.U.uNight,o.night===undefined?1:o.night);gl.uniform1f(pr.U.uExp,o.exp||1.1);gl.uniform1f(pr.U.uDim,o.dim||0);
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,m.i);gl.drawElements(gl.TRIANGLES,m.n,m.big?gl.UNSIGNED_INT:gl.UNSIGNED_SHORT,0);gl.activeTexture(gl.TEXTURE0);
  if(o.halo!==false){const ga=E.atmGeo,ma=R.mesh(ga),pa=P.atm;gl.useProgram(pa.p);off(pa);common(pa,M4.mul(o.m||M4.id(),M4.S(1.07)));attr(pa,'aP',ma.p,3);attr(pa,'aN',ma.nr,3);gl.uniform3fv(pa.U.uCam,S.eye);gl.uniform3fv(pa.U.uSun,o.sun||[1,.3,.6]);gl.uniform3fv(pa.U.uAtm,o.atm||[.35,.6,1]);gl.uniform1f(pa.U.uK,o.haloK||1.0);gl.depthMask(false);gl.enable(gl.CULL_FACE);gl.cullFace(gl.FRONT);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ma.i);gl.drawElements(gl.TRIANGLES,ma.n,ma.big?gl.UNSIGNED_INT:gl.UNSIGNED_SHORT,0);gl.disable(gl.CULL_FACE);gl.depthMask(true);}};
 R.project=(p,m)=>{const w=m?M4.xf(m,p):p,v=S.VP,x=v[0]*w[0]+v[4]*w[1]+v[8]*w[2]+v[12],y=v[1]*w[0]+v[5]*w[1]+v[9]*w[2]+v[13],z=v[2]*w[0]+v[6]*w[1]+v[10]*w[2]+v[14],ww=v[3]*w[0]+v[7]*w[1]+v[11]*w[2]+v[15];return[(x/ww*.5+.5)*R.w,(1-(y/ww*.5+.5))*R.h,z/ww,ww];};
 R.ray=(sx,sy)=>{/* world-space ray from screen point */const inv=M4.inv(S.VP),nx=sx/R.w*2-1,ny=1-sy/R.h*2,a=M4.xf4(inv,[nx,ny,-1,1]),b=M4.xf4(inv,[nx,ny,1,1]);const p0=[a[0]/a[3],a[1]/a[3],a[2]/a[3]],p1=[b[0]/b[3],b[1]/b[3],b[2]/b[3]];return{o:p0,d:norm(sub(p1,p0))};};
 R.end=(ctx,x,y,w,h)=>{ctx.drawImage(cv,0,0,cv.width,cv.height,x||0,y||0,w||R.w,h||R.h);};R.state=()=>S;return R;}
M4.xf4=(m,p)=>[m[0]*p[0]+m[4]*p[1]+m[8]*p[2]+m[12]*p[3],m[1]*p[0]+m[5]*p[1]+m[9]*p[2]+m[13]*p[3],m[2]*p[0]+m[6]*p[1]+m[10]*p[2]+m[14]*p[3],m[3]*p[0]+m[7]*p[1]+m[11]*p[2]+m[15]*p[3]];
M4.inv=m=>{const a=m,o=new Float32Array(16);const b00=a[0]*a[5]-a[1]*a[4],b01=a[0]*a[6]-a[2]*a[4],b02=a[0]*a[7]-a[3]*a[4],b03=a[1]*a[6]-a[2]*a[5],b04=a[1]*a[7]-a[3]*a[5],b05=a[2]*a[7]-a[3]*a[6],b06=a[8]*a[13]-a[9]*a[12],b07=a[8]*a[14]-a[10]*a[12],b08=a[8]*a[15]-a[11]*a[12],b09=a[9]*a[14]-a[10]*a[13],b10=a[9]*a[15]-a[11]*a[13],b11=a[10]*a[15]-a[11]*a[14];let d=b00*b11-b01*b10+b02*b09+b03*b08-b04*b07+b05*b06;if(!d)return M4.id();d=1/d;
 o[0]=(a[5]*b11-a[6]*b10+a[7]*b09)*d;o[1]=(a[2]*b10-a[1]*b11-a[3]*b09)*d;o[2]=(a[13]*b05-a[14]*b04+a[15]*b03)*d;o[3]=(a[10]*b04-a[9]*b05-a[11]*b03)*d;o[4]=(a[6]*b08-a[4]*b11-a[7]*b07)*d;o[5]=(a[0]*b11-a[2]*b08+a[3]*b07)*d;o[6]=(a[14]*b02-a[12]*b05-a[15]*b01)*d;o[7]=(a[8]*b05-a[10]*b02+a[11]*b01)*d;o[8]=(a[4]*b10-a[5]*b08+a[7]*b06)*d;o[9]=(a[1]*b08-a[0]*b10-a[3]*b06)*d;o[10]=(a[12]*b04-a[13]*b02+a[15]*b00)*d;o[11]=(a[9]*b02-a[8]*b04-a[11]*b00)*d;o[12]=(a[5]*b07-a[4]*b09-a[6]*b06)*d;o[13]=(a[0]*b09-a[1]*b07+a[2]*b06)*d;o[14]=(a[13]*b01-a[12]*b03-a[14]*b00)*d;o[15]=(a[8]*b03-a[9]*b01+a[10]*b00)*d;return o;};
let _G3=null;function G3(){if(!_G3)_G3=makeGLX(W,H);if(_G3.ok&&_G3.setDpr)_G3.setDpr(cvD());return _G3;}
/* orbit camera eye from state */
function orbitEye(s,dist,tgt,base){tgt=tgt||[0,0,0];const yaw=s.ry||0,pit=clamp(s.rx||0,-1.45,1.45);return add(tgt,[dist*Math.sin(yaw)*Math.cos(pit),dist*Math.sin(pit),dist*Math.cos(yaw)*Math.cos(pit)]);}
function glFail(ctx,msg){bg(ctx,'#faf7ff');text(ctx,msg||'WebGL is not available in this browser.',W/2,H/2,C.mut,15,'center');}
