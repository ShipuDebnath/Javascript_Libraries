/* ===================== Charts & Data Viz ===================== */
function axes(ctx,x0,y0,x1,y1,ymax,ny,fmt,col){ctx.font='12px '+FONT;for(let i=0;i<=ny;i++){const y=y0-(y0-y1)*i/ny;line(ctx,x0,y,x1,y,i?'#f1efea':'#d6d3cd',1);text(ctx,fmt?fmt(ymax*i/ny):String(Math.round(ymax*i/ny)),x0-8,y+4,col||C.mut,12,'right');}}
function squarify(items,x,y,w,h){const out=[];const total=items.reduce((a,b)=>a+b.v,0)||1;let rest=items.map(i=>Object.assign({},i,{a:i.v*w*h/total}));
 const worst=(row,s)=>{const sum=row.reduce((a,b)=>a+b.a,0),mx=Math.max(...row.map(r=>r.a)),mn=Math.min(...row.map(r=>r.a));return Math.max(s*s*mx/(sum*sum),sum*sum/(s*s*mn));};
 while(rest.length){const sh=Math.min(w,h);let row=[rest[0]],best=worst(row,sh),i=1;while(i<rest.length){const nr=row.concat([rest[i]]),wv=worst(nr,sh);if(wv<=best){row=nr;best=wv;i++;}else break;}
  const sum=row.reduce((a,b)=>a+b.a,0);if(w>=h){const cw=sum/h;let yy=y;row.forEach(r=>{const rh=r.a/cw;out.push(Object.assign(r,{x,y:yy,w:cw,h:rh}));yy+=rh;});x+=cw;w-=cw;}else{const rh=sum/w;let xx=x;row.forEach(r=>{const rw=r.a/rh;out.push(Object.assign(r,{x:xx,y,w:rw,h:rh}));xx+=rw;});y+=rh;h-=rh;}rest=rest.slice(row.length);}return out;}
function isoLines(F,nx,ny,lev,X,Y){const seg=[],ip=(p1,p2,v1,v2)=>{const t=(lev-v1)/((v2-v1)||1e-9);return[lerp(p1[0],p2[0],t),lerp(p1[1],p2[1],t)];};
 for(let j=0;j<ny-1;j++)for(let i=0;i<nx-1;i++){const a=F[j][i],b=F[j][i+1],c=F[j+1][i+1],d=F[j+1][i],idx=(a>lev?8:0)|(b>lev?4:0)|(c>lev?2:0)|(d>lev?1:0);if(idx===0||idx===15)continue;
  const A=[X(i),Y(j)],B=[X(i+1),Y(j)],Cc=[X(i+1),Y(j+1)],D=[X(i),Y(j+1)],tp=ip(A,B,a,b),rt=ip(B,Cc,b,c),bt=ip(D,Cc,d,c),lf=ip(A,D,a,d);
  const T={1:[[lf,bt]],2:[[bt,rt]],3:[[lf,rt]],4:[[tp,rt]],5:[[lf,tp],[bt,rt]],6:[[tp,bt]],7:[[lf,tp]],8:[[lf,tp]],9:[[tp,bt]],10:[[lf,bt],[tp,rt]],11:[[tp,rt]],12:[[lf,rt]],13:[[bt,rt]],14:[[lf,bt]]};T[idx].forEach(s=>seg.push(s));}return seg;}

lib('d3','D3.js','charts','The toolkit for bespoke data visualisation: scales, layouts, transitions, geo and every interaction you can imagine.');
ex({t:'One dataset, three layouts (data joins)',d:'The same 70 data points transition between a scatterplot, a circle packing and grouped columns. Each mark keeps its identity across layouts.',hint:'Click to jump to the next layout.',int:1,
 init(s){const r=rng(7),n=70;s.d=[];for(let i=0;i<n;i++)s.d.push({cat:i%4,v:8+r()*18,sx:70+r()*(W-140),sy:60+r()*(H-150)});const P=s.d.map(d=>({x:W/2+(r()-.5)*40,y:H/2+(r()-.5)*40,r:d.v}));
  for(let it=0;it<400;it++)for(let i=0;i<P.length;i++){const a=P[i];a.x+=(W/2-a.x)*.01;a.y+=(H/2-a.y)*.01;for(let j=i+1;j<P.length;j++){const b=P[j],dx=b.x-a.x,dy=b.y-a.y,dd=Math.hypot(dx,dy)||1,m=a.r+b.r+1.5;if(dd<m){const f=(m-dd)/2/dd;a.x-=dx*f;a.y-=dy*f;b.x+=dx*f;b.y+=dy*f;}}}
  const cnt=[0,0,0,0];s.d.forEach((d,i)=>{d.px=P[i].x;d.py=P[i].y;const c=cnt[d.cat]++;d.cx=110+d.cat*167+((c%4)-1.5)*30;d.cy=H-80-Math.floor(c/4)*32;});s.from=0;s.to=0;s.k=1;s.timer=2.4;s.onDown=()=>{s.timer=3.2;};},
 draw(ctx,s,t,dt){bg(ctx);s.timer+=dt;if(s.timer>3.2){s.timer=0;s.from=s.to;s.to=(s.to+1)%3;s.k=0;}s.k=Math.min(1,s.k+dt/.9);const k=ease(s.k),pos=(d,l)=>l==0?[d.sx,d.sy,.55]:l==1?[d.px,d.py,1]:[d.cx,d.cy,.55],cols=['#4f46e5','#0d9488','#e11d48','#d97706'];
  for(const d of s.d){const a=pos(d,s.from),b=pos(d,s.to);circle(ctx,lerp(a[0],b[0],k),lerp(a[1],b[1],k),d.v*lerp(a[2],b[2],k),rgba(cols[d.cat],.78),'#fff',1.5);}
  if(s.to===2&&k>.9)['Alpha','Beta','Gamma','Delta'].forEach((n,i)=>text(ctx,n,110+i*167,H-34,C.mut,13,'center'));text(ctx,['scatterplot','circle packing','grouped columns'][s.to],20,32,C.ink,18,'left',FONT,600);cap(ctx,'selection.data(data, d=>d.id).join("circle").transition().duration(900)');},
 code:`const t=d3.transition().duration(900).ease(d3.easeCubicInOut);
svg.selectAll('circle').data(data,d=>d.id).join('circle')
  .transition(t).attr('cx',d=>x(d.value)).attr('cy',d=>y(d.score)).attr('r',d=>r(d.size));
// pack layout: d3.pack().size([w,h]).padding(2)(d3.hierarchy({children:data}).sum(d=>d.size))`});
ex({t:'Force-directed graph with drag',d:'d3-force with link, charge, collision and centring forces. Drag nodes to re-heat the simulation; hover to see neighbours.',hint:'Drag a node · hover to highlight.',int:1,
 init(s){const r=rng(12),N=64;s.n=[];for(let i=0;i<N;i++){const g=i%5;s.n.push({g,x:W/2+Math.cos(g/5*TAU)*120+(r()-.5)*60,y:H/2+Math.sin(g/5*TAU)*90+(r()-.5)*60,vx:0,vy:0,deg:0});}s.E=[];for(let i=0;i<N;i++){const j=(Math.floor(r()*13)*5+s.n[i].g)%N;if(j!==i)s.E.push([i,j]);if(r()<.18)s.E.push([i,Math.floor(r()*N)]);}s.E=s.E.filter(e=>e[0]!==e[1]);s.E.forEach(e=>{s.n[e[0]].deg++;s.n[e[1]].deg++;});s.alpha=1;s.dr=-1;
  s.onDown=(x,y)=>{s.n.forEach((n,i)=>{if(Math.hypot(n.x-x,n.y-y)<12)s.dr=i;});if(s.dr>=0)s.alpha=Math.max(s.alpha,.4);};s.onMove=(x,y)=>{if(s.dr>=0&&s.down){s.n[s.dr].x=x;s.n[s.dr].y=y;s.alpha=Math.max(s.alpha,.3);}};s.onUp=()=>{s.dr=-1;};},
 draw(ctx,s,t){bg(ctx);const N=s.n,a=s.alpha;s.alpha=Math.max(.02,a*.995);
  for(let i=0;i<N.length;i++)for(let j=i+1;j<N.length;j++){const dx=N[j].x-N[i].x,dy=N[j].y-N[i].y,d2=dx*dx+dy*dy+1,f=-380/d2*a;N[i].vx+=dx*f*.05;N[i].vy+=dy*f*.05;N[j].vx-=dx*f*.05;N[j].vy-=dy*f*.05;const d=Math.sqrt(d2),m=18;if(d<m){const o=(m-d)/d*.5;N[i].x-=dx*o*.5;N[i].y-=dy*o*.5;N[j].x+=dx*o*.5;N[j].y+=dy*o*.5;}}
  for(const e of s.E){const A=N[e[0]],B=N[e[1]],dx=B.x-A.x,dy=B.y-A.y,d=Math.hypot(dx,dy)||1,f=(d-50)/d*.08*a;A.vx+=dx*f;A.vy+=dy*f;B.vx-=dx*f;B.vy-=dy*f;}
  N.forEach((n,i)=>{n.vx+=(W/2-n.x)*.012*a;n.vy+=(H/2-n.y)*.016*a;n.vx*=.6;n.vy*=.6;if(i!==s.dr){n.x=clamp(n.x+n.vx,12,W-12);n.y=clamp(n.y+n.vy,12,H-12);}});
  let hv=s.dr;if(hv<0&&s.hover)N.forEach((n,i)=>{if(Math.hypot(n.x-s.mx,n.y-s.my)<12)hv=i;});const nb=new Set([hv]);s.E.forEach(e=>{if(e[0]===hv)nb.add(e[1]);if(e[1]===hv)nb.add(e[0]);});
  for(const e of s.E){const on=hv<0||e[0]===hv||e[1]===hv;line(ctx,N[e[0]].x,N[e[0]].y,N[e[1]].x,N[e[1]].y,on?(hv<0?'rgba(120,113,108,.35)':'rgba(28,25,23,.7)'):'rgba(120,113,108,.08)',on&&hv>=0?2:1.2);}
  N.forEach((n,i)=>{ctx.globalAlpha=hv<0||nb.has(i)?1:.2;circle(ctx,n.x,n.y,5+n.deg*1.2,PAL[n.g],'#fff',2);});ctx.globalAlpha=1;if(hv>=0)tooltip(ctx,N[hv].x,N[hv].y-8,['node '+hv,'group '+N[hv].g+' · degree '+N[hv].deg]);
  text(ctx,'alpha '+s.alpha.toFixed(2),W-16,26,C.mut,12,'right',MONO);cap(ctx,'d3.forceSimulation(nodes).force("link",d3.forceLink(links)).force("charge",d3.forceManyBody())');},
 code:`const sim=d3.forceSimulation(nodes)
  .force('link',d3.forceLink(links).id(d=>d.id).distance(50))
  .force('charge',d3.forceManyBody().strength(-90))
  .force('collide',d3.forceCollide(9)).force('center',d3.forceCenter(w/2,h/2));
node.call(d3.drag().on('start',e=>{if(!e.active)sim.alphaTarget(.3).restart();})
  .on('drag',e=>{e.subject.fx=e.x;e.subject.fy=e.y;}).on('end',e=>{e.subject.fx=e.subject.fy=null;}));`});
ex({t:'Zoomable treemap',d:'A squarified d3.treemap of a software budget. Click a group to zoom in with an animated transition; click again to zoom out.',hint:'Click a group to zoom · click again to return.',int:1,
 init(s){const r=rng(4),G=[['Rendering',['WebGL','Canvas','SVG','Shaders','Fonts']],['Data',['Parsing','Storage','Search','Stats']],['Maps',['Tiles','Vector','Rasters','Geocoding','Projections','Routing']],['Audio',['Synth','Samples']],['UI',['Layout','Forms','Charts','Icons','Motion']]];
  s.G=G.map((g,gi)=>({n:g[0],gi,c:g[1].map((n,ci)=>({n,v:Math.round(20+r()*120),gi,ci,key:gi+'-'+ci}))}));s.G.forEach(g=>g.v=g.c.reduce((a,b)=>a+b.v,0));s.zoom=-1;s.cur={};
  s.layout=()=>{const T={};if(s.zoom<0){squarify(s.G.slice().sort((a,b)=>b.v-a.v),14,40,W-28,H-54).forEach(g=>{g.R=[g.x,g.y,g.w,g.h];squarify(g.c.slice().sort((a,b)=>b.v-a.v),g.x+3,g.y+20,g.w-6,g.h-23).forEach(c=>T[c.key]=[c.x,c.y,c.w,c.h,1]);});}
   else{const g=s.G[s.zoom];squarify(g.c.slice().sort((a,b)=>b.v-a.v),14,40,W-28,H-54).forEach(c=>T[c.key]=[c.x,c.y,c.w,c.h,1]);s.G.forEach(o=>{if(o!==g)o.c.forEach(c=>T[c.key]=[o.R[0]+o.R[2]/2,o.R[1]+o.R[3]/2,0,0,0]);});}s.T=T;};s.layout();
  s.onDown=(x,y)=>{if(s.zoom>=0){s.zoom=-1;s.layout();return;}const g=s.G.find(g=>g.R&&x>g.R[0]&&x<g.R[0]+g.R[2]&&y>g.R[1]&&y<g.R[1]+g.R[3]);if(g){s.zoom=g.gi;s.layout();}};},
 draw(ctx,s,t){bg(ctx);text(ctx,s.zoom<0?'Budget · all teams':'Budget › '+s.G[s.zoom].n,16,26,C.ink,15,'left',FONT,600);
  if(s.zoom<0)s.G.forEach(g=>{if(!g.R)return;text(ctx,g.n+'  '+g.v,g.R[0]+6,g.R[1]+14,C.ink2,12,'left',FONT,600);});let hv=null;
  s.G.forEach(g=>g.c.forEach(c=>{const T=s.T[c.key],cu=s.cur[c.key]||(s.cur[c.key]=T.slice());for(let i=0;i<5;i++)cu[i]=lerp(cu[i],T[i],.14);if(cu[4]<.02||cu[2]<1)return;ctx.globalAlpha=cu[4];const col=PAL[c.gi];ctx.fillStyle=mixHex(col,'#ffffff',.25+.45*(c.ci%3)/3);rr(ctx,cu[0]+1,cu[1]+1,cu[2]-2,cu[3]-2,6);ctx.fill();
   const on=s.hover&&s.mx>cu[0]&&s.mx<cu[0]+cu[2]&&s.my>cu[1]&&s.my<cu[1]+cu[3];if(on){hv=c;ctx.strokeStyle=C.ink;ctx.lineWidth=2;ctx.stroke();}if(cu[2]>46&&cu[3]>26){text(ctx,c.n,cu[0]+8,cu[1]+20,'#fff',12.5,'left',FONT,600);if(cu[3]>44)text(ctx,c.v+'k',cu[0]+8,cu[1]+37,'rgba(255,255,255,.85)',11.5,'left',MONO);}ctx.globalAlpha=1;}));
  if(hv)tooltip(ctx,s.mx,s.my,[hv.n,'$'+hv.v+'k · '+s.G[hv.gi].n]);cap(ctx,'d3.treemap().tile(d3.treemapSquarify).size([w,h]).padding(2)(root)');},
 code:`const root=d3.treemap().tile(d3.treemapSquarify).size([w,h]).paddingTop(20).paddingInner(2)
  (d3.hierarchy(data).sum(d=>d.value).sort((a,b)=>b.value-a.value));
function zoom(d){x.domain([d.x0,d.x1]);y.domain([d.y0,d.y1]);
  cell.transition().duration(750).attr('transform',d=>'translate('+x(d.x0)+','+y(d.y0)+')');}`});
ex({t:'Bar chart race',d:'Twelve contenders over 26 years. Values interpolate between keyframes, bars re-rank smoothly, and the year ticks over in the corner.',hint:'Drag the year slider to scrub.',
 controls:[{type:'range',k:'yr',l:'Year',min:2000,max:2025,step:.01,v:2000,fmt:v=>Math.floor(v)},{type:'btn',l:'▶ / ❚❚',fn:s=>{s.play=!s.play;}}],
 init(s){const r=rng(21),names=['Three.js','D3','GSAP','Leaflet','Chart.js','p5.js','PixiJS','ECharts','Plotly','Babylon','Mapbox','Konva'];s.E=names.map((n,i)=>{let v=5+r()*20;const g=.5+r()*1.5;return{n,c:PAL[i%PAL.length],vals:Array.from({length:26},(_,y)=>v=v*(1+g*.08*(r()+.1))+r()*6),rank:i};});s.yr=2000;s.play=true;},onCtl(s,k){if(k==='yr'){s.yr=s.p.yr;s.play=false;}},
 draw(ctx,s,t,dt){bg(ctx);if(s.play){s.yr+=dt*1.4;if(s.yr>2025.99)s.yr=2000;}const f=s.yr-2000,i0=Math.min(24,Math.floor(f)),u=f-i0,V=s.E.map(e=>lerp(e.vals[i0],e.vals[i0+1],u)),order=V.map((v,i)=>i).sort((a,b)=>V[b]-V[a]),mx=V[order[0]];
  order.forEach((i,k)=>{s.E[i].rank=lerp(s.E[i].rank,k,.12);});const bh=29,x0=110,x1=W-90;
  s.E.forEach((e,i)=>{const y=24+e.rank*(bh+4),w=(x1-x0)*V[i]/mx;if(e.rank>10.5)return;ctx.fillStyle=e.c;rr(ctx,x0,y,w,bh,6);ctx.fill();text(ctx,e.n,x0-8,y+19,C.ink2,13,'right',FONT,600);text(ctx,Math.round(V[i]).toLocaleString(),x0+w+6,y+19,C.mut,12,'left',MONO);});
  text(ctx,String(Math.floor(s.yr)),W-24,H-24,'rgba(28,25,23,.12)',86,'right',FONT,800);},
 code:`const frames=d3.pairs(keyframes).flatMap(([a,b])=>d3.range(10).map(i=>interpolate(a,b,i/10)));
for(const frame of frames){
  const t=svg.transition().duration(250).ease(d3.easeLinear);
  x.domain([0,frame[0].value]);
  bars.data(frame,d=>d.name).join('rect').transition(t).attr('y',d=>y(d.rank)).attr('width',d=>x(d.value)-x(0));
  await t.end();}`});

lib('echarts','Apache ECharts','charts','A declarative chart engine with 20+ chart types, rich interaction and smooth animation for dashboards.',{ik:'Apache ECharts'});
ex({t:'Dashboard: bars + smoothed line + gauge',d:'Gradient bars, a smoothed line with symbols and an animated gauge, with an axis-pointer tooltip.',hint:'Hover the chart for the axis tooltip.',
 draw(ctx,s,t){bg(ctx);const g=easeOut(clamp(((t%9)/9)/.25,0,1)),data=[120,200,150,80,70,110,130],ln=[90,140,170,120,100,160,150],x0=60,y0=H-60,cw=390,ch=290,mx=240,bw=30,step=(cw-20)/7,days=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  axes(ctx,x0,y0,x0+cw,y0-ch,mx,4);let hi=-1;if(s.hover&&s.mx>x0&&s.mx<x0+cw)hi=clamp(Math.floor((s.mx-x0-6)/step),0,6);if(hi>=0){ctx.fillStyle='rgba(79,70,229,.06)';ctx.fillRect(x0+6+hi*step,y0-ch,step,ch);}
  data.forEach((v,i)=>{const x=x0+16+i*step,h=ch*v/mx*g,gr=ctx.createLinearGradient(0,y0-h,0,y0);gr.addColorStop(0,'#818cf8');gr.addColorStop(1,'#4f46e5');ctx.fillStyle=gr;rr(ctx,x,y0-h,bw,Math.max(h,1),5);ctx.fill();text(ctx,days[i],x+bw/2,y0+20,C.mut,12,'center');});
  const pts=ln.map((v,i)=>[x0+16+i*step+bw/2,y0-ch*v/mx*g]);ctx.strokeStyle='#f59e0b';ctx.lineWidth=3;smoothOpen(ctx,pts);ctx.stroke();pts.forEach((p,i)=>circle(ctx,p[0],p[1],i===hi?7:4.5,'#fff','#f59e0b',2.5));
  const gx=580,gy=220,v=.55+.38*Math.sin(t*.8),a0=.75*Math.PI,sw=1.5*Math.PI;ctx.lineCap='round';ctx.lineWidth=18;ctx.strokeStyle='#f1efea';ctx.beginPath();ctx.arc(gx,gy,92,a0,a0+sw);ctx.stroke();const gg=ctx.createLinearGradient(gx-90,0,gx+90,0);gg.addColorStop(0,'#10b981');gg.addColorStop(.5,'#f59e0b');gg.addColorStop(1,'#ef4444');ctx.strokeStyle=gg;ctx.beginPath();ctx.arc(gx,gy,92,a0,a0+sw*v);ctx.stroke();
  for(let i=0;i<=10;i++){const a=a0+sw*i/10;line(ctx,gx+Math.cos(a)*70,gy+Math.sin(a)*70,gx+Math.cos(a)*(i%5?74:66),gy+Math.sin(a)*(i%5?74:66),C.faint,1.5);}const na=a0+sw*v;ctx.lineWidth=4;line(ctx,gx,gy,gx+Math.cos(na)*64,gy+Math.sin(na)*64,C.ink,4);circle(ctx,gx,gy,8,C.ink);text(ctx,Math.round(v*100)+'%',gx,gy+52,C.ink,30,'center',FONT,700);text(ctx,'CPU load',gx,gy+74,C.mut,13,'center');
  if(hi>=0)tooltip(ctx,x0+16+hi*step+bw/2,y0-ch*Math.max(data[hi],ln[hi])/mx-6,[days[hi],'● Visits  '+data[hi],'● Orders  '+ln[hi]]);cap(ctx,'chart.setOption({ tooltip:{trigger:"axis"}, series:[bar, line, gauge] })');},
 code:`const chart=echarts.init(document.getElementById('c'));
chart.setOption({tooltip:{trigger:'axis'},xAxis:{type:'category',data:days},yAxis:{},
  series:[{type:'bar',data:visits,itemStyle:{borderRadius:5,color:new echarts.graphic.LinearGradient(0,0,0,1,[{offset:0,color:'#818cf8'},{offset:1,color:'#4f46e5'}])}},
    {type:'line',smooth:true,data:orders},
    {type:'gauge',center:['80%','50%'],data:[{value:62,name:'CPU'}]}]});`});
ex({t:'Sankey: a remote-sensing pipeline',d:'Flows from sensors through processing steps to products. Hover a node to focus its adjacent flows.',hint:'Hover a node.',int:1,
 init(s){const N=[['Landsat',0],['Sentinel-2',0],['MODIS',0],['Atmospheric corr.',1],['Cloud masking',1],['NDVI',2],['Land cover',2],['Change map',2]],Lk=[[0,3,30],[1,3,40],[2,4,25],[1,4,15],[3,5,35],[3,6,35],[4,6,20],[4,7,20]],xs=[100,345,590],nw=16;
  s.nodes=N.map((n,i)=>({name:n[0],col:n[1],i,in:0,out:0,x:xs[n[1]],io:0,oo:0}));s.links=Lk.map(l=>({a:l[0],b:l[1],v:l[2]}));for(const l of s.links){s.nodes[l.a].out+=l.v;s.nodes[l.b].in+=l.v;}s.nodes.forEach(n=>n.v=Math.max(n.in,n.out));
  let sc=9;for(let c=0;c<3;c++){const ns=s.nodes.filter(n=>n.col==c),tot=ns.reduce((a,n)=>a+n.v,0);sc=Math.min(sc,(H-90-(ns.length-1)*18)/tot);}s.nw=nw;
  for(let c=0;c<3;c++){const ns=s.nodes.filter(n=>n.col==c),tot=ns.reduce((a,n)=>a+n.v*sc,0)+(ns.length-1)*18;let y=(H-tot)/2;for(const n of ns){n.y=y;n.h=n.v*sc;y+=n.h+18;}}
  for(const l of s.links){const A=s.nodes[l.a],B=s.nodes[l.b];l.y0=A.y+A.oo;A.oo+=l.v*sc;l.y1=B.y+B.io;B.io+=l.v*sc;l.h=l.v*sc;}},
 draw(ctx,s,t){bg(ctx);s.hov=-1;if(s.hover)for(const n of s.nodes)if(s.mx>n.x-6&&s.mx<n.x+s.nw+6&&s.my>n.y&&s.my<n.y+n.h)s.hov=n.i;const cl=i=>PAL[i%PAL.length],g=easeOut(clamp(t/1.4,0,1));
  for(const l of s.links){const A=s.nodes[l.a],B=s.nodes[l.b],x0=A.x+s.nw,x1=lerp(x0,B.x,g),xm=(x0+x1)/2,on=s.hov<0||l.a==s.hov||l.b==s.hov,gr=ctx.createLinearGradient(x0,0,x1,0);gr.addColorStop(0,rgba(cl(A.i),on?.4:.07));gr.addColorStop(1,rgba(cl(B.i),on?.4:.07));
   ctx.fillStyle=gr;ctx.beginPath();ctx.moveTo(x0,l.y0);ctx.bezierCurveTo(xm,l.y0,xm,l.y1,x1,l.y1);ctx.lineTo(x1,l.y1+l.h);ctx.bezierCurveTo(xm,l.y1+l.h,xm,l.y0+l.h,x0,l.y0+l.h);ctx.closePath();ctx.fill();}
  for(const n of s.nodes){ctx.fillStyle=cl(n.i);rr(ctx,n.x,n.y,s.nw,n.h,3);ctx.fill();const lx=n.col==0?n.x-8:n.x+s.nw+8;text(ctx,n.name,lx,n.y+n.h/2+5,C.ink,13.5,n.col==0?'right':'left',FONT,600);text(ctx,String(n.v),lx,n.y+n.h/2+21,C.mut,11.5,n.col==0?'right':'left',MONO);}
  cap(ctx,'series:[{ type:"sankey", emphasis:{focus:"adjacency"}, data, links }]');},
 code:`chart.setOption({series:[{type:'sankey',emphasis:{focus:'adjacency'},nodeAlign:'justify',
  lineStyle:{color:'gradient',curveness:.5},
  data:[{name:'Landsat'},{name:'NDVI'}],links:[{source:'Landsat',target:'Atmospheric corr.',value:30}]}]});`});
ex({t:'Calendar heatmap (a year of activity)',d:'365 daily values on a calendar coordinate system with a visualMap colour scale, month labels and a hover tooltip.',hint:'Hover a day.',int:1,
 init(s){const r=rng(8);s.v=[];for(let d=0;d<365;d++){const wd=(d+3)%7,sea=.5+.5*Math.sin((d-60)/365*TAU);s.v.push(wd>4?Math.floor(r()*3*sea):Math.floor(sea*12*r()+r()*4));}},
 draw(ctx,s,t){bg(ctx);const cs=10,gap=2,x0=56,y0=110,mx=15,cols=['#f5f3ef','#c7d2fe','#818cf8','#4f46e5','#312e81'];let hv=-1;text(ctx,'2026 · contributions',x0,60,C.ink,18,'left',FONT,600);
  const rev=clamp(t/1.2,0,1)*365;for(let d=0;d<365;d++){const day=(d+3)%7,wk=Math.floor((d+3)/7),x=x0+wk*(cs+gap),y=y0+day*(cs+gap),v=s.v[d];ctx.fillStyle=d<rev?cols[v===0?0:Math.min(4,1+Math.floor(v/4))]:'#faf9f6';rr(ctx,x,y,cs,cs,2.5);ctx.fill();if(s.hover&&s.mx>=x&&s.mx<x+cs&&s.my>=y&&s.my<y+cs)hv=d;}
  ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'].forEach((m,i)=>text(ctx,m,x0+i*4.42*(cs+gap),y0-10,C.mut,11.5));['Mon','Wed','Fri'].forEach((d,i)=>text(ctx,d,x0-8,y0+(1+i*2)*(cs+gap)+9,C.mut,10.5,'right'));
  text(ctx,'Less',x0+500,y0+120,C.mut,11.5,'right');cols.forEach((c,i)=>{ctx.fillStyle=c;rr(ctx,x0+506+i*15,y0+110,11.5,11.5,2.5);ctx.fill();});text(ctx,'More',x0+585,y0+120,C.mut,11.5);
  const tot=s.v.reduce((a,b)=>a+b,0);[['Total',tot],['Best day',Math.max(...s.v)],['Active days',s.v.filter(v=>v>0).length]].forEach((k,i)=>{text(ctx,String(k[1]),x0+i*160,y0+200,C.ink,28,'left',FONT,700);text(ctx,k[0],x0+i*160,y0+222,C.mut,12.5);});
  if(hv>=0){const dt=new Date(Date.UTC(2026,0,1+hv));tooltip(ctx,s.mx,s.my,[dt.toDateString(),s.v[hv]+' contributions']);}cap(ctx,'calendar:{range:"2026"}, series:{type:"heatmap", coordinateSystem:"calendar"}');},
 code:`chart.setOption({visualMap:{min:0,max:16,inRange:{color:['#f5f3ef','#4f46e5']},orient:'horizontal'},
  calendar:{range:'2026',cellSize:12},tooltip:{},
  series:{type:'heatmap',coordinateSystem:'calendar',data:days.map(d=>[d.date,d.count])}});`});
ex({t:'Nightingale rose with legend toggles',d:'A rose-type pie where each sector’s radius encodes the value. Click legend items to toggle sectors; the rest re-flow with animation.',hint:'Click legend items · hover sectors.',int:1,
 init(s){s.D=[['Rendering',40],['Data',33],['Maps',28],['Physics',22],['Audio',18],['UI',30],['AI',25],['Docs',12]].map((d,i)=>({n:d[0],v:d[1],on:true,cur:0,c:PAL[i%PAL.length]}));s.onDown=(x,y)=>{s.D.forEach((d,i)=>{if(x>520&&x<700&&Math.abs(y-(96+i*32))<13)d.on=!d.on;});};},
 draw(ctx,s,t){bg(ctx);const cx=260,cy=H/2+6,on=s.D.filter(d=>d.on),n=on.length||1,mx=Math.max(1,...on.map(d=>d.v)),spin=easeOut(clamp(t/1.6,0,1));let k=0,hv=null;
  s.D.forEach(d=>{const tgt=d.on?1:0;d.cur=lerp(d.cur,tgt,.12);});const tot=s.D.reduce((a,d)=>a+d.cur,0)||1;let a=-Math.PI/2+(1-spin)*-1.5;
  s.D.forEach(d=>{const sw=d.cur/tot*TAU*spin,r=(50+150*d.v/mx)*d.cur*spin;if(sw>.001){const mid=a+sw/2,ang=Math.atan2(s.my-cy,s.mx-cx),dist=Math.hypot(s.mx-cx,s.my-cy);let aa=ang;while(aa<a)aa+=TAU;const isH=s.hover&&aa<a+sw&&dist<r&&dist>30;if(isH)hv=d;const off=isH?8:0;ctx.fillStyle=d.c;ctx.beginPath();ctx.arc(cx+Math.cos(mid)*off,cy+Math.sin(mid)*off,r,a,a+sw);ctx.arc(cx+Math.cos(mid)*off,cy+Math.sin(mid)*off,30,a+sw,a,true);ctx.closePath();ctx.fill();ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.stroke();}a+=sw;});
  circle(ctx,cx,cy,30,'#fff');s.D.forEach((d,i)=>{const y=96+i*32;ctx.globalAlpha=d.on?1:.35;rr(ctx,524,y-8,16,16,4);ctx.fillStyle=d.c;ctx.fill();text(ctx,d.n,550,y+5,C.ink,14);text(ctx,String(d.v),690,y+5,C.mut,12.5,'right',MONO);ctx.globalAlpha=1;});
  if(hv)tooltip(ctx,s.mx,s.my,[hv.n,'value '+hv.v]);cap(ctx,'series:[{ type:"pie", roseType:"radius", radius:[30, 200] }]');},
 code:`chart.setOption({legend:{orient:'vertical',right:10},tooltip:{},
  series:[{type:'pie',roseType:'radius',radius:[30,200],itemStyle:{borderRadius:6,borderColor:'#fff',borderWidth:2},
    data:[{value:40,name:'Rendering'},{value:33,name:'Data'},{value:28,name:'Maps'}]}]});`});

lib('plotly','Plotly.js','charts','Scientific charting: 3D surfaces, contours, statistical plots and maps with zoom, hover and export built in.');
ex({t:'3D surface with colour scale',d:'A damped radial wave rendered as a shaded surface with a Viridis colour scale, bounding box and colour bar.',hint:'Drag to rotate the camera.',orbit:{ry:.6,rx:.9,auto:.3},
 draw(ctx,s,t){bg(ctx);const N=30,f=(x,z)=>{const r=Math.hypot(x,z);return Math.cos(r*5-t*2)*Math.exp(-r*.75);};const Q=[];
  const P=[];for(let i=0;i<=N;i++){P[i]=[];for(let j=0;j<=N;j++){const x=(i/N-.5)*3,z=(j/N-.5)*3,y=f(x,z);P[i][j]=[x,-y*.9,z,y];}}for(let i=0;i<N;i++)for(let j=0;j<N;j++){const q=[P[i][j],P[i+1][j],P[i+1][j+1],P[i][j+1]];Q.push({v:q.map(p=>p.slice(0,3)),hy:(q[0][3]+q[2][3])/2});}
  wireBox(ctx,s.ry,s.rx,105,6,[1.5,1,1.5]);renderQuads(ctx,Q,{ry:s.ry,rx:s.rx,sc:105,d:6,col:(q,dif)=>mixHex(hex2rgb2(ramp((q.hy+.8)/1.8)),'#ffffff',(1-dif)*.12),wire:'rgba(255,255,255,.18)'});
  for(let i=0;i<=20;i++){ctx.fillStyle=ramp(1-i/20);ctx.fillRect(W-40,60+i*14,16,14);}text(ctx,'1.0',W-46,68,C.mut,11,'right');text(ctx,'-0.8',W-46,350,C.mut,11,'right');cap(ctx,'Plotly.newPlot(div,[{type:"surface", z, colorscale:"Viridis"}])');},
 code:`Plotly.newPlot('plot',[{type:'surface',z:matrix,colorscale:'Viridis',
  contours:{z:{show:true,usecolormap:true,project:{z:true}}}}],
  {scene:{camera:{eye:{x:1.5,y:1.5,z:1}}},margin:{t:0}},{responsive:true});`});
ex({t:'Filled contour with isolines & hover',d:'A filled contour (heatmap with interpolation) plus marching-squares isolines at ten levels, a colour bar and a crosshair readout.',hint:'Hover to read the value under the cursor.',int:1,
 init(s){const nx=80,ny=50;s.nx=nx;s.ny=ny;s.F=[];const f=(x,y)=>3*(1-x)*(1-x)*Math.exp(-x*x-(y+1)*(y+1))-10*(x/5-x*x*x-Math.pow(y,5))*Math.exp(-x*x-y*y)-1/3*Math.exp(-(x+1)*(x+1)-y*y);for(let j=0;j<ny;j++){s.F[j]=[];for(let i=0;i<nx;i++)s.F[j][i]=f(-3+i/(nx-1)*6,3-j/(ny-1)*6);}s.f=f;
  const c=document.createElement('canvas');c.width=nx;c.height=ny;const x=c.getContext('2d'),im=x.createImageData(nx,ny);for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){const m=scale(SPECT.slice().reverse(),(s.F[j][i]+6.5)/14.6).match(/\d+/g),k=(j*nx+i)*4;im.data[k]=+m[0];im.data[k+1]=+m[1];im.data[k+2]=+m[2];im.data[k+3]=255;}x.putImageData(im,0,0);s.img=c;
  const X0=60,X1=600,Y0=30,Y1=400;s.box=[X0,Y0,X1,Y1];s.iso=[];for(let L=-6;L<=8;L+=1.4)s.iso.push(isoLines(s.F,nx,ny,L,i=>X0+i/(nx-1)*(X1-X0),j=>Y0+j/(ny-1)*(Y1-Y0)));},
 draw(ctx,s,t){bg(ctx);const[X0,Y0,X1,Y1]=s.box;ctx.imageSmoothingEnabled=true;ctx.drawImage(s.img,X0,Y0,X1-X0,Y1-Y0);ctx.strokeStyle='rgba(28,25,23,.45)';ctx.lineWidth=1;const rv=clamp(t/1.5,0,1);s.iso.forEach((L,i)=>{if(i/s.iso.length>rv)return;ctx.beginPath();for(const[a,b]of L){ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);}ctx.stroke();});
  ctx.strokeStyle=C.line;ctx.strokeRect(X0,Y0,X1-X0,Y1-Y0);for(let i=0;i<=6;i++){text(ctx,String(i-3),X0+i*(X1-X0)/6,Y1+18,C.mut,11,'center');text(ctx,String(3-i),X0-8,Y0+i*(Y1-Y0)/6+4,C.mut,11,'right');}
  for(let i=0;i<=24;i++){ctx.fillStyle=scale(SPECT.slice().reverse(),1-i/24);ctx.fillRect(630,30+i*15,18,15);}text(ctx,'8.1',656,40,C.mut,11);text(ctx,'-6.5',656,404,C.mut,11);
  if(s.hover&&s.mx>X0&&s.mx<X1&&s.my>Y0&&s.my<Y1){const x=-3+(s.mx-X0)/(X1-X0)*6,y=3-(s.my-Y0)/(Y1-Y0)*6;line(ctx,s.mx,Y0,s.mx,Y1,'rgba(28,25,23,.4)',1,[4,4]);line(ctx,X0,s.my,X1,s.my,'rgba(28,25,23,.4)',1,[4,4]);tooltip(ctx,s.mx,s.my,['x '+x.toFixed(2)+'  y '+y.toFixed(2),'z = '+s.f(x,y).toFixed(3)]);}
  cap(ctx,'{type:"contour", z, colorscale:"Spectral", contours:{coloring:"heatmap"}}');},
 code:`Plotly.newPlot('plot',[{type:'contour',z:peaks,x,y,colorscale:'Spectral',reversescale:true,
  contours:{coloring:'heatmap',showlabels:true,start:-6,end:8,size:1.4},line:{color:'rgba(0,0,0,.4)'}}],
  {hovermode:'closest'});`});
ex({t:'Violin + box plots with jittered points',d:'Four distributions (normal, skewed, bimodal, uniform) as kernel-density violins with inner box plots and every observation jittered.',hint:'Switch view · hover a group for its statistics.',controls:[{type:'seg',k:'m',v:'Violin + box',opts:['Violin + box','Box only','Points only']}],
 init(s){const r=rng(31);const G=[['Normal',()=>gauss(r)*.8+3.5],['Skewed',()=>2+Math.pow(r(),2.4)*5],['Bimodal',()=>r()<.5?2.2+gauss(r)*.45:5.1+gauss(r)*.5],['Uniform',()=>1.5+r()*5]];
  s.G=G.map(([n,f],i)=>{const v=Array.from({length:150},f).sort((a,b)=>a-b),q=p=>v[Math.floor(p*(v.length-1))];const kde=[];for(let y=0;y<=8;y+=.1){let d=0;for(const x of v)d+=Math.exp(-Math.pow((y-x)/.3,2)/2);kde.push([y,d/v.length]);}return{n,v,q1:q(.25),md:q(.5),q3:q(.75),lo:q(.02),hi:q(.98),mean:v.reduce((a,b)=>a+b,0)/v.length,kde,c:PAL[i],j:v.map(()=>(r()-.5))};});},
 draw(ctx,s,t){bg(ctx);const X0=70,X1=W-30,Y0=H-50,Y1=30,Y=v=>Y0-(v/8)*(Y0-Y1),gw=(X1-X0)/4,m=s.p.m,g=easeOut(clamp(t/1.2,0,1));axes(ctx,X0,Y0,X1,Y1,8,4);let hv=null;
  s.G.forEach((G,i)=>{const cx=X0+gw*(i+.5);if(s.hover&&Math.abs(s.mx-cx)<gw/2)hv=G;const mk=Math.max(...G.kde.map(k=>k[1]));
   if(m==='Violin + box'){ctx.beginPath();G.kde.forEach(([y,d],k)=>{const x=cx+d/mk*gw*.4*g;k?ctx.lineTo(x,Y(y)):ctx.moveTo(x,Y(y));});for(let k=G.kde.length-1;k>=0;k--){const[y,d]=G.kde[k];ctx.lineTo(cx-d/mk*gw*.4*g,Y(y));}ctx.closePath();ctx.fillStyle=rgba(G.c,.16);ctx.fill();ctx.strokeStyle=G.c;ctx.lineWidth=1.5;ctx.stroke();}
   if(m!=='Points only'){const bw=m==='Box only'?40:14;line(ctx,cx,Y(G.lo),cx,Y(G.hi),G.c,1.5);ctx.fillStyle=m==='Box only'?rgba(G.c,.2):G.c;rr(ctx,cx-bw/2,Y(G.q3),bw,Y(G.q1)-Y(G.q3),3);ctx.fill();if(m==='Box only'){ctx.strokeStyle=G.c;ctx.stroke();}line(ctx,cx-bw/2,Y(G.md),cx+bw/2,Y(G.md),m==='Box only'?G.c:'#fff',2.5);}
   if(m!=='Box only')G.v.forEach((v,k)=>circle(ctx,cx+G.j[k]*(m==='Points only'?gw*.6:gw*.7)+(m==='Violin + box'?0:0),Y(v),2.2,rgba(G.c,m==='Points only'?.65:.35)));
   text(ctx,G.n,cx,Y0+22,C.ink2,13,'center',FONT,600);});
  if(hv)tooltip(ctx,s.mx,s.my,[hv.n,'median '+hv.md.toFixed(2)+'  mean '+hv.mean.toFixed(2),'Q1 '+hv.q1.toFixed(2)+'  Q3 '+hv.q3.toFixed(2)]);cap(ctx,'{type:"violin", box:{visible:true}, points:"all", jitter:.5}');},
 code:`Plotly.newPlot('plot',groups.map(g=>({type:'violin',y:g.values,name:g.name,
  box:{visible:true},meanline:{visible:true},points:'all',jitter:.5,pointpos:0})),{violinmode:'group'});`});

lib('chartjs','Chart.js','charts','Simple, responsive, animated canvas charts: line, bar, doughnut, radar, polar, bubble and mixed.',{ik:'Chart.js'});
ex({t:'Area line with index tooltip + doughnut',d:'A filled line chart with a vertical hover guide and tooltip, next to a doughnut that animates its arcs on load.',hint:'Hover the line chart.',
 draw(ctx,s,t){bg(ctx);const d=[12,19,14,25,22,30,28,36,32,41],p=easeOut(clamp((t%10)/1.4,0,1)),x0=56,x1=440,y0=H-56,y1=50,mx=45;axes(ctx,x0,y0,x1,y1,mx,4);
  const pt=d.map((v,i)=>[x0+i*(x1-x0)/9,y0-(y0-y1)*v/mx*p]);const gr=ctx.createLinearGradient(0,y1,0,y0);gr.addColorStop(0,'rgba(79,70,229,.32)');gr.addColorStop(1,'rgba(79,70,229,0)');ctx.beginPath();ctx.moveTo(pt[0][0],y0);smoothOpen(ctx,pt);ctx.lineTo(pt[9][0],y0);ctx.lineTo(pt[0][0],y0);ctx.fillStyle=gr;ctx.fill();
  ctx.strokeStyle='#4f46e5';ctx.lineWidth=3;smoothOpen(ctx,pt);ctx.stroke();pt.forEach(q=>circle(ctx,q[0],q[1],4,'#fff','#4f46e5',2.5));
  if(s.hover&&s.mx>x0-10&&s.mx<x1+10){const i=clamp(Math.round((s.mx-x0)/(x1-x0)*9),0,9),q=pt[i];line(ctx,q[0],y1,q[0],y0,'rgba(28,25,23,.25)',1,[5,4]);circle(ctx,q[0],q[1],7,'#4f46e5','#fff',2);tooltip(ctx,q[0],q[1],['Day '+(i+1),'■ NDVI index: '+d[i]]);}
  const cx=585,cy=H/2-10,vals=[40,25,20,15],cols=['#4f46e5','#06b6d4','#ec4899','#f59e0b'];let a=-Math.PI/2;for(let i=0;i<4;i++){const sw=vals[i]/100*TAU*p;ctx.beginPath();ctx.arc(cx,cy,82,a,a+sw);ctx.arc(cx,cy,50,a+sw,a,true);ctx.closePath();ctx.fillStyle=cols[i];ctx.fill();ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.stroke();a+=sw;}
  ['Forest','Water','Urban','Crops'].forEach((n,i)=>{ctx.fillStyle=cols[i];rr(ctx,520+(i%2)*80,cy+104+Math.floor(i/2)*22,12,12,3);ctx.fill();text(ctx,n,536+(i%2)*80,cy+114+Math.floor(i/2)*22,C.ink2,12);});cap(ctx,'new Chart(ctx,{type:"line", options:{interaction:{mode:"index"}}})');},
 code:`new Chart(ctx,{type:'line',data:{labels,datasets:[{label:'NDVI',data,fill:true,tension:.4,
  backgroundColor:gradient,borderColor:'#4f46e5'}]},
  options:{interaction:{mode:'index',intersect:false},plugins:{tooltip:{enabled:true}}}});
new Chart(ctx2,{type:'doughnut',data:{labels:['Forest','Water','Urban','Crops'],datasets:[{data:[40,25,20,15]}]}});`});
ex({t:'Radar chart comparing two datasets',d:'Two libraries compared on six axes. Click a legend item to hide a dataset; hover a vertex for its value.',hint:'Click the legend · hover points.',int:1,
 init(s){s.ax=['Speed','Size','Features','Docs','3D','Community'];s.ds=[{n:'Chart.js',v:[9,9,6,8,2,9],c:'#4f46e5',on:true,k:0},{n:'ECharts',v:[7,5,10,8,7,8],c:'#e11d48',on:true,k:0}];s.onDown=(x,y)=>{s.ds.forEach((d,i)=>{if(y>18&&y<40&&x>W/2-130+i*140&&x<W/2-20+i*140)d.on=!d.on;});};},
 draw(ctx,s,t){bg(ctx);const cx=W/2,cy=H/2+18,R=150,n=6,P=(i,v)=>[cx+Math.cos(-Math.PI/2+i/n*TAU)*R*v/10,cy+Math.sin(-Math.PI/2+i/n*TAU)*R*v/10];
  for(let l=2;l<=10;l+=2){poly(ctx,s.ax.map((_,i)=>P(i,l)),null,'#ece9e3',1);}s.ax.forEach((a,i)=>{const p=P(i,10),q=P(i,11.6);line(ctx,cx,cy,p[0],p[1],'#ece9e3',1);text(ctx,a,q[0],q[1]+4,C.ink2,13,'center',FONT,600);});let hv=null;
  s.ds.forEach(d=>{d.k=lerp(d.k,d.on?easeOut(clamp(t/1.2,0,1)):0,.15);if(d.k<.01)return;const pts=d.v.map((v,i)=>P(i,v*d.k));poly(ctx,pts,rgba(d.c,.15),d.c,2.5);pts.forEach((p,i)=>{circle(ctx,p[0],p[1],4,'#fff',d.c,2.5);if(s.hover&&Math.hypot(s.mx-p[0],s.my-p[1])<9)hv=[p,d,i];});});
  s.ds.forEach((d,i)=>{ctx.globalAlpha=d.on?1:.4;ctx.fillStyle=d.c;rr(ctx,W/2-130+i*140,22,30,12,3);ctx.fill();text(ctx,d.n,W/2-94+i*140,33,C.ink,13);if(!d.on)line(ctx,W/2-94+i*140,29,W/2-94+i*140+ctx.measureText(d.n).width,29,C.ink,1);ctx.globalAlpha=1;});
  if(hv)tooltip(ctx,hv[0][0],hv[0][1],[s.ax[hv[2]],hv[1].n+': '+hv[1].v[hv[2]]]);},
 code:`new Chart(ctx,{type:'radar',data:{labels:['Speed','Size','Features','Docs','3D','Community'],
  datasets:[{label:'Chart.js',data:[9,9,6,8,2,9],fill:true},{label:'ECharts',data:[7,5,10,8,7,8],fill:true}]},
  options:{scales:{r:{min:0,max:10}}}});`});
ex({t:'Mixed bar + line with animated updates',d:'Grouped bars and a line on one axis. Randomise the data and every element tweens from its old value to its new one.',hint:'Press Randomise · hover for the index tooltip.',controls:[{type:'btn',l:'Randomise',pri:1,fn:s=>s.rand()},{type:'btn',l:'Add month',fn:s=>s.addM()}],
 init(s){const r=()=>Math.random();s.n=8;s.mk=()=>Array.from({length:12},()=>[20+r()*70,15+r()*60,30+r()*50]);s.T=s.mk();s.cur=s.T.map(a=>a.map(()=>0));s.rand=()=>{s.T=s.mk();};s.addM=()=>{s.n=s.n>=12?6:s.n+1;};},
 draw(ctx,s,t){bg(ctx);const x0=56,x1=W-24,y0=H-54,y1=40,mx=100,n=s.n,step=(x1-x0)/n,M=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];axes(ctx,x0,y0,x1,y1,mx,5);
  for(let i=0;i<12;i++)for(let k=0;k<3;k++)s.cur[i][k]=lerp(s.cur[i][k],s.T[i][k],.09);let hi=-1;if(s.hover&&s.mx>x0&&s.mx<x1)hi=clamp(Math.floor((s.mx-x0)/step),0,n-1);if(hi>=0){ctx.fillStyle='rgba(79,70,229,.05)';ctx.fillRect(x0+hi*step,y1,step,y0-y1);}
  const bw=Math.min(22,step*.3);for(let i=0;i<n;i++){const cx=x0+step*(i+.5);[['#a5b4fc',0],['#4f46e5',1]].forEach(([c,k],j)=>{const h=(y0-y1)*s.cur[i][k]/mx;ctx.fillStyle=c;rr(ctx,cx-bw-1+j*(bw+2),y0-h,bw,h,4);ctx.fill();});text(ctx,M[i],cx,y0+18,C.mut,11.5,'center');}
  const pts=Array.from({length:n},(_,i)=>[x0+step*(i+.5),y0-(y0-y1)*s.cur[i][2]/mx]);ctx.strokeStyle='#f59e0b';ctx.lineWidth=3;smoothOpen(ctx,pts);ctx.stroke();pts.forEach(p=>circle(ctx,p[0],p[1],4.5,'#fff','#f59e0b',2.5));
  if(hi>=0)tooltip(ctx,x0+step*(hi+.5),y1+60,[M[hi],'■ Plan '+Math.round(s.cur[hi][0]),'■ Actual '+Math.round(s.cur[hi][1]),'— Target '+Math.round(s.cur[hi][2])]);cap(ctx,'chart.data.datasets[0].data = newData; chart.update()');},
 code:`const chart=new Chart(ctx,{data:{labels:months,datasets:[
  {type:'bar',label:'Plan',data:plan},{type:'bar',label:'Actual',data:actual},
  {type:'line',label:'Target',data:target,tension:.4}]},options:{interaction:{mode:'index'}}});
randomBtn.onclick=()=>{chart.data.datasets.forEach(d=>d.data=d.data.map(()=>Math.random()*100));chart.update();};`});

lib('vegalite','Vega-Lite','charts','A grammar of interactive graphics: charts as JSON specs with encodings, transforms and selections.',{ik:'Vega-Lite'});
ex({t:'From JSON spec to binned heatmap',d:'The spec on the left is the whole program: bin x and y, aggregate count to colour. Hover cells to read counts.',hint:'Hover a cell.',int:1,
 init(s){const r=rng(5),NX=22,NY=16;s.c=Array.from({length:NX},()=>new Array(NY).fill(0));for(let i=0;i<900;i++){const a=gauss(r),b=.6*a+.8*gauss(r),x=Math.floor(clamp(NX/2+a*3.6,0,NX-1)),y=Math.floor(clamp(NY/2-b*2.7,0,NY-1));s.c[x][y]++;}s.NX=NX;s.NY=NY;s.mx_=Math.max(...s.c.map(a=>Math.max(...a)));},
 draw(ctx,s,t){bg(ctx);ctx.fillStyle='#faf9f6';rr(ctx,10,14,262,H-56,10);ctx.fill();const spec=['{','  "mark": "rect",','  "encoding": {','    "x": {"bin": true,','          "field": "x"},','    "y": {"bin": true,','          "field": "y"},','    "color": {','      "aggregate": "count"}','  }','}'];spec.forEach((l,i)=>{const m=l.match(/"[^"]+"/g);text(ctx,l,22,46+i*25,i%3==0?C.teal:C.indigo,14,'left',MONO);});
  const gx=296,gy=20,cw=(W-gx-16)/s.NX,ch=(H-gy-46)/s.NY;let hv=null;for(let i=0;i<s.NX;i++)for(let j=0;j<s.NY;j++){const v=s.c[i][j];ctx.fillStyle=v?scale(['#eef2ff','#a5b4fc','#4f46e5','#1e1b4b'],v/s.mx_):'#fafaf9';ctx.fillRect(gx+i*cw,gy+j*ch,cw-1,ch-1);if(s.hover&&s.mx>=gx+i*cw&&s.mx<gx+(i+1)*cw&&s.my>=gy+j*ch&&s.my<gy+(j+1)*ch)hv=[i,j,v];}
  if(hv){ctx.strokeStyle=C.ink;ctx.lineWidth=2;ctx.strokeRect(gx+hv[0]*cw,gy+hv[1]*ch,cw-1,ch-1);tooltip(ctx,s.mx,s.my,['count: '+hv[2]]);}cap(ctx,'vegaEmbed("#vis", spec)');},
 code:`vegaEmbed('#vis',{data:{values:rows},mark:'rect',
  encoding:{x:{bin:{maxbins:22},field:'x'},y:{bin:{maxbins:16},field:'y'},color:{aggregate:'count'}}});`});
ex({t:'Linked brushing: scatter → histogram',d:'An interval selection on the scatterplot filters a linked histogram, the signature Vega-Lite interaction (params + filter transform).',hint:'Drag a rectangle on the scatterplot · double-click to clear.',int:1,
 init(s){const r=rng(17);s.P=[];for(let i=0;i<320;i++){const g=r()<.5,x=g?2+gauss(r)*.8:5.5+gauss(r)*1,y=x*.7+gauss(r)*.9+(g?0:1.5);s.P.push([clamp(x,0,9.9),clamp(y,0,9.9),g]);}s.b=null;s.onDown=(x,y)=>{if(x<420)s.b=[x,y,x,y];};s.onMove=(x,y)=>{if(s.down&&s.b){s.b[2]=clamp(x,40,410);s.b[3]=clamp(y,20,400);}};s.onDbl=()=>{s.b=null;};},
 draw(ctx,s,t){bg(ctx);const X=v=>40+v*37,Y=v=>400-v*38;ctx.strokeStyle=C.line;ctx.strokeRect(40,20,370,380);for(let i=0;i<=10;i+=2){text(ctx,String(i),X(i),416,C.mut,10.5,'center');text(ctx,String(i),34,Y(i)+4,C.mut,10.5,'right');}
  const B=s.b&&Math.abs(s.b[2]-s.b[0])>3?[Math.min(s.b[0],s.b[2]),Math.min(s.b[1],s.b[3]),Math.max(s.b[0],s.b[2]),Math.max(s.b[1],s.b[3])]:null,sel=p=>!B||(X(p[0])>=B[0]&&X(p[0])<=B[2]&&Y(p[1])>=B[1]&&Y(p[1])<=B[3]);
  if(B){ctx.fillStyle='rgba(79,70,229,.08)';ctx.fillRect(B[0],B[1],B[2]-B[0],B[3]-B[1]);ctx.strokeStyle=C.indigo;ctx.setLineDash([5,4]);ctx.strokeRect(B[0],B[1],B[2]-B[0],B[3]-B[1]);ctx.setLineDash([]);}
  let n=0;s.P.forEach(p=>{const on=sel(p);if(on)n++;circle(ctx,X(p[0]),Y(p[1]),3.5,on?(p[2]?C.indigo:C.rose):'#e7e5e4');});
  const hx=450,hw=250,bins=new Array(10).fill(0),all=new Array(10).fill(0);s.P.forEach(p=>{const b=Math.min(9,Math.floor(p[1]));all[b]++;if(sel(p))bins[b]++;});const m=Math.max(...all);text(ctx,'count of y (selected)',hx,32,C.ink2,12.5,'left',FONT,600);
  all.forEach((v,i)=>{const y=50+i*35,w=v/m*hw;ctx.fillStyle='#f1efea';rr(ctx,hx,y,w,26,4);ctx.fill();const w2=bins[i]/m*hw;ctx.fillStyle=C.indigo;rr(ctx,hx,y,w2,26,4);ctx.fill();text(ctx,i+'–'+(i+1),hx-6,y+17,C.mut,10.5,'right');text(ctx,String(bins[i]),hx+Math.max(w,w2)+5,y+17,C.mut,11,'left',MONO);});
  text(ctx,n+' of '+s.P.length+' selected',hx,428,C.indigo,13,'left',FONT,600);},
 code:`{"hconcat":[
  {"params":[{"name":"brush","select":"interval"}],"mark":"point",
   "encoding":{"x":{"field":"x","type":"quantitative"},"y":{"field":"y","type":"quantitative"},
     "color":{"condition":{"param":"brush","field":"group"},"value":"lightgray"}}},
  {"transform":[{"filter":{"param":"brush"}}],"mark":"bar",
   "encoding":{"y":{"bin":true,"field":"y"},"x":{"aggregate":"count"}}}]}`});

lib('obsplot','Observable Plot','charts','Concise exploratory charts: layered marks, automatic scales, facets and tips in a line or two.',{ik:'Observable Plot'});
ex({t:'Ridgeline of monthly distributions',d:'Overlapping density areas faceted by month (fy), drifting over time, as Plot.areaY with fy does.',
 draw(ctx,s,t){bg(ctx);const rows=7,x0=90,x1=W-30,lbl=['Jan','Feb','Mar','Apr','May','Jun','Jul'];
  for(let r=0;r<rows;r++){const y=70+r*48,mu=.22+r*.09+.04*Math.sin(t*.8+r),s2=.07+.03*Math.sin(t*.5+r*2),mu2=mu+.22,pts=[];for(let i=0;i<=120;i++){const u=i/120,v=Math.exp(-Math.pow((u-mu)/s2,2)/2)+.55*Math.exp(-Math.pow((u-mu2)/(s2*1.4),2)/2);pts.push([x0+u*(x1-x0),y-v*56]);}
   ctx.beginPath();ctx.moveTo(x0,y);pts.forEach(p=>ctx.lineTo(p[0],p[1]));ctx.lineTo(x1,y);ctx.closePath();ctx.fillStyle=hsl(250-r*16,70,72+r*1.5,.92);ctx.fill();ctx.strokeStyle=hsl(250-r*16,70,40);ctx.lineWidth=1.6;ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.stroke();text(ctx,lbl[r],x0-12,y,C.ink2,13,'right');}
  line(ctx,x0,H-48,x1,H-48,C.line,1);for(let i=0;i<=5;i++){const x=x0+i*(x1-x0)/5;text(ctx,String(i*20),x,H-30,C.mut,11.5,'center');}cap(ctx,'Plot.areaY(data,{x:"value", y:"density", fy:"month"}).plot({fy:{padding:-1.5}})');},
 code:`Plot.plot({height:420,fy:{padding:-1.5},
  marks:[Plot.areaY(data,{x:'temp',y:'density',fy:'month',fill:'month',curve:'basis'}),
         Plot.lineY(data,{x:'temp',y:'density',fy:'month',strokeWidth:1.5})]});`});
ex({t:'Faceted small multiples with regression & tips',d:'Three facets of the same dot chart (one per species) with linear regression bands and a pointer tip on the nearest dot.',hint:'Hover a panel.',int:1,
 init(s){const r=rng(3);s.F=[['Adelie',190,3700,C.orange],['Chinstrap',196,3730,C.violet],['Gentoo',217,5080,C.teal]].map(([n,fm,mm,c])=>{const pts=Array.from({length:60},()=>{const f=fm+gauss(r)*6.5;return[f,mm+(f-fm)*32+gauss(r)*280];});const mx=pts.reduce((a,p)=>a+p[0],0)/60,my=pts.reduce((a,p)=>a+p[1],0)/60;let sxy=0,sxx=0;pts.forEach(p=>{sxy+=(p[0]-mx)*(p[1]-my);sxx+=(p[0]-mx)**2;});const m=sxy/sxx;return{n,c,pts,m,b:my-m*mx};});},
 draw(ctx,s,t){bg(ctx);const pw=(W-60)/3,X=(i,v)=>40+i*(pw+8)+(v-170)/(235-170)*pw,Y=v=>H-50-(v-2600)/(6400-2600)*(H-100);let best=null;
  s.F.forEach((F,i)=>{const px=40+i*(pw+8);ctx.fillStyle='#faf9f6';ctx.fillRect(px,50,pw,H-100);text(ctx,F.n,px+pw/2,40,C.ink,14,'center',FONT,600);for(let g=0;g<=4;g++){line(ctx,px,50+g*(H-100)/4,px+pw,50+g*(H-100)/4,'#ffffff',1.5);}
   ctx.fillStyle=rgba(F.c,.12);ctx.beginPath();ctx.moveTo(X(i,175),Y(F.m*175+F.b-260));ctx.lineTo(X(i,230),Y(F.m*230+F.b-260));ctx.lineTo(X(i,230),Y(F.m*230+F.b+260));ctx.lineTo(X(i,175),Y(F.m*175+F.b+260));ctx.fill();line(ctx,X(i,175),Y(F.m*175+F.b),X(i,230),Y(F.m*230+F.b),F.c,2.5);
   F.pts.forEach(p=>{const x=X(i,p[0]),y=Y(p[1]);circle(ctx,x,y,3.4,'#fff',F.c,1.6);if(s.hover){const d=Math.hypot(s.mx-x,s.my-y);if(d<20&&(!best||d<best[0]))best=[d,x,y,F,p];}});text(ctx,'flipper (mm)',px+pw/2,H-22,C.mut,11,'center');});
  for(let g=0;g<=4;g++)text(ctx,String(2600+g*950),34,H-50-g*(H-100)/4+4,C.mut,10.5,'right');if(best){circle(ctx,best[1],best[2],7,null,C.ink,2);tooltip(ctx,best[1],best[2],[best[3].n,'flipper '+best[4][0].toFixed(0)+' mm','mass '+best[4][1].toFixed(0)+' g']);}},
 code:`Plot.plot({grid:true,facet:{data:penguins,x:'species'},
  marks:[Plot.dot(penguins,{x:'flipper_length',y:'body_mass',stroke:'species',tip:true}),
         Plot.linearRegressionY(penguins,{x:'flipper_length',y:'body_mass',stroke:'species'})]});`});

lib('uplot','uPlot','charts','A tiny (~50 KB), extremely fast time-series chart that handles hundreds of thousands of points.',{ik:'uPlot'});
ex({t:'200,000 points with drag-to-zoom',d:'A long random-walk series decimated to min/max per pixel column (the trick behind uPlot’s speed). Drag to zoom into any range.',hint:'Drag horizontally to zoom · double-click to reset.',int:1,
 init(s){const N=200000,r=rng(77);s.N=N;s.y=new Float32Array(N);let v=0;for(let i=0;i<N;i++){v+=gauss(r)*.6+Math.sin(i/9000)*.04;s.y[i]=v+Math.sin(i/300)*4;}s.a=0;s.b=N;s.sel=null;s.dec=null;s.key='';
  s.onDown=x=>{if(x>50)s.sel=[x,x];};s.onMove=x=>{if(s.sel&&s.down)s.sel[1]=clamp(x,50,W-14);};s.onUp=()=>{if(s.sel&&Math.abs(s.sel[1]-s.sel[0])>4){const A=Math.min(...s.sel),B=Math.max(...s.sel),span=s.b-s.a;const na=Math.floor(s.a+(A-50)/(W-64)*span),nb=Math.floor(s.a+(B-50)/(W-64)*span);if(nb-na>50){s.a=na;s.b=nb;}}s.sel=null;};s.onDbl=()=>{s.a=0;s.b=s.N;};},
 draw(ctx,s,t){bg(ctx);const x0=50,x1=W-14,y0=H-44,y1=20,cols=x1-x0,k=s.a+':'+s.b;if(s.key!==k){s.key=k;const mn=new Float32Array(cols),mx=new Float32Array(cols);let gmin=1e9,gmax=-1e9;const span=s.b-s.a;for(let c=0;c<cols;c++){const i0=s.a+Math.floor(c*span/cols),i1=Math.max(i0+1,s.a+Math.floor((c+1)*span/cols));let a=1e9,b=-1e9;for(let i=i0;i<i1;i++){const v=s.y[i];if(v<a)a=v;if(v>b)b=v;}mn[c]=a;mx[c]=b;if(a<gmin)gmin=a;if(b>gmax)gmax=b;}s.dec={mn,mx,gmin,gmax};}
  const D=s.dec,Y=v=>y0-(v-D.gmin)/(D.gmax-D.gmin||1)*(y0-y1);for(let g=0;g<=4;g++){const v=D.gmin+(D.gmax-D.gmin)*g/4;line(ctx,x0,Y(v),x1,Y(v),'#f1efea',1);text(ctx,v.toFixed(0),x0-6,Y(v)+4,C.mut,10.5,'right');}
  ctx.strokeStyle='#0d9488';ctx.lineWidth=1;ctx.beginPath();for(let c=0;c<cols;c++){ctx.moveTo(x0+c+.5,Y(D.mn[c]));ctx.lineTo(x0+c+.5,Y(D.mx[c])+.5);}ctx.stroke();
  for(let g=0;g<=5;g++){const i=Math.floor(s.a+(s.b-s.a)*g/5);text(ctx,i.toLocaleString(),x0+g*cols/5,y0+16,C.mut,10.5,'center');}
  if(s.sel){const A=Math.min(...s.sel),B=Math.max(...s.sel);ctx.fillStyle='rgba(13,148,136,.12)';ctx.fillRect(A,y1,B-A,y0-y1);}
  if(s.hover&&s.mx>x0&&s.mx<x1&&!s.sel){const c=Math.floor(s.mx-x0),i=Math.floor(s.a+c*(s.b-s.a)/cols);line(ctx,s.mx,y1,s.mx,y0,'rgba(28,25,23,.35)',1,[3,3]);circle(ctx,s.mx,Y(s.y[i]),4,'#0d9488','#fff',1.5);
   ctx.fillStyle='rgba(255,255,255,.92)';rr(ctx,W-250,24,232,24,6);ctx.fill();text(ctx,'x '+i.toLocaleString()+'   y '+s.y[i].toFixed(2),W-240,41,C.ink,12,'left',MONO);}
  badge(ctx,(s.b-s.a).toLocaleString()+' points in view',x0+8,y1+6,'#ccfbf1','#0f766e');},
 code:`const u=new uPlot({width:720,height:400,
  series:[{},{label:'Signal',stroke:'#0d9488',width:1}],
  cursor:{drag:{x:true,y:false}},scales:{x:{time:false}}},[xs,ys],el);   // 200k points
// double-click resets zoom; u.setScale('x',{min,max}) zooms programmatically`});
ex({t:'Live streaming sensors (60 fps)',d:'Three channels stream in at 60 samples per second into a rolling 10-second window with a live legend.',
 init(s){s.buf=[[],[],[]];s.ph=[0,0,0];},
 draw(ctx,s,t,dt){bg(ctx);const cols=['#4f46e5','#e11d48','#d97706'],names=['Temp °C','Humidity %','CO₂ ppm/10'];const v=[22+Math.sin(t*.7)*3+gauss(Math.random)*.3,55+Math.sin(t*.31+1)*10+gauss(Math.random)*.6,42+Math.sin(t*1.7)*6+(Math.random()<.01?14:0)+gauss(Math.random)*.5];
  s.buf.forEach((b,i)=>{b.push([t,v[i]]);while(b.length&&b[0][0]<t-10)b.shift();});const x0=50,x1=W-14,y0=H-40,y1=60,X=tt=>x1-(t-tt)/10*(x1-x0),Y=val=>y0-(val-10)/60*(y0-y1);
  for(let g=0;g<=6;g++){const val=10+g*10;line(ctx,x0,Y(val),x1,Y(val),'#f1efea',1);text(ctx,String(val),x0-6,Y(val)+4,C.mut,10.5,'right');}for(let k=0;k<=10;k+=2)text(ctx,'-'+(10-k)+'s',x0+k/10*(x1-x0),y0+16,C.mut,10.5,'center');
  s.buf.forEach((b,i)=>{ctx.strokeStyle=cols[i];ctx.lineWidth=1.8;ctx.beginPath();b.forEach((p,k)=>k?ctx.lineTo(X(p[0]),Y(p[1])):ctx.moveTo(X(p[0]),Y(p[1])));ctx.stroke();const L=b[b.length-1];circle(ctx,X(L[0]),Y(L[1]),3.5,cols[i]);});
  names.forEach((n,i)=>{const x=50+i*200;ctx.fillStyle=cols[i];ctx.fillRect(x,24,14,3);text(ctx,n,x+20,30,C.ink2,12.5);text(ctx,v[i].toFixed(1),x+120,30,C.ink,13,'left',MONO,600);});},
 code:`const u=new uPlot(opts,[xs,temp,hum,co2],el);
setInterval(()=>{xs.push(now());temp.push(read());if(xs.length>600){xs.shift();temp.shift();}
  u.setData([xs,temp,hum,co2]);},1000/60);`});

lib('apex','ApexCharts','charts','Modern interactive SVG charts with polished defaults: radial bars, candlesticks, heatmaps and brush charts.',{isNew:true});
ex({t:'Radial bar: concentric progress rings',d:'Four rings with rounded caps and a gradient track, animating in; hover a ring to show its value in the centre.',hint:'Hover a ring.',int:1,
 draw(ctx,s,t){bg(ctx);const cx=W/2-90,cy=H/2,D=[['Apples',76,'#4f46e5'],['Oranges',62,'#0d9488'],['Bananas',89,'#f59e0b'],['Berries',44,'#e11d48']],g=easeOut(clamp(t/1.6,0,1));let hv=-1;const dd=Math.hypot(s.mx-cx,s.my-cy);
  D.forEach((d,i)=>{const r=160-i*30;if(s.hover&&Math.abs(dd-r)<13)hv=i;ctx.lineCap='round';ctx.lineWidth=hv===i?22:18;ctx.strokeStyle='#f3f1ec';ctx.beginPath();ctx.arc(cx,cy,r,0,TAU);ctx.stroke();ctx.strokeStyle=d[2];ctx.beginPath();ctx.arc(cx,cy,r,-Math.PI/2,-Math.PI/2+TAU*d[1]/100*g);ctx.stroke();});
  const sh=hv>=0?D[hv]:['Total',Math.round(D.reduce((a,d)=>a+d[1],0)/4),C.ink];text(ctx,sh[0],cx,cy-6,C.mut,14,'center');text(ctx,Math.round(sh[1]*g)+'%',cx,cy+28,sh[2],34,'center',FONT,700);
  D.forEach((d,i)=>{const y=120+i*52;circle(ctx,W-210,y,7,d[2]);text(ctx,d[0],W-194,y+5,C.ink,15,'left',FONT,i===hv?700:500);text(ctx,d[1]+'%',W-40,y+5,C.mut,14,'right',MONO);});cap(ctx,'{chart:{type:"radialBar"}, plotOptions:{radialBar:{hollow:{size:"30%"}}}}');},
 code:`new ApexCharts(el,{chart:{type:'radialBar',height:380},series:[76,62,89,44],
  labels:['Apples','Oranges','Bananas','Berries'],
  plotOptions:{radialBar:{hollow:{size:'30%'},track:{background:'#f3f1ec'},dataLabels:{total:{show:true}}}},
  stroke:{lineCap:'round'}}).render();`});
ex({t:'Candlestick with volume & crosshair',d:'OHLC candles over volume bars with a crosshair, price label on the axis and an OHLC tooltip.',hint:'Hover the candles.',int:1,
 init(s){const r=rng(99);let p=100;s.c=Array.from({length:60},()=>{const o=p,c=o+gauss(r)*2.2,h=Math.max(o,c)+r()*1.8,l=Math.min(o,c)-r()*1.8;p=c;return{o,c,h,l,v:20+r()*80};});},
 draw(ctx,s,t){bg(ctx);const x0=20,x1=W-60,y0=300,y1=20,n=s.c.length,cw=(x1-x0)/n,mn=Math.min(...s.c.map(c=>c.l)),mx=Math.max(...s.c.map(c=>c.h)),Y=v=>y0-(v-mn)/(mx-mn)*(y0-y1),rv=clamp(t/1.5,0,1)*n;
  for(let g=0;g<=4;g++){const v=mn+(mx-mn)*g/4;line(ctx,x0,Y(v),x1,Y(v),'#f1efea',1);text(ctx,v.toFixed(1),x1+6,Y(v)+4,C.mut,10.5);}
  s.c.forEach((c,i)=>{if(i>rv)return;const x=x0+i*cw+cw/2,up=c.c>=c.o,col=up?'#10b981':'#ef4444';line(ctx,x,Y(c.h),x,Y(c.l),col,1.3);ctx.fillStyle=col;ctx.fillRect(x-cw*.32,Y(Math.max(c.o,c.c)),cw*.64,Math.max(1,Math.abs(Y(c.o)-Y(c.c))));ctx.fillStyle=rgba(col,.3);const vh=c.v/100*90;ctx.fillRect(x-cw*.32,H-24-vh,cw*.64,vh);});
  if(s.hover&&s.mx>x0&&s.mx<x1){const i=clamp(Math.floor((s.mx-x0)/cw),0,n-1),c=s.c[i],x=x0+i*cw+cw/2;line(ctx,x,y1,x,H-24,'rgba(28,25,23,.35)',1,[4,4]);if(s.my<y0){line(ctx,x0,s.my,x1,s.my,'rgba(28,25,23,.35)',1,[4,4]);const v=mn+(y0-s.my)/(y0-y1)*(mx-mn);ctx.fillStyle=C.ink;rr(ctx,x1+2,s.my-10,52,20,4);ctx.fill();text(ctx,v.toFixed(1),x1+28,s.my+4,'#fff',11,'center',MONO);}
   tooltip(ctx,x,Y(c.h),['Day '+(i+1),'O '+c.o.toFixed(2)+'  H '+c.h.toFixed(2),'L '+c.l.toFixed(2)+'  C '+c.c.toFixed(2)]);}},
 code:`new ApexCharts(el,{chart:{type:'candlestick',height:350},
  series:[{data:days.map(d=>({x:d.date,y:[d.open,d.high,d.low,d.close]}))}],
  xaxis:{type:'datetime'},tooltip:{shared:true}}).render();`});
