/* ===================== Drawing & Vector ===================== */
function rough(ctx,seed,rgh){const R=rng(seed),k=rgh===undefined?1:rgh,j=a=>(R()-.5)*a*2*k;
 const fillP=(pathFn,x,y,w,h,col,style,gap)=>{ctx.save();pathFn();ctx.clip();ctx.strokeStyle=col;ctx.fillStyle=col;ctx.lineWidth=1.5;gap=gap||8;
  if(style==='solid'){ctx.globalAlpha=.85;ctx.fillRect(x-5,y-5,w+10,h+10);}
  else if(style==='dots'){for(let a=x;a<x+w;a+=gap)for(let b=y;b<y+h;b+=gap){ctx.beginPath();ctx.arc(a+j(1.5),b+j(1.5),1.6,0,TAU);ctx.fill();}}
  else{const ang=style==='zigzag'?.0:-.8,lines=(an,dash)=>{const c=Math.cos(an),s=Math.sin(an),L=w+h;for(let k2=-L;k2<L;k2+=gap){const cx=x+w/2+c*k2,cy=y+h/2+s*k2;ctx.beginPath();if(dash)ctx.setLineDash([6,5]);ctx.moveTo(cx-s*L+j(2),cy+c*L+j(2));ctx.lineTo(cx+s*L+j(2),cy-c*L+j(2));ctx.stroke();ctx.setLineDash([]);}};
   if(style==='zigzag'){for(let a=x-10;a<x+w+10;a+=gap){ctx.beginPath();for(let b=y-10,i=0;b<y+h+10;b+=gap,i++)ctx.lineTo(a+(i%2?gap:0)+j(1),b+j(1));ctx.stroke();}}
   else{lines(ang,style==='dashed');if(style==='cross-hatch')lines(ang+Math.PI/2);}}ctx.restore();};
 const o={line(x1,y1,x2,y2,col,lw){ctx.strokeStyle=col;ctx.lineWidth=lw||2.2;ctx.lineCap='round';for(let p=0;p<2;p++){ctx.beginPath();ctx.moveTo(x1+j(2),y1+j(2));ctx.quadraticCurveTo((x1+x2)/2+j(4),(y1+y2)/2+j(4),x2+j(2),y2+j(2));ctx.stroke();}},
  circ(x,y,r,col,fill,style,gap){if(fill)fillP(()=>{ctx.beginPath();ctx.arc(x,y,r,0,TAU);},x-r,y-r,2*r,2*r,fill,style||'hachure',gap);ctx.strokeStyle=col;ctx.lineWidth=2.2;for(let p=0;p<2;p++){ctx.beginPath();const n=24,of=R()*TAU;for(let i=0;i<=n+2;i++){const a=of+i/n*TAU,rd=r+j(2.4),px=x+Math.cos(a)*rd,py=y+Math.sin(a)*rd;i?ctx.lineTo(px,py):ctx.moveTo(px,py);}ctx.stroke();}},
  ell(x,y,rx,ry,col,fill,style){if(fill)fillP(()=>{ctx.beginPath();ctx.ellipse(x,y,Math.abs(rx),Math.abs(ry),0,0,TAU);},x-rx,y-ry,2*rx,2*ry,fill,style||'hachure');ctx.strokeStyle=col;ctx.lineWidth=2.2;for(let p=0;p<2;p++){ctx.beginPath();const n=24,of=R()*TAU;for(let i=0;i<=n+2;i++){const a=of+i/n*TAU,px=x+Math.cos(a)*(rx+j(2.4)),py=y+Math.sin(a)*(ry+j(2.4));i?ctx.lineTo(px,py):ctx.moveTo(px,py);}ctx.stroke();}},
  rect(x,y,w,h,col,fill,style,gap){if(fill)fillP(()=>{ctx.beginPath();ctx.rect(x,y,w,h);},x,y,w,h,fill,style||'hachure',gap);this.line(x,y,x+w,y,col);this.line(x+w,y,x+w,y+h,col);this.line(x+w,y+h,x,y+h,col);this.line(x,y+h,x,y,col);},
  arrow(x1,y1,x2,y2,col){this.line(x1,y1,x2,y2,col);const a=Math.atan2(y2-y1,x2-x1);this.line(x2,y2,x2-14*Math.cos(a-.5),y2-14*Math.sin(a-.5),col);this.line(x2,y2,x2-14*Math.cos(a+.5),y2-14*Math.sin(a+.5),col);}};return o;}
const HAND='"Comic Sans MS","Segoe Print","Bradley Hand","Chalkboard SE",cursive';

lib('p5','p5.js','draw','Creative coding for artists and educators: a setup/draw loop, shapes, noise, vectors, input, pixels and sound.',{ik:'p5.js'});
ex({t:'Spirograph shaped by the pointer',d:'A hypotrochoid with 2,600 vertices; the pointer sets the gear ratio and pen offset, and the hue rotates with frameCount.',hint:'Move the pointer to change the gears.',
 draw(ctx,s,t){bg(ctx,'#fffdf9');const R=130+(s.hover?(s.mx-W/2)/12:Math.sin(t*.3)*18),r=R*(.27+(s.hover?s.my/H*.3:.15+.08*Math.sin(t*.2))),d=r*1.5,k=(R-r)/r,N=2600,cx=W/2,cy=H/2,rt=t*.15;ctx.lineWidth=1.5;
  for(let g=0;g<26;g++){ctx.beginPath();for(let i=g*100;i<=Math.min(N,(g+1)*100);i++){const th=i/N*TAU*9,x=(R-r)*Math.cos(th)+d*Math.cos(k*th),y=(R-r)*Math.sin(th)-d*Math.sin(k*th),X=cx+x*Math.cos(rt)-y*Math.sin(rt),Y=cy+x*Math.sin(rt)+y*Math.cos(rt);i===g*100?ctx.moveTo(X,Y):ctx.lineTo(X,Y);}ctx.strokeStyle=hsl((g*14+t*20)%360,70,50,.8);ctx.stroke();}
  cap(ctx,'x = (R−r)·cos θ + d·cos(((R−r)/r)·θ)');},
 code:`function setup(){createCanvas(720,440);colorMode(HSB);noFill();}
function draw(){background(40,3,100);const R=130+(mouseX-width/2)/12,r=R*(.27+mouseY/height*.3),d=r*1.5;
  beginShape();for(let th=0;th<TWO_PI*9;th+=.02)vertex(width/2+(R-r)*cos(th)+d*cos((R-r)/r*th),height/2+(R-r)*sin(th)-d*sin((R-r)/r*th));endShape();}`});
ex({t:'Perlin flow field with 2,500 particles',d:'Particles follow angles from a noise field and leave soft trails that slowly fade. Click to reseed the field and palette.',hint:'Click to reseed.',int:1,
 controls:[{type:'range',k:'sc',l:'Noise scale',min:.002,max:.012,step:.0005,v:.005},{type:'select',k:'pal',l:'Palette',v:'Ink',opts:['Ink','Ocean','Sunset','Forest']}],
 init(s){s.seed=Math.random()*100;s.reset=()=>{s.P=Array.from({length:2500},()=>({x:Math.random()*W,y:Math.random()*H,c:Math.floor(Math.random()*4)}));bg(s.ctx,'#fffdf9');};s.reset();s.onDown=()=>{s.seed=Math.random()*100;s.reset();};},onCtl(s){s.reset();},
 draw(ctx,s,t,dt){ctx.fillStyle='rgba(255,253,249,.035)';ctx.fillRect(0,0,W,H);const pals={Ink:['#1c1917','#4f46e5','#78716c','#e11d48'],Ocean:['#0c4a6e','#0284c7','#0d9488','#67e8f9'],Sunset:['#9d174d','#ea580c','#f59e0b','#7c3aed'],Forest:['#14532d','#15803d','#65a30d','#a16207']}[s.p.pal];
  ctx.lineWidth=1;for(const p of s.P){const a=fbm(p.x*s.p.sc+s.seed,p.y*s.p.sc+t*.05)*TAU*2.2,nx=p.x+Math.cos(a)*1.4,ny=p.y+Math.sin(a)*1.4;ctx.strokeStyle=rgba(pals[p.c],.25);ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(nx,ny);ctx.stroke();p.x=nx;p.y=ny;if(p.x<0||p.x>W||p.y<0||p.y>H||Math.random()<.002){p.x=Math.random()*W;p.y=Math.random()*H;}}},
 code:`function draw(){background(255,9);           // translucent: trails fade
  for(const p of particles){const a=noise(p.x*.005,p.y*.005,frameCount*.002)*TWO_PI*2;
    const v=p5.Vector.fromAngle(a,1.4);line(p.x,p.y,p.x+v.x,p.y+v.y);p.add(v);}}`});
ex({t:'Recursive tree in the wind',d:'A fractal tree drawn with push()/rotate()/pop(). The pointer sets the branch angle; leaves sway in a noise-driven wind.',hint:'Move the pointer left/right to change the branch angle.',
 draw(ctx,s,t){vgrad(ctx,'#f0f9ff','#fffbeb');ctx.fillStyle='#e7e5e4';ctx.fillRect(0,H-36,W,36);const ang=s.hover?(s.mx/W)*1.1+.15:.48+.12*Math.sin(t*.4);ctx.lineCap='round';
  const br=(x,y,len,a,d)=>{const w=Math.sin(t*1.3+d*.7)*.04*d+fbm(t*.3,d)*.03,x2=x+Math.sin(a+w)*len,y2=y-Math.cos(a+w)*len;ctx.strokeStyle=d<3?'#57534e':hsl(30-d*4,25,35+d*4);ctx.lineWidth=Math.max(1,10-d*1.3);ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x2,y2);ctx.stroke();
   if(d>=9){circle(ctx,x2,y2,4,hsl(120+((x2*7)%60)-30,55,48,.75));return;}br(x2,y2,len*.74,a-ang,d+1);br(x2,y2,len*.74,a+ang*.85,d+1);};br(W/2,H-36,96,0,0);cap(ctx,'push(); rotate(angle); branch(len*.74); pop();');},
 code:`function branch(len,depth){line(0,0,0,-len);translate(0,-len);
  if(depth>9){circle(0,0,8);return;}
  push();rotate(angle);branch(len*.74,depth+1);pop();
  push();rotate(-angle*.85);branch(len*.74,depth+1);pop();}
function draw(){background(250);translate(width/2,height-36);angle=map(mouseX,0,width,.15,1.25);branch(96,0);}`});
ex({t:'Kaleidoscope paint (8-fold symmetry)',d:'Draw with the pointer and every stroke is mirrored eight times around the centre, with hue cycling as you draw.',hint:'Drag to paint · use the buttons to clear or change symmetry.',int:1,
 controls:[{type:'range',k:'n',l:'Symmetry',min:2,max:16,v:8},{type:'range',k:'w',l:'Brush',min:1,max:12,v:3},{type:'btn',l:'Clear',fn:s=>s.clear()}],
 init(s){s.clear=()=>{bg(s.ctx,'#fffdf9');for(let r=40;r<260;r+=40)circle(s.ctx,W/2,H/2,r,null,'#f3f0ea',1);};s.clear();s.last=null;s.h=0;s.onUp=()=>{s.last=null;};},
 draw(ctx,s,t){let p;if(t<7&&!s.down){p=[Math.sin(t*2.3)*150*Math.cos(t*.7),Math.cos(t*3.1)*120];}else{if(!s.down||!s.hover){s.last=null;return;}p=[s.mx-W/2,s.my-H/2];}if(s.last){s.h=(s.h+1.5)%360;const n=s.p.n;ctx.lineCap='round';ctx.lineWidth=s.p.w;ctx.strokeStyle=hsl(s.h,70,50,.8);
  for(let i=0;i<n;i++){const a=i/n*TAU;for(const m of[1,-1]){const tr=q=>{const x=q[0],y=q[1]*m;return[W/2+x*Math.cos(a)-y*Math.sin(a),H/2+x*Math.sin(a)+y*Math.cos(a)];},A=tr(s.last),B=tr(p);ctx.beginPath();ctx.moveTo(A[0],A[1]);ctx.lineTo(B[0],B[1]);ctx.stroke();}}}s.last=p;},
 code:`function draw(){if(!mouseIsPressed)return;translate(width/2,height/2);
  const [x,y,px,py]=[mouseX-width/2,mouseY-height/2,pmouseX-width/2,pmouseY-height/2];
  for(let i=0;i<8;i++){rotate(TWO_PI/8);line(x,y,px,py);push();scale(1,-1);line(x,y,px,py);pop();}}`});

lib('paper','Paper.js','draw','A vector-graphics scripting framework: Bézier paths, boolean operations, hit-testing and smoothing on canvas.',{ik:'Paper.js'});
ex({t:'Bézier blob with live segment handles',d:'A smooth closed path with ten segments; their handles are shown, and the pointer pushes the segment points away.',hint:'Hover near the blob to push it.',
 draw(ctx,s,t){bg(ctx,'#fffdf9');const cx=W/2,cy=H/2,n=10,pts=[];for(let i=0;i<n;i++){const a=i/n*TAU,r=125*(1+.2*Math.sin(t*1.2+i*1.7)+.1*Math.sin(t*2.1+i*3.1));let x=cx+Math.cos(a)*r,y=cy+Math.sin(a)*r;if(s.hover){const dx=x-s.mx,dy=y-s.my,d=Math.hypot(dx,dy);if(d<110&&d>1){const f=(110-d)*.55;x+=dx/d*f;y+=dy/d*f;}}pts.push([x,y]);}
  smoothClosed(ctx,pts);const g=ctx.createLinearGradient(cx-120,cy-120,cx+120,cy+120);g.addColorStop(0,'#a5b4fc');g.addColorStop(1,'#5eead4');ctx.fillStyle=g;ctx.fill();ctx.strokeStyle='#1c1917';ctx.lineWidth=2.5;ctx.stroke();
  for(let i=0;i<n;i++){const p0=pts[(i-1+n)%n],p1=pts[i],p2=pts[(i+1)%n],hx=(p2[0]-p0[0])/6,hy=(p2[1]-p0[1])/6;line(ctx,p1[0]-hx,p1[1]-hy,p1[0]+hx,p1[1]+hy,'#4f46e5',1.4);circle(ctx,p1[0]+hx,p1[1]+hy,3.5,'#fff','#4f46e5',1.5);circle(ctx,p1[0]-hx,p1[1]-hy,3.5,'#fff','#4f46e5',1.5);ctx.fillStyle='#fff';ctx.fillRect(p1[0]-4.5,p1[1]-4.5,9,9);ctx.strokeStyle='#1c1917';ctx.lineWidth=1.5;ctx.strokeRect(p1[0]-4.5,p1[1]-4.5,9,9);}
  cap(ctx,'path.smooth({type:"catmull-rom"}); path.segments[i].handleIn');},
 code:`const path=new paper.Path({closed:true,fillColor:'#a5b4fc',strokeColor:'#1c1917'});
for(let i=0;i<10;i++)path.add(center.add(new paper.Point({length:125,angle:i*36})));
path.smooth({type:'catmull-rom'});path.fullySelected=true;
paper.view.onMouseMove=e=>path.segments.forEach(s=>{const d=s.point.subtract(e.point);if(d.length<110)s.point=s.point.add(d.normalize(110-d.length));});`});
ex({t:'Boolean operations: unite, intersect, subtract, exclude',d:'Two editable shapes combined with Paper’s path boolean operations. Drag either shape and switch the operation.',hint:'Drag the shapes · pick an operation.',int:1,
 controls:[{type:'seg',k:'op',v:'unite',opts:['unite','intersect','subtract','exclude']}],
 init(s){s.A={x:300,y:220};s.B={x:420,y:220};s.dg=null;s.off=document.createElement('canvas');s.off.width=W*2;s.off.height=H*2;s.onDown=(x,y)=>{if(Math.hypot(x-s.B.x,y-s.B.y)<100)s.dg=s.B;else if(Math.abs(x-s.A.x)<100&&Math.abs(y-s.A.y)<90)s.dg=s.A;if(s.dg)s.dd=[x-s.dg.x,y-s.dg.y];};s.onMove=(x,y)=>{if(s.dg&&s.down){s.dg.x=x-s.dd[0];s.dg.y=y-s.dd[1];}};s.onUp=()=>{s.dg=null;};},
 draw(ctx,s,t){paper(ctx,'#fffdf9');const o=s.off.getContext('2d');o.setTransform(2,0,0,2,0,0);o.clearRect(0,0,W,H);const pa=c=>{c.beginPath();rr(c,s.A.x-100,s.A.y-80,200,160,26);},pb=c=>{c.beginPath();c.arc(s.B.x,s.B.y,100,0,TAU);};const op=s.p.op;
  o.fillStyle='#4f46e5';pa(o);o.fill();o.globalCompositeOperation=op==='unite'?'source-over':op==='intersect'?'destination-in':op==='subtract'?'destination-out':'xor';pb(o);o.fill();o.globalCompositeOperation='source-over';
  ctx.save();ctx.shadowColor='rgba(79,70,229,.3)';ctx.shadowBlur=20;ctx.shadowOffsetY=8;ctx.drawImage(s.off,0,0,W,H);ctx.restore();ctx.setLineDash([6,5]);ctx.strokeStyle='rgba(28,25,23,.45)';ctx.lineWidth=1.5;pa(ctx);ctx.stroke();pb(ctx);ctx.stroke();ctx.setLineDash([]);
  text(ctx,'A',s.A.x-90,s.A.y-60,C.mut,14,'left',MONO);text(ctx,'B',s.B.x+70,s.B.y-60,C.mut,14,'left',MONO);cap(ctx,'const result = rectA.'+op+'(circleB)');},
 code:`const a=new paper.Path.Rectangle({rectangle:[200,140,200,160],radius:26});
const b=new paper.Path.Circle({center:[420,220],radius:100});
const result=a.unite(b);            // or a.intersect(b), a.subtract(b), a.exclude(b)
result.fillColor='#4f46e5';a.remove();b.remove();`});
ex({t:'Freehand → simplify → smooth',d:'Draw a stroke: the grey dots are the raw pointer samples, the blue curve is path.simplify(), which fits far fewer Bézier segments.',hint:'Draw a line with the pointer.',int:1,controls:[{type:'range',k:'tol',l:'Tolerance',min:1,max:20,step:.5,v:6}],
 init(s){s.raw=[];const r=rng(2);for(let i=0;i<=80;i++){const u=i/80;s.raw.push([80+u*560+Math.sin(u*9)*20+(r()-.5)*8,220+Math.sin(u*6)*90+(r()-.5)*8]);}s.onDown=(x,y)=>{s.raw=[[x,y]];};s.onMove=(x,y)=>{if(s.down){const l=s.raw[s.raw.length-1];if(Math.hypot(x-l[0],y-l[1])>3)s.raw.push([x,y]);}};},
 draw(ctx,s,t){paper(ctx,'#fffdf9');const rdp=(P,e)=>{if(P.length<3)return P;let dm=0,ix=0;const[a,b]=[P[0],P[P.length-1]];for(let i=1;i<P.length-1;i++){const p=P[i],d=Math.abs((b[1]-a[1])*p[0]-(b[0]-a[0])*p[1]+b[0]*a[1]-b[1]*a[0])/(Math.hypot(b[0]-a[0],b[1]-a[1])||1);if(d>dm){dm=d;ix=i;}}return dm>e?rdp(P.slice(0,ix+1),e).slice(0,-1).concat(rdp(P.slice(ix),e)):[a,b];};
  s.raw.forEach(p=>circle(ctx,p[0],p[1],2.2,'#a8a29e'));if(s.raw.length>1){const sp=rdp(s.raw,s.p.tol);ctx.strokeStyle='#4f46e5';ctx.lineWidth=3.5;smoothOpen(ctx,sp);ctx.stroke();sp.forEach(p=>{ctx.fillStyle='#fff';ctx.fillRect(p[0]-4,p[1]-4,8,8);ctx.strokeStyle='#4f46e5';ctx.lineWidth=1.5;ctx.strokeRect(p[0]-4,p[1]-4,8,8);});
   badge(ctx,s.raw.length+' raw points',16,16,'#f5f5f4',C.ink2);badge(ctx,sp.length+' segments after simplify('+s.p.tol+')',150,16,'#eef2ff',C.indigo);}},
 code:`const tool=new paper.Tool();let path;
tool.onMouseDown=e=>{path=new paper.Path({strokeColor:'#4f46e5',strokeWidth:3});};
tool.onMouseDrag=e=>path.add(e.point);
tool.onMouseUp=()=>{path.simplify(6);path.fullySelected=true;};`});

function shapeEditor(add){return{int:1,hint:add?'Click empty space to add · drag to move · drag the round handle to rotate · corner to scale.':'Drag to move · drag the round handle to rotate · drag a corner to scale.',
 init(s){s.sh=add?[{k:'star',x:360,y:220,r:70,a:0,c:45}]:[{k:'rect',x:180,y:190,r:55,a:.2,c:230},{k:'circle',x:380,y:140,r:50,a:0,c:340},{k:'star',x:540,y:260,r:62,a:0,c:40},{k:'tri',x:290,y:320,r:55,a:.3,c:160}];s.sel=s.sh[0];s.mode=null;
  const hnd=q=>[q.x+Math.sin(q.a)*(q.r+34),q.y-Math.cos(q.a)*(q.r+34)],cor=q=>[[-1,-1],[1,-1],[1,1],[-1,1]].map(([cx,cy])=>[q.x+(cx*q.r)*Math.cos(q.a)-(cy*q.r)*Math.sin(q.a),q.y+(cx*q.r)*Math.sin(q.a)+(cy*q.r)*Math.cos(q.a)]);
  s.onDown=(x,y)=>{if(s.sel){const h=hnd(s.sel);if(Math.hypot(x-h[0],y-h[1])<16){s.mode='rot';return;}if(cor(s.sel).some(c=>Math.hypot(x-c[0],y-c[1])<12)){s.mode='scale';return;}}
   for(let i=s.sh.length-1;i>=0;i--){const q=s.sh[i];if(Math.hypot(x-q.x,y-q.y)<q.r){s.sel=q;s.mode='move';s.dd=[x-q.x,y-q.y];s.sh.splice(i,1);s.sh.push(q);return;}}
   if(add){const q={k:['rect','circle','tri','star'][Math.floor(Math.random()*4)],x,y,r:34+Math.random()*30,a:(Math.random()-.5),c:Math.floor(Math.random()*360)};s.sh.push(q);s.sel=q;s.mode='move';s.dd=[0,0];}else s.sel=null;};
  s.onMove=(x,y)=>{if(!s.down||!s.sel)return;const q=s.sel;if(s.mode==='rot')q.a=Math.atan2(x-q.x,-(y-q.y));else if(s.mode==='scale')q.r=clamp(Math.hypot(x-q.x,y-q.y)/1.414,15,160);else if(s.mode==='move'){q.x=x-s.dd[0];q.y=y-s.dd[1];}};s.onUp=()=>{s.mode=null;};s.cor=cor;},
 draw(ctx,s,t){paper(ctx);for(const q of s.sh){ctx.save();ctx.translate(q.x,q.y);ctx.rotate(q.a);ctx.shadowColor='rgba(0,0,0,.12)';ctx.shadowBlur=12;ctx.shadowOffsetY=5;ctx.fillStyle=hsl(q.c,75,62);ctx.strokeStyle=hsl(q.c,60,35);ctx.lineWidth=3;ctx.beginPath();
   if(q.k=='rect')rr(ctx,-q.r*.8,-q.r*.8,q.r*1.6,q.r*1.6,12);else if(q.k=='circle')ctx.arc(0,0,q.r*.9,0,TAU);else if(q.k=='tri'){for(let i=0;i<3;i++){const a=-Math.PI/2+i*TAU/3;i?ctx.lineTo(Math.cos(a)*q.r,Math.sin(a)*q.r):ctx.moveTo(Math.cos(a)*q.r,Math.sin(a)*q.r);}ctx.closePath();}else{for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,rd=i%2?q.r*.45:q.r;i?ctx.lineTo(Math.cos(a)*rd,Math.sin(a)*rd):ctx.moveTo(Math.cos(a)*rd,Math.sin(a)*rd);}ctx.closePath();}
   ctx.fill();ctx.shadowColor='transparent';ctx.stroke();ctx.restore();}
  if(s.sel){const q=s.sel;ctx.save();ctx.translate(q.x,q.y);ctx.rotate(q.a);ctx.strokeStyle='#2563eb';ctx.lineWidth=1.5;ctx.strokeRect(-q.r,-q.r,2*q.r,2*q.r);for(const[cx,cy]of[[-1,-1],[1,-1],[1,1],[-1,1],[0,-1],[1,0],[0,1],[-1,0]]){ctx.fillStyle='#fff';ctx.fillRect(cx*q.r-5,cy*q.r-5,10,10);ctx.strokeRect(cx*q.r-5,cy*q.r-5,10,10);}
   line(ctx,0,-q.r,0,-q.r-34,'#2563eb',1.5);circle(ctx,0,-q.r-34,8,'#fff','#2563eb',2);ctx.restore();text(ctx,'x '+Math.round(q.x)+'  y '+Math.round(q.y)+'  r '+Math.round(q.r)+'  ∠ '+Math.round(q.a*57.3)+'°',W-14,H-14,C.mut,12,'right',MONO);}}};}
lib('konva','Konva.js','draw','Canvas scene graph for interactive figures: drag-and-drop, transformers, layers, events and export.',{ik:'Konva.js'});
ex(Object.assign({t:'Transformer: move, rotate, scale',d:'Select a shape to get a Konva.Transformer with corner anchors and a rotation handle.',code:`const tr=new Konva.Transformer({rotateEnabled:true,keepRatio:true});layer.add(tr);
stage.on('click',e=>tr.nodes(e.target===stage?[]:[e.target]));
shape.draggable(true);   // every shape: drag, then transform with the anchors`},shapeEditor(false)));
ex({t:'Image annotation with labelled boxes',d:'Draw bounding boxes on an image, pick a label class, and drag existing boxes, as in a labelling tool built on Konva.',hint:'Drag on empty image area to draw a box · drag a box to move it.',int:1,
 controls:[{type:'seg',k:'cls',v:'tree',opts:['tree','house','car','person']},{type:'btn',l:'Undo',fn:s=>s.B.pop()},{type:'btn',l:'Export JSON',fn:(s,b)=>{b.textContent=s.B.length+' boxes → JSON ✓';setTimeout(()=>b.textContent='Export JSON',1500);}}],
 init(s){const c=document.createElement('canvas');c.width=W;c.height=H;const x=c.getContext('2d');const g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,'#bfdbfe');g.addColorStop(.55,'#e0f2fe');g.addColorStop(.56,'#bbf7d0');g.addColorStop(1,'#86efac');x.fillStyle=g;x.fillRect(0,0,W,H);
  x.fillStyle='#fde68a';x.beginPath();x.arc(620,70,34,0,TAU);x.fill();x.fillStyle='#fca5a5';x.fillRect(330,180,140,110);x.fillStyle='#b91c1c';x.beginPath();x.moveTo(318,182);x.lineTo(400,120);x.lineTo(482,182);x.fill();x.fillStyle='#78350f';x.fillRect(388,236,26,54);
  [[120,170],[200,200],[560,190]].forEach(([tx,ty])=>{x.fillStyle='#78350f';x.fillRect(tx-6,ty+40,12,60);x.fillStyle='#15803d';x.beginPath();x.arc(tx,ty+20,42,0,TAU);x.fill();});x.fillStyle='#2563eb';x.fillRect(520,330,120,40);x.fillStyle='#1e3a8a';x.fillRect(545,312,70,24);x.fillStyle='#111';[545,615].forEach(cx=>{x.beginPath();x.arc(cx,372,13,0,TAU);x.fill();});
  x.fillStyle='#7c2d12';x.beginPath();x.arc(258,300,10,0,TAU);x.fill();x.fillStyle='#4338ca';x.fillRect(250,310,16,40);s.img=c;
  s.B=[{x:300,y:112,w:200,h:182,c:'house'},{x:510,y:300,w:140,h:88,c:'car'}];s.dr=null;s.mv=null;
  s.onDown=(x,y)=>{for(let i=s.B.length-1;i>=0;i--){const b=s.B[i];if(x>b.x&&x<b.x+b.w&&y>b.y&&y<b.y+b.h){s.mv=[b,x-b.x,y-b.y];return;}}s.dr={x,y,w:0,h:0,c:s.p.cls};};
  s.onMove=(x,y)=>{if(!s.down)return;if(s.mv){s.mv[0].x=x-s.mv[1];s.mv[0].y=y-s.mv[2];}else if(s.dr){s.dr.w=x-s.dr.x;s.dr.h=y-s.dr.y;}};
  s.onUp=()=>{if(s.dr&&Math.abs(s.dr.w)>8&&Math.abs(s.dr.h)>8){const d=s.dr;if(d.w<0){d.x+=d.w;d.w=-d.w;}if(d.h<0){d.y+=d.h;d.h=-d.h;}s.B.push(d);}s.dr=null;s.mv=null;};},
 draw(ctx,s,t){ctx.drawImage(s.img,0,0,W,H);const col={tree:'#16a34a',house:'#dc2626',car:'#2563eb',person:'#9333ea'};const all=s.dr?s.B.concat([s.dr]):s.B;
  all.forEach(b=>{const c=col[b.c];ctx.fillStyle=rgba(c,.12);ctx.fillRect(b.x,b.y,b.w,b.h);ctx.strokeStyle=c;ctx.lineWidth=2.5;ctx.setLineDash(b===s.dr?[6,4]:[]);ctx.strokeRect(b.x,b.y,b.w,b.h);ctx.setLineDash([]);ctx.font='600 12px '+FONT;const tw=ctx.measureText(b.c).width+12;ctx.fillStyle=c;ctx.fillRect(b.x,b.y-20,tw,20);text(ctx,b.c,b.x+6,b.y-6,'#fff',12,'left',FONT,600);});
  const cnt={};s.B.forEach(b=>cnt[b.c]=(cnt[b.c]||0)+1);ctx.fillStyle='rgba(255,255,255,.9)';rr(ctx,12,12,150,26+Object.keys(cnt).length*18,8);ctx.fill();text(ctx,'Annotations',22,30,C.ink,12.5,'left',FONT,600);Object.keys(cnt).forEach((k,i)=>text(ctx,'● '+k+' × '+cnt[k],22,48+i*18,col[k],12));},
 code:`stage.on('mousedown',e=>{if(e.target!==image)return;start=stage.getPointerPosition();
  box=new Konva.Rect({x:start.x,y:start.y,stroke:colors[cls],strokeWidth:2,draggable:true,name:cls});layer.add(box);});
stage.on('mousemove',()=>{if(!box)return;const p=stage.getPointerPosition();box.size({width:p.x-start.x,height:p.y-start.y});});
const json=JSON.stringify(layer.find('Rect').map(r=>({...r.getClientRect(),label:r.name()})));`});
ex({t:'Snapping with smart alignment guides',d:'Drag the cards: when an edge or centre lines up with another card, a magenta guide appears and the card snaps into place.',hint:'Drag a card near another card’s edge or centre.',int:1,
 init(s){s.R=[{x:70,y:70,w:150,h:90,c:'#4f46e5'},{x:300,y:160,w:130,h:130,c:'#0d9488'},{x:480,y:60,w:170,h:80,c:'#e11d48'},{x:500,y:270,w:120,h:110,c:'#d97706'}];s.dg=null;
  s.onDown=(x,y)=>{for(let i=s.R.length-1;i>=0;i--){const r=s.R[i];if(x>r.x&&x<r.x+r.w&&y>r.y&&y<r.y+r.h){s.dg=r;s.dd=[x-r.x,y-r.y];s.R.splice(i,1);s.R.push(r);return;}}};
  s.onMove=(x,y)=>{if(!s.dg||!s.down)return;const r=s.dg;r.x=x-s.dd[0];r.y=y-s.dd[1];s.G=[];const T=6;for(const o of s.R){if(o===r)continue;for(const[a,b]of[[r.x,o.x],[r.x,o.x+o.w],[r.x+r.w,o.x],[r.x+r.w,o.x+o.w],[r.x+r.w/2,o.x+o.w/2]])if(Math.abs(a-b)<T){r.x+=b-a;s.G.push(['v',b]);break;}
   for(const[a,b]of[[r.y,o.y],[r.y,o.y+o.h],[r.y+r.h,o.y],[r.y+r.h,o.y+o.h],[r.y+r.h/2,o.y+o.h/2]])if(Math.abs(a-b)<T){r.y+=b-a;s.G.push(['h',b]);break;}}};s.onUp=()=>{s.dg=null;s.G=[];};s.G=[];},
 draw(ctx,s,t){paper(ctx);s.R.forEach(r=>{ctx.save();ctx.shadowColor='rgba(0,0,0,.12)';ctx.shadowBlur=r===s.dg?24:10;ctx.shadowOffsetY=r===s.dg?10:4;ctx.fillStyle='#fff';rr(ctx,r.x,r.y,r.w,r.h,12);ctx.fill();ctx.restore();ctx.fillStyle=r.c;rr(ctx,r.x,r.y,r.w,8,4);ctx.fill();ctx.fillStyle=rgba(r.c,.15);rr(ctx,r.x+12,r.y+22,r.w*.5,10,5);ctx.fill();rr(ctx,r.x+12,r.y+40,r.w*.7,8,4);ctx.fill();});
  (s.G||[]).forEach(g=>{if(g[0]==='v')line(ctx,g[1],0,g[1],H,'#db2777',1.2,[4,3]);else line(ctx,0,g[1],W,g[1],'#db2777',1.2,[4,3]);});if(s.dg)text(ctx,Math.round(s.dg.x)+', '+Math.round(s.dg.y),s.dg.x,s.dg.y-8,'#db2777',11.5,'left',MONO);cap(ctx,'node.on("dragmove", snapToGuides)');},
 code:`layer.on('dragmove',e=>{const box=e.target.getClientRect();guides.destroyChildren();
  for(const stop of lineGuideStops()){if(Math.abs(stop-box.x)<6){e.target.x(e.target.x()+stop-box.x);
    guides.add(new Konva.Line({points:[stop,0,stop,stage.height()],stroke:'#db2777',dash:[4,3]}));}}});`});

lib('fabric','Fabric.js','draw','An object model on canvas for design editors: selection, transforms, text, images, filters, brushes and JSON.',{ik:'Fabric.js'});
ex(Object.assign({t:'Canva-style editor: add & transform',d:'Click empty space to add a random shape; select, move, scale and rotate with Fabric-style controls.',code:`const canvas=new fabric.Canvas('c');
canvas.on('mouse:down',e=>{if(e.target)return;const p=e.pointer;
  canvas.add(new fabric.Rect({left:p.x,top:p.y,width:80,height:80,fill:randomColor(),angle:Math.random()*30}));});`},shapeEditor(true)));
ex({t:'Image filters pipeline',d:'Stackable filters applied to a generated photo: grayscale, sepia, invert, brightness, pixelate and blur, recomputed on change.',hint:'Toggle filters and drag the sliders.',
 controls:[{type:'toggle',k:'gr',l:'Grayscale',v:false},{type:'toggle',k:'se',l:'Sepia',v:false},{type:'toggle',k:'iv',l:'Invert',v:false},{type:'range',k:'br',l:'Brightness',min:-.5,max:.5,step:.05,v:0},{type:'range',k:'px',l:'Pixelate',min:1,max:20,v:1},{type:'range',k:'bl',l:'Blur',min:0,max:8,v:0}],
 init(s){const c=document.createElement('canvas');c.width=360;c.height=220;const x=c.getContext('2d');const g=x.createLinearGradient(0,0,0,220);g.addColorStop(0,'#f97316');g.addColorStop(.5,'#fde68a');g.addColorStop(.51,'#0e7490');g.addColorStop(1,'#164e63');x.fillStyle=g;x.fillRect(0,0,360,220);x.fillStyle='#fff7ed';x.beginPath();x.arc(180,108,40,Math.PI,0);x.fill();
  x.fillStyle='#1c1917';x.beginPath();x.moveTo(0,112);for(let i=0;i<=360;i+=10)x.lineTo(i,100-Math.abs(Math.sin(i*.03))*40-Math.sin(i*.11)*10);x.lineTo(360,112);x.fill();for(let i=0;i<40;i++){x.fillStyle='rgba(255,255,255,'+(.2+Math.random()*.4)+')';x.fillRect(140+Math.random()*80,112+i*2.5,Math.random()*60,1.5);}s.src=c;s.out=document.createElement('canvas');s.out.width=360;s.out.height=220;s.dirty=true;},onCtl(s){s.dirty=true;},
 draw(ctx,s,t){if(s.dirty){s.dirty=false;const o=s.out.getContext('2d'),p=s.p;o.filter=p.bl?'blur('+p.bl+'px)':'none';o.clearRect(0,0,360,220);if(p.px>1){const tw=Math.ceil(360/p.px),th=Math.ceil(220/p.px),tm=document.createElement('canvas');tm.width=tw;tm.height=th;tm.getContext('2d').drawImage(s.src,0,0,tw,th);o.imageSmoothingEnabled=false;o.drawImage(tm,0,0,360,220);}else o.drawImage(s.src,0,0);o.filter='none';
   const im=o.getImageData(0,0,360,220),d=im.data;for(let i=0;i<d.length;i+=4){let r=d[i],g=d[i+1],b=d[i+2];if(p.gr){const l=.299*r+.587*g+.114*b;r=g=b=l;}if(p.se){const R=r*.393+g*.769+b*.189,G=r*.349+g*.686+b*.168,B=r*.272+g*.534+b*.131;r=R;g=G;b=B;}if(p.iv){r=255-r;g=255-g;b=255-b;}r+=p.br*255;g+=p.br*255;b+=p.br*255;d[i]=r;d[i+1]=g;d[i+2]=b;}o.putImageData(im,0,0);}
  paper(ctx);ctx.save();ctx.shadowColor='rgba(0,0,0,.2)';ctx.shadowBlur=24;ctx.shadowOffsetY=10;ctx.drawImage(s.out,W/2-270,H/2-170,540,330);ctx.restore();const on=['gr','se','iv'].filter(k=>s.p[k]).map(k=>({gr:'Grayscale',se:'Sepia',iv:'Invert'}[k]));if(s.p.px>1)on.push('Pixelate('+s.p.px+')');if(s.p.bl)on.push('Blur('+s.p.bl+')');if(s.p.br)on.push('Brightness('+s.p.br+')');
  cap(ctx,'img.filters = ['+(on.map(f=>'new '+f.split('(')[0]+'()').join(', ')||'')+']; img.applyFilters()');},
 code:`fabric.FabricImage.fromURL('photo.jpg').then(img=>{
  img.filters.push(new fabric.filters.Grayscale(),new fabric.filters.Pixelate({blocksize:8}),
    new fabric.filters.Brightness({brightness:.1}),new fabric.filters.Blur({blur:.2}));
  img.applyFilters();canvas.add(img);});`});
ex({t:'Free-drawing brushes',d:'Pencil, spray, circle and ribbon brushes with colour and width, drawing onto a persistent canvas like canvas.isDrawingMode.',hint:'Drag to draw · pick a brush.',int:1,
 controls:[{type:'seg',k:'b',v:'Pencil',opts:['Pencil','Spray','Circles','Ribbon']},{type:'select',k:'c',l:'Colour',v:'Indigo',opts:['Indigo','Rose','Teal','Amber','Ink']},{type:'range',k:'w',l:'Width',min:1,max:30,v:6},{type:'btn',l:'Clear',fn:s=>s.clr()}],
 init(s){s.clr=()=>paper(s.ctx);s.clr();s.last=null;s.onUp=()=>{s.last=null;};},
 draw(ctx,s,t){const auto=t<5&&!s.down;if(auto){s.mx=360+Math.sin(t*2)*250*Math.cos(t*.5);s.my=220+Math.sin(t*3.3)*120;s.ab=['Pencil','Spray','Circles','Ribbon'][Math.floor(t/1.25)%4];}if(!s.down&&!auto){s.last=null;return;}const col={Indigo:'#4f46e5',Rose:'#e11d48',Teal:'#0d9488',Amber:'#d97706',Ink:'#1c1917'}[s.p.c],w=s.p.w,p=[s.mx,s.my],L=s.last||p,b=auto?s.ab:s.p.b;
  if(b==='Pencil'){ctx.strokeStyle=col;ctx.lineWidth=w;ctx.lineCap='round';line(ctx,L[0],L[1],p[0],p[1],col,w);}
  else if(b==='Spray'){ctx.fillStyle=col;for(let i=0;i<w*4;i++){const a=Math.random()*TAU,r=Math.random()*w*2.5;ctx.fillRect(p[0]+Math.cos(a)*r,p[1]+Math.sin(a)*r,1.4,1.4);}}
  else if(b==='Circles'){circle(ctx,p[0],p[1],w*(.5+Math.random()),rgba(col,.25+Math.random()*.4));}
  else{const d=Math.hypot(p[0]-L[0],p[1]-L[1]);for(let i=0;i<5;i++){ctx.strokeStyle=rgba(col,.35);ctx.lineWidth=1;line(ctx,L[0]+i*w/2-w,L[1]-i*w/3,p[0]+i*w/2-w,p[1]-i*w/3,rgba(col,.4),1);}}s.last=p;},
 code:`canvas.isDrawingMode=true;
canvas.freeDrawingBrush=new fabric.SprayBrush(canvas);   // PencilBrush, CircleBrush, PatternBrush
canvas.freeDrawingBrush.color='#4f46e5';canvas.freeDrawingBrush.width=6;`});

lib('rough','Rough.js','draw','Hand-drawn, sketchy graphics with hachure fills for informal diagrams and charts.',{ik:'Rough.js'});
ex({t:'Sketchy water-cycle diagram',d:'Rough lines, circles, rectangles, arrows and hachure fills that redraw every few frames, so it “boils” like a pencil sketch.',
 draw(ctx,s,t){bg(ctx,'#fffdf5');const r=rough(ctx,Math.floor(t*3)+11),ink='#292524';
  r.circ(110,95,40,'#b45309','#f59e0b');for(let i=0;i<10;i++){const a=i/10*TAU;r.line(110+Math.cos(a)*54,95+Math.sin(a)*54,110+Math.cos(a)*72,95+Math.sin(a)*72,'#b45309',2.2);}
  r.circ(430,90,36,ink,'#93c5fd');r.circ(480,78,44,ink,'#93c5fd');r.circ(535,92,34,ink,'#93c5fd');for(let i=0;i<6;i++)r.line(440+i*18,150,432+i*18,185,'#2563eb',2.2);
  r.rect(30,320,660,90,ink,'#4ade80');r.rect(250,255,150,66,ink,'#a5b4fc');r.line(190,290,190,320,ink);r.circ(190,270,22,'#15803d','#22c55e');
  r.arrow(150,160,235,235,'#dc2626');r.arrow(580,200,620,300,'#2563eb');r.arrow(300,250,380,160,'#7c3aed');
  text(ctx,'sunlight',150,150,ink,22,'left',HAND);text(ctx,'rain',560,185,ink,22,'right',HAND);text(ctx,'lake',325,295,ink,22,'center',HAND);text(ctx,'evaporation',390,228,'#7c3aed',19,'left',HAND);text(ctx,'plant',190,255,ink,20,'center',HAND);cap(ctx,'rc.rectangle(x,y,w,h,{fill:"green", hachureGap:9})');},
 code:`const rc=rough.canvas(document.getElementById('c'));
rc.circle(110,95,80,{fill:'#f59e0b',stroke:'#b45309',fillStyle:'hachure'});
rc.rectangle(30,320,660,90,{fill:'#4ade80',hachureGap:9,roughness:1.4});
rc.line(150,160,235,235,{stroke:'#dc2626',strokeWidth:2});`});
ex({t:'Sketchy bar chart with roughness control',d:'A real chart drawn with Rough.js primitives: hachure-filled bars, wobbly axes and handwritten labels. Raise roughness to make it messier.',hint:'Drag the roughness slider.',controls:[{type:'range',k:'r',l:'Roughness',min:0,max:3,step:.1,v:1.2},{type:'range',k:'g',l:'Hachure gap',min:4,max:16,v:7}],
 draw(ctx,s,t){bg(ctx,'#fffdf5');const r=rough(ctx,Math.floor(t*2)+5,s.p.r),D=[['Mon',42],['Tue',65],['Wed',51],['Thu',80],['Fri',72],['Sat',30]],x0=80,y0=380,ink='#292524';r.line(x0,30,x0,y0,ink);r.line(x0,y0,W-30,y0,ink);
  D.forEach(([n,v],i)=>{const x=x0+30+i*100,h=v*3.6;r.rect(x,y0-h,64,h,ink,PAL[i],'hachure',s.p.g);text(ctx,n,x+32,y0+26,ink,18,'center',HAND);text(ctx,String(v),x+32,y0-h-10,ink,17,'center',HAND);});text(ctx,'Daily sketches',W/2,40,ink,24,'center',HAND);cap(ctx,'{roughness:'+s.p.r.toFixed(1)+', hachureGap:'+s.p.g+'}');},
 code:`data.forEach((d,i)=>rc.rectangle(x0+i*100,y0-d.v*3.6,64,d.v*3.6,
  {fill:colors[i],fillStyle:'hachure',hachureGap:7,roughness:1.2,bowing:1.5}));`});
ex({t:'Fill-style gallery',d:'The same circle filled with each Rough.js fill style: hachure, solid, zigzag, cross-hatch, dots, dashed and zigzag-line.',
 draw(ctx,s,t){bg(ctx,'#fffdf5');const st=['hachure','solid','zigzag','cross-hatch','dots','dashed'],r=rough(ctx,Math.floor(t*2)+3);st.forEach((f,i)=>{const x=125+(i%3)*235,y=125+Math.floor(i/3)*190;r.circ(x,y,64,'#292524',PAL[i],f,f==='dots'?9:8);text(ctx,f,x,y+96,'#292524',19,'center',HAND);});},
 code:`['hachure','solid','zigzag','cross-hatch','dots','dashed','zigzag-line'].forEach((fillStyle,i)=>
  rc.circle(120+i*140,120,128,{fill:colors[i],fillStyle,hachureGap:8}));`});

lib('svgjs','SVG.js','draw','A lightweight fluent API to create, animate and manipulate SVG: shapes, gradients, masks, text on paths.',{ik:'SVG.js'});
ex({t:'Interactive cell diagram (inline SVG)',d:'A real scalable SVG with gradients, motion along a path and hoverable organelles, crisp at any zoom level.',hint:'Hover or tap an organelle.',
 dom(el,s){el.innerHTML=`<svg viewBox="0 0 720 440" style="position:absolute;inset:0;width:100%;height:100%;background:#fffdf9"><defs><radialGradient id="gn" cx=".4" cy=".4"><stop offset="0" stop-color="#c7d2fe"/><stop offset="1" stop-color="#6366f1"/></radialGradient><radialGradient id="gm" cx=".4" cy=".3"><stop offset="0" stop-color="#fecaca"/><stop offset="1" stop-color="#ef4444"/></radialGradient><radialGradient id="cy" cx=".5" cy=".45"><stop offset="0" stop-color="#ecfeff"/><stop offset="1" stop-color="#a5f3fc"/></radialGradient><path id="mp" d="M120 230 C 220 90, 330 360, 430 220 S 600 120, 640 250"/></defs>
<ellipse cx="360" cy="222" rx="335" ry="196" fill="url(#cy)" stroke="#0891b2" stroke-width="6"/>
<g class="org" data-t="Nucleus: stores DNA and controls the cell"><circle cx="270" cy="200" r="72" fill="url(#gn)" stroke="#4338ca" stroke-width="4"/><circle cx="250" cy="185" r="22" fill="#4338ca"/></g>
<g class="org" data-t="Mitochondrion: makes ATP; the inner folds are cristae"><g><ellipse cx="500" cy="305" rx="70" ry="32" fill="url(#gm)" stroke="#b91c1c" stroke-width="4"/><path d="M455 305q10-24 20 0t20 0t20 0t20 0" fill="none" stroke="#b91c1c" stroke-width="3"/><animateTransform attributeName="transform" type="rotate" values="-6 500 305;6 500 305;-6 500 305" dur="4s" repeatCount="indefinite"/></g></g>
<g class="org" data-t="Endoplasmic reticulum: folds and transports proteins"><path d="M360 140q40-20 60 10t60-10q40-20 50 20" fill="none" stroke="#d97706" stroke-width="9" stroke-linecap="round"/><path d="M370 170q40-20 60 10t60-10q30-15 45 15" fill="none" stroke="#f59e0b" stroke-width="9" stroke-linecap="round"/></g>
<g class="org" data-t="Golgi apparatus: packages and ships proteins"><path d="M150 330q50-24 100 0" fill="none" stroke="#db2777" stroke-width="9" stroke-linecap="round"/><path d="M155 350q45-22 90 0" fill="none" stroke="#ec4899" stroke-width="9" stroke-linecap="round"/><path d="M162 370q38-18 76 0" fill="none" stroke="#f472b6" stroke-width="9" stroke-linecap="round"/></g>
<g class="org" data-t="Lysosome: digests waste with enzymes"><circle cx="610" cy="190" r="26" fill="#bbf7d0" stroke="#15803d" stroke-width="4"/><circle cx="602" cy="184" r="5" fill="#15803d"/></g>
<circle r="7" fill="#f59e0b"><animateMotion dur="9s" repeatCount="indefinite"><mpath href="#mp"/></animateMotion></circle><circle r="5" fill="#0891b2"><animateMotion dur="12s" begin="-4s" repeatCount="indefinite"><mpath href="#mp"/></animateMotion></circle>
<text x="360" y="44" fill="#0e7490" font-size="18" text-anchor="middle" font-family="system-ui">cell membrane</text></svg><div class="capx" style="position:absolute;left:12px;right:12px;bottom:12px;background:rgba(28,25,23,.86);color:#fff;border-radius:10px;padding:8px 12px;font-size:13.5px">Hover an organelle ↑</div>`;
  el.querySelectorAll('.org').forEach(g=>{g.style.cursor='pointer';g.style.transition='filter .2s';const f=()=>{el.querySelector('.capx').textContent=g.getAttribute('data-t');g.style.filter='drop-shadow(0 4px 10px rgba(0,0,0,.25)) brightness(1.08)';};g.addEventListener('mouseenter',f);g.addEventListener('click',f);g.addEventListener('mouseleave',()=>g.style.filter='');});},
 code:`const draw=SVG().addTo('#cell').viewbox(0,0,720,440);
const nucleus=draw.circle(144).center(270,200).fill(draw.gradient('radial',add=>{add.stop(0,'#c7d2fe');add.stop(1,'#6366f1');}));
nucleus.on('mouseenter',()=>caption.text('Nucleus: stores DNA'));
draw.circle(14).fill('#f59e0b').animate(9000).loop().plot?.();`});
ex({t:'Text on a path, gradients & masks',d:'Text flows along a rotating circular path, a gradient sweeps across it, and a circular mask follows the pointer to reveal a hidden layer.',hint:'Move the pointer to move the mask.',
 dom(el,s){el.innerHTML=`<svg viewBox="0 0 720 440" style="position:absolute;inset:0;width:100%;height:100%;background:#fff"><defs><linearGradient id="tg" x1="0" x2="1"><stop offset="0" stop-color="#4f46e5"><animate attributeName="stop-color" values="#4f46e5;#e11d48;#0d9488;#4f46e5" dur="6s" repeatCount="indefinite"/></stop><stop offset="1" stop-color="#db2777"><animate attributeName="stop-color" values="#db2777;#d97706;#4f46e5;#db2777" dur="6s" repeatCount="indefinite"/></stop></linearGradient>
<path id="cp" d="M360 220 m-140 0 a140 140 0 1 1 280 0 a140 140 0 1 1 -280 0"/><mask id="mk"><rect width="720" height="440" fill="black"/><circle class="mc" cx="360" cy="220" r="90" fill="white"/></mask><pattern id="pt" width="24" height="24" patternUnits="userSpaceOnUse"><circle cx="12" cy="12" r="4" fill="#4f46e5" opacity=".35"/></pattern></defs>
<rect width="720" height="440" fill="#faf9f6"/><g mask="url(#mk)"><rect width="720" height="440" fill="#eef2ff"/><rect width="720" height="440" fill="url(#pt)"/><text x="360" y="232" text-anchor="middle" font-family="Georgia,serif" font-size="40" font-weight="700" fill="#312e81">hidden layer</text></g>
<g class="rot"><text font-family="ui-monospace,Menlo,monospace" font-size="21" font-weight="700" fill="url(#tg)" letter-spacing="3"><textPath href="#cp">SVG.JS · TEXT ON A PATH · GRADIENTS · MASKS · PATTERNS · </textPath></text></g>
<circle class="mo" cx="360" cy="220" r="90" fill="none" stroke="#1c1917" stroke-dasharray="4 5" stroke-width="1.5"/></svg>`;
  const svg=el.querySelector('svg'),mc=el.querySelector('.mc'),mo=el.querySelector('.mo');s.rot=el.querySelector('.rot');s.mx=360;s.my=220;s.tx=360;s.ty=220;svg.addEventListener('pointermove',e=>{const r=svg.getBoundingClientRect();s.tx=(e.clientX-r.left)/r.width*720;s.ty=(e.clientY-r.top)/r.height*440;});s.mc=mc;s.mo=mo;},
 tick(s,t){if(!s.rot)return;s.mx=lerp(s.mx,s.tx,.12);s.my=lerp(s.my,s.ty,.12);s.rot.setAttribute('transform','rotate('+(t*20%360)+' 360 220)');[s.mc,s.mo].forEach(c=>{c.setAttribute('cx',s.mx);c.setAttribute('cy',s.my);});},
 code:`const path=draw.path('M360 220 m-140 0 a140 140 0 1 1 280 0 a140 140 0 1 1 -280 0');
const text=draw.text('SVG.JS · TEXT ON A PATH · ').path(path).font({size:21,weight:700});
text.fill(draw.gradient('linear',add=>{add.stop(0,'#4f46e5');add.stop(1,'#db2777');}));
const mask=draw.mask().add(draw.circle(180).fill('#fff'));hidden.maskWith(mask);
draw.on('mousemove',e=>mask.first().center(e.offsetX,e.offsetY));`});
ex({t:'Bézier curve editor with live path data',d:'Drag the endpoints and control handles of a cubic Bézier; the SVG path string updates below it as you edit.',hint:'Drag any of the four points.',
 dom(el,s){el.innerHTML='<svg viewBox="0 0 720 440" style="position:absolute;inset:0;width:100%;height:100%;background:#fffdf9;touch-action:none"><path class="gl" fill="none" stroke="#c7d2fe" stroke-width="1.5" stroke-dasharray="5 5"/><path class="cv" fill="none" stroke="#4f46e5" stroke-width="5" stroke-linecap="round"/><g class="hs"></g><foreignObject x="20" y="380" width="680" height="50"><div xmlns="http://www.w3.org/1999/xhtml" class="pd" style="font:13px ui-monospace,Menlo,monospace;background:#1c1917;color:#86efac;border-radius:8px;padding:8px 12px"></div></foreignObject></svg>';
  const svg=el.querySelector('svg'),P=[[110,300],[200,60],[520,60],[610,300]],hs=el.querySelector('.hs');P.forEach((p,i)=>{const c=document.createElementNS('http://www.w3.org/2000/svg','circle');c.setAttribute('r',i%3?10:13);c.setAttribute('fill',i%3?'#fff':'#4f46e5');c.setAttribute('stroke','#4f46e5');c.setAttribute('stroke-width',3);c.style.cursor='grab';hs.appendChild(c);
   c.addEventListener('pointerdown',e=>{c.setPointerCapture(e.pointerId);const mv=ev=>{const r=svg.getBoundingClientRect();P[i]=[clamp((ev.clientX-r.left)/r.width*720,10,710),clamp((ev.clientY-r.top)/r.height*440,10,370)];upd();};const up=()=>{c.removeEventListener('pointermove',mv);c.removeEventListener('pointerup',up);};c.addEventListener('pointermove',mv);c.addEventListener('pointerup',up);});});
  const upd=()=>{const d='M'+P[0].map(Math.round)+' C'+P.slice(1).map(p=>p.map(Math.round).join(',')).join(' ');el.querySelector('.cv').setAttribute('d',d);el.querySelector('.gl').setAttribute('d','M'+P[0]+' L'+P[1]+' M'+P[2]+' L'+P[3]);[...hs.children].forEach((c,i)=>{c.setAttribute('cx',P[i][0]);c.setAttribute('cy',P[i][1]);});el.querySelector('.pd').textContent='path.plot("'+d+'")';};upd();},
 code:`const curve=draw.path().fill('none').stroke({color:'#4f46e5',width:5});
handles.forEach((h,i)=>h.draggable().on('dragmove',()=>{pts[i]=[h.cx(),h.cy()];
  curve.plot(['M',...pts[0],'C',...pts[1],...pts[2],...pts[3]]);}));   // needs svg.draggable.js`});

lib('pts','Pts.js','draw','A compact library for visualising space, geometry and interaction: points, groups, forms and spaces.',{ik:'Pts.js'});
ex({t:'Point field reacting to the pointer',d:'A grid of points; each draws a line toward the pointer whose length and colour depend on distance, a classic Pts sketch.',hint:'Move the pointer over the field.',
 draw(ctx,s,t){bg(ctx);const px=s.hover?s.mx:W/2+Math.cos(t*.7)*220,py=s.hover?s.my:H/2+Math.sin(t*1.1)*130;for(let x=24;x<W;x+=24)for(let y=22;y<H;y+=24){const dx=px-x,dy=py-y,d=Math.hypot(dx,dy),k=clamp(1-d/260,0,1),l=k*18;
  if(k>0){line(ctx,x,y,x+dx/d*l,y+dy/d*l,hsl(250-k*200,70,50,.3+k*.7),1+k*2);}circle(ctx,x,y,1.2+k*3,k>0?hsl(250-k*200,70,50):'#d6d3cd');}circle(ctx,px,py,6,null,C.ink,2);cap(ctx,'form.line([pt, pt.$subtract(space.pointer).$multiply(-k)])');},
 code:`const space=new CanvasSpace('#pts').setup({bgcolor:'#fff'}),form=space.getForm();
const pts=Create.gridPts(space.innerBound,30,18);
space.add(()=>pts.forEach(p=>{const d=space.pointer.$subtract(p),k=Math.max(0,1-d.magnitude()/260);
  form.stroke(\`hsl(\${250-k*200},70%,50%)\`).line([p,p.$add(d.unit().multiply(k*18))]);}));space.play();`});
ex({t:'Convex hull & perpendiculars',d:'Drifting points with their convex hull recomputed every frame, and perpendicular lines dropped from the pointer onto every hull edge.',hint:'Move the pointer.',
 init(s){const r=rng(6);s.P=Array.from({length:26},()=>({x:160+r()*400,y:90+r()*260,vx:(r()-.5)*30,vy:(r()-.5)*30}));},
 draw(ctx,s,t,dt){bg(ctx,'#fbfaf8');s.P.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.x<120||p.x>600)p.vx*=-1;if(p.y<60||p.y>380)p.vy*=-1;});const pts=s.P.map(p=>[p.x,p.y]).sort((a,b)=>a[0]-b[0]||a[1]-b[1]),cr=(o,a,b)=>(a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0]),lo=[],up=[];
  for(const p of pts){while(lo.length>=2&&cr(lo[lo.length-2],lo[lo.length-1],p)<=0)lo.pop();lo.push(p);}for(let i=pts.length-1;i>=0;i--){const p=pts[i];while(up.length>=2&&cr(up[up.length-2],up[up.length-1],p)<=0)up.pop();up.push(p);}const hull=lo.slice(0,-1).concat(up.slice(0,-1));
  poly(ctx,hull,'rgba(79,70,229,.07)','#4f46e5',2);const px=s.hover?s.mx:W/2+Math.cos(t*.6)*80,py=s.hover?s.my:H/2+Math.sin(t*.8)*60;
  hull.forEach((a,i)=>{const b=hull[(i+1)%hull.length],dx=b[0]-a[0],dy=b[1]-a[1],u=clamp(((px-a[0])*dx+(py-a[1])*dy)/(dx*dx+dy*dy),0,1),q=[a[0]+dx*u,a[1]+dy*u];line(ctx,px,py,q[0],q[1],'rgba(225,29,72,.5)',1.2,[3,3]);circle(ctx,q[0],q[1],3.5,'#e11d48');});
  pts.forEach(p=>circle(ctx,p[0],p[1],3.5,'#1c1917'));circle(ctx,px,py,6,'#e11d48');cap(ctx,'Polygon.convexHull(pts); Line.perpendicularFromPt(edge, pointer)');},
 code:`space.add(()=>{const hull=Polygon.convexHull(pts);form.fill('#4f46e522').stroke('#4f46e5').polygon(hull);
  Polygon.lines(hull).forEach(ln=>form.stroke('#e11d48').line([space.pointer,Line.perpendicularFromPt(ln,space.pointer)]));});`});

lib('excalidraw','Excalidraw','draw','An embeddable hand-drawn whiteboard: shapes, arrows, text and libraries with JSON import/export.');
ex({t:'Mini whiteboard: rectangle, ellipse, arrow, pen',d:'Pick a tool and drag on the board. Shapes render in the hand-drawn style with a stable seed per element, like Excalidraw elements.',hint:'Pick a tool, then drag on the board.',int:1,
 controls:[{type:'seg',k:'tool',v:'Rectangle',opts:['Rectangle','Ellipse','Arrow','Pen']},{type:'select',k:'c',l:'Stroke',v:'Ink',opts:['Ink','Indigo','Rose','Teal']},{type:'toggle',k:'f',l:'Hachure fill',v:true},{type:'btn',l:'Undo',fn:s=>s.E.pop()},{type:'btn',l:'Clear',fn:s=>{s.E=[];}}],
 init(s){s.E=[{k:'Rectangle',x:80,y:80,w:180,h:100,c:'#1c1917',f:'#a5b4fc',sd:3},{k:'Ellipse',x:420,y:90,w:200,h:110,c:'#1c1917',f:'#fda4af',sd:5},{k:'Arrow',x:265,y:130,w:150,h:20,c:'#1c1917',sd:7}];s.cur=null;
  s.onDown=(x,y)=>{const cols={Ink:'#1c1917',Indigo:'#4f46e5',Rose:'#e11d48',Teal:'#0d9488'};s.cur={k:s.p.tool,x,y,w:0,h:0,c:cols[s.p.c],f:s.p.f?rgba(cols[s.p.c]==='#1c1917'?'#d97706':cols[s.p.c],.55):null,sd:Math.floor(Math.random()*1000),pts:[[x,y]]};};
  s.onMove=(x,y)=>{if(s.cur&&s.down){s.cur.w=x-s.cur.x;s.cur.h=y-s.cur.y;if(s.cur.k==='Pen')s.cur.pts.push([x,y]);}};s.onUp=()=>{if(s.cur&&(Math.abs(s.cur.w)>4||Math.abs(s.cur.h)>4))s.E.push(s.cur);s.cur=null;};},
 draw(ctx,s,t){paper(ctx,'#fff','#ece9e3');const all=s.cur?s.E.concat([s.cur]):s.E;for(const e of all){const r=rough(ctx,e.sd,1);const x=Math.min(e.x,e.x+e.w),y=Math.min(e.y,e.y+e.h),w=Math.abs(e.w),h=Math.abs(e.h);
  if(e.k==='Rectangle')r.rect(x,y,w,h,e.c,e.f,'hachure',8);else if(e.k==='Ellipse')r.ell(x+w/2,y+h/2,w/2,h/2,e.c,e.f);else if(e.k==='Arrow')r.arrow(e.x,e.y,e.x+e.w,e.y+e.h,e.c);else{ctx.strokeStyle=e.c;ctx.lineWidth=2.5;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();e.pts.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.stroke();}}
  text(ctx,'Ideas board',96,140,C.ink,24,'left',HAND);text(ctx,s.E.length+' elements',W-14,24,C.mut,12,'right',MONO);},
 code:`import {Excalidraw,exportToSvg} from '@excalidraw/excalidraw';
<Excalidraw initialData={{elements,appState:{viewBackgroundColor:'#fff'}}}
  onChange={(els)=>localStorage.setItem('board',JSON.stringify(els))} />
const svg=await exportToSvg({elements,appState,files:null});`});

lib('two','Two.js','draw','A renderer-agnostic 2D drawing API: the same scene draws to SVG, Canvas or WebGL.',{isNew:true});
ex({t:'Rope following the pointer',d:'A Two.Path with 40 vertices joined by distance constraints (Verlet), drawn as a smooth tapered curve that trails the pointer.',hint:'Move the pointer and swing the rope.',
 init(s){s.N=40;s.P=Array.from({length:s.N},(_,i)=>({x:W/2,y:60+i*8,px:W/2,py:60+i*8}));},
 draw(ctx,s,t,dt){bg(ctx,'#fffdf9');const P=s.P,head=s.hover?[s.mx,s.my]:[W/2+Math.cos(t)*200,H/2+Math.sin(t*1.7)*120];P[0].x=head[0];P[0].y=head[1];
  for(let i=1;i<P.length;i++){const p=P[i],vx=(p.x-p.px)*.985,vy=(p.y-p.py)*.985;p.px=p.x;p.py=p.y;p.x+=vx;p.y+=vy+.35;}for(let k=0;k<8;k++)for(let i=1;i<P.length;i++){const a=P[i-1],b=P[i],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1,f=(d-9)/d;if(i>1){a.x+=dx*f*.5;a.y+=dy*f*.5;}b.x-=dx*f*.5;b.y-=dy*f*.5;}
  for(let i=1;i<P.length;i++){const a=P[i-1],b=P[i];line(ctx,a.x,a.y,b.x,b.y,hsl(250+i*3,70,55),Math.max(2,16-i*.35));}ctx.lineCap='round';P.forEach((p,i)=>{if(i%6===0)circle(ctx,p.x,p.y,Math.max(2,9-i*.18),'#fff',hsl(250+i*3,70,45),2);});circle(ctx,P[0].x,P[0].y,10,'#e11d48');cap(ctx,'two.makeCurve(points, true); two.bind("update", step).play()');},
 code:`const two=new Two({type:Two.Types.svg,fullscreen:true}).appendTo(document.body);
const rope=two.makeCurve(points,true);rope.noFill().stroke='#6366f1';rope.linewidth=10;
two.bind('update',()=>{verletStep(points,mouse);rope.vertices.forEach((v,i)=>v.set(points[i].x,points[i].y));}).play();`});
ex({t:'Renderer-agnostic pattern',d:'A grid of rotating polygons whose side counts and phases ripple outward. Switch renderer: the scene description stays the same.',controls:[{type:'seg',k:'r',v:'canvas',opts:['svg','canvas','webgl']}],
 draw(ctx,s,t){bg(ctx);for(let i=0;i<12;i++)for(let j=0;j<7;j++){const x=50+i*56,y=50+j*56,d=Math.hypot(i-5.5,j-3),n=3+Math.floor((d+t)%5),a=t*.8-d*.4,sc=18+6*Math.sin(t*2-d);ctx.beginPath();for(let k=0;k<n;k++){const an=a+k/n*TAU;ctx.lineTo(x+Math.cos(an)*sc,y+Math.sin(an)*sc);}ctx.closePath();ctx.fillStyle=hsl(230+d*18,70,62,.85);ctx.fill();ctx.strokeStyle=hsl(230+d*18,70,35);ctx.lineWidth=1.5;ctx.stroke();}
  badge(ctx,'Two.Types.'+s.p.r,W-14,12,'#eef2ff',C.indigo,'right');cap(ctx,'two.makePolygon(x, y, radius, sides)');},
 code:`const two=new Two({type:Two.Types.webgl,width:720,height:440});   // or svg, canvas
for(const c of cells){const p=two.makePolygon(c.x,c.y,18,3);shapes.push(p);}
two.bind('update',f=>shapes.forEach((p,i)=>{p.rotation+=.02;p.sides=3+((i+f/60)|0)%5;})).play();`});

lib('vivus','Vivus','draw','Makes SVGs look like they are being drawn: delayed, sync, one-by-one and scenario animations.',{isNew:true});
ex({t:'Line-drawing icons: delayed, sync, one-by-one',d:'Real SVG icons whose strokes animate through stroke-dashoffset in each of Vivus’s three modes.',controls:[{type:'seg',k:'m',v:'delayed',opts:['delayed','sync','oneByOne']},{type:'btn',l:'↻ Replay',pri:1,fn:s=>{s.t0=s.t;}}],
 dom(el,s){const I=['<path d="M3 10.5 12 3l9 7.5V21H3z"/><path d="M9 21v-7h6v7"/>','<circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>','<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/>','<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3z"/><circle cx="12" cy="13" r="3"/>','<path d="m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01z"/>','<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>','<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>','<path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"/>'];
  el.innerHTML='<div style="position:absolute;inset:0;display:grid;grid-template-columns:repeat(4,1fr);gap:8px;padding:26px;background:#fffdf9">'+I.map((p,i)=>'<div style="display:grid;place-items:center"><svg viewBox="0 0 24 24" style="width:82%;max-width:110px" fill="none" stroke="'+PAL[i]+'" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">'+p+'</svg></div>').join('')+'</div>';
  s.paths=[...el.querySelectorAll('path,circle')].map(p=>{const L=p.getTotalLength?p.getTotalLength():60;p.style.strokeDasharray=L;p.style.strokeDashoffset=L;return{p,L,svg:p.ownerSVGElement};});const svgs=[...el.querySelectorAll('svg')];s.paths.forEach(o=>o.si=svgs.indexOf(o.svg));s.t0=0;},
 tick(s,t){if(!s.paths)return;const T=(t-s.t0)%5,m=s.p.m,n=s.paths.length;s.paths.forEach((o,i)=>{let k;if(m==='sync')k=T/1.8;else if(m==='delayed')k=(T-i*.08)/1.4;else k=T*n/3.2-i;o.p.style.strokeDashoffset=o.L*(1-ease(clamp(k,0,1)));});},
 code:`new Vivus('icons',{type:'delayed',duration:120,animTimingFunction:Vivus.EASE_OUT},
  v=>v.play(v.getStatus()==='end'?-1:1));     // 'delayed' | 'sync' | 'oneByOne' | 'scenario'`});
