/* ===================== Global numbering + full-screen player across every library ===================== */
(function(){
const css=`
.ex header .no.gno{min-width:auto;padding:2px 8px;border-radius:99px;background:linear-gradient(135deg,rgba(124,58,237,.14),rgba(236,72,153,.12));color:#5b21b6;font:700 11px var(--mono);letter-spacing:.02em}
.ex header .tb button[data-a=play]{color:#7c3aed;font-weight:800}
#player{position:fixed;inset:0;z-index:300;display:none;color:#fff;font-family:var(--sans);overflow:hidden;background:radial-gradient(1200px 700px at 20% 10%,#3b2a7a 0%,transparent 60%),radial-gradient(900px 600px at 90% 90%,#5b1d5e 0%,transparent 55%),linear-gradient(160deg,#1a1336,#0d0a1f)}
#player.open{display:block}
#player .pl-blob{position:absolute;width:46vmax;height:46vmax;border-radius:50%;filter:blur(90px);opacity:.28;pointer-events:none;animation:plb 24s ease-in-out infinite alternate}
@keyframes plb{to{transform:translate(8vw,6vh) scale(1.15)}}
#player .pl-top{position:absolute;left:0;right:0;top:0;height:64px;display:flex;align-items:center;gap:14px;padding:0 18px;z-index:5;background:linear-gradient(180deg,rgba(13,10,31,.75),rgba(13,10,31,0));transition:opacity .35s}
#player .pl-num{font:800 22px var(--mono);letter-spacing:-.02em;background:linear-gradient(135deg,#c4b5fd,#f9a8d4);-webkit-background-clip:text;background-clip:text;color:transparent;white-space:nowrap}
#player .pl-num small{font:600 12px var(--mono);color:rgba(255,255,255,.45);-webkit-text-fill-color:rgba(255,255,255,.45)}
#player .pl-meta{min-width:0;display:flex;flex-direction:column;gap:2px}
#player .pl-meta .t{font:700 15px var(--sans);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#player .pl-meta .l{font:600 11.5px var(--sans);color:rgba(255,255,255,.65);display:flex;gap:8px;align-items:center;white-space:nowrap}
#player .pl-meta .chip{padding:1px 8px;border-radius:99px;font:700 10px var(--sans);letter-spacing:.04em;text-transform:uppercase}
#player .pl-sp{flex:1}
#player .pl-btn{height:36px;min-width:36px;padding:0 12px;border-radius:12px;border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.08);backdrop-filter:blur(12px);color:#fff;font:600 13px var(--sans);cursor:pointer;display:inline-flex;align-items:center;gap:6px;white-space:nowrap;transition:background .2s,transform .2s}
#player .pl-btn:hover{background:rgba(255,255,255,.18)}
#player .pl-btn.on{background:linear-gradient(135deg,#7c3aed,#db2777);border-color:transparent}
#player .pl-go{display:flex;align-items:center;gap:4px;height:36px;padding:0 4px 0 10px;border-radius:12px;border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.08)}
#player .pl-go input{width:54px;background:transparent;border:0;outline:0;color:#fff;font:700 13px var(--mono)}
#player .pl-go span{font:600 12px var(--mono);color:rgba(255,255,255,.5)}
#player .pl-stage{position:absolute;left:0;right:0;top:64px;bottom:92px;display:grid;place-items:center}
#player .pl-slide{position:absolute;display:flex;flex-direction:column;align-items:center;gap:10px;transition:transform .5s cubic-bezier(.2,.8,.2,1),opacity .45s ease,filter .45s ease}
#player .pl-slide.in-r{transform:translateX(9vw) scale(.94);opacity:0;filter:blur(6px)}
#player .pl-slide.in-l{transform:translateX(-9vw) scale(.94);opacity:0;filter:blur(6px)}
#player .pl-slide.out-l{transform:translateX(-9vw) scale(.94);opacity:0;filter:blur(6px);pointer-events:none}
#player .pl-slide.out-r{transform:translateX(9vw) scale(.94);opacity:0;filter:blur(6px);pointer-events:none}
#player .ex{margin:0!important;padding:0!important;border:0!important;background:transparent!important;box-shadow:none!important;backdrop-filter:none!important;width:auto!important;max-width:none!important;content-visibility:visible!important;transform:none!important;opacity:1!important}
#player .ex>header,#player .ex>.exd{display:none!important}
#player .ex>.stage{border-radius:18px;overflow:hidden;box-shadow:0 30px 90px rgba(0,0,0,.45),0 0 0 1px rgba(255,255,255,.14);aspect-ratio:auto!important;flex:none!important;border:0!important}
#player .ex>.ctl{display:none!important}
#player .ex>pre.code{display:none!important}
#player .pl-nav{position:absolute;top:50%;transform:translateY(-50%);z-index:6;width:58px;height:58px;border-radius:50%;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.1);backdrop-filter:blur(14px);color:#fff;font-size:28px;line-height:1;cursor:pointer;display:grid;place-items:center;transition:background .2s,transform .2s,opacity .35s}
#player .pl-nav:hover{background:rgba(255,255,255,.22);transform:translateY(-50%) scale(1.06)}
#player .pl-nav.p{left:18px}#player .pl-nav.n{right:18px}
#player .pl-nav .tipn{position:absolute;top:66px;white-space:nowrap;font:600 11px var(--sans);color:rgba(255,255,255,.75);background:rgba(13,10,31,.7);padding:4px 9px;border-radius:8px;opacity:0;transition:opacity .2s;pointer-events:none}
#player .pl-nav.p .tipn{left:0}#player .pl-nav.n .tipn{right:0}
#player .pl-nav:hover .tipn{opacity:1}
#player .pl-bot{position:absolute;left:0;right:0;bottom:0;height:92px;z-index:5;padding:0 18px 12px;display:flex;flex-direction:column;justify-content:flex-end;gap:8px;background:linear-gradient(0deg,rgba(13,10,31,.8),rgba(13,10,31,0));transition:opacity .35s}
#player .pl-row{display:flex;align-items:center;gap:10px;min-width:0}
#player .pl-desc{flex:1;min-width:0;font:500 12.5px var(--sans);color:rgba(255,255,255,.72);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#player .pl-desc b{color:#f9a8d4;font-weight:600}
#player .pl-track{position:relative;height:16px;cursor:pointer;display:flex;gap:2px;align-items:center}
#player .pl-track .seg{height:6px;border-radius:3px;opacity:.55;transition:height .15s,opacity .15s;position:relative}
#player .pl-track .seg.cur{opacity:1;height:8px}
#player .pl-track:hover .seg{height:9px}
#player .pl-track .mk{position:absolute;top:-2px;width:4px;height:20px;border-radius:2px;background:#fff;box-shadow:0 0 12px #fff;transition:left .45s cubic-bezier(.2,.8,.2,1);pointer-events:none}
#player .pl-track .ttip{position:absolute;bottom:22px;transform:translateX(-50%);white-space:nowrap;font:600 11px var(--sans);background:rgba(13,10,31,.92);padding:5px 9px;border-radius:8px;pointer-events:none;display:none}
#player .pl-auto{position:relative}
#player .pl-auto i{position:absolute;left:8px;right:8px;bottom:4px;height:2px;border-radius:1px;background:rgba(255,255,255,.2);overflow:hidden}
#player .pl-auto i b{display:block;height:100%;width:0;background:#f9a8d4}
#player .pl-panel{position:absolute;right:18px;bottom:104px;z-index:7;width:min(380px,40vw);max-height:calc(100vh - 220px);overflow:auto;padding:14px;border-radius:16px;background:rgba(255,255,255,.94);backdrop-filter:blur(18px);color:#140e29;box-shadow:0 20px 60px rgba(0,0,0,.35);display:none}
#player .pl-panel.on{display:block}
#player .pl-panel h6{margin:0 0 10px;font:700 12px var(--sans);letter-spacing:.06em;text-transform:uppercase;color:#7c3aed}
#player .pl-panel .ctl{display:flex!important;flex-wrap:wrap;gap:10px;padding:0!important;border:0!important;background:transparent!important}
#player .pl-panel pre.code{display:block!important;margin:0;max-height:52vh;overflow:auto;font-size:11.5px;border-radius:10px}
#player.idle .pl-top,#player.idle .pl-bot,#player.idle .pl-nav{opacity:0}
#player.idle{cursor:none}
#player .pl-toast{position:absolute;left:50%;top:84px;transform:translateX(-50%);z-index:8;padding:8px 14px;border-radius:99px;background:rgba(255,255,255,.95);color:#140e29;font:700 13px var(--sans);box-shadow:0 10px 30px rgba(0,0,0,.3);opacity:0;transition:opacity .3s}
#player .pl-toast.on{opacity:1}
.libnav{display:grid;grid-template-columns:1fr auto 1fr;gap:14px;margin:26px 0 10px;align-items:stretch}
.libnav a,.libnav button{display:flex;flex-direction:column;gap:3px;padding:14px 16px;border-radius:16px;border:1px solid rgba(255,255,255,.9);background:rgba(255,255,255,.62);backdrop-filter:blur(14px);text-decoration:none;color:#140e29;font-family:var(--sans);cursor:pointer;transition:transform .2s,box-shadow .2s}
.libnav a:hover,.libnav button:hover{transform:translateY(-2px);box-shadow:0 12px 30px rgba(76,29,149,.14)}
.libnav small{font:600 11px var(--mono);color:#8b84a8}
.libnav b{font:700 15px var(--sans)}
.libnav .nx{text-align:right;align-items:flex-end}
.libnav button{align-items:center;justify-content:center;background:linear-gradient(135deg,#7c3aed,#db2777);color:#fff;border:0;font:700 14px var(--sans)}
.libnav button small{color:rgba(255,255,255,.75)}
#playb{display:inline-flex;align-items:center;gap:6px;margin-left:8px;border:0;border-radius:99px;padding:7px 13px;font:700 12px var(--sans);color:#fff;cursor:pointer;background:linear-gradient(135deg,#7c3aed,#db2777);box-shadow:0 6px 18px rgba(124,58,237,.3);white-space:nowrap}
`;const st=document.createElement('style');st.textContent=css;document.head.appendChild(st);

/* ---------- global sequence ---------- */
let SEQ=null;const GN=new Map();
const seq=()=>{if(SEQ)return SEQ;SEQ=[];CATS.forEach(c=>LIBS.filter(L=>L.cat===c[0]).forEach(L=>L.ex.forEach((X,i)=>{SEQ.push({L,X,i,c});GN.set(X,SEQ.length);})));return SEQ;};
window.SEQN=()=>seq().length;window.seqAt=n=>seq()[n-1];

/* ---------- number every card + ▶ button; ⛶ opens the player ---------- */
const _m=mountEx;mountEx=function(L,X,i,opt){const el=_m(L,X,i,opt);seq();const n=GN.get(X);if(n&&el){const no=el.querySelector('header .no');if(no){no.textContent='#'+n;no.classList.add('gno');no.title='Example '+n+' of '+SEQ.length+' (number '+(i+1)+' in '+L.name+')';}
 const tb=el.querySelector('.tb');if(tb&&!tb.querySelector('[data-a=play]')){const b=document.createElement('button');b.dataset.a='play';b.title='Play full screen from #'+n+' (next / previous across all libraries)';b.textContent='▶';tb.insertBefore(b,tb.firstChild);}el.dataset.gn=n;}return el;};
document.addEventListener('click',e=>{const b=e.target.closest('.ex .tb button[data-a=play],.ex .tb button[data-a=fs]');if(!b)return;const el=b.closest('.ex');if(!el||!el.dataset.gn||el.closest('#player'))return;e.stopPropagation();e.preventDefault();openPlayer(+el.dataset.gn,true);},true);

/* ---------- player DOM ---------- */
const P=document.createElement('div');P.id='player';P.innerHTML='<div class="pl-blob" style="left:-10vmax;top:-12vmax;background:#7c3aed"></div><div class="pl-blob" style="right:-14vmax;bottom:-16vmax;background:#db2777;animation-delay:-8s"></div>'+
 '<div class="pl-top"><div class="pl-num"></div><div class="pl-meta"><div class="t"></div><div class="l"></div></div><div class="pl-sp"></div>'+
 '<label class="pl-go" title="Jump to any number"><span>#</span><input inputmode="numeric" placeholder="go"></label>'+
 '<button class="pl-btn pl-auto" data-p="auto" title="Autoplay (Space)">▶ Auto<i><b></b></i></button><button class="pl-btn" data-p="dur" title="Seconds per example">12 s</button>'+
 '<button class="pl-btn" data-p="ctl" title="Controls (C)">⚙ Controls</button><button class="pl-btn" data-p="code" title="Code (K)">&lt;/&gt;</button><button class="pl-btn" data-p="open" title="Open on its library page">↗</button><button class="pl-btn" data-p="fs" title="Full screen (F)">⛶</button><button class="pl-btn" data-p="x" title="Exit (Esc)">✕</button></div>'+
 '<div class="pl-stage"></div><button class="pl-nav p" data-p="prev" title="Previous (←)">‹<span class="tipn"></span></button><button class="pl-nav n" data-p="next" title="Next (→)">›<span class="tipn"></span></button>'+
 '<div class="pl-panel"></div><div class="pl-toast"></div>'+
 '<div class="pl-bot"><div class="pl-row"><div class="pl-desc"></div></div><div class="pl-track"><div class="mk"></div><div class="ttip"></div></div></div>';
document.body.appendChild(P);
const $=q=>P.querySelector(q),stage=$('.pl-stage'),track=$('.pl-track'),panel=$('.pl-panel');
let cur=0,slide=null,auto=false,dur=12,el0=0,panelMode=null,back=null,paused=[],idleT=0,busy=false;

const kill=sl=>{sl.querySelectorAll('.stage').forEach(stg=>{const s=stg._s;if(s){s.dead=true;try{s.destroy&&s.destroy();}catch(e){}ACTIVE.delete(s);}});sl.remove();};
const fit=()=>{const r=stage.getBoundingClientRect(),aw=r.width-170,ah=r.height-16,k=Math.max(.3,Math.min(aw/720,ah/440));return[Math.round(720*k),Math.round(440*k),k];};
const buildTrack=()=>{if(track.querySelector('.seg'))return;const S=seq();let k=0;CATS.forEach(c=>{const n=S.filter(x=>x.c===c).length;if(!n)return;const d=document.createElement('div');d.className='seg';d.style.flex=n;d.style.background=c[3]||'#a78bfa';d.dataset.c=c[0];d.dataset.a=k+1;d.dataset.n=n;track.appendChild(d);k+=n;});};
const posOf=n=>{const segs=[...track.querySelectorAll('.seg')],tr=track.getBoundingClientRect();for(const s of segs){const a=+s.dataset.a,c=+s.dataset.n;if(n>=a&&n<a+c){const r=s.getBoundingClientRect();return r.left-tr.left+(n-a+.5)/c*r.width;}}return 0;};
const nOfX=x=>{const segs=[...track.querySelectorAll('.seg')],tr=track.getBoundingClientRect();for(const s of segs){const r=s.getBoundingClientRect();if(x+tr.left>=r.left-1&&x+tr.left<=r.right+1){const a=+s.dataset.a,c=+s.dataset.n;return clamp(a+Math.floor((x+tr.left-r.left)/r.width*c),a,a+c-1);}}return null;};
const label=n=>{const e=seq()[n-1];return'#'+n+' · '+e.L.name+' · '+e.X.t.split(':')[0];};
const toastP=t=>{const o=$('.pl-toast');o.textContent=t;o.classList.add('on');clearTimeout(o._t);o._t=setTimeout(()=>o.classList.remove('on'),1400);};

function show(n,dir){const S=seq();n=((n-1+S.length)%S.length)+1;const E=S[n-1],prevLib=cur?S[cur-1].L:null;cur=n;el0=0;
 const[w,h,k]=fit();window.__hiD=Math.min(2.5,Math.max(Math.min(2,window.devicePixelRatio||1),k*(window.devicePixelRatio||1)));
 const sl=document.createElement('div');sl.className='pl-slide '+(dir<0?'in-l':dir>0?'in-r':'');stage.appendChild(sl);
 let ex;try{ex=mountEx(E.L,E.X,E.i,{into:sl});}catch(e){sl.innerHTML='<p class="warn">'+esc(e.message)+'</p>';}
 if(ex){const sg=ex.querySelector('.stage');sg.style.width=w+'px';sg.style.height=h+'px';const s=sg._s;if(s&&s._boot)s._boot();if(s)s.vis=true;}
 if(slide){const old=slide;old.classList.add(dir<0?'out-r':'out-l');setTimeout(()=>kill(old),520);}slide=sl;requestAnimationFrame(()=>requestAnimationFrame(()=>sl.classList.remove('in-l','in-r')));
 $('.pl-num').innerHTML='#'+n+' <small>/ '+S.length+'</small>';$('.pl-meta .t').textContent=E.X.t;$('.pl-meta .t').title=E.X.t;
 $('.pl-meta .l').innerHTML='<span class="chip" style="background:'+(E.c[3]||'#7c3aed')+'">'+esc(E.c[1])+'</span><span>'+esc(E.L.combo?E.L.combo.map(id=>LIBMAP[id]?LIBMAP[id].name:id).join(' + '):E.L.name)+' · example '+(E.i+1)+' of '+E.L.ex.length+'</span>';
 $('.pl-desc').innerHTML=esc(E.X.d||'')+(E.X.hint?'  <b>· '+esc(E.X.hint)+'</b>':'');
 const pv=S[(n-2+S.length)%S.length],nx=S[n%S.length];$('.pl-nav.p .tipn').textContent=(pv.L!==E.L?'← Previous library · ':'')+label(n-1||S.length);$('.pl-nav.n .tipn').textContent=(nx.L!==E.L?'Next library → ':'')+label(n%S.length+1);
 if(prevLib&&prevLib!==E.L)toastP((dir<0?'◀ ':'')+E.L.name+(dir>=0?' ▶':'')+'  ·  '+E.L.ex.length+' example'+(E.L.ex.length>1?'s':''));
 track.querySelectorAll('.seg').forEach(s=>s.classList.toggle('cur',s.dataset.c===E.c[0]));$('.pl-track .mk').style.left=(posOf(n)-2)+'px';
 if(panelMode)fillPanel();try{history.replaceState(null,'','#/play/'+n);}catch(e){}}

function fillPanel(){if(!slide)return;const ex=slide.querySelector('.ex');panel.innerHTML='';if(!ex)return;if(panelMode==='ctl'){const c=ex.querySelector('.ctl');panel.innerHTML='<h6>Controls</h6>';if(c&&c.children.length){panel.appendChild(c);}else panel.insertAdjacentHTML('beforeend','<p style="margin:0;color:#6b6288;font:500 13px var(--sans)">This example has no controls. Interact with it directly: '+esc(seq()[cur-1].X.hint||'drag, hover or scroll.')+'</p>');}
 else{const c=ex.querySelector('pre.code');panel.innerHTML='<h6>Code · '+esc(seq()[cur-1].L.name)+'</h6>';if(c){c.hidden=false;panel.appendChild(c);}else panel.insertAdjacentHTML('beforeend','<p style="margin:0">No snippet for this one.</p>');}}
function setPanel(m){panelMode=panelMode===m?null:m;panel.classList.toggle('on',!!panelMode);P.querySelector('[data-p=ctl]').classList.toggle('on',panelMode==='ctl');P.querySelector('[data-p=code]').classList.toggle('on',panelMode==='code');if(panelMode)fillPanel();}

window.openPlayer=(n,wantFs)=>{seq();if(P.classList.contains('open')){show(n,n>cur?1:-1);return;}back=location.hash.startsWith('#/play')?'#/':location.hash;paused=[];for(const s of ACTIVE){if(!s.paused){s.paused=true;paused.push(s);}}
 P.classList.add('open');document.body.style.overflow='hidden';buildTrack();if(wantFs&&!document.fullscreenElement&&document.documentElement.requestFullscreen){document.documentElement.requestFullscreen({navigationUI:'hide'}).catch(()=>{});P._fs=true;}
 slide=null;cur=0;setTimeout(()=>show(n||1,0),wantFs?120:0);wake();};
function closePlayer(){if(!P.classList.contains('open'))return;P.classList.remove('open');if(slide){kill(slide);slide=null;}stage.innerHTML='';window.__hiD=0;document.body.style.overflow='';setAuto(false);panelMode=null;panel.classList.remove('on');
 paused.forEach(s=>{if(!s.dead)s.paused=false;});paused=[];if(document.fullscreenElement&&P._fs)document.exitFullscreen().catch(()=>{});P._fs=false;try{history.replaceState(null,'',back||'#/');}catch(e){}const el=document.querySelector('.ex[data-gn="'+cur+'"]');if(el)el.scrollIntoView({block:'center',behavior:'smooth'});}
const go=d=>show(cur+d,d);
const goLib=d=>{const S=seq(),L=S[cur-1].L;let a=cur;while(a>1&&S[a-2].L===L)a--;if(d>0){let n=cur;while(n<=S.length&&S[n-1].L===L)n++;show(n>S.length?1:n,1);}else{let b=a-1<1?S.length:a-1;const PL=S[b-1].L;while(b>1&&S[b-2].L===PL)b--;show(b,-1);}};
const setAuto=on=>{auto=on;el0=0;const b=P.querySelector('[data-p=auto]');b.classList.toggle('on',on);b.firstChild.textContent=on?'❚❚ Auto':'▶ Auto';};

P.addEventListener('click',e=>{const b=e.target.closest('[data-p]');if(!b)return;const a=b.dataset.p;
 if(a==='prev')go(-1);if(a==='next')go(1);if(a==='x')closePlayer();if(a==='auto')setAuto(!auto);if(a==='dur'){dur=dur===8?12:dur===12?20:dur===20?40:8;b.textContent=dur+' s';el0=0;}
 if(a==='ctl'||a==='code')setPanel(a);if(a==='open'){const E=seq()[cur-1];closePlayer();location.hash='#/l/'+E.L.id+'/'+(E.i+1);}
 if(a==='fs'){if(document.fullscreenElement)document.exitFullscreen().catch(()=>{});else if(document.documentElement.requestFullscreen){document.documentElement.requestFullscreen().catch(()=>toastP('Full screen is blocked here, so the player fills the window'));P._fs=true;}}});
const gi=$('.pl-go input');gi.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Enter'){const v=parseInt(gi.value,10);if(v>=1&&v<=seq().length){show(v,v>cur?1:-1);gi.value='';gi.blur();}else toastP('Choose 1 – '+seq().length);}if(e.key==='Escape')gi.blur();});
track.addEventListener('mousemove',e=>{const r=track.getBoundingClientRect(),n=nOfX(e.clientX-r.left),t=$('.pl-track .ttip');if(!n){t.style.display='none';return;}t.style.display='block';t.style.left=(e.clientX-r.left)+'px';t.textContent=label(n);});
track.addEventListener('mouseleave',()=>$('.pl-track .ttip').style.display='none');track.addEventListener('click',e=>{const r=track.getBoundingClientRect(),n=nOfX(e.clientX-r.left);if(n&&n!==cur)show(n,n>cur?1:-1);});
document.addEventListener('keydown',e=>{if(!P.classList.contains('open'))return;if(e.target.closest&&e.target.closest('input,textarea,select,[contenteditable]')&&!e.target.closest('.pl-go'))return;const k=e.key;
 if(k==='ArrowRight'){e.shiftKey?goLib(1):go(1);}else if(k==='ArrowLeft'){e.shiftKey?goLib(-1):go(-1);}else if(k==='PageDown')goLib(1);else if(k==='PageUp')goLib(-1);else if(k==='Home')show(1,-1);else if(k==='End')show(seq().length,1);
 else if(k===' '){setAuto(!auto);}else if(k==='Escape'){closePlayer();}else if(k==='f'||k==='F'){P.querySelector('[data-p=fs]').click();}else if(k==='c'||k==='C')setPanel('ctl');else if(k==='k'||k==='K')setPanel('code');else if(/^[0-9]$/.test(k)){gi.focus();gi.value=k;}else return;e.preventDefault();e.stopPropagation();wake();},true);
document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement&&P._fs&&P.classList.contains('open')){P._fs=false;closePlayer();}else if(P.classList.contains('open')&&slide){setTimeout(()=>{const sg=slide.querySelector('.ex>.stage');if(sg){const[w,h]=fit();sg.style.width=w+'px';sg.style.height=h+'px';}$('.pl-track .mk').style.left=(posOf(cur)-2)+'px';},120);}});
window.addEventListener('resize',()=>{if(!P.classList.contains('open')||!slide)return;const sg=slide.querySelector('.ex>.stage');if(sg){const[w,h]=fit();sg.style.width=w+'px';sg.style.height=h+'px';}$('.pl-track .mk').style.left=(posOf(cur)-2)+'px';});
/* swipe on the backdrop (not on the demo) */
let sx=null;P.addEventListener('pointerdown',e=>{if(e.target.closest('.ex,.pl-panel,.pl-top,.pl-bot,.pl-nav'))return;sx=e.clientX;});P.addEventListener('pointerup',e=>{if(sx===null)return;const d=e.clientX-sx;sx=null;if(Math.abs(d)>60)go(d<0?1:-1);});
/* auto-hide chrome when idle; autoplay pauses while you interact */
function wake(){P.classList.remove('idle');idleT=0;}P.addEventListener('pointermove',wake);P.addEventListener('pointerdown',()=>{wake();el0=0;});
setInterval(()=>{if(!P.classList.contains('open'))return;idleT+=.1;if(idleT>3.2&&!panelMode&&!P.querySelector(':hover.pl-btn'))P.classList.add('idle');if(auto&&!document.hidden){el0+=.1;P.querySelector('.pl-auto b').style.width=Math.min(100,el0/dur*100)+'%';if(el0>=dur)go(1);}else P.querySelector('.pl-auto b').style.width='0';},100);

/* ---------- header button, library-to-library navigation, #/play/N route ---------- */
const top=document.getElementById('top');if(top){const b=document.createElement('button');b.id='playb';b.innerHTML='▶ Play all';b.title='Full-screen player: every example in order, with next / previous across libraries';b.onclick=()=>{const m=location.hash.match(/^#\/l\/([^/]+)/);let n=1;if(m){const k=seq().findIndex(x=>x.L.id===m[1]);if(k>=0)n=k+1;}openPlayer(n,true);};const ref=document.getElementById('cmdb')||document.getElementById('pz');top.insertBefore(b,ref);}
const _vl=viewLib;viewLib=function(id,exn){_vl(id,exn);const S=seq(),L=LIBMAP[id];if(!L)return;const first=S.findIndex(x=>x.L===L)+1;if(!first)return;const libsInOrder=[...new Set(S.map(x=>x.L))],k=libsInOrder.indexOf(L),pv=libsInOrder[(k-1+libsInOrder.length)%libsInOrder.length],nx=libsInOrder[(k+1)%libsInOrder.length],r=l=>{const a=S.findIndex(x=>x.L===l)+1;return'#'+a+(l.ex.length>1?'–#'+(a+l.ex.length-1):'');};
 const main=document.getElementById('main');if(!main)return;const nav=document.createElement('div');nav.className='libnav';nav.innerHTML='<a href="#/l/'+pv.id+'"><small>← previous library · '+r(pv)+'</small><b>'+esc(pv.name)+'</b></a><button data-n="'+first+'"><span>▶ Play from #'+first+'</span><small>full screen · ← → moves across libraries</small></button><a class="nx" href="#/l/'+nx.id+'"><small>next library · '+r(nx)+' →</small><b>'+esc(nx.name)+'</b></a>';
 const old=main.querySelector('.pn');if(old)old.replaceWith(nav);else(main.querySelector('.wrap')||main).appendChild(nav);nav.querySelector('button').onclick=()=>openPlayer(first,true);
 const hd=main.querySelector('h1');if(hd&&!hd.querySelector('.gnr')){hd.insertAdjacentHTML('beforeend',' <span class="gnr" style="font:700 13px var(--mono);color:#7c3aed;vertical-align:middle;padding:3px 10px;border-radius:99px;background:rgba(124,58,237,.1)">'+r(L)+'</span>');}};
document.addEventListener('keydown',e=>{if(P.classList.contains('open')||document.getElementById('cmdk')&&document.getElementById('cmdk').classList.contains('open'))return;if(e.target.closest&&e.target.closest('input,textarea,select,[contenteditable]'))return;if((e.key===']'||e.key==='[')&&location.hash.startsWith('#/l/')){const a=document.querySelector('.libnav '+(e.key===']'?'a.nx':'a:first-child'));a&&a.click();}});
const _r=route;route=function(){const p=location.hash.replace(/^#\/?/,'').split('/');if(p[0]==='play'){const n=clamp(parseInt(p[1],10)||1,1,seq().length);const E=seq()[n-1];try{history.replaceState(null,'','#/l/'+E.L.id+'/'+(E.i+1));}catch(e){}_r();setTimeout(()=>openPlayer(n,false),60);return;}if(P.classList.contains('open')&&!location.hash.startsWith('#/play'))closePlayer();_r();};
})();
