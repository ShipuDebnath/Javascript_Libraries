/* ===================== 3D & WebGL part 2: shaders, regl, Zdog, COBE, A-Frame ===================== */
const SH_WARP=`float h(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float n(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h(i),h(i+vec2(1.,0.)),f.x),mix(h(i+vec2(0.,1.)),h(i+vec2(1.,1.)),f.x),f.y);}
float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<6;i++){v+=a*n(p);p=p*2.02+vec2(1.7,9.2);a*=.5;}return v;}
void main(){vec2 uv=(gl_FragCoord.xy-.5*r)/r.y;vec2 q=vec2(fbm(uv*2.+t*.07),fbm(uv*2.+vec2(5.2,1.3)-t*.07));
vec2 w=vec2(fbm(uv*2.+4.*q+vec2(1.7,9.2)+.11*t),fbm(uv*2.+4.*q+vec2(8.3,2.8)+.09*t));float f=fbm(uv*2.+4.*w);
vec3 col=mix(vec3(.99,.975,1.),vec3(.78,.69,.99),smoothstep(.2,.8,f));col=mix(col,vec3(.49,.23,.93),smoothstep(.55,.95,f*f*1.6)*.8);
col=mix(col,vec3(.05,.58,.53),clamp(length(q)*.8-.35,0.,1.)*.5);col=mix(col,vec3(.93,.28,.6),smoothstep(.5,.85,f*length(w))*.6);
float e=fbm(uv*9.+w*3.);col+=.06*(e-.5);vec2 mm=(m-.5*r)/r.y;float d=length(uv-mm);col=mix(col,vec3(1.),.4*exp(-6.*d));gl_FragColor=vec4(col,1.);}`;
const SH_META=`void main(){vec2 uv=(gl_FragCoord.xy-.5*r)/r.y;vec2 mm=(m-.5*r)/r.y;float f=0.;vec2 g=vec2(0.);
for(int i=0;i<9;i++){float fi=float(i);vec2 c=.36*vec2(sin(t*.55+fi*1.7)*1.55,cos(t*.75+fi*2.3));vec2 d=uv-c;float k=.010/dot(d,d);f+=k;g+=-2.*k*d/dot(d,d);}
vec2 dm=uv-mm;float km=.016/(dot(dm,dm)+.0001);f+=km;g+=-2.*km*dm/(dot(dm,dm)+.0001);float hq=sqrt(max(1.-1./f,.0004));vec2 gh=g/(2.*f*f*hq);
vec3 bgc=mix(vec3(.995,.985,1.),vec3(.95,.93,.99),uv.y+.5);vec3 N=normalize(vec3(-gh*.16,1.));vec3 L=normalize(vec3(-.4,.6,.7));
vec3 base=mix(vec3(.43,.2,.9),vec3(.05,.58,.75),clamp(uv.y+.55,0.,1.));base=mix(base,vec3(.93,.25,.55),smoothstep(-.3,.8,uv.x)*.55);
float dif=max(dot(N,L),0.);float sp=pow(max(dot(reflect(-L,N),vec3(0.,0.,1.)),0.),40.);float fr=pow(1.-N.z,2.);
vec3 liq=base*(.45+.65*dif)+vec3(1.)*sp*.9+vec3(.9,.85,1.)*fr*.35;float e=smoothstep(.98,1.04,f);
float sh=smoothstep(.55,1.,f)*(1.-e);vec3 col=mix(bgc*(1.-sh*.12),liq,e);gl_FragColor=vec4(col,1.);}`;
const SH_SDF=`float sdBox(vec3 p,vec3 b){vec3 q=abs(p)-b;return length(max(q,0.))+min(max(q.x,max(q.y,q.z)),0.);}
float smin(float a,float b,float k){float h=clamp(.5+.5*(b-a)/k,0.,1.);return mix(b,a,h)-k*h*(1.-h);}
mat2 R(float a){float c=cos(a),s=sin(a);return mat2(c,-s,s,c);}
float obj(vec3 p){vec3 q=p;q.xz*=R(t*.5);q.xy*=R(t*.3);float b=sdBox(q,vec3(.5))-.09;float sp=length(q)-.72;float s2=length(p-vec3(sin(t*.9)*1.15,.15+cos(t*.7)*.35,cos(t*.9)*.3))-.36;
float tor=length(vec2(length(q.xz)-.95,q.y))-.08;float d=smin(mix(b,sp,.5+.5*sin(t*.6)),s2,.35);return smin(d,tor,.15);}
float map(vec3 p){return min(obj(p),p.y+1.15);}
vec3 nor(vec3 p){vec2 e=vec2(.0007,0.);return normalize(vec3(map(p+e.xyy)-map(p-e.xyy),map(p+e.yxy)-map(p-e.yxy),map(p+e.yyx)-map(p-e.yyx)));}
void main(){vec2 uv=(gl_FragCoord.xy-.5*r)/r.y;vec2 mm=m/r-.5;vec3 ro=vec3(0.,.55+mm.y*1.5,3.7);ro.xz*=R(mm.x*2.5);vec3 f=normalize(-ro),rt=normalize(cross(vec3(0,1,0),f)),u=cross(f,rt);vec3 rd=normalize(f*1.5+uv.x*rt+uv.y*u);
float d=0.;for(int i=0;i<110;i++){float hh=map(ro+rd*d);if(hh<.0008||d>20.)break;d+=hh;}
vec3 bgc=mix(vec3(.965,.95,.99),vec3(.995,.99,1.),uv.y+.5);vec3 col=bgc;
if(d<20.){vec3 p=ro+rd*d,n=nor(p),l=normalize(vec3(-.5,.9,.5));float dif=clamp(dot(n,l),0.,1.);float sh=1.,tt=.03;for(int i=0;i<48;i++){float hh=map(p+l*tt);sh=min(sh,10.*hh/tt);tt+=clamp(hh,.02,.25);if(hh<.001||tt>6.)break;}sh=clamp(sh,0.,1.);
float ao=clamp(.5+.5*map(p+n*.15)/.15,0.,1.);bool fl=obj(p)>.002;vec3 alb=fl?vec3(.96,.95,.985):mix(vec3(.43,.2,.92),vec3(.95,.42,.68),.5+.5*n.y+.25*n.x);
float fre=pow(1.-max(dot(n,-rd),0.),3.);vec3 refl=mix(vec3(.9,.88,.97),vec3(1.),reflect(rd,n).y*.5+.5);
float spe=pow(clamp(dot(reflect(rd,n),l),0.,1.),60.);col=alb*(.42*ao+.7*dif*sh)+(fl?vec3(0.):(spe*sh*.9+refl*fre*.45));if(fl)col=mix(col,bgc,smoothstep(3.,9.,d));}
gl_FragColor=vec4(col,1.);}`;
lib('ogl','OGL','c3d','A minimal (~30 KB) WebGL library for custom GLSL: abstract backgrounds, shader art and tiny 3D scenes.');
ex({t:'Domain-warped silk (6-octave fbm)',d:'A real GPU fragment shader: fractal noise warped through itself twice, graded into lavender, violet, teal and rose for a light interface.',hint:'Move the pointer to add a soft glow.',dom(el,s){glFrag(SH_WARP,el,s);},tick(s,t){if(s.render)s.render(t);},
 code:`import {Renderer,Program,Mesh,Triangle} from './libs/ogl.mjs';
const renderer=new Renderer({dpr:2}),gl=renderer.gl;document.body.appendChild(gl.canvas);
const program=new Program(gl,{vertex,fragment,uniforms:{uTime:{value:0},uMouse:{value:[.5,.5]}}});
const mesh=new Mesh(gl,{geometry:new Triangle(gl),program});
requestAnimationFrame(function f(t){program.uniforms.uTime.value=t*.001;renderer.render({scene:mesh});requestAnimationFrame(f);});`});
ex({t:'Liquid metaballs with a lit surface',d:'Nine implicit blobs plus your pointer; the field gradient becomes a surface normal, so the liquid is shaded with diffuse, specular and fresnel light.',hint:'Move the pointer into the liquid.',dom(el,s){glFrag(SH_META,el,s);},tick(s,t){if(s.render)s.render(t);},
 code:`float f=0.;vec2 g=vec2(0.);
for(int i=0;i<9;i++){vec2 d=uv-centre(i);float k=.010/dot(d,d);f+=k;g+=-2.*k*d/dot(d,d);}
vec3 N=normalize(vec3(-g*.012,1.));   // field gradient → normal
vec3 col=mix(bg,shade(base,N),smoothstep(.98,1.04,f));`});
ex({t:'Ray-marched signed distance fields',d:'No meshes: a box morphing into a sphere, smooth-unioned with a ring and a roaming ball, with soft shadows, ambient occlusion and fresnel reflections, all per pixel.',hint:'Move the pointer to orbit the camera.',dom(el,s){glFrag(SH_SDF,el,s);},tick(s,t){if(s.render)s.render(t);},
 code:`float map(vec3 p){
  float d=smin(mix(sdBox(q,vec3(.5))-.09,length(q)-.72,morph),length(p-ball)-.36,.35);
  return min(smin(d,sdTorus(q,vec2(.95,.08)),.15),p.y+1.15);}
for(int i=0;i<110;i++){float h=map(ro+rd*d);if(h<.0008)break;d+=h;}   // sphere tracing`});

const SH_JULIA=`void main(){vec2 uv=(gl_FragCoord.xy-.5*r)/r.y*2.5;vec2 mm=m/r-.5;vec2 c=vec2(-.7269+.035*cos(t*.33)+mm.x*.12,.1889+.035*sin(t*.25)+mm.y*.12);vec2 z=uv;float i=0.;vec2 dz=vec2(1.,0.);
for(int k=0;k<220;k++){if(dot(z,z)>1024.)break;dz=2.*vec2(z.x*dz.x-z.y*dz.y,z.x*dz.y+z.y*dz.x);z=vec2(z.x*z.x-z.y*z.y,2.*z.x*z.y)+c;i+=1.;}
float sm=i-log2(log2(dot(z,z)))+4.;float de=.5*sqrt(dot(z,z)/max(dot(dz,dz),1e-20))*log(dot(z,z));vec3 col=.55+.45*cos(6.2831*(sm*.022+vec3(.6,.7,.82)));col=mix(vec3(.995,.985,1.),col,smoothstep(1.,20.,sm));
col=mix(col,vec3(.2,.1,.45),1.-smoothstep(0.,.006,de));if(i>=219.)col=mix(vec3(.86,.8,1.),vec3(.45,.25,.9),clamp(length(z)*1.4,0.,1.));gl_FragColor=vec4(col,1.);}`;
const SH_VOR=`vec2 h2(vec2 p){p=vec2(dot(p,vec2(127.1,311.7)),dot(p,vec2(269.5,183.3)));return fract(sin(p)*43758.5453);}
void main(){vec2 uv=gl_FragCoord.xy/r.y*5.;vec2 mm=m/r.y*5.;vec2 i=floor(uv),f=fract(uv);float md=8.,md2=8.;vec2 id=vec2(0.),mr=vec2(0.);
for(int y=-1;y<=1;y++)for(int x=-1;x<=1;x++){vec2 g=vec2(float(x),float(y));vec2 o=h2(i+g);o=.5+.42*sin(t*.7+6.28*o);vec2 d=g+o-f;float dd=dot(d,d);if(dd<md){md2=md;md=dd;id=i+g;mr=d;}else if(dd<md2)md2=dd;}
float edge=sqrt(md2)-sqrt(md);vec3 c=.66+.27*cos(6.28*(h2(id).x*.6+vec3(.55,.68,.85))+1.5);c=mix(c,vec3(1.),.22);
vec3 N=normalize(vec3(-mr*1.6,1.));float l=dot(N,normalize(vec3(-.4,.6,.7)));c*=.75+.35*l;c+=pow(max(l,0.),18.)*.35;
float near=exp(-length(id+.5-mm)*.6);c=mix(c,vec3(.49,.23,.93),near*.5);c=mix(vec3(.16,.1,.3),c,smoothstep(.01,.05,edge));gl_FragColor=vec4(c,1.);}`;
const SH_MANDEL=`void main(){vec2 uv=(gl_FragCoord.xy-.5*r)/r.y;float z=exp(3.2+mod(t*.38,5.8));vec2 c=vec2(-.743643887,.131825904)+uv*2.6/z;vec2 q=vec2(0.);float i=0.;
for(int k=0;k<320;k++){q=vec2(q.x*q.x-q.y*q.y,2.*q.x*q.y)+c;if(dot(q,q)>256.)break;i+=1.;}
float sm=i-log2(log2(dot(q,q)))+4.;vec3 col=.5+.5*cos(3.4+sm*.11+vec3(0.,.55,1.1));col=mix(vec3(.995,.985,1.),col,smoothstep(0.,30.,sm));if(i>319.)col=vec3(.2,.12,.42);gl_FragColor=vec4(col,1.);}`;
lib('glsl','GlslCanvas / WebGL shaders','c3d','Run a fragment shader on a canvas with automatic time, resolution and mouse uniforms: fractals, noise and GPU art.',{ik:'GlslCanvas / WebGL shaders'});
ex({t:'Julia set with distance-estimated filaments',d:'An escape-time fractal with smooth colouring and a distance estimator that draws the hair-thin filaments crisply. The constant drifts and follows the pointer.',hint:'Move the pointer to morph the fractal.',dom(el,s){glFrag(SH_JULIA,el,s);},tick(s,t){if(s.render)s.render(t);},
 code:`<canvas class="glslCanvas" data-fragment-url="julia.frag" width="720" height="440"></canvas>
dz=2.*cmul(z,dz);z=cmul(z,z)+c;          // derivative for distance estimation
float de=.5*length(z)/length(dz)*log(length(z));`});
ex({t:'Bevelled Voronoi cells',d:'Cellular noise with moving seeds; the vector to each seed becomes a normal, giving every cell a soft bevel and highlight.',hint:'Move the pointer over the cells.',dom(el,s){glFrag(SH_VOR,el,s);},tick(s,t){if(s.render)s.render(t);},
 code:`for(int y=-1;y<=1;y++)for(int x=-1;x<=1;x++){vec2 g=vec2(x,y),o=.5+.42*sin(u_time*.7+6.28*hash2(i+g));
  vec2 d=g+o-f;float dd=dot(d,d);if(dd<md){md2=md;md=dd;mr=d;}else if(dd<md2)md2=dd;}
vec3 N=normalize(vec3(-mr*1.6,1.));   // bevel normal from the cell vector`});
ex({t:'Infinite Mandelbrot zoom',d:'A 320-iteration zoom into Seahorse Valley to about 8,000× before it loops (GPU float precision is the limit).',dom(el,s){glFrag(SH_MANDEL,el,s);},tick(s,t){if(s.render)s.render(t);},
 code:`float zoom=exp(1.5+mod(u_time*.38,7.5));
vec2 c=vec2(-.743643887,.131825904)+uv*2.6/zoom;
for(int k=0;k<320;k++){z=vec2(z.x*z.x-z.y*z.y,2.*z.x*z.y)+c;if(dot(z,z)>256.)break;n++;}`});

lib('regl','regl','c3d','Functional, stateless WebGL: concise draw commands for custom GPU renderers and big point clouds.');
ex({t:'80,000 GPU points morphing between shapes',d:'One draw call. Each point carries a random seed; the vertex shader builds a sphere, a torus and a wave field from it and blends between them.',hint:'Move the pointer to tilt the cloud.',
 dom(el,s){const d=Math.min(2,window.devicePixelRatio||1),cv=document.createElement('canvas');cv.width=W*d;cv.height=H*d;el.appendChild(cv);const gl=cv.getContext('webgl',{antialias:true});if(!gl){el.innerHTML='<p class="warn">WebGL not available.</p>';return;}
  const VS=`attribute vec3 a;uniform float t;uniform vec2 mo;uniform float asp;uniform float dpr;varying vec3 vc;varying float va;
  mat3 ry(float q){float c=cos(q),s=sin(q);return mat3(c,0.,-s,0.,1.,0.,s,0.,c);}mat3 rx(float q){float c=cos(q),s=sin(q);return mat3(1.,0.,0.,0.,c,s,0.,-s,c);}
  void main(){float th=a.x*6.2832,ph=acos(2.*a.y-1.);vec3 A=vec3(sin(ph)*cos(th),cos(ph),sin(ph)*sin(th))*.85;
  float u=a.y*6.2832;vec3 B=vec3((1.+.38*cos(u))*cos(th),.38*sin(u),(1.+.38*cos(u))*sin(th))*.72;
  float x=(a.x-.5)*2.6,z=(a.y-.5)*2.6;vec3 Cc=vec3(x,.28*sin(x*3.5+t*1.5)*cos(z*3.5+t),z);
  float st=mod(t*.16,3.);float k=smoothstep(0.,.35,fract(st));vec3 p;if(st<1.)p=mix(Cc,A,k);else if(st<2.)p=mix(A,B,k);else p=mix(B,Cc,k);
  p+=(a-.5)*.012;p=rx(.45+mo.y)*ry(t*.25+mo.x)*p;float w=3.2-p.z;gl_Position=vec4(p.x/w*3.4/asp,p.y/w*3.4,0.,1.);gl_PointSize=dpr*(1.8+2.6/w);
  vc=mix(mix(vec3(.43,.2,.9),vec3(.05,.58,.53),a.z),vec3(.88,.11,.43),smoothstep(.3,1.,p.y+.3)*.6);va=.5+.45*clamp(1.-(w-2.2)/2.,0.,1.);}`;
  const FS=`precision mediump float;varying vec3 vc;varying float va;void main(){vec2 c=gl_PointCoord-.5;float d=dot(c,c);if(d>.25)discard;gl_FragColor=vec4(vc,va*(1.-d*2.6));}`;
  const sh=(ty,src)=>{const o=gl.createShader(ty);gl.shaderSource(o,src);gl.compileShader(o);if(!gl.getShaderParameter(o,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(o));return o;};
  const pg=gl.createProgram();gl.attachShader(pg,sh(gl.VERTEX_SHADER,VS));gl.attachShader(pg,sh(gl.FRAGMENT_SHADER,FS));gl.linkProgram(pg);gl.useProgram(pg);
  const N=80000,arr=new Float32Array(N*3),r=rng(5);for(let i=0;i<N*3;i++)arr[i]=r();const b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,arr,gl.STATIC_DRAW);const loc=gl.getAttribLocation(pg,'a');gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,3,gl.FLOAT,false,0,0);
  const U=n=>gl.getUniformLocation(pg,n),ut=U('t'),um=U('mo'),ua=U('asp'),ud=U('dpr');gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);s.mo=[0,0];
  cv.addEventListener('pointermove',e=>{const R=cv.getBoundingClientRect();s.mo=[((e.clientX-R.left)/R.width-.5)*1.5,((e.clientY-R.top)/R.height-.5)*1.2];});
  s.render=t=>{gl.viewport(0,0,cv.width,cv.height);gl.clearColor(.99,.98,1,1);gl.clear(gl.COLOR_BUFFER_BIT);gl.uniform1f(ut,t);gl.uniform2f(um,s.mo[0],s.mo[1]);gl.uniform1f(ua,W/H);gl.uniform1f(ud,d);gl.drawArrays(gl.POINTS,0,N);};
  s.destroy=()=>{const x=gl.getExtension('WEBGL_lose_context');if(x)x.loseContext();};},tick(s,t){if(s.render)s.render(t);},
 code:`const regl=createREGL();
const draw=regl({vert,frag,attributes:{seed:seeds},uniforms:{t:({time})=>time,mouse:regl.prop('mouse')},
  count:80000,primitive:'points',blend:{enable:true,func:{src:'src alpha',dst:'one minus src alpha'}}});
regl.frame(()=>{regl.clear({color:[.99,.98,1,1]});draw({mouse});});`});
ex({t:'Instanced heat-map tiles',d:'A 72×44 grid of rounded tiles coloured by a moving Gaussian field: the kind of data-parallel layer regl makes trivial.',hint:'Move the pointer to place a heat source.',int:1,
 draw(ctx,s,t){bg(ctx,'#faf7ff');const N=72,M=44,cw=W/N,ch=H/M,hx=s.hover?s.mx/W:.5+.3*Math.cos(t*.7),hy=s.hover?s.my/H:.5+.3*Math.sin(t*.9);
  for(let i=0;i<N;i++)for(let j=0;j<M;j++){const x=(i+.5)/N,y=(j+.5)/M;const v=Math.exp(-((x-hx)*(x-hx)*9+(y-hy)*(y-hy)*14))+.55*Math.exp(-((x-.25-.1*Math.sin(t))*(x-.25-.1*Math.sin(t))*30+(y-.3)*(y-.3)*30))+.3*fbm(x*5+t*.2,y*5);ctx.fillStyle=scale(['#faf5ff','#e9d5ff','#c084fc','#7c3aed','#4c1d95','#1e1b4b'],clamp(v*.75,0,1));rr(ctx,i*cw+.6,j*ch+.6,cw-1.2,ch-1.2,2);ctx.fill();}
  cap(ctx,'regl({ attributes:{ offset, value }, instances: 3168 })');},
 code:`const tiles=regl({vert,frag,attributes:{corner:[[0,0],[1,0],[0,1],[1,1]],
  offset:{buffer:offsets,divisor:1},value:{buffer:values,divisor:1}},instances:72*44,count:4,primitive:'triangle strip'});`});

function zRender(ctx,items,ry,rx,cx,cy,sc){sc=sc||1;const L=items.map(it=>{const P=it.pts.map(p=>rot(p,ry,rx));return{it,P,z:P.reduce((a,p)=>a+p[2],0)/P.length+(it.zb||0)};}).sort((a,b)=>a.z-b.z);ctx.lineCap='round';ctx.lineJoin='round';
 for(const{it,P}of L){ctx.beginPath();P.forEach((p,i)=>i?ctx.lineTo(cx+p[0]*sc,cy+p[1]*sc):ctx.moveTo(cx+p[0]*sc,cy+p[1]*sc));if(P.length===1)ctx.lineTo(cx+P[0][0]*sc+.01,cy+P[0][1]*sc);if(it.closed)ctx.closePath();if(it.fill){ctx.fillStyle=it.color;ctx.fill();}ctx.strokeStyle=it.color;ctx.lineWidth=(it.stroke||1)*sc;ctx.stroke();}}
function zBox(c,w,h,d,cols,stroke){const x=w/2,y=h/2,z=d/2,F=[[[-x,-y,z],[x,-y,z],[x,y,z],[-x,y,z],cols.front],[[-x,-y,-z],[x,-y,-z],[x,y,-z],[-x,y,-z],cols.back||cols.front],[[-x,-y,-z],[-x,-y,z],[-x,y,z],[-x,y,-z],cols.left],[[x,-y,-z],[x,-y,z],[x,y,z],[x,y,-z],cols.right],[[-x,-y,-z],[x,-y,-z],[x,-y,z],[-x,-y,z],cols.top],[[-x,y,-z],[x,y,-z],[x,y,z],[-x,y,z],cols.bottom||cols.left]];
 return F.map(f=>({pts:f.slice(0,4).map(p=>add(p,c)),closed:true,fill:true,color:f[4],stroke:stroke||2}));}
lib('zdog','Zdog','c3d','A tiny pseudo-3D engine for flat, round, designer-friendly illustrations on canvas or SVG.');
ex({t:'Drag-rotate illustration: little robot',d:'Built only from Zdog primitives: boxes, round-capped strokes and points; flat colour per face and z-sorted with deliberately no lighting, which is the Zdog look.',hint:'Drag to spin the robot.',orbit:{ry:.5,rx:-.15,auto:.5},
 draw(ctx,s,t){bg(ctx,'#fbf6ff');circle(ctx,W/2,H/2,190,'#f1e7ff');const sw=Math.sin(t*3)*.5,I=[];
  I.push(...zBox([0,-62,0],86,64,64,{front:'#a78bfa',back:'#7c3aed',left:'#8b5cf6',right:'#8b5cf6',top:'#c4b5fd',bottom:'#6d28d9'},6));
  I.push({pts:[[-19,-68,33]],color:'#1e1b4b',stroke:16},{pts:[[19,-68,33]],color:'#1e1b4b',stroke:16},{pts:[[-16,-71,38]],color:'#fff',stroke:4,zb:1},{pts:[[22,-71,38]],color:'#fff',stroke:4,zb:1},{pts:[[-12,-46,33],[0,-41,33],[12,-46,33]],color:'#1e1b4b',stroke:4});
  I.push({pts:[[0,-95,0],[0,-120,0]],color:'#4c4369',stroke:4},{pts:[[0,-126,0]],color:'#e11d48',stroke:16});
  I.push(...zBox([0,18,0],74,78,46,{front:'#0ea5e9',back:'#0369a1',left:'#0284c7',right:'#0284c7',top:'#38bdf8',bottom:'#075985'},6));
  I.push({pts:[[0,10,24]],color:'#fde68a',stroke:18},{pts:[[0,10,26]],color:'#f59e0b',stroke:8,zb:1});
  I.push({pts:[[-44,-8,0],[-62,22+sw*10,sw*24],[-66,46+sw*8,sw*30]],color:'#7dd3fc',stroke:13},{pts:[[44,-8,0],[62,22-sw*10,-sw*24],[66,46-sw*8,-sw*30]],color:'#7dd3fc',stroke:13});
  I.push({pts:[[-66,52+sw*8,sw*30]],color:'#a78bfa',stroke:18},{pts:[[66,52-sw*8,-sw*30]],color:'#a78bfa',stroke:18});
  I.push({pts:[[-18,60,0],[-18,98,sw*12]],color:'#312e81',stroke:16},{pts:[[18,60,0],[18,98,-sw*12]],color:'#312e81',stroke:16},{pts:[[-18,104,sw*12+6],[-18,104,sw*12+18]],color:'#1e1b4b',stroke:16},{pts:[[18,104,-sw*12+6],[18,104,-sw*12+18]],color:'#1e1b4b',stroke:16});
  softShadow(ctx,W/2,H/2+128,90,14,.18);zRender(ctx,I,s.ry,s.rx,W/2,H/2+8,1.25);cap(ctx,'new Zdog.Box({ addTo: head, width: 86, stroke: 6, color: "#a78bfa" })');},
 code:`const illo=new Zdog.Illustration({element:'.zdog-canvas',dragRotate:true});
const head=new Zdog.Box({addTo:illo,width:86,height:64,depth:64,stroke:6,color:'#a78bfa',leftFace:'#8b5cf6',rightFace:'#8b5cf6',topFace:'#c4b5fd'});
new Zdog.Shape({addTo:head,translate:{x:-19,z:33},stroke:16,color:'#1e1b4b'});
(function a(){illo.updateRenderGraph();requestAnimationFrame(a);})();`});
ex({t:'Spinning logo cube & orbiting dots',d:'A Zdog box with a different flat colour per face and a ring of round points: playful loaders and logos.',orbit:{ry:.4,rx:-.5,auto:.9},
 draw(ctx,s,t){bg(ctx,'#f8f5ff');const I=zBox([0,0,0],110,110,110,{front:'#7c3aed',back:'#6d28d9',left:'#e11d48',right:'#0d9488',top:'#f59e0b',bottom:'#0284c7'},10);
  for(let i=0;i<16;i++){const a=i/16*TAU+t,y=Math.sin(a*2+t)*20;I.push({pts:[[Math.cos(a)*120,y,Math.sin(a)*120]],color:PAL[i%PAL.length],stroke:14});}
  zRender(ctx,I,s.ry,s.rx,W/2,H/2,1.35);cap(ctx,'new Zdog.Box({ leftFace:"#e11d48", rightFace:"#0d9488", topFace:"#f59e0b" })');},
 code:`new Zdog.Box({addTo:illo,width:110,height:110,depth:110,stroke:10,color:'#7c3aed',leftFace:'#e11d48',rightFace:'#0d9488',topFace:'#f59e0b'});
illo.rotate.y+=.02;illo.updateRenderGraph();`});

function dotGlobe(G,s,o){o=o||{};const E=EARTH(),n=E.pts.length;if(!s.dg){s.dg={P:new Float32Array(n*3),C:new Float32Array(n*4),S:new Float32Array(n)};E.pts.forEach((q,i)=>s.dg.P.set(q.p,i*3));}
 const D=s.dg,em=o.m||M4.id(),cur=o.cursor,land=o.land||[.27,.16,.55],sea=o.sea||[.6,.5,.88];for(let i=0;i<n;i++){const q=E.pts[i];let a=q.land?.92:.14,sz=q.land?1.3:.75,c=q.land?land:sea;
  if(cur){const w=M4.xf(em,q.p),d=len3(sub(w,cur));if(d<.45){const k=1-d/.45;sz*=1+k*1.7;a=Math.min(1,a+k*.7);c=mixc(c,[.88,.11,.43],k*.85);}}D.C[i*4]=c[0];D.C[i*4+1]=c[1];D.C[i*4+2]=c[2];D.C[i*4+3]=a;D.S[i]=sz;}
 G.points(D.P,D.C,D.S,{m:em,size:o.size||.5,soft:.35});}
lib('cobe','COBE','c3d','A ~5 KB WebGL dotted globe with markers: the classic landing-page globe.');
const COBE_M=[[40.71,-74],[51.5,-.12],[35.68,139.69],[-33.86,151.2],[30.04,31.24],[19.07,72.88],[-23.55,-46.63],[1.35,103.82],[37.77,-122.42],[55.75,37.62],[6.5,3.4],[-1.29,36.82]];
ex({t:'40,000-dot Earth that reacts to the cursor',d:'Forty thousand Fibonacci-sampled dots tested against traced continent outlines: land in ink, sea faint. Dots under the cursor swell and glow, markers pulse, and dragging spins with momentum.',hint:'Hover the globe · drag to spin.',orbit:{ry:.5,rx:.3,auto:.22},int:1,
 draw(ctx,s,t){const G=G3();if(!G.ok)return glFail(ctx);G.begin({eye:[0,0,3.6],fov:38});bg(ctx,'#ffffff');const g=ctx.createRadialGradient(W/2,H/2,140,W/2,H/2,260);g.addColorStop(0,'rgba(124,58,237,.10)');g.addColorStop(1,'rgba(124,58,237,0)');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
  const em=M4.mul(M4.RX(s.rx),M4.RY(s.ry));let cur=null;if(s.hover){const r=G.ray(s.mx,s.my),d=raySphere(r,[0,0,0],1);if(d>0)cur=add(r.o,mul(r.d,d));}
  G.draw(SPH(),{m:M4.S(.985),color:'#ffffff',rough:.9,op:.92,glass:0});dotGlobe(G,s,{m:em,cursor:cur});
  const MP=[],MC=[],MS=[];COBE_M.forEach((m,i)=>{const w=M4.xf(em,llv(m[0],m[1],1.01));if(w[2]<0)return;const pulse=(t*.8+i*.37)%1;MP.push(...w,...w);MC.push(.88,.11,.43,1,.88,.11,.43,(1-pulse)*.5);MS.push(5,5+pulse*14);});if(MP.length)G.points(new Float32Array(MP),new Float32Array(MC),new Float32Array(MS),{size:1,soft:.3});G.end(ctx);
  if(cur){const w=M4.xf(M4.inv(em),cur),la=Math.asin(clamp(w[1],-1,1))/D2R,lo=Math.atan2(-w[2],w[0])/D2R;tooltip(ctx,s.mx,s.my,[Math.abs(la).toFixed(1)+'°'+(la>=0?'N':'S')+'  '+Math.abs(lo).toFixed(1)+'°'+(lo>=0?'E':'W'),EARTH().isLand(la,lo)?'land':'ocean']);}
  cap(ctx,'createGlobe(canvas,{ mapSamples:40000, markers, onRender:s=>s.phi=phi+=.005 })');},
 code:`let phi=0;const globe=createGlobe(canvas,{devicePixelRatio:2,width:1200,height:1200,phi:0,theta:.3,dark:0,diffuse:1.2,
  mapSamples:40000,mapBrightness:6,baseColor:[1,1,1],markerColor:[.9,.1,.4],glowColor:[.95,.93,1],
  markers:[{location:[40.71,-74],size:.08},{location:[35.68,139.69],size:.05}],
  onRender:state=>{state.phi=phi+pointerDelta;phi+=.005;}});`});
ex({t:'Connections: great-circle arcs with travelling pulses',d:'Arcs lift off the dotted Earth along great circles and a bright pulse travels each one: the usual COBE + custom-layer pattern.',hint:'Drag to spin.',orbit:{ry:1.2,rx:.35,auto:.15},
 draw(ctx,s,t){const G=G3();if(!G.ok)return glFail(ctx);G.begin({eye:[0,0,3.7],fov:38});bg(ctx,'#fdfcff');const em=M4.mul(M4.RX(s.rx),M4.RY(s.ry));G.draw(SPH(),{m:M4.S(.985),color:'#ffffff',rough:.9,op:.94,glass:0});dotGlobe(G,s,{m:em,land:[.33,.2,.6]});
  const A=[[0,1],[1,4],[4,5],[5,7],[7,2],[2,3],[0,8],[8,2],[0,6],[1,9],[10,4],[11,5],[6,10],[3,7]];const LP=[],LC=[];
  A.forEach((ar,k)=>{const a=llv(...COBE_M[ar[0]]),b=llv(...COBE_M[ar[1]]),om=Math.acos(clamp(dot(a,b),-1,1)),sn=Math.sin(om)||1,u=(t*.32+k*.17)%1.25,P=f=>mul(add(mul(a,Math.sin((1-f)*om)/sn),mul(b,Math.sin(f*om)/sn)),1+.32*Math.sin(Math.PI*f)*Math.min(1,om/1.5));for(let i=0;i<60;i++){const f0=i/60,f1=(i+1)/60,d=u-f0,al=d>0&&d<.22?1-d/.22:0;LP.push(...P(f0),...P(f1));const c=al?[.88,.11,.43,.35+al*.65]:[.49,.23,.93,.3];LC.push(...c,...c);}});
  G.lines(new Float32Array(LP),new Float32Array(LC),{m:em});const MP=[],MC=[];COBE_M.forEach(m=>{MP.push(...llv(m[0],m[1],1.01));MC.push(.88,.11,.43,1);});G.points(new Float32Array(MP),new Float32Array(MC),null,{m:em,size:3.5,soft:.25});G.end(ctx);cap(ctx,'arcs = routes.map(([a,b]) => greatCircle(a, b, lift=.32))');},
 code:`// COBE renders the dotted globe; arcs are drawn by your own layer each frame
onRender:state=>{state.phi=phi;phi+=.004;overlay.drawArcs(project(arcs,state.phi,state.theta));}`});

lib('aframe','A-Frame','c3d','Declarative WebXR: build VR/AR scenes with HTML tags on top of Three.js.',{isNew:true});
ex({t:'Walkable VR room with fuse cursor',d:'An <a-scene> with sky, glossy floor, primitives and a fuse cursor. Look around with the pointer and walk with W A S D; the gaze ring fills when it rests on an object.',hint:'Click the scene, drag to look, W A S D to walk.',int:1,
 init(s){s.cam=[0,1.6,5];s.yaw=0;s.pitch=-.12;s.keys={};s.onMove=(x,y,dx,dy)=>{if(s.down){s.yaw-=dx*.006;s.pitch=clamp(s.pitch-dy*.006,-1.2,1.2);}};s.onKey=e=>{s.keys[e.key.toLowerCase()]=true;e.preventDefault();};const ku=e=>{s.keys[e.key.toLowerCase()]=false;};window.addEventListener('keyup',ku);s.destroy=()=>window.removeEventListener('keyup',ku);s.gz=0;s.last=-1;
  s.O=[[[-1.6,.55,-1],()=>GM('rbox2',()=>GEO.superq(.4,.4,.4,.3,40,28)),'#7c3aed',.55,1,'box'],[[1.8,.8,-2.6],()=>GM('vrcol',()=>GEO.superq(.35,.8,.35,.5,40,28)),'#e11d48',.5,1,'column'],[[.2,1.3,-3.2],SPH,'#0284c7',.62,.6,'sphere'],[[-.2,.7,1.2],()=>GM('vrcyl',()=>GEO.superq(.45,.7,.45,.2,48,24)),'#0d9488',.5,1,'cylinder'],[[2.4,.6,.6],SMALLKNOT,'#d97706',.5,2.4,'knot']];},
 draw(ctx,s,t,dt){const G=G3();if(!G.ok)return glFail(ctx);const k=s.keys,sp=2.2*dt,fw=[-Math.sin(s.yaw),0,-Math.cos(s.yaw)],rt=[Math.cos(s.yaw),0,-Math.sin(s.yaw)];if(k.w||k.arrowup)s.cam=add(s.cam,mul(fw,sp));if(k.s||k.arrowdown)s.cam=add(s.cam,mul(fw,-sp));if(k.a||k.arrowleft)s.cam=add(s.cam,mul(rt,-sp));if(k.d||k.arrowright)s.cam=add(s.cam,mul(rt,sp));s.cam[0]=clamp(s.cam[0],-6,6);s.cam[2]=clamp(s.cam[2],-6,7);
  if(!s.down&&!s.hover)s.yaw=Math.sin(t*.25)*.35;const dir=[-Math.sin(s.yaw)*Math.cos(s.pitch),Math.sin(s.pitch),-Math.cos(s.yaw)*Math.cos(s.pitch)];G.begin({eye:s.cam,target:add(s.cam,dir),fov:62,fogD:.08,fog:hexv('#f3ecfb')});
  const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,'#c7d2fe');g.addColorStop(.55,'#fae8ff');g.addColorStop(1,'#f5f0fb');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
  G.draw(FLOOR('vr',16,0),{color:'#efe8f8',rough:.15,clear:1});gridLines(G,.002,8,1,[.49,.23,.93,.22]);
  const ray={o:s.cam,d:norm(dir)};let hit=-1,bd=1e9;s.O.forEach((o,i)=>{const d=raySphere(ray,o[0],o[3]);if(d>0&&d<bd){bd=d;hit=i;}});s.O.forEach((o,i)=>G.draw(o[1](),{m:M4.chain(M4.T(...o[0]),M4.RY(t*.4+i),M4.S(o[4])),color:o[2],rough:.25,clear:1,rim:'#ffffff',rimK:hit===i?.9:0}));G.end(ctx);
  if(hit!==s.last){s.gz=0;s.last=hit;}if(hit>=0)s.gz=Math.min(1,s.gz+dt/1.4);circle(ctx,W/2,H/2,hit>=0?12:7,null,hit>=0?'#e11d48':'#140E29',2.5);if(hit>=0){ctx.strokeStyle='#e11d48';ctx.lineWidth=4;ctx.beginPath();ctx.arc(W/2,H/2,12,-Math.PI/2,-Math.PI/2+TAU*s.gz);ctx.stroke();if(s.gz>=1)text(ctx,'click! ('+s.O[hit][5]+')',W/2+18,H/2-12,'#e11d48',13,'left',FONT,700);}
  hud(ctx,['<a-camera wasd-controls>','pos '+s.cam.map(v=>v.toFixed(1)).join(', ')],14,14);},
 code:`<a-scene fog="type: exponential; color:#f3ecfb">
  <a-box position="-1.6 .55 -1" color="#7c3aed" material="roughness:.25"></a-box>
  <a-sphere position=".2 1.3 -3.2" radius=".62" color="#0284c7"></a-sphere>
  <a-plane rotation="-90 0 0" width="16" height="16" color="#efe8f8"></a-plane>
  <a-sky color="#e9e3ff"></a-sky>
  <a-camera wasd-controls look-controls><a-cursor fuse="true" fuse-timeout="1400"></a-cursor></a-camera>
</a-scene>`});
