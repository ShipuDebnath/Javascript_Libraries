'use strict';
/* ============ core math ============ */
const TAU=Math.PI*2,W=720,H=440;
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v)),lerp=(a,b,t)=>a+(b-a)*t;
const smooth=(a,b,x)=>{const t=clamp((x-a)/(b-a),0,1);return t*t*(3-2*t);};
const ease=t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2,easeOut=t=>1-Math.pow(1-t,3),easeIn=t=>t*t*t;
const elastic=t=>t<=0?0:t>=1?1:Math.pow(2,-10*t)*Math.sin((t*10-.75)*TAU/3)+1;
const backOut=t=>{const c1=1.70158,c3=c1+1;return 1+c3*Math.pow(t-1,3)+c1*Math.pow(t-1,2);};
const bounce=t=>{const n=7.5625,d=2.75;if(t<1/d)return n*t*t;if(t<2/d)return n*(t-=1.5/d)*t+.75;if(t<2.5/d)return n*(t-=2.25/d)*t+.9375;return n*(t-=2.625/d)*t+.984375;};
function rng(seed){let s=Math.floor(seed)%2147483647;if(s<=0)s+=2147483646;return()=>(s=s*16807%2147483647)/2147483647;}
function gauss(r){return Math.sqrt(-2*Math.log(r()+1e-9))*Math.cos(TAU*r());}
function hash(x,y){const h=Math.sin(x*127.1+y*311.7)*43758.5453;return h-Math.floor(h);}
function noise(x,y){const xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi,u=xf*xf*(3-2*xf),v=yf*yf*(3-2*yf);return hash(xi,yi)*(1-u)*(1-v)+hash(xi+1,yi)*u*(1-v)+hash(xi,yi+1)*(1-u)*v+hash(xi+1,yi+1)*u*v;}
function fbm(x,y){return noise(x,y)*.5+noise(x*2,y*2)*.25+noise(x*4,y*4)*.125+noise(x*8,y*8)*.0625;}
const add=(a,b)=>[a[0]+b[0],a[1]+b[1],a[2]+b[2]],sub=(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]],mul=(a,k)=>[a[0]*k,a[1]*k,a[2]*k],dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const len3=a=>Math.hypot(a[0],a[1],a[2]),norm=a=>{const l=len3(a)||1;return[a[0]/l,a[1]/l,a[2]/l];};
function rot(p,ry,rx){let c=Math.cos(ry),s=Math.sin(ry);const x1=p[0]*c+p[2]*s,z1=-p[0]*s+p[2]*c;c=Math.cos(rx);s=Math.sin(rx);return[x1,p[1]*c-z1*s,p[1]*s+z1*c];}
function rotZ(p,a){const c=Math.cos(a),s=Math.sin(a);return[p[0]*c-p[1]*s,p[0]*s+p[1]*c,p[2]];}
function pr(p,sc,d,cx,cy){d=d||5;const k=d/(d-p[2]);return[(cx===undefined?W/2:cx)+p[0]*sc*k,(cy===undefined?H/2:cy)+p[1]*sc*k,p[2],k];}
function ll(lat,lon,alt){alt=alt||0;const c=Math.cos(lat);return[c*Math.cos(lon)*(1+alt),-Math.sin(lat)*(1+alt),c*Math.sin(lon)*(1+alt)];}
const D2R=Math.PI/180;

/* ============ colour ============ */
const C={bg:'#ffffff',bg2:'#f7f6f3',ink:'#1c1917',ink2:'#44403c',mut:'#78716c',faint:'#a8a29e',grid:'#ece9e3',line:'#d6d3cd',
 indigo:'#4f46e5',teal:'#0d9488',rose:'#e11d48',amber:'#d97706',sky:'#0284c7',violet:'#7c3aed',emerald:'#059669',pink:'#db2777',orange:'#ea580c',cyan:'#0891b2',lime:'#65a30d'};
const PAL=['#4f46e5','#0d9488','#e11d48','#d97706','#0284c7','#7c3aed','#059669','#db2777','#ea580c','#0891b2'];
function hsl(h,s,l,a){return 'hsla('+Math.round(h)+','+Math.round(s)+'%,'+Math.round(l)+'%,'+(a===undefined?1:a)+')';}
function hsl2rgb(h,s,l){s/=100;l/=100;const k=n=>(n+h/30)%12,a=s*Math.min(l,1-l),f=n=>l-a*Math.max(-1,Math.min(k(n)-3,9-k(n),1));return[Math.round(f(0)*255),Math.round(f(8)*255),Math.round(f(4)*255)];}
function hex2rgb(h){if(Array.isArray(h))return h;if(h.startsWith('rgb')){const m=h.match(/[\d.]+/g).map(Number);return[m[0],m[1],m[2]];}if(h.startsWith('hsl')){const m=h.match(/[\d.]+/g).map(Number);return hsl2rgb(m[0],m[1],m[2]);}h=h.replace('#','');if(h.length==3)h=h.split('').map(c=>c+c).join('');const n=parseInt(h,16);return[n>>16&255,n>>8&255,n&255];}
function hex2rgb2(h){const c=hex2rgb(h);return '#'+c.map(v=>Math.round(v).toString(16).padStart(2,'0')).join('');}
function rgba(h,a){const c=hex2rgb(h);return 'rgba('+c[0]+','+c[1]+','+c[2]+','+a+')';}
function mixHex(a,b,t){const x=hex2rgb(a),y=hex2rgb(b);return 'rgb('+Math.round(lerp(x[0],y[0],t))+','+Math.round(lerp(x[1],y[1],t))+','+Math.round(lerp(x[2],y[2],t))+')';}
const VIRIDIS=['#440154','#482878','#3e4989','#31688e','#26828e','#1f9e89','#35b779','#6ece58','#b5de2b','#fde725'];
const MAGMA=['#000004','#1c1046','#4f127b','#812581','#b5367a','#e55964','#fb8761','#fec287','#fcfdbf'];
const SPECT=['#5e4fa2','#3288bd','#66c2a5','#abdda4','#e6f598','#fee08b','#fdae61','#f46d43','#d53e4f'];
function scale(cols,u){u=clamp(u,0,1)*(cols.length-1);const i=Math.min(cols.length-2,Math.floor(u));return mixHex(cols[i],cols[i+1],u-i);}
function ramp(u){return scale(VIRIDIS,u);}

/* ============ canvas helpers ============ */
const FONT='"Inter","Segoe UI",system-ui,-apple-system,sans-serif',MONO='ui-monospace,"JetBrains Mono","SF Mono",Menlo,Consolas,monospace';
function bg(ctx,c){ctx.fillStyle=c||C.bg;ctx.fillRect(0,0,W,H);}
function paper(ctx,c,dot){bg(ctx,c||C.bg);ctx.fillStyle=dot||'#e9e6e0';for(let x=12;x<W;x+=24)for(let y=12;y<H;y+=24)ctx.fillRect(x,y,1.6,1.6);}
function gridBg(ctx,step,c,col){bg(ctx,c||C.bg);ctx.strokeStyle=col||'#f0eee9';ctx.lineWidth=1;ctx.beginPath();for(let x=0;x<=W;x+=step){ctx.moveTo(x+.5,0);ctx.lineTo(x+.5,H);}for(let y=0;y<=H;y+=step){ctx.moveTo(0,y+.5);ctx.lineTo(W,y+.5);}ctx.stroke();}
function vgrad(ctx,a,b){const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,a);g.addColorStop(1,b);ctx.fillStyle=g;ctx.fillRect(0,0,W,H);}
function text(ctx,str,x,y,col,size,align,font,weight){ctx.fillStyle=col||C.ink;ctx.font=(weight?weight+' ':'')+(size||16)+'px '+(font||FONT);ctx.textAlign=align||'left';ctx.textBaseline='alphabetic';ctx.fillText(str,x,y);}
function cap(ctx,str,dark){ctx.font='12.5px '+MONO;const w=ctx.measureText(str).width;ctx.fillStyle=dark?'rgba(15,15,20,.55)':'rgba(255,255,255,.86)';rr(ctx,10,H-30,w+18,22,6);ctx.fill();ctx.fillStyle=dark?'#e7e5e4':'#78716c';ctx.textAlign='left';ctx.textBaseline='middle';ctx.fillText(str,19,H-19);ctx.textBaseline='alphabetic';}
function badge(ctx,str,x,y,bgc,fg,align){ctx.font='600 13px '+FONT;const w=ctx.measureText(str).width+16;if(align==='right')x-=w;ctx.fillStyle=bgc||'#eef2ff';rr(ctx,x,y,w,24,12);ctx.fill();ctx.fillStyle=fg||C.indigo;ctx.textAlign='left';ctx.textBaseline='middle';ctx.fillText(str,x+8,y+12.5);ctx.textBaseline='alphabetic';return w;}
function rr(ctx,x,y,w,h,r){r=Math.min(r,Math.abs(w)/2,Math.abs(h)/2);ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();}
function circle(ctx,x,y,r,fill,stroke,lw){ctx.beginPath();ctx.arc(x,y,Math.max(0,r),0,TAU);if(fill){ctx.fillStyle=fill;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=lw||1;ctx.stroke();}}
function poly(ctx,pts,fill,stroke,lw,open){ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));if(!open)ctx.closePath();if(fill){ctx.fillStyle=fill;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=lw||1;ctx.stroke();}}
function line(ctx,x1,y1,x2,y2,col,lw,dash){ctx.strokeStyle=col;ctx.lineWidth=lw||1;if(dash)ctx.setLineDash(dash);ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();if(dash)ctx.setLineDash([]);}
function arrow(ctx,x1,y1,x2,y2,col,lw,hd){hd=hd||10;line(ctx,x1,y1,x2,y2,col,lw);const a=Math.atan2(y2-y1,x2-x1);ctx.fillStyle=col;ctx.beginPath();ctx.moveTo(x2,y2);ctx.lineTo(x2-hd*Math.cos(a-.42),y2-hd*Math.sin(a-.42));ctx.lineTo(x2-hd*Math.cos(a+.42),y2-hd*Math.sin(a+.42));ctx.closePath();ctx.fill();}
function sphere(ctx,x,y,r,h,s,l){if(r<=.2)return;s=s===undefined?70:s;l=l===undefined?55:l;const g=ctx.createRadialGradient(x-r*.38,y-r*.42,r*.06,x,y,r);g.addColorStop(0,hsl(h,s*.6,Math.min(97,l+38)));g.addColorStop(.45,hsl(h,s,l));g.addColorStop(1,hsl(h,s,Math.max(8,l-24)));ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.fill();}
function softShadow(ctx,x,y,rx,ry,a){const g=ctx.createRadialGradient(x,y,0,x,y,rx);g.addColorStop(0,'rgba(28,25,23,'+(a||.22)+')');g.addColorStop(1,'rgba(28,25,23,0)');ctx.save();ctx.translate(x,y);ctx.scale(1,ry/rx);ctx.translate(-x,-y);ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,rx,0,TAU);ctx.fill();ctx.restore();}
function smoothClosed(ctx,pts){const n=pts.length;ctx.beginPath();for(let i=0;i<n;i++){const p0=pts[(i-1+n)%n],p1=pts[i],p2=pts[(i+1)%n],p3=pts[(i+2)%n];if(i===0)ctx.moveTo(p1[0],p1[1]);ctx.bezierCurveTo(p1[0]+(p2[0]-p0[0])/6,p1[1]+(p2[1]-p0[1])/6,p2[0]-(p3[0]-p1[0])/6,p2[1]-(p3[1]-p1[1])/6,p2[0],p2[1]);}ctx.closePath();}
function smoothOpen(ctx,pts){ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);for(let i=0;i<pts.length-1;i++){const p0=pts[Math.max(0,i-1)],p1=pts[i],p2=pts[i+1],p3=pts[Math.min(pts.length-1,i+2)];ctx.bezierCurveTo(p1[0]+(p2[0]-p0[0])/6,p1[1]+(p2[1]-p0[1])/6,p2[0]-(p3[0]-p1[0])/6,p2[1]-(p3[1]-p1[1])/6,p2[0],p2[1]);}}
function polyPt(pts,u){let tot=0;const ls=[];for(let i=1;i<pts.length;i++){const l=Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1]);ls.push(l);tot+=l;}let d=clamp(u,0,1)*tot;for(let i=0;i<ls.length;i++){if(d<=ls[i]){const f=ls[i]?d/ls[i]:0;return[lerp(pts[i][0],pts[i+1][0],f),lerp(pts[i][1],pts[i+1][1],f)];}d-=ls[i];}return pts[pts.length-1];}
function tooltip(ctx,x,y,lines,opt){opt=opt||{};ctx.font='13px '+FONT;let w=0;lines.forEach(l=>{w=Math.max(w,ctx.measureText(l).width);});w+=20;const h=lines.length*18+12;let bx=clamp(x-w/2,4,W-w-4),by=y-h-12;if(by<4)by=y+16;ctx.save();ctx.shadowColor='rgba(0,0,0,.15)';ctx.shadowBlur=12;ctx.shadowOffsetY=3;ctx.fillStyle=opt.bg||'#1c1917';rr(ctx,bx,by,w,h,7);ctx.fill();ctx.restore();lines.forEach((l,i)=>text(ctx,l,bx+10,by+20+i*18,i===0&&lines.length>1?'#fff':'#e7e5e4',13,'left',FONT,i===0&&lines.length>1?600:400));}
function cvD(){if(document.body.classList.contains("perf"))return window.__hiD?Math.min(1.5,window.__hiD):1;return window.__hiD||Math.min(2,Math.max(1,window.devicePixelRatio||1));}
function mkCv(el,w,h){w=w||W;h=h||H;const d=cvD(),cv=document.createElement('canvas');cv.width=w*d;cv.height=h*d;el.appendChild(cv);const ctx=cv.getContext('2d');ctx.setTransform(d,0,0,d,0,0);return{cv,ctx,w,h,d};}

/* ============ 3D mesh helpers ============ */
function paramQuads(f,U,V){const P=[];for(let i=0;i<=U;i++){P[i]=[];for(let j=0;j<=V;j++)P[i][j]=f(i/U,j/V);}const Q=[];for(let i=0;i<U;i++)for(let j=0;j<V;j++)Q.push({v:[P[i][j],P[i+1][j],P[i+1][j+1],P[i][j+1]],u:(i+.5)/U,w:(j+.5)/V});return Q;}
function boxQuads(c,sx,sy,sz,extra){const F=[[[0,0,1],[[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]]],[[0,0,-1],[[1,-1,-1],[-1,-1,-1],[-1,1,-1],[1,1,-1]]],[[1,0,0],[[1,-1,1],[1,-1,-1],[1,1,-1],[1,1,1]]],[[-1,0,0],[[-1,-1,-1],[-1,-1,1],[-1,1,1],[-1,1,-1]]],[[0,-1,0],[[-1,-1,-1],[1,-1,-1],[1,-1,1],[-1,-1,1]]],[[0,1,0],[[-1,1,1],[1,1,1],[1,1,-1],[-1,1,-1]]]];return F.map(([n,vs],k)=>Object.assign({v:vs.map(v=>[c[0]+v[0]*sx,c[1]+v[1]*sy,c[2]+v[2]*sz]),face:k,bc:c},extra||{}));}
const LIGHT=norm([-.45,-.75,.55]);
function renderQuads(ctx,Q,o){o=o||{};const L=o.light||LIGHT,ry=o.ry||0,rx=o.rx||0,sc=o.sc||140,d=o.d||6,cx=o.cx,cy=o.cy,out=[];const tf=o.tf||(p=>rot(p,ry,rx)),P=o.proj||(p=>pr(p,sc,d,cx,cy)),cam=o.cam||[0,0,d];
 for(const q of Q){const r=q.v.map(tf);if(o.near&&r.some(p=>p[2]>-o.near))continue;let n=norm(cross(sub(r[2],r[0]),sub(r[3],r[1])));const c=mul(add(add(r[0],r[1]),add(r[2],r[3])),.25),vd=norm(sub(cam,c));let f=dot(n,vd);
  if(q.bc){n=norm(sub(c,tf(q.bc)));f=dot(n,vd);}
  if(f<0){if(o.cull||q.bc)continue;n=mul(n,-1);}
  const dif=Math.max(0,dot(n,L)),hv=norm(add(L,vd)),spec=Math.pow(Math.max(0,dot(n,hv)),o.shin||36);
  const fill=o.col?o.col(q,dif,spec,n):hsl(q.h===undefined?(o.h||230):q.h,o.s||65,clamp(28+dif*42+spec*(o.specK||28),5,97));
  out.push({pts:r.map(P),z:c[2],fill,q});}
 if(o.extra)for(const e of o.extra)out.push(e);
 out.sort((a,b)=>a.z-b.z);ctx.lineJoin='round';
 for(const it of out){if(it.fn){it.fn();continue;}ctx.beginPath();it.pts.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.closePath();ctx.fillStyle=it.fill;ctx.fill();ctx.strokeStyle=o.wire?(o.wire===true?'rgba(28,25,23,.35)':o.wire):it.fill;ctx.lineWidth=o.wire?.8:.6;ctx.stroke();}
 return out;}
function torusKnot(U,V,p,q,R,r){const C3=u=>[(2+Math.cos(q*u))*Math.cos(p*u)*R,(2+Math.cos(q*u))*Math.sin(p*u)*R,Math.sin(q*u)*R],e=.002;
 return paramQuads((a,b)=>{const u=a*TAU,c=C3(u),A=C3(u+e),B=C3(u-e),T=norm(sub(A,B)),N=norm(sub(add(A,B),mul(c,2))),Bn=cross(T,N),th=b*TAU;return add(c,mul(add(mul(N,Math.cos(th)),mul(Bn,Math.sin(th))),r));},U,V);}
function sphereQuads(c,r,U,V,h){return paramQuads((a,b)=>{const th=a*TAU,ph=b*Math.PI;return[c[0]+r*Math.sin(ph)*Math.cos(th),c[1]-r*Math.cos(ph),c[2]+r*Math.sin(ph)*Math.sin(th)];},U,V).map(q=>(q.h=h,q));}
function wireBox(ctx,ry,rx,sc,d,b,col){const V=[];for(const x of[-b[0],b[0]])for(const y of[-b[1],b[1]])for(const z of[-b[2],b[2]])V.push(pr(rot([x,y,z],ry,rx),sc,d));ctx.strokeStyle=col||'rgba(120,113,108,.35)';ctx.lineWidth=1;[[0,1],[2,3],[4,5],[6,7],[0,2],[1,3],[4,6],[5,7],[0,4],[1,5],[2,6],[3,7]].forEach(e=>{ctx.beginPath();ctx.moveTo(V[e[0]][0],V[e[0]][1]);ctx.lineTo(V[e[1]][0],V[e[1]][1]);ctx.stroke();});}
function floorGrid(ctx,ry,rx,sc,d,y,n,step,col){ctx.strokeStyle=col||'rgba(120,113,108,.22)';ctx.lineWidth=1;const P=p=>pr(rot(p,ry,rx),sc,d);for(let i=-n;i<=n;i++){let a=P([i*step,y,-n*step]),b=P([i*step,y,n*step]);ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();a=P([-n*step,y,i*step]);b=P([n*step,y,i*step]);ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();}}

/* fibonacci globe points */
const GL=(()=>{const a=[],N=2600;for(let i=0;i<N;i++){const y=1-2*(i+.5)/N,r=Math.sqrt(1-y*y),th=i*2.39996,x=Math.cos(th)*r,z=Math.sin(th)*r,lon=Math.atan2(z,x),lat=Math.asin(y);a.push({p:[x,-y,z],lat,lon,land:fbm(lon*1.25+7,lat*1.4+7)>.52});}return a;})();
function lightGlobe(ctx,ry,rx,sc,o){o=o||{};const cx=o.cx||W/2,cy=o.cy||H/2;softShadow(ctx,cx,cy+sc*1.05,sc*.9,sc*.16,.18);const g=ctx.createRadialGradient(cx-sc*.35,cy-sc*.4,sc*.1,cx,cy,sc);g.addColorStop(0,o.c0||'#ffffff');g.addColorStop(1,o.c1||'#dbe4f3');ctx.fillStyle=g;ctx.beginPath();ctx.arc(cx,cy,sc,0,TAU);ctx.fill();
 for(const q of GL){const r=rot(q.p,ry,rx);if(r[2]<.02)continue;const x=cx+r[0]*sc,y=cy+r[1]*sc;if(q.land){ctx.fillStyle=o.land?o.land(q,r):hsl(o.hue||232,55,Math.round(62-r[2]*22),.9);const s=1.3+r[2]*1.6;ctx.fillRect(x-s/2,y-s/2,s,s);}else if(o.sea){ctx.fillStyle=o.sea;ctx.fillRect(x-.6,y-.6,1.2,1.2);}}
 ctx.strokeStyle=o.rim||'rgba(79,70,229,.18)';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(cx,cy,sc,0,TAU);ctx.stroke();}

/* ============ WebGL fragment shader helper ============ */
function glFrag(frag,el,s,uniforms){const d=cvD(),cv=document.createElement('canvas');cv.width=W*d;cv.height=H*d;el.appendChild(cv);
 const gl=cv.getContext('webgl',{preserveDrawingBuffer:false,antialias:false});if(!gl){el.insertAdjacentHTML('beforeend','<p class="warn">WebGL is not available in this browser.</p>');return;}
 const sh=(type,src)=>{const o=gl.createShader(type);gl.shaderSource(o,src);gl.compileShader(o);if(!gl.getShaderParameter(o,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(o));return o;};
 const pg=gl.createProgram();gl.attachShader(pg,sh(gl.VERTEX_SHADER,'attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}'));
 gl.attachShader(pg,sh(gl.FRAGMENT_SHADER,'#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\nuniform vec2 r;uniform float t;uniform vec2 m;uniform float k;uniform float k2;\n'+frag));gl.linkProgram(pg);if(!gl.getProgramParameter(pg,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(pg));gl.useProgram(pg);
 const b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),gl.STATIC_DRAW);const loc=gl.getAttribLocation(pg,'p');gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,2,gl.FLOAT,false,0,0);
 const U={r:gl.getUniformLocation(pg,'r'),t:gl.getUniformLocation(pg,'t'),m:gl.getUniformLocation(pg,'m'),k:gl.getUniformLocation(pg,'k'),k2:gl.getUniformLocation(pg,'k2')};
 s.gmx=cv.width/2;s.gmy=cv.height/2;s.k=s.k||0;s.k2=s.k2||0;
 cv.addEventListener('pointermove',e=>{const R=cv.getBoundingClientRect();s.gmx=(e.clientX-R.left)*cv.width/R.width;s.gmy=cv.height-(e.clientY-R.top)*cv.height/R.height;s.hover=true;});
 cv.addEventListener('pointerleave',()=>{s.hover=false;});cv.addEventListener('pointerdown',e=>{if(s.onDown)s.onDown(e);});
 s.render=t=>{gl.viewport(0,0,cv.width,cv.height);gl.uniform2f(U.r,cv.width,cv.height);gl.uniform1f(U.t,t);gl.uniform2f(U.m,s.gmx,s.gmy);gl.uniform1f(U.k,s.k);gl.uniform1f(U.k2,s.k2);gl.drawArrays(gl.TRIANGLES,0,3);};
 s.destroy=()=>{const x=gl.getExtension('WEBGL_lose_context');if(x)x.loseContext();};}

/* ============ registry ============ */
const CATS=[
 ['c3d','3D & WebGL','Engines, GPU shaders, globes and virtual worlds','#4f46e5'],
 ['anim','Animation & Motion','Timelines, springs, vector playback and text effects','#db2777'],
 ['charts','Charts & Data Viz','From bespoke D3 art to dashboards and scientific plots','#0284c7'],
 ['draw','Drawing & Vector','Generative art, Bézier paths, editors and SVG','#d97706'],
 ['fx','Particles & Effects','Backgrounds, confetti, sprites and gradients','#7c3aed'],
 ['phys','Physics','Rigid bodies, constraints, chaos and soft bodies','#ea580c'],
 ['net','Diagrams & Networks','Flowcharts, graphs, timelines and Gantt charts','#0d9488'],
 ['bio','Biology & Chemistry','Molecules, proteins, genomes and chromosomes','#059669'],
 ['gis','Maps & GIS','Maps, globes, geospatial analysis and rasters','#0891b2'],
 ['math','Mathematics','Geometry, function plots, 3D maths and equations','#6d28d9'],
 ['ui','UI Components','Carousels, slides, grids, tours, tooltips and icons','#be185d'],
 ['media','Audio & Media','Synths, waveforms, notation and 360° images','#c2410c'],
 ['ai','AI & Vision','Neural networks and computer vision in the browser','#9333ea'],
 ['data','Data, Search & Storage','Statistics, parsing, search, databases and colour','#15803d'],
 ['docs','Documents & Editors','PDFs, code editors, rich text and Markdown','#57534e'],
 ['sci','Science & Games','Astronomy, orbits and 2D game engines','#b45309'],
 ['native','Native Browser APIs','What the browser can do with no library at all','#475569'],
 ['hybrid','Hybrid Stacks','Two or more libraries working together','#e11d48']];
const LIBS=[],LIBMAP={};let CL=null;
function lib(id,name,cat,tag,o){o=o||{};CL={id,name,cat,tag,ex:[],isNew:!!o.isNew,ik:o.ik||name,combo:o.combo,info:o.info,stars:o.stars};LIBS.push(CL);LIBMAP[id]=CL;}
function ex(o){CL.ex.push(o);}
