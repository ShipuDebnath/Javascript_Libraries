/* ===================== App features: ⌘K palette, Board, Compare, Tour, colour-blind palette ===================== */
(function(){
const css=`
#cmdk{position:fixed;inset:0;z-index:120;display:none;align-items:flex-start;justify-content:center;padding-top:12vh;background:rgba(20,14,41,.28);backdrop-filter:blur(6px)}
#cmdk.open{display:flex}
#cmdk .box{width:min(640px,92vw);background:rgba(255,255,255,.92);backdrop-filter:blur(18px) saturate(1.3);border:1px solid rgba(255,255,255,.9);border-radius:18px;box-shadow:0 30px 80px rgba(76,29,149,.28);overflow:hidden;animation:cmdIn .18s cubic-bezier(.2,.8,.2,1)}
@keyframes cmdIn{from{transform:translateY(-8px) scale(.98);opacity:0}}
#cmdk input{width:100%;border:0;outline:0;background:transparent;padding:18px 20px;font:500 17px var(--sans);color:#140e29;border-bottom:1px solid rgba(124,58,237,.12)}
#cmdk ul{list-style:none;margin:0;padding:6px;max-height:52vh;overflow:auto}
#cmdk li{display:flex;align-items:center;gap:12px;padding:9px 12px;border-radius:10px;cursor:pointer;font:500 14px var(--sans);color:#2b2346}
#cmdk li.on{background:linear-gradient(90deg,rgba(124,58,237,.12),rgba(236,72,153,.08))}
#cmdk li i{font-style:normal;width:24px;height:24px;display:grid;place-items:center;border-radius:7px;background:rgba(124,58,237,.1);color:#6d28d9;font-size:13px;flex:none}
#cmdk li small{margin-left:auto;color:#8b84a8;font:11px var(--mono);white-space:nowrap}
#cmdk li b{font-weight:700;color:#6d28d9}
#cmdk .ft{display:flex;gap:14px;padding:9px 16px;border-top:1px solid rgba(124,58,237,.1);font:11px var(--mono);color:#8b84a8}
#cmdk kbd,#cmdb kbd{font:600 10.5px var(--mono);padding:2px 6px;border-radius:6px;background:rgba(124,58,237,.1);color:#5b21b6}
#cmdb{margin-left:8px;display:inline-flex;align-items:center;gap:6px;border:1px solid rgba(124,58,237,.22);background:rgba(255,255,255,.6);backdrop-filter:blur(8px);border-radius:99px;padding:6px 12px;font:600 12px var(--sans);color:#4c1d95;cursor:pointer;white-space:nowrap}
#board{position:relative;height:calc(100vh - 150px);min-height:520px;border-radius:22px;overflow:hidden;background:radial-gradient(circle at 30% 20%,rgba(255,255,255,.7),rgba(237,233,254,.5));border:1px solid rgba(255,255,255,.85);cursor:grab;touch-action:none}
#board.dragging{cursor:grabbing}
#board .plane{position:absolute;left:0;top:0;transform-origin:0 0;will-change:transform}
#board .bc{position:absolute;width:360px;background:rgba(255,255,255,.8);border:1px solid rgba(255,255,255,.95);border-radius:16px;box-shadow:0 14px 40px rgba(76,29,149,.12);overflow:hidden}
#board .bc h5{margin:0;padding:9px 12px;font:700 12.5px var(--sans);color:#140e29;display:flex;gap:8px;align-items:center}
#board .bc h5 a{margin-left:auto;font:600 11px var(--sans);color:#7c3aed;text-decoration:none}
#board .bc .mini{height:220px;position:relative}
#board .bc .mini>div{position:absolute;inset:0}
#board .bc canvas{width:100%;height:100%;display:block}
#board .hudb{position:absolute;right:14px;bottom:14px;display:flex;gap:6px;z-index:2}
#board .hudb button{border:1px solid rgba(124,58,237,.2);background:rgba(255,255,255,.9);border-radius:10px;padding:6px 10px;font:600 12px var(--sans);color:#4c1d95;cursor:pointer}
#board .zl{position:absolute;left:14px;bottom:14px;font:600 11px var(--mono);color:#6b6288;background:rgba(255,255,255,.8);padding:5px 9px;border-radius:8px;z-index:2}
#board .grpl{position:absolute;font:800 30px var(--sans);color:rgba(76,29,149,.18);letter-spacing:-.02em;white-space:nowrap}
.cmpbar{display:flex;flex-wrap:wrap;gap:6px;margin:4px 0 14px}
.cmpbar button{border:1px solid rgba(124,58,237,.2);background:rgba(255,255,255,.7);border-radius:99px;padding:5px 11px;font:600 12px var(--sans);color:#4c1d95;cursor:pointer}
.cmpbar button.on{background:#7c3aed;color:#fff;border-color:#7c3aed}
.cmpg{display:grid;grid-template-columns:repeat(auto-fill,minmax(420px,1fr));gap:16px}
#tourbar{position:fixed;left:50%;bottom:22px;transform:translateX(-50%);z-index:110;display:flex;align-items:center;gap:10px;padding:8px 10px 8px 16px;border-radius:99px;background:rgba(20,14,41,.86);backdrop-filter:blur(14px);color:#fff;font:600 13px var(--sans);box-shadow:0 18px 50px rgba(20,14,41,.35);max-width:92vw}
#tourbar .cap{max-width:52vw;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#tourbar .pg{width:120px;height:4px;border-radius:2px;background:rgba(255,255,255,.18);overflow:hidden}#tourbar .pg i{display:block;height:100%;background:linear-gradient(90deg,#a78bfa,#f472b6);width:0}
#tourbar button{border:0;background:rgba(255,255,255,.12);color:#fff;border-radius:99px;width:30px;height:30px;cursor:pointer;font-size:13px}
.ah2{display:flex;align-items:center;justify-content:space-between;margin-top:10px;padding-top:10px;border-top:1px solid rgba(124,58,237,.1);font:600 12.5px var(--sans);color:#2b2346}
`;const st=document.createElement('style');st.textContent=css;document.head.appendChild(st);

/* ---- colour-blind-safe palette ---- */
const OKABE=['#0072B2','#E69F00','#009E73','#CC79A7','#56B4E9','#D55E00','#F0E442','#332288','#999999','#117733'],ORIG={};
const pals=()=>{const L={PAL,CHP};Object.keys(THEMES).forEach(k=>L['T_'+k]=THEMES[k].pal);return L;};
window.setCB=on=>{const L=pals();Object.entries(L).forEach(([k,a])=>{if(!ORIG[k])ORIG[k]=a.slice();const src=on?OKABE:ORIG[k];for(let i=0;i<a.length;i++)a[i]=src[i%src.length];});PREF.cb=!!on;savePref();document.body.classList.toggle('cb',!!on);};
if(PREF.cb)setCB(true);
const addCBSwitch=()=>{const pop=document.getElementById('ambpop');if(pop)addGlass(pop);if(!pop||pop.querySelector('.ah2'))return;pop.insertAdjacentHTML('beforeend','<div class="ah2">Colour-blind-safe charts<label class="sw"><input type="checkbox" id="cbsw" '+(PREF.cb?'checked':'')+'><i></i></label></div>');pop.querySelector('#cbsw').onchange=e=>{setCB(e.target.checked);toast(e.target.checked?'Okabe–Ito palette on':'Original palettes');route();};};
new MutationObserver(addCBSwitch).observe(document.body,{childList:true,subtree:false});setInterval(addCBSwitch,1500);


/* ---- glass transparency ---- */
const GCSS=document.createElement('style');GCSS.textContent=`:root{--ga:.64;--gb:14px}
body .ex,body .cat,body .tile,body .man .box,body .note,body .g2>div{background:linear-gradient(155deg,rgba(255,255,255,var(--ga)),rgba(255,255,255,calc(var(--ga)*.55)))!important;backdrop-filter:blur(var(--gb)) saturate(1.35)!important;-webkit-backdrop-filter:blur(var(--gb)) saturate(1.35)!important}
body .ex>header{background-color:rgba(255,255,255,calc(var(--ga)*.6))!important}
body .exd,body .ex .ctl{background-color:rgba(255,255,255,calc(var(--ga)*.45))!important}
body #side{background:rgba(255,255,255,calc(var(--ga)*.6))!important;backdrop-filter:blur(var(--gb))!important;-webkit-backdrop-filter:blur(var(--gb))!important}
body #top{background:rgba(250,247,255,calc(var(--ga)*.95))!important;backdrop-filter:blur(var(--gb)) saturate(1.4)!important;-webkit-backdrop-filter:blur(var(--gb)) saturate(1.4)!important}
body .stats div,body .libnav a{background:rgba(255,255,255,calc(var(--ga)*.95))!important;backdrop-filter:blur(var(--gb))!important}
body .hero{background:linear-gradient(160deg,rgba(255,255,255,calc(var(--ga)*.85)),rgba(240,232,255,calc(var(--ga)*.5)))!important}
body .hero:after{opacity:calc(.3 + var(--ga))}
.glp{margin-top:10px;padding-top:10px;border-top:1px solid rgba(124,58,237,.1)}
.glp .hd{display:flex;justify-content:space-between;font:600 12.5px var(--sans);color:#2b2346;margin-bottom:8px}
.glp .hd small{font:600 11px var(--mono);color:#8b84a8}
.glp .ps{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:8px}
.glp .ps button{border:1px solid rgba(124,58,237,.18);border-radius:10px;padding:8px 4px 6px;font:600 11px var(--sans);color:#4c1d95;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:5px;background:transparent}
.glp .ps button i{width:28px;height:18px;border-radius:5px;border:1px solid rgba(124,58,237,.25);background:linear-gradient(135deg,#c4b5fd,#f9a8d4)}
.glp .ps button i b{display:block;width:100%;height:100%;border-radius:4px}
.glp .ps button.on{border-color:#7c3aed;box-shadow:0 0 0 2px rgba(124,58,237,.18)}
.glp input[type=range]{width:100%;accent-color:#7c3aed}`;document.head.appendChild(GCSS);
const GPRE={Solid:92,Frosted:64,Clear:36,Crystal:14};
window.setGlass=a=>{a=clamp(+a,8,95);const t=(95-a)/87;document.documentElement.style.setProperty('--ga',(a/100).toFixed(3));document.documentElement.style.setProperty('--gb',Math.round(8+t*16)+'px');PREF.glass=a;savePref();const pop=document.getElementById('ambpop');if(pop){const r=pop.querySelector('.glp input');if(r)r.value=a;const v=pop.querySelector('.glp .hd small');if(v)v.textContent=(100-a)+'% see-through';pop.querySelectorAll('.glp .ps button').forEach(b=>b.classList.toggle('on',GPRE[b.dataset.g]===a));}};
setGlass(PREF.glass===undefined?64:PREF.glass);
const addGlass=pop=>{if(pop.querySelector('.glp'))return;pop.insertAdjacentHTML('beforeend','<div class="glp"><div class="hd">Glass windows<small></small></div><div class="ps">'+Object.entries(GPRE).map(([n,v])=>'<button data-g="'+n+'"><i><b style="background:rgba(255,255,255,'+(v/100)+')"></b></i>'+n+'</button>').join('')+'</div><input type="range" min="8" max="95" step="1" aria-label="Glass opacity"></div>');
 pop.querySelector('.glp .ps').onclick=e=>{const b=e.target.closest('[data-g]');if(b)setGlass(GPRE[b.dataset.g]);};pop.querySelector('.glp input').oninput=e=>setGlass(e.target.value);setGlass(PREF.glass);};

/* ---- command palette ---- */
const ov=document.createElement('div');ov.id='cmdk';ov.innerHTML='<div class="box"><input placeholder="Jump to a library, example or action…" spellcheck="false"><ul></ul><div class="ft"><span><kbd>↑</kbd><kbd>↓</kbd> move</span><span><kbd>↵</kbd> open</span><span><kbd>esc</kbd> close</span><span>type a number to play it</span><span style="margin-left:auto">'+'{N} items'+'</span></div></div>';document.body.appendChild(ov);
const inp=ov.querySelector('input'),ul=ov.querySelector('ul');let items=[],res=[],sel=0;
const build=()=>{items=[];const V=[['⌂','Home','#/'],['◎','Guides & task finder','#/guide'],['≡','Full index','#/index'],['★','Favourites','#/fav'],['▦','Board: every highlight on one canvas','#/board'],['⇆','Compare chart libraries side by side','#/compare']];V.forEach(v=>items.push({ic:v[0],t:v[1],k:'view',go:()=>location.hash=v[2]}));
 CATS.forEach(c=>items.push({ic:'▣',t:c[1],k:'category',go:()=>location.hash='#/c/'+c[0]}));LIBS.forEach(L=>{items.push({ic:'◆',t:L.name,sub:L.tag,k:'library',go:()=>location.hash='#/l/'+L.id});L.ex.forEach((X,i)=>items.push({ic:'▸',t:X.t,sub:L.name,k:L.name,go:()=>location.hash='#/l/'+L.id+'/'+(i+1)}));});
 const A=[['▶','Start the guided tour',()=>startTour()],['✺','Toggle ambient scene',()=>{AMB.set({on:!AMB.cfg.on});}],['◐','Toggle colour-blind-safe palette',()=>{setCB(!PREF.cb);toast(PREF.cb?'Okabe–Ito palette on':'Original palettes');route();}],['❚❚','Pause / resume all animations',()=>document.getElementById('pz').click()],['☰','Hide / show sidebar',()=>{const b=document.getElementById('sidet');b&&b.click();}],['⚡','Toggle eco mode',()=>{const b=document.getElementById('perf');b&&b.click();}],['⇪','Open the file-drop lab',()=>{typeof openLab==='function'?openLab():toast('Drop a file anywhere');}]];A.forEach(a=>items.push({ic:a[0],t:a[1],k:'action',go:a[2]}));
 ov.querySelector('.ft span:last-child').textContent=items.length.toLocaleString()+' items';};
const score=(q,t)=>{t=t.toLowerCase();if(!q)return 1;const i=t.indexOf(q);if(i===0)return 100;if(i>0)return 80-Math.min(30,i)+(t[i-1]===' '?10:0);let p=0,sc=0,run=0;for(const ch of q){const k=t.indexOf(ch,p);if(k<0)return 0;run=k===p?run+1:0;sc+=1+run*2;p=k+1;}return sc/(q.length*3)*40;};
const hl=(t,q)=>{if(!q)return esc(t);const i=t.toLowerCase().indexOf(q);return i<0?esc(t):esc(t.slice(0,i))+'<b>'+esc(t.slice(i,i+q.length))+'</b>'+esc(t.slice(i+q.length));};
const render=()=>{const q=inp.value.trim().toLowerCase(),nm=q.match(/^#?(\d{1,4})$/);res=(q?items.map(it=>({it,s:score(q,it.t)+(it.k==='library'?8:it.k==='view'||it.k==='action'?6:0)})).filter(x=>x.s>(q.length>2?24:8)).sort((a,b)=>b.s-a.s).map(x=>x.it):items.filter(it=>it.k==='view'||it.k==='action').concat(items.filter(it=>it.k==='library').slice(0,6))).slice(0,40);if(nm&&window.seqAt){const n=+nm[1],E=n>=1&&n<=SEQN()?seqAt(n):null;if(E)res.unshift({ic:'▶',t:'#'+n+' · '+E.X.t,sub:E.L.name,k:E.L.name,go:()=>openPlayer(n,true)});}sel=Math.min(sel,Math.max(0,res.length-1));
 ul.innerHTML=res.map((it,i)=>'<li class="'+(i===sel?'on':'')+'" data-i="'+i+'"><i>'+it.ic+'</i><span>'+hl(it.t,q)+'</span><small>'+esc(it.k==='library'||it.k==='view'||it.k==='action'||it.k==='category'?it.k:it.sub||'')+'</small></li>').join('')||'<li style="color:#8b84a8">No matches</li>';const on=ul.querySelector('.on');on&&on.scrollIntoView({block:'nearest'});};
window.openCmdk=()=>{build();ov.classList.add('open');inp.value='';sel=0;render();setTimeout(()=>inp.focus(),10);};const close=()=>ov.classList.remove('open');
inp.addEventListener('input',()=>{sel=0;render();});inp.addEventListener('keydown',e=>{if(e.key==='ArrowDown'){sel=Math.min(res.length-1,sel+1);render();e.preventDefault();}if(e.key==='ArrowUp'){sel=Math.max(0,sel-1);render();e.preventDefault();}if(e.key==='Enter'&&res[sel]){close();res[sel].go();}if(e.key==='Escape')close();});
ul.addEventListener('click',e=>{const li=e.target.closest('li[data-i]');if(!li)return;close();res[+li.dataset.i].go();});ul.addEventListener('mousemove',e=>{const li=e.target.closest('li[data-i]');if(li&&+li.dataset.i!==sel){sel=+li.dataset.i;ul.querySelectorAll('li').forEach((x,i)=>x.classList.toggle('on',i===sel));}});ov.addEventListener('click',e=>{if(e.target===ov)close();});
document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();ov.classList.contains('open')?close():openCmdk();}});
const top=document.getElementById('top');if(top){const b=document.createElement('button');b.id='cmdb';b.innerHTML='<span>⌘</span> Jump to… <kbd>'+(/Mac/.test(navigator.platform)?'⌘':'Ctrl')+' K</kbd>';b.onclick=openCmdk;const pz=document.getElementById('pz');top.insertBefore(b,pz);}

/* ---- Board: infinite canvas of live highlights ---- */
const BOARD=[['3D & WebGL',[['three',0],['three',6],['ogl',0],['regl',2],['glsl',3],['babylon',0]]],['Science',[['molstar',2],['ngl',2],['3dmol',0],['pixi',3],['d3',5],['ngl',0]]],['Earth',[['cesium',3],['cesium',4],['globegl',2],['deckgl',3],['maplibre',0],['h3',0]]],['Charts',[['d3',6],['d3',7],['echarts',0],['obsplot',2],['vegalite',2],['plotly',4]]],['Maths & physics',[['p5',4],['matter',4],['mathbox',0],['mathbox',2],['katex',2],['rete',0]]]];
function viewBoard(){const w=setView('<div class="crumb"><a href="#/">Home</a> / Board</div><h1 style="margin:2px 0 4px">Board</h1><p style="margin:0 0 14px;color:var(--mut)">Every highlight on one infinite canvas. Drag to pan, scroll to zoom, click a title to open the example. Only cards in view are running.</p><div id="board"><div class="plane"></div><div class="zl"></div><div class="hudb"><button data-z="in">＋</button><button data-z="out">－</button><button data-z="fit">Fit</button></div></div>');
 const bd=w.querySelector('#board'),pl=bd.querySelector('.plane'),zl=bd.querySelector('.zl');let cam={x:20,y:20,z:.62};const app=()=>{pl.style.transform='translate('+cam.x+'px,'+cam.y+'px) scale('+cam.z+')';zl.textContent=Math.round(cam.z*100)+'%';};
 BOARD.forEach(([g,list],gi)=>{const gy=gi*330;pl.insertAdjacentHTML('beforeend','<div class="grpl" style="left:0;top:'+(gy)+'px">'+g+'</div>');list.forEach(([id,i],k)=>{const L=LIBMAP[id];if(!L||!L.ex[i])return;const c=document.createElement('div');c.className='bc';c.style.left=(k*390)+'px';c.style.top=(gy+46)+'px';c.innerHTML='<h5>'+esc(L.ex[i].t.split(':')[0].slice(0,38))+'<a href="#/l/'+id+'/'+(i+1)+'">'+esc(L.name)+' →</a></h5><div class="mini"><div></div></div>';pl.appendChild(c);const host=c.querySelector('.mini>div');const s=startEx({X:L.ex[i],el:c,stage:host,ctl:null});});});
 app();let drag=null;bd.addEventListener('pointerdown',e=>{if(e.target.closest('a,button'))return;drag=[e.clientX,e.clientY,cam.x,cam.y];bd.classList.add('dragging');bd.setPointerCapture(e.pointerId);});bd.addEventListener('pointermove',e=>{if(!drag)return;cam.x=drag[2]+e.clientX-drag[0];cam.y=drag[3]+e.clientY-drag[1];app();});bd.addEventListener('pointerup',()=>{drag=null;bd.classList.remove('dragging');});
 bd.addEventListener('wheel',e=>{e.preventDefault();const r=bd.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top,k=e.deltaY>0?.9:1.1,nz=clamp(cam.z*k,.18,1.6);cam.x=mx-(mx-cam.x)*nz/cam.z;cam.y=my-(my-cam.y)*nz/cam.z;cam.z=nz;app();},{passive:false});
 bd.querySelector('.hudb').onclick=e=>{const z=e.target.dataset.z;if(!z)return;const r=bd.getBoundingClientRect();if(z==='fit'){cam={x:20,y:20,z:Math.min(r.width/(6*390),r.height/(5*330))};}else{const k=z==='in'?1.25:.8,nz=clamp(cam.z*k,.18,1.6),mx=r.width/2,my=r.height/2;cam.x=mx-(mx-cam.x)*nz/cam.z;cam.y=my-(my-cam.y)*nz/cam.z;cam.z=nz;}pl.style.transition='transform .35s cubic-bezier(.2,.8,.2,1)';app();setTimeout(()=>pl.style.transition='',380);};}

/* ---- Compare: same chart type in each library's default look ---- */
function viewCompare(ty){const libs=[['echarts','ECharts'],['plotly','Plotly'],['chartjs','Chart.js'],['apex','ApexCharts']],types=[...new Set(libs.flatMap(([k])=>GAL[k]?GAL[k].types:[]))].filter(t=>libs.filter(([k])=>GAL[k]&&GAL[k].types.includes(t)).length>=2);ty=types.includes(ty)?ty:'bar';
 const w=setView('<div class="crumb"><a href="#/">Home</a> / Compare</div><h1 style="margin:2px 0 4px">Compare chart libraries</h1><p style="margin:0 0 10px;color:var(--mut)">The same chart type and data drawn in each library\'s default style: palette, fonts, grid and plot background. Libraries that don\'t offer the type are left out.</p><div class="cmpbar">'+types.map(t=>'<button class="'+(t===ty?'on':'')+'" data-t="'+t+'">'+esc(GNAME[t]||t)+'</button>').join('')+'</div><div class="cmpg"></div>');
 w.querySelector('.cmpbar').onclick=e=>{const b=e.target.closest('[data-t]');if(b)location.hash='#/compare/'+b.dataset.t;};const g=w.querySelector('.cmpg');
 libs.forEach(([k,n],i)=>{if(!GAL[k]||!GAL[k].types.includes(ty))return;const T=THEMES[GAL[k].T];const X={t:n+' · '+(GNAME[ty]||ty),d:'Default '+n+' styling.',int:1,orbit:{ry:0,rx:0,auto:0},draw(ctx,s,t){const kk=easeOut(clamp(t/1.1,0,1));ctx.fillStyle=T.bg;ctx.fillRect(0,0,W,H);try{CT[ty](ctx,T,kk,s,t);}catch(e){text(ctx,'⚠ '+e.message,20,60,'#e11d48',12);}gTitle(ctx,T,n);},code:GAL[k].code(ty)};mountEx({id:k,name:n},X,i,{into:g});});}

/* ---- Tour ---- */
const TOUR=[['three',0,'Three.js · physically based materials'],['molstar',2,'Mol* · CRISPR-Cas9 cutting DNA'],['three',6,'Three.js · an animal cell you can explore'],['cesium',3,'CesiumJS · the real day/night line, right now'],['globegl',2,'Globe.gl · a global wind field'],['d3',6,'d3 · chord diagram of world trade'],['echarts',0,'ECharts · every chart type'],['regl',2,'regl · Mandelbrot with a live Julia set'],['p5',4,'p5.js · Fourier epicycles'],['matter',4,'Matter.js · double-pendulum chaos'],['ngl',2,'NGL · protein folding down a funnel'],['rete',0,'Rete.js · a live dataflow graph']];
let tour=null;window.startTour=()=>{if(tour)return;tour={i:0,paused:false,t0:0,el:null};const bar=document.createElement('div');bar.id='tourbar';bar.innerHTML='<span>▶ Tour</span><span class="cap"></span><span class="pg"><i></i></span><button data-a="prev">‹</button><button data-a="pp">❚❚</button><button data-a="next">›</button><button data-a="x">✕</button>';document.body.appendChild(bar);
 bar.onclick=e=>{const a=e.target.dataset.a;if(a==='x')stopTour();if(a==='next')stepTour(1);if(a==='prev')stepTour(-1);if(a==='pp'){tour.paused=!tour.paused;e.target.textContent=tour.paused?'▶':'❚❚';}};stepTour(0);tour.iv=setInterval(()=>{if(!tour||tour.paused)return;tour.el+=0.1;const k=tour.el/11;bar.querySelector('.pg i').style.width=Math.min(100,k*100)+'%';if(k>=1)stepTour(1);},100);};
function stepTour(d){if(!tour)return;tour.i=(tour.i+d+TOUR.length)%TOUR.length;tour.el=0;const[id,n,cap]=TOUR[tour.i];if(FOCUS)FOCUS.exit();document.querySelectorAll('.pseudo-fs').forEach(x=>x.classList.remove('pseudo-fs'));document.getElementById('tourbar').querySelector('.cap').textContent=(tour.i+1)+' / '+TOUR.length+' · '+cap;location.hash='#/l/'+id+'/'+(n+1);
 setTimeout(()=>{const el=document.getElementById('ex-'+id+'-'+(n+1));if(!el)return;el.classList.add('pseudo-fs');document.body.classList.add('has-pfs');const st=el.querySelector('.stage');if(st&&st._s&&st._s._boot)st._s._boot();},450);}
function stopTour(){if(!tour)return;clearInterval(tour.iv);tour=null;document.querySelectorAll('.pseudo-fs').forEach(x=>x.classList.remove('pseudo-fs'));document.body.classList.remove('has-pfs');const b=document.getElementById('tourbar');b&&b.remove();}
document.addEventListener('keydown',e=>{if(!tour)return;if(e.key==='Escape')stopTour();if(e.key==='ArrowRight')stepTour(1);if(e.key==='ArrowLeft')stepTour(-1);});

/* ---- routing + sidebar links ---- */
const _route=route;route=function(){const p=location.hash.replace(/^#\/?/,'').split('/');if(p[0]==='board'){document.body.classList.remove('sideopen');viewBoard();markSide();return;}if(p[0]==='compare'){document.body.classList.remove('sideopen');viewCompare(p[1]);markSide();return;}if(p[0]==='tour'){location.hash='#/';setTimeout(startTour,50);return;}_route();};
const _bs=buildSide;buildSide=function(){_bs();const nt=document.querySelector('#side .navtop');if(nt&&!nt.querySelector('[data-r=board]'))nt.insertAdjacentHTML('beforeend','<a href="#/board" data-r="board">▦ Board</a><a href="#/compare" data-r="compare">⇆ Compare charts</a><a href="#/tour" data-r="tour">▶ Guided tour</a>');};
})();
