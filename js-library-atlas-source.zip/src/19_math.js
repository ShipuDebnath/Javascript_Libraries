/* ===================== Mathematics ===================== */
function mathGrid(ctx,X,Y,x0,x1,y0,y1,step){bg(ctx,'#fdfdfc');ctx.lineWidth=1;for(let x=Math.ceil(x0/step)*step;x<=x1;x+=step){line(ctx,X(x),0,X(x),H,Math.abs(x)<1e-9?'#78716c':'#f0eee9',Math.abs(x)<1e-9?1.5:1);if(Math.abs(x)>1e-9)text(ctx,+x.toFixed(2)+'',X(x),Y(0)+14,C.faint,10.5,'center');}
 for(let y=Math.ceil(y0/step)*step;y<=y1;y+=step){line(ctx,0,Y(y),W,Y(y),Math.abs(y)<1e-9?'#78716c':'#f0eee9',Math.abs(y)<1e-9?1.5:1);if(Math.abs(y)>1e-9)text(ctx,+y.toFixed(2)+'',X(0)-6,Y(y)+4,C.faint,10.5,'right');}}
function safeFn(src){const s=src.trim().toLowerCase();if(!/^[0-9x+\-*/^().,\s a-z]*$/.test(s))throw new Error('Only x, numbers, + − * / ^ ( ) and Math functions are allowed');const words=s.match(/[a-z]+/g)||[];const ok=['x','sin','cos','tan','asin','acos','atan','sqrt','abs','exp','log','pow','pi','e','floor','ceil','min','max','sinh','cosh','tanh','sign','round'];for(const w of words)if(!ok.includes(w))throw new Error('Unknown name: '+w);
 const body=s.replace(/\^/g,'**').replace(/\bpi\b/g,'Math.PI').replace(/\be\b/g,'Math.E').replace(/\b(sin|cos|tan|asin|acos|atan|sqrt|abs|exp|log|pow|floor|ceil|min|max|sinh|cosh|tanh|sign|round)\b/g,'Math.$1');return new Function('x','return '+body+';');}

lib('jsxgraph','JSXGraph','math','Interactive geometry, function plotting and calculus constructions where everything updates as you drag.');
ex({t:'Triangle: circumcircle, centroid, angles',d:'Drag the vertices: the circumcircle, circumcentre O, centroid G, angles and area all update live, a dependent construction.',hint:'Drag the three vertices.',int:1,
 init(s){s.P=[[190,320],[520,340],[340,100]];s.dg=-1;s.onDown=(x,y)=>{s.dg=-1;let bd=30;s.P.forEach((p,i)=>{const d=Math.hypot(p[0]-x,p[1]-y);if(d<bd){bd=d;s.dg=i;}});};s.onMove=(x,y)=>{if(s.down&&s.dg>=0)s.P[s.dg]=[clamp(x,20,W-20),clamp(y,50,H-20)];};s.onUp=()=>{s.dg=-1;};},
 draw(ctx,s,t){gridBg(ctx,40,'#fdfdfc','#f1efea');const[A,B,Cp]=s.P,d=2*(A[0]*(B[1]-Cp[1])+B[0]*(Cp[1]-A[1])+Cp[0]*(A[1]-B[1]));if(Math.abs(d)>1){const ux=((A[0]*A[0]+A[1]*A[1])*(B[1]-Cp[1])+(B[0]*B[0]+B[1]*B[1])*(Cp[1]-A[1])+(Cp[0]*Cp[0]+Cp[1]*Cp[1])*(A[1]-B[1]))/d,uy=((A[0]*A[0]+A[1]*A[1])*(Cp[0]-B[0])+(B[0]*B[0]+B[1]*B[1])*(A[0]-Cp[0])+(Cp[0]*Cp[0]+Cp[1]*Cp[1])*(B[0]-A[0]))/d,R=Math.hypot(A[0]-ux,A[1]-uy);
   if(R<2000){ctx.setLineDash([7,6]);circle(ctx,ux,uy,R,null,'#6366f1',1.8);ctx.setLineDash([]);circle(ctx,ux,uy,4.5,'#6366f1');text(ctx,'O',ux+8,uy-6,'#4f46e5',15,'left',FONT,700);text(ctx,'R = '+(R/40).toFixed(2),W-16,28,'#4f46e5',15,'right',FONT,600);}}
  poly(ctx,s.P,'rgba(13,148,136,.1)','#0d9488',2.5);const cg=[(A[0]+B[0]+Cp[0])/3,(A[1]+B[1]+Cp[1])/3];s.P.forEach(p=>line(ctx,p[0],p[1],cg[0],cg[1],'rgba(217,119,6,.35)',1,[3,3]));circle(ctx,cg[0],cg[1],4.5,'#d97706');text(ctx,'G',cg[0]+8,cg[1]-6,'#b45309',15,'left',FONT,700);
  ['A','B','C'].forEach((nm,i)=>{const p=s.P[i],q=s.P[(i+1)%3],r=s.P[(i+2)%3],v1=[q[0]-p[0],q[1]-p[1]],v2=[r[0]-p[0],r[1]-p[1]],ang=Math.acos(clamp((v1[0]*v2[0]+v1[1]*v2[1])/(Math.hypot(...v1)*Math.hypot(...v2)+1e-9),-1,1)),a1=Math.atan2(v1[1],v1[0]),a2=Math.atan2(v2[1],v2[0]);
   ctx.fillStyle='rgba(219,39,119,.15)';ctx.beginPath();ctx.moveTo(p[0],p[1]);let da=a2-a1;while(da>Math.PI)da-=TAU;while(da<-Math.PI)da+=TAU;ctx.arc(p[0],p[1],24,a1,a1+da,da<0);ctx.closePath();ctx.fill();circle(ctx,p[0],p[1],i==s.dg?10:7.5,'#db2777','#fff',2);const mx=(q[0]+r[0])/2-p[0],my=(q[1]+r[1])/2-p[1],l=Math.hypot(mx,my)+1e-6;text(ctx,nm+' '+(ang/D2R).toFixed(1)+'°',p[0]-mx/l*40-24,p[1]-my/l*40+6,C.ink,14,'left',FONT,600);});
  const area=Math.abs((B[0]-A[0])*(Cp[1]-A[1])-(Cp[0]-A[0])*(B[1]-A[1]))/2/1600;text(ctx,'Area = '+area.toFixed(2)+' u²',16,28,C.ink,15,'left',FONT,600);cap(ctx,'board.create("circumcircle",[A,B,C]); board.create("midpoint",…)');},
 code:`const b=JXG.JSXGraph.initBoard('box',{boundingbox:[-5,5,5,-5],axis:false,grid:true});
const A=b.create('point',[-2,-1],{name:'A'}),B=b.create('point',[3,-1.5]),C=b.create('point',[0,3]);
b.create('polygon',[A,B,C],{fillColor:'#0d9488',fillOpacity:.1});
b.create('circumcircle',[A,B,C],{dash:2});b.create('angle',[B,A,C],{radius:.6});`});
ex({t:'Tangent line & Riemann sums',d:'Drag the glider along f(x) to move the tangent and read the derivative; choose the number and type of rectangles and compare the Riemann sum with the exact integral.',hint:'Drag the red point · adjust n.',int:1,controls:[{type:'range',k:'n',l:'Rectangles n',min:2,max:60,v:10},{type:'seg',k:'ty',v:'mid',opts:['left','mid','right']}],
 init(s){s.f=x=>Math.sin(x)*1.6+x*.35+.4;s.F=x=>-Math.cos(x)*1.6+x*x*.175+.4*x;s.gx=2;s.onDown=(x,y)=>{s.dg=true;};s.onUp=()=>{s.dg=false;};},
 draw(ctx,s,t){const x0=-1,x1=8,y0=-2,y1=5,X=x=>(x-x0)/(x1-x0)*W,Y=y=>H-(y-y0)/(y1-y0)*H,iX=px=>x0+px/W*(x1-x0);mathGrid(ctx,X,Y,x0,x1,y0,y1,1);if(s.dg&&s.down)s.gx=clamp(iX(s.mx),x0,x1);else if(!s.hover)s.gx=3.5+Math.sin(t*.5)*3;
  const a=.5,b=6.5,n=s.p.n,dx=(b-a)/n;let sum=0;for(let i=0;i<n;i++){const xs=a+i*dx+(s.p.ty==='left'?0:s.p.ty==='mid'?dx/2:dx),h=s.f(xs);sum+=h*dx;ctx.fillStyle=h>=0?'rgba(79,70,229,.18)':'rgba(225,29,72,.18)';ctx.fillRect(X(a+i*dx),Math.min(Y(h),Y(0)),X(dx)-X(0),Math.abs(Y(h)-Y(0)));ctx.strokeStyle='rgba(79,70,229,.5)';ctx.lineWidth=1;ctx.strokeRect(X(a+i*dx),Math.min(Y(h),Y(0)),X(dx)-X(0),Math.abs(Y(h)-Y(0)));}
  ctx.strokeStyle='#1c1917';ctx.lineWidth=2.5;ctx.beginPath();for(let px=0;px<=W;px+=2){const x=iX(px);px?ctx.lineTo(px,Y(s.f(x))):ctx.moveTo(px,Y(s.f(x)));}ctx.stroke();
  const gx=s.gx,gy=s.f(gx),m=(s.f(gx+1e-4)-s.f(gx-1e-4))/2e-4;line(ctx,X(gx-2),Y(gy-2*m),X(gx+2),Y(gy+2*m),'#e11d48',2);circle(ctx,X(gx),Y(gy),8,'#e11d48','#fff',2.5);
  const exact=s.F(b)-s.F(a);ctx.fillStyle='rgba(255,255,255,.94)';rr(ctx,14,14,250,82,10);ctx.fill();text(ctx,"f'("+gx.toFixed(2)+') = '+m.toFixed(3),26,38,'#e11d48',14,'left',MONO,600);text(ctx,'Σ '+s.p.ty+' (n='+n+') = '+sum.toFixed(4),26,60,C.indigo,13,'left',MONO);text(ctx,'∫ exact = '+exact.toFixed(4)+'  err '+Math.abs(sum-exact).toExponential(1),26,80,C.ink2,12.5,'left',MONO);},
 code:`const f=b.create('functiongraph',[x=>1.6*Math.sin(x)+.35*x+.4]);
const p=b.create('glider',[2,0,f],{color:'#e11d48'});b.create('tangent',[p]);
const n=b.create('slider',[[0,-1.5],[3,-1.5],[2,10,60]],{name:'n',snapWidth:1});
b.create('riemannsum',[f,()=>n.Value(),'middle',.5,6.5],{fillColor:'#4f46e5',fillOpacity:.2});`});
ex({t:'Unit circle → sine & cosine waves',d:'Drag the point around the unit circle; its projections trace sin θ and cos θ on the linked graph, connecting the circle to the waves.',hint:'Drag the point on the circle (or let it spin).',int:1,
 init(s){s.th=.6;s.onDown=()=>{s.dg=true;};s.onUp=()=>{s.dg=false;};},
 draw(ctx,s,t,dt){bg(ctx,'#fdfdfc');const cx=150,cy=H/2,R=110,gx=300,gw=390;if(s.dg&&s.down)s.th=Math.atan2(-(s.my-cy),s.mx-cx);else s.th+=dt*.8;s.th=((s.th%TAU)+TAU)%TAU;
  line(ctx,cx-R-20,cy,cx+R+20,cy,'#d6d3cd',1);line(ctx,cx,cy-R-20,cx,cy+R+20,'#d6d3cd',1);circle(ctx,cx,cy,R,null,'#a8a29e',1.5);line(ctx,gx,cy,gx+gw,cy,'#d6d3cd',1);[-1,1].forEach(v=>line(ctx,gx,cy-v*R,gx+gw,cy-v*R,'#f1efea',1));
  const px=cx+Math.cos(s.th)*R,py=cy-Math.sin(s.th)*R;ctx.fillStyle='rgba(79,70,229,.12)';ctx.beginPath();ctx.moveTo(cx,cy);ctx.arc(cx,cy,30,0,-s.th,true);ctx.fill();line(ctx,cx,cy,px,py,'#1c1917',2);line(ctx,px,py,px,cy,'#e11d48',3);line(ctx,cx,cy,px,cy,'#0d9488',3);
  const X=th=>gx+th/TAU*gw;['sin','cos'].forEach((k,j)=>{ctx.strokeStyle=j?'#0d9488':'#e11d48';ctx.lineWidth=j?2:2.5;ctx.globalAlpha=j?.55:1;ctx.beginPath();for(let a=0;a<=TAU;a+=.03){const y=cy-(j?Math.cos(a):Math.sin(a))*R;a?ctx.lineTo(X(a),y):ctx.moveTo(X(a),y);}ctx.stroke();ctx.globalAlpha=1;});
  line(ctx,px,py,X(s.th),py,'rgba(225,29,72,.4)',1,[4,4]);circle(ctx,X(s.th),py,6,'#e11d48');circle(ctx,X(s.th),cy-Math.cos(s.th)*R,5,'#0d9488');circle(ctx,px,py,8,'#4f46e5','#fff',2.5);
  [['π/2',Math.PI/2],['π',Math.PI],['3π/2',1.5*Math.PI],['2π',TAU]].forEach(([l,a])=>text(ctx,l,X(a),cy+R+22,C.mut,12,'center'));text(ctx,'θ = '+(s.th/D2R).toFixed(0)+'°',20,30,C.ink,15,'left',FONT,700);text(ctx,'sin θ = '+Math.sin(s.th).toFixed(3),20,52,'#e11d48',13,'left',MONO);text(ctx,'cos θ = '+Math.cos(s.th).toFixed(3),20,72,'#0d9488',13,'left',MONO);},
 code:`const c=b.create('circle',[[0,0],1]),P=b.create('glider',[.8,.6,c]);
const th=()=>Math.atan2(P.Y(),P.X());
b.create('segment',[P,[()=>P.X(),0]],{strokeColor:'#e11d48'});           // sin
board2.create('functiongraph',[Math.sin,0,2*Math.PI]);board2.create('point',[th,()=>Math.sin(th())]);
b.addChild(board2);   // linked boards update together`});

lib('mathbox','MathBox','math','Presentation-quality animated mathematics on Three.js: curves, surfaces, vector fields and coordinate systems.');
ex({t:'Lorenz attractor drawn in 3D',d:'The Lorenz system integrated for 6,000 steps and revealed progressively, coloured along its length.',hint:'Drag to orbit.',orbit:{ry:0,rx:.25,auto:.3},
 init(s){let x=1,y=1,z=1;s.P=[];for(let i=0;i<6000;i++){const dt=.006,dx=10*(y-x),dy=x*(28-z)-y,dz=x*y-8/3*z;x+=dx*dt;y+=dy*dt;z+=dz*dt;if(i>200)s.P.push([x*.055,-(z-25)*.055,y*.055]);}},
 draw(ctx,s,t){bg(ctx,'#fdfdfc');const n=Math.min(s.P.length,Math.floor(900+(t%14)*620)),R=s.P.slice(0,n).map(p=>pr(rot(p,s.ry,s.rx),135));for(let g=0;g<n;g+=40){ctx.beginPath();for(let i=g;i<=Math.min(n-1,g+40);i++)i==g?ctx.moveTo(R[i][0],R[i][1]):ctx.lineTo(R[i][0],R[i][1]);ctx.strokeStyle=hsl(250-g/s.P.length*250,70,48);ctx.lineWidth=1.6;ctx.stroke();}
  if(n>1)circle(ctx,R[n-1][0],R[n-1][1],6,'#e11d48','#fff',2);cap(ctx,'dx/dt=σ(y−x)  dy/dt=x(ρ−z)−y  dz/dt=xy−βz');},
 code:`const view=mathbox.cartesian({range:[[-30,30],[-30,30],[0,50]],scale:[1,1,1]});
view.array({width:6000,expr:(emit,i)=>{step();emit(x,y,z);},channels:3})
  .line({color:'#4f46e5',width:2});`});
ex({t:'Morphing parametric surface',d:'A mesh of parametric curves morphing between a torus, a sphere and a twisted Möbius-like band, drawn as MathBox-style lines and points.',hint:'Drag to orbit.',orbit:{ry:.3,rx:.5,auto:.3},controls:[{type:'toggle',k:'pts',l:'Show points',v:true}],
 draw(ctx,s,t){bg(ctx,'#fdfdfc');const k=(t*.18)%3,i0=Math.floor(k),f=ease(clamp((k-i0)*1.6-.3,0,1)),S=[(u,v)=>[(1+.4*Math.cos(v))*Math.cos(u),.4*Math.sin(v),(1+.4*Math.cos(v))*Math.sin(u)],(u,v)=>{const ph=v/2;return[Math.cos(u)*Math.sin(ph)*1.2,-Math.cos(ph)*1.2,Math.sin(u)*Math.sin(ph)*1.2];},(u,v)=>{const w=(v/TAU-.5)*.9;return[(1+w*Math.cos(u/2))*Math.cos(u),w*Math.sin(u/2),(1+w*Math.cos(u/2))*Math.sin(u)];}],A=S[i0%3],B=S[(i0+1)%3],F=(u,v)=>{const a=A(u,v),b=B(u,v);return[lerp(a[0],b[0],f),lerp(a[1],b[1],f),lerp(a[2],b[2],f)];};
  const N=36,M=16;for(let j=0;j<=M;j++){ctx.beginPath();for(let i=0;i<=N;i++){const p=pr(rot(F(i/N*TAU,j/M*TAU),s.ry,s.rx),130);i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]);}ctx.strokeStyle=hsl(200+j*8,65,52,.75);ctx.lineWidth=1.4;ctx.stroke();}
  for(let i=0;i<N;i+=2){ctx.beginPath();for(let j=0;j<=M;j++){const p=pr(rot(F(i/N*TAU,j/M*TAU),s.ry,s.rx),130);j?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]);}ctx.strokeStyle='rgba(219,39,119,.4)';ctx.lineWidth=1;ctx.stroke();}
  if(s.p.pts)for(let i=0;i<N;i+=3)for(let j=0;j<=M;j+=2){const r=rot(F(i/N*TAU,j/M*TAU),s.ry,s.rx),p=pr(r,130);circle(ctx,p[0],p[1],1.8+r[2]*.8,'#1c1917');}
  badge(ctx,['torus','sphere','band'][i0%3]+' → '+['torus','sphere','band'][(i0+1)%3],14,14,'#eef2ff',C.indigo);},
 code:`view.area({width:36,height:16,rangeX:[0,2*Math.PI],rangeY:[0,2*Math.PI],channels:3,
  expr:(emit,u,v,i,j,t)=>{const a=torus(u,v),b=sphere(u,v),k=morph(t);emit(...mix(a,b,k));}})
  .surface({lineX:true,lineY:true,color:'#0ea5e9',fill:false}).point({size:4});`});

function tex2html(src){let i=0;const s=src;const G={alpha:'α',beta:'β',gamma:'γ',delta:'δ',epsilon:'ε',theta:'θ',lambda:'λ',mu:'μ',pi:'π',sigma:'σ',phi:'φ',omega:'ω',rho:'ρ',tau:'τ',psi:'ψ',chi:'χ',xi:'ξ',eta:'η',zeta:'ζ',kappa:'κ',nu:'ν',Psi:'Ψ',Phi:'Φ',Lambda:'Λ',Delta:'Δ',Sigma:'Σ',Omega:'Ω',Gamma:'Γ',infty:'∞',pm:'±',cdot:'·',times:'×',leq:'≤',geq:'≥',neq:'≠',approx:'≈',to:'→',rightarrow:'→',partial:'∂',nabla:'∇',in:'∈',forall:'∀',exists:'∃',hbar:'ℏ',ldots:'…',quad:' ',',':' '};
 const atom=c=>/[a-zA-Z]/.test(c)?'<i>'+c+'</i>':esc(c);
 const grp=()=>{if(s[i]==='{'){i++;const o=seq('}');i++;return o;}if(s[i]==='\\')return cmd();return atom(s[i++]);};
 const cmd=()=>{i++;let n='';while(i<s.length&&/[a-zA-Z]/.test(s[i]))n+=s[i++];if(!n){const c=s[i++];return G[c]||esc(c);}
  if(n==='frac'){const a=grp(),b=grp();return '<span class="fr"><span>'+a+'</span><span>'+b+'</span></span>';}
  if(n==='sqrt'){const a=grp();return '<span class="sq"><span class="rd">√</span><span class="ov">'+a+'</span></span>';}
  if(n==='sum'||n==='int'||n==='prod'||n==='oint')return '<span class="big">'+{sum:'∑',int:'∫',prod:'∏',oint:'∮'}[n]+'</span>';
  if(n==='text'||n==='mathrm'){i++;let o='';while(i<s.length&&s[i]!=='}')o+=s[i++];i++;return '<span style="font-style:normal">'+esc(o)+'</span>';}
  if(n==='vec'||n==='hat'||n==='bar'){const a=grp();return '<span class="acc" data-a="'+{vec:'→',hat:'^',bar:'‾'}[n]+'">'+a+'</span>';}
  if(n==='left'||n==='right'){const c=s[i++];return '<span style="font-size:1.4em;vertical-align:middle">'+esc(c)+'</span>';}
  if(['sin','cos','tan','log','ln','lim','exp','det','max','min'].includes(n))return '<span style="font-style:normal">'+n+'</span> ';
  return G[n]!==undefined?G[n]:'<span style="color:#e11d48">\\'+esc(n)+'</span>';};
 const seq=end=>{let o='';while(i<s.length&&s[i]!==end){const c=s[i];if(c==='^'){i++;o+='<sup>'+grp()+'</sup>';}else if(c==='_'){i++;o+='<sub>'+grp()+'</sub>';}else if(c===' '){i++;}else if(c==='='||c==='+'||c==='-'||c==='<'||c==='>'){i++;o+=' '+(c==='-'?'−':esc(c))+' ';}else o+=grp();}return o;};
 return seq(undefined);}
const TEXCSS='<style>.tx{font:30px/1.6 "Cambria Math","Latin Modern Math","STIX Two Math","Times New Roman",serif;color:#1c1917}.tx i{font-style:italic}.tx .fr{display:inline-flex;flex-direction:column;vertical-align:middle;text-align:center;margin:0 3px;font-size:.92em}.tx .fr>span:first-child{border-bottom:1.5px solid currentColor;padding:0 5px}.tx .fr>span:last-child{padding:0 5px}.tx .sq{display:inline-flex;align-items:flex-start}.tx .rd{font-size:1.15em;font-style:normal;line-height:1.1}.tx .ov{border-top:1.5px solid currentColor;padding:1px 3px 0;margin-top:.24em}.tx .big{font-size:1.6em;vertical-align:middle;font-style:normal}.tx sup,.tx sub{font-size:.62em}.tx .acc{position:relative;display:inline-block}.tx .acc:before{content:attr(data-a);position:absolute;left:0;right:0;top:-.62em;text-align:center;font-size:.7em;font-style:normal}</style>';
lib('katex','KaTeX / MathJax','math','Fast, beautiful TeX maths typesetting for the web: equations, matrices, integrals and chemistry.',{ik:'KaTeX / MathJax'});
ex({t:'Gallery of typeset equations',d:'Classic equations typeset from LaTeX source: Euler, the quadratic formula, the Gaussian integral, Schrödinger and Gauss, Bayes, the Basel sum and a classic limit.',
 dom(el){const E=[['e^{i\\pi}+1=0','Euler’s identity'],['x=\\frac{-b\\pm\\sqrt{b^2-4ac}}{2a}','Quadratic formula'],['\\int_{-\\infty}^{\\infty}e^{-x^2}dx=\\sqrt{\\pi}','Gaussian integral'],['i\\hbar\\frac{\\partial\\psi}{\\partial t}=\\hat{H}\\psi','Schrödinger'],['\\nabla\\cdot\\vec{E}=\\frac{\\rho}{\\epsilon_0}','Gauss’s law'],['P(A|B)=\\frac{P(B|A)P(A)}{P(B)}','Bayes’ theorem'],['\\sum_{n=1}^{\\infty}\\frac{1}{n^2}=\\frac{\\pi^2}{6}','Basel problem'],['\\lim_{x\\to 0}\\frac{\\sin x}{x}=1','A famous limit']];
  el.innerHTML=TEXCSS+'<div class="pad" style="display:grid;grid-template-columns:1fr 1fr;gap:4px 22px;align-content:center;background:#fffefb">'+E.map(e=>'<div><div class="tx" style="font-size:20px;line-height:1.5">'+tex2html(e[0])+'</div><div style="font:12px var(--sans);color:var(--mut)">'+e[1]+'</div></div>').join('')+'</div>';},
 code:`katex.render(String.raw\`x=\\frac{-b\\pm\\sqrt{b^2-4ac}}{2a}\`,el,{displayMode:true});
renderMathInElement(document.body,{delimiters:[{left:'$$',right:'$$',display:true},{left:'$',right:'$',display:false}]});`});
ex({t:'Live LaTeX editor',d:'Type LaTeX and it renders as you type (a subset: fractions, roots, powers, indices, Greek, sums, integrals, accents and \\text).',hint:'Edit the source or pick an example.',
 dom(el){el.innerHTML=TEXCSS+'<div class="pad dk"><div class="row exr"></div><textarea class="src" rows="3" spellcheck="false"></textarea><div class="tx out" style="flex:1;display:grid;place-items:center;background:#fffefb;border:1px solid var(--line);border-radius:12px;font-size:34px;overflow:auto;padding:8px"></div></div>';
  const ta=el.querySelector('.src'),out=el.querySelector('.out'),X={Gaussian:'f(x)=\\frac{1}{\\sigma\\sqrt{2\\pi}}e^{-\\frac{(x-\\mu)^2}{2\\sigma^2}}',Fourier:'\\hat{f}(\\xi)=\\int_{-\\infty}^{\\infty}f(x)e^{-2\\pi i x\\xi}dx',Taylor:'e^x=\\sum_{n=0}^{\\infty}\\frac{x^n}{n!}',Einstein:'E=mc^2',NDVI:'\\text{NDVI}=\\frac{NIR-Red}{NIR+Red}'};
  const ex_=el.querySelector('.exr');Object.keys(X).forEach(k=>{const b=document.createElement('button');b.className='chipbtn';b.textContent=k;b.onclick=()=>{ta.value=X[k];run();};ex_.appendChild(b);});const run=()=>{out.innerHTML='<span>'+tex2html(ta.value)+'</span>';};ta.value=X.Gaussian;ta.addEventListener('input',run);run();},
 code:`textarea.addEventListener('input',()=>{
  try{katex.render(textarea.value,preview,{displayMode:true,throwOnError:false});}
  catch(e){preview.textContent=e.message;}});`});

lib('functionplot','function-plot','math','A tiny D3-based plotter for functions: zoom and pan, derivatives, tips, implicit and parametric curves.',{isNew:true,info:{lv:'Beginner',r:'SVG (D3)',s:'≈ 0.3 MB with D3',u:'mauriciopoppe.github.io/function-plot',t:['Plot y = f(x) with zoom and pan','Show derivatives and tangents on hover','Parametric, polar and implicit curves','Shade areas under curves for teaching'],c:['Interval-arithmetic sampling avoids missing asymptotes','Annotations, tips, multiple graphs, closed areas','Built-in evaluator for string expressions'],l:['2D only; needs D3 and the built-in evaluator'],o:'Fully offline.',k:`functionPlot({target:'#plot',width:720,height:440,grid:true,
  data:[{fn:'sin(x)*x',derivative:{fn:'sin(x)+x*cos(x)',updateOnMouseMove:true}},{fn:'x^2/10',closed:true}]});`,a:'JSXGraph, Desmos API, Plotly.js'}});
ex({t:'Plot any expression with zoom, pan & derivative',d:'Type f(x). Drag to pan, scroll to zoom; the tip tracks the curve and the derivative tangent follows the pointer.',hint:'Edit f(x) · drag to pan · scroll to zoom.',int:1,
 controls:[{type:'select',k:'ex',l:'Example',v:'sin(x)*x',opts:['sin(x)*x','x^3-4*x','exp(-x^2)*cos(4*x)','tan(x)','abs(x)-2','sqrt(abs(x))*sign(x)']},{type:'toggle',k:'der',l:'Derivative',v:true}],
 init(s){s.vx=[-8,8];s.vy=[-5,5];s.mk=()=>{try{s.f=safeFn(s.p.ex);s.err='';}catch(e){s.err=e.message;}};s.mk();let lx,ly;s.onDown=(x,y)=>{lx=x;ly=y;};s.onMove=(x,y)=>{if(s.down){const dx=(x-lx)/W*(s.vx[1]-s.vx[0]),dy=(y-ly)/H*(s.vy[1]-s.vy[0]);s.vx=s.vx.map(v=>v-dx);s.vy=s.vy.map(v=>v+dy);lx=x;ly=y;}};
  s.onWheel=dy=>{const k=1+dy*.0015,cx=s.vx[0]+s.mx/W*(s.vx[1]-s.vx[0]),cy=s.vy[1]-s.my/H*(s.vy[1]-s.vy[0]);s.vx=s.vx.map(v=>cx+(v-cx)*k);s.vy=s.vy.map(v=>cy+(v-cy)*k);};},onCtl(s){s.mk();},
 draw(ctx,s,t){const[x0,x1]=s.vx,[y0,y1]=s.vy,X=x=>(x-x0)/(x1-x0)*W,Y=y=>H-(y-y0)/(y1-y0)*H,step=Math.pow(10,Math.floor(Math.log10((x1-x0)/6)));mathGrid(ctx,X,Y,x0,x1,y0,y1,step*(((x1-x0)/step)>14?2:1));if(s.err){text(ctx,s.err,20,30,'#e11d48',13);return;}
  ctx.strokeStyle='#4f46e5';ctx.lineWidth=2.6;ctx.beginPath();let pen=false,py=0;for(let px=0;px<=W;px+=1.5){const x=x0+px/W*(x1-x0),y=s.f(x);if(!isFinite(y)||(pen&&Math.abs(Y(y)-py)>H)){pen=false;continue;}py=Y(y);pen?ctx.lineTo(px,py):ctx.moveTo(px,py);pen=true;}ctx.stroke();
  const mx=s.hover?x0+s.mx/W*(x1-x0):x0+(x1-x0)*(.5+.3*Math.sin(t*.5)),my=s.f(mx);if(isFinite(my)){const d=(s.f(mx+1e-5)-s.f(mx-1e-5))/2e-5;if(s.p.der&&isFinite(d)){const w=(x1-x0)*.15;line(ctx,X(mx-w),Y(my-w*d),X(mx+w),Y(my+w*d),'#e11d48',2);}line(ctx,X(mx),0,X(mx),H,'rgba(28,25,23,.18)',1,[4,4]);circle(ctx,X(mx),Y(my),6,'#4f46e5','#fff',2);tooltip(ctx,X(mx),Y(my),['x = '+mx.toFixed(3),'f(x) = '+my.toFixed(4),s.p.der?"f'(x) = "+d.toFixed(4):'']);}
  badge(ctx,'f(x) = '+s.p.ex,14,14,'#eef2ff',C.indigo);},
 code:`functionPlot({target:'#plot',grid:true,xAxis:{domain:[-8,8]},yAxis:{domain:[-5,5]},
  data:[{fn:'sin(x)*x',derivative:{fn:'sin(x)+x*cos(x)',updateOnMouseMove:true}}],tip:{xLine:true}});`});
ex({t:'Intersections & area between curves',d:'Two functions, their intersection points found numerically, and the area between them shaded and integrated.',controls:[{type:'range',k:'a',l:'a in a·cos(x)',min:.5,max:3,step:.1,v:2},{type:'range',k:'b',l:'b in x²/b',min:2,max:12,step:.5,v:6}],
 draw(ctx,s,t){const x0=-5,x1=5,y0=-3,y1=5,X=x=>(x-x0)/(x1-x0)*W,Y=y=>H-(y-y0)/(y1-y0)*H,f=x=>s.p.a*Math.cos(x),g=x=>x*x/s.p.b;mathGrid(ctx,X,Y,x0,x1,y0,y1,1);
  const roots=[];for(let x=x0;x<x1;x+=.01){const h1=f(x)-g(x),h2=f(x+.01)-g(x+.01);if(h1*h2<=0){let a=x,b=x+.01;for(let k=0;k<30;k++){const m=(a+b)/2;(f(a)-g(a))*(f(m)-g(m))<=0?b=m:a=m;}roots.push((a+b)/2);}}
  let area=0;if(roots.length>=2){const a=roots[0],b=roots[roots.length-1];ctx.fillStyle='rgba(13,148,136,.18)';ctx.beginPath();for(let x=a;x<=b;x+=.02)ctx.lineTo(X(x),Y(f(x)));for(let x=b;x>=a;x-=.02)ctx.lineTo(X(x),Y(g(x)));ctx.fill();for(let x=a;x<b;x+=.001)area+=Math.abs(f(x)-g(x))*.001;}
  [[f,'#4f46e5'],[g,'#e11d48']].forEach(([F,c])=>{ctx.strokeStyle=c;ctx.lineWidth=2.6;ctx.beginPath();for(let px=0;px<=W;px+=2){const y=F(x0+px/W*(x1-x0));px?ctx.lineTo(px,Y(y)):ctx.moveTo(px,Y(y));}ctx.stroke();});
  roots.forEach(r=>{circle(ctx,X(r),Y(f(r)),6,'#fff','#1c1917',2.5);text(ctx,'('+r.toFixed(2)+', '+f(r).toFixed(2)+')',X(r)+8,Y(f(r))-10,C.ink,12,'left',MONO);});
  badge(ctx,'f(x) = '+s.p.a+'·cos x',14,14,'#eef2ff',C.indigo);badge(ctx,'g(x) = x²/'+s.p.b,14,44,'#ffe4e6','#be123c');if(area)badge(ctx,'area = '+area.toFixed(3),14,74,'#ccfbf1','#0f766e');},
 code:`functionPlot({target:'#plot',data:[{fn:'2*cos(x)'},{fn:'x^2/6'},
  {fn:'2*cos(x)',closed:true,range:[-1.27,1.27]}],annotations:[{x:-1.27},{x:1.27}]});`});
