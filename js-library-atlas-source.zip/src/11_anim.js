/* ===================== Animation & Motion ===================== */
const EASES={'elastic.out':elastic,'back.out':backOut,'bounce.out':bounce,'power3.inOut':ease,'expo.out':t=>t>=1?1:1-Math.pow(2,-10*t),'none':t=>t};
function drawPartial(ctx,pts,u){if(u<=0)return;let tot=0;const L=[];for(let i=1;i<pts.length;i++){const l=Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1]);L.push(l);tot+=l;}let d=u*tot;ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++){if(d>=L[i-1]){ctx.lineTo(pts[i][0],pts[i][1]);d-=L[i-1];}else{const f=d/L[i-1];ctx.lineTo(lerp(pts[i-1][0],pts[i][0],f),lerp(pts[i-1][1],pts[i][1],f));break;}}ctx.stroke();}

lib('gsap','GSAP','anim','Professional-grade timelines, easing, staggers, scroll-driven animation, SVG morphing and motion paths.');
ex({t:'Timeline with scrubbing & a live Gantt view',d:'Ten staggered tweens on one timeline. The lower panel shows each tween as a bar with the playhead, exactly how a GSAP timeline is laid out in time.',hint:'Change the ease · drag the scrubber · reverse it.',
 controls:[{type:'select',k:'ease',l:'Ease',v:'elastic.out',opts:Object.keys(EASES)},{type:'range',k:'prog',l:'Scrub',min:0,max:1,step:.001,v:0,fmt:v=>Math.round(v*100)+'%'},{type:'btn',l:'▶ / ❚❚',fn:s=>{s.play=!s.play;}},{type:'btn',l:'⇄ Reverse',fn:s=>{s.dir*=-1;s.play=true;}}],
 init(s){s.prog=0;s.play=true;s.dir=1;},onCtl(s,k){if(k==='prog'){s.prog=s.p.prog;s.play=false;}},
 draw(ctx,s,t,dt){bg(ctx);const T=2.4;if(s.play){s.prog+=s.dir*dt/T;if(s.prog>1.25){s.dir=-1;}if(s.prog<-.15){s.dir=1;}}const P=clamp(s.prog,0,1),E=EASES[s.p.ease],n=10,st=.07,du=1-st*(n-1);
  for(let i=0;i<n;i++){const k=clamp((P-i*st)/du,0,1),e=E(k),x=70+i*(W-140)/(n-1),y=lerp(250,70,e),r=14+e*10;line(ctx,x,60,x,262,'#f1efea',1);ctx.save();ctx.translate(x,y);ctx.rotate(e*Math.PI);ctx.fillStyle=hsl(250-i*14,70,58);ctx.shadowColor='rgba(79,70,229,.25)';ctx.shadowBlur=10;ctx.shadowOffsetY=4;rr(ctx,-r,-r,2*r,2*r,7);ctx.fill();ctx.restore();}
  const gx=60,gw=W-120,gy=296;ctx.fillStyle='#faf9f6';rr(ctx,gx-14,gy-14,gw+28,122,10);ctx.fill();for(let i=0;i<n;i++){const a=i*st,b=a+du;ctx.fillStyle=hsl(250-i*14,70,58,.85);rr(ctx,gx+a*gw,gy+i*9,du*gw,6,3);ctx.fill();}
  const px=gx+P*gw;line(ctx,px,gy-8,px,gy+96,C.rose,2);circle(ctx,px,gy-8,5,C.rose);text(ctx,(P*T).toFixed(2)+'s',px+8,gy-3,C.rose,12,'left',MONO);cap(ctx,'gsap.timeline().to(".box",{y:-180,rotation:180,ease:"'+s.p.ease+'",stagger:.07})');},
 code:`const tl=gsap.timeline({paused:true})
  .to('.box',{y:-180,rotation:180,duration:1.2,ease:'elastic.out(1,.4)',stagger:.07});
scrubber.oninput=e=>tl.progress(e.target.value);   // scrub
reverseBtn.onclick=()=>tl.reversed(!tl.reversed());`});
ex({t:'ScrollTrigger storytelling (scroll inside)',d:'A pinned chart that builds as you scroll: bars grow, a line draws itself, a counter ticks, then the section un-pins. All driven by scroll progress.',hint:'Scroll inside this panel.',
 dom(el,s){el.innerHTML='<div class="sc" style="position:absolute;inset:0;overflow:auto;scroll-behavior:auto;background:#fff"><div style="height:100%;display:grid;place-items:center;text-align:center;background:linear-gradient(#fff,#f5f3ff)"><div><div style="font:600 34px var(--serif)">Scroll to tell the story</div><div style="color:var(--mut)">↓ ScrollTrigger pins the next section</div></div></div><div class="pinw" style="height:300%;position:relative"><div class="pin" style="position:sticky;top:0;height:'+0+'px;display:flex;flex-direction:column;justify-content:center;padding:18px 26px"><div style="display:flex;justify-content:space-between;align-items:baseline"><b class="hd" style="font:600 22px var(--serif)">Forest cover recovered</b><b class="ct" style="font:600 30px var(--mono);color:var(--ac)">0%</b></div><svg viewBox="0 0 640 230" style="width:100%;margin-top:6px"></svg></div></div><div style="height:100%;display:grid;place-items:center;background:#f0fdfa;font:600 26px var(--serif)">…and the section un-pins. ✓</div></div><div class="bar" style="position:absolute;left:0;top:0;height:4px;background:var(--ac);width:0"></div>';
  const sc=el.querySelector('.sc'),pin=el.querySelector('.pin'),svg=el.querySelector('svg'),ct=el.querySelector('.ct'),bar=el.querySelector('.bar'),pw=el.querySelector('.pinw');const D=[22,35,31,48,52,61,58,74,83,91];
  let h='';D.forEach((v,i)=>{h+='<rect x="'+(20+i*62)+'" y="200" width="40" height="0" rx="6" fill="hsl('+(160+i*8)+',60%,55%)" data-v="'+v+'"/>';});h+='<path d="" fill="none" stroke="#e11d48" stroke-width="4" stroke-linecap="round"/><line x1="10" y1="200" x2="630" y2="200" stroke="#d6d3cd"/>';svg.innerHTML=h;
  const rects=[...svg.querySelectorAll('rect')],path=svg.querySelector('path');path.setAttribute('d','M'+D.map((v,i)=>(40+i*62)+' '+(200-v*1.9-8)).join(' L'));const L=path.getTotalLength?path.getTotalLength():1000;path.style.strokeDasharray=L;
  const upd=()=>{pin.style.height=sc.clientHeight+'px';const top=pw.offsetTop,span=pw.offsetHeight-sc.clientHeight,p=clamp((sc.scrollTop-top)/span,0,1);bar.style.width=(sc.scrollTop/(sc.scrollHeight-sc.clientHeight)*100)+'%';
   rects.forEach((r,i)=>{const k=easeOut(clamp(p*1.8-i*.07,0,1)),hh=r.dataset.v*1.9*k;r.setAttribute('y',200-hh);r.setAttribute('height',hh);});path.style.strokeDashoffset=L*(1-clamp((p-.45)/.45,0,1));ct.textContent=Math.round(91*clamp(p/.9,0,1))+'%';};
  sc.addEventListener('scroll',upd);s.tick0=upd;setTimeout(upd,30);},tick(s){},
 code:`gsap.registerPlugin(ScrollTrigger);
const tl=gsap.timeline({scrollTrigger:{trigger:'.chart',pin:true,scrub:true,start:'top top',end:'+=200%'}});
tl.from('.bar',{scaleY:0,transformOrigin:'bottom',stagger:.07})
  .from('.trend',{drawSVG:0},'>-0.2')
  .from('.counter',{textContent:0,snap:{textContent:1}},0);`});
function shapeAt(k,t){t=((t%1)+1)%1;if(k==='circle')return[Math.sin(TAU*t),-Math.cos(TAU*t)];
 if(k==='star'){const e=Math.floor(t*10),f=t*10-e,v=i=>{const a=i*Math.PI/5,r=i%2?.45:1;return[Math.sin(a)*r,-Math.cos(a)*r];},A=v(e),B=v(e+1);return[lerp(A[0],B[0],f),lerp(A[1],B[1],f)];}
 if(k==='heart'){const a=TAU*t;return[16*Math.pow(Math.sin(a),3)/17,-(13*Math.cos(a)-5*Math.cos(2*a)-2*Math.cos(3*a)-Math.cos(4*a))/17-.1];}
 if(k==='square'){const e=Math.floor(t*4),f=t*4-e,c=[[0,-1],[1,-1],[1,1],[-1,1],[-1,-1],[0,-1]];const P=[[0,-.85],[.85,-.85],[.85,.85],[-.85,.85],[-.85,-.85],[0,-.85]];const u=t*8;const i=Math.floor(u),g=u-i,seq=[[0,-.85],[.85,-.85],[.85,0],[.85,.85],[0,.85],[-.85,.85],[-.85,0],[-.85,-.85],[0,-.85]];return[lerp(seq[i][0],seq[i+1][0],g),lerp(seq[i][1],seq[i+1][1],g)];}
 const a=TAU*t,r=.8+.14*Math.sin(a*3)+.08*Math.cos(a*5);return[Math.sin(a)*r,-Math.cos(a)*r];}
ex({t:'MorphSVG & DrawSVG: shape morphing',d:'A path morphs circle → star → heart → square → blob with matched point order, while its outline is drawn on and its gradient rotates.',hint:'Click to jump to the next shape.',int:1,
 init(s){s.seq=['circle','star','heart','square','blob'];s.i=0;s.k=1;s.onDown=()=>{s.k=1;};},
 draw(ctx,s,t,dt){bg(ctx,'#fffdf9');s.k+=dt/1.1;if(s.k>=1.9){s.k=0;s.i=(s.i+1)%s.seq.length;}const a=s.seq[s.i],b=s.seq[(s.i+1)%s.seq.length],e=EASES['power3.inOut'](clamp(s.k,0,1)),N=200,R=150,pts=[];
  for(let j=0;j<N;j++){const p=shapeAt(a,j/N),q=shapeAt(b,j/N);pts.push([W/2+lerp(p[0],q[0],e)*R,H/2+lerp(p[1],q[1],e)*R]);}
  softShadow(ctx,W/2,H/2+R+22,R*.9,16,.15);const g=ctx.createLinearGradient(W/2+Math.cos(t)*R,H/2+Math.sin(t)*R,W/2-Math.cos(t)*R,H/2-Math.sin(t)*R);g.addColorStop(0,'#6366f1');g.addColorStop(1,'#ec4899');
  poly(ctx,pts,g);ctx.strokeStyle='#1c1917';ctx.lineWidth=3;ctx.lineJoin='round';const dr=clamp(s.k*1.4,0,1);drawPartial(ctx,[...pts,pts[0]],dr<1?dr:1);
  text(ctx,a+' → '+b,24,36,C.ink2,16,'left',MONO);cap(ctx,'gsap.to("#shape",{morphSVG:"#'+b+'", drawSVG:"0% 100%"})');},
 code:`gsap.registerPlugin(MorphSVGPlugin,DrawSVGPlugin);
gsap.timeline({repeat:-1})
  .to('#shape',{morphSVG:'#star',duration:1.1,ease:'power3.inOut'})
  .to('#shape',{morphSVG:'#heart',duration:1.1,ease:'power3.inOut'},'+=.8')
  .fromTo('#outline',{drawSVG:'0%'},{drawSVG:'100%',duration:.8},0);`});
ex({t:'MotionPath: paper plane with auto-rotate',d:'A plane follows a looping Bézier path, rotating to the path tangent, leaving a fading trail.',controls:[{type:'range',k:'sp',l:'Speed',min:.05,max:.4,step:.01,v:.14},{type:'toggle',k:'path',l:'Show path',v:true}],
 init(s){s.u=0;s.tr=[];s.P=[];const cp=[[90,330],[60,90],[330,80],[360,220],[390,360],[650,370],[640,140],[620,40],[380,40],[360,220],[340,400],[110,420],[90,330]];for(let i=0;i<cp.length-1;i+=3){const[a,b,c,d]=[cp[i],cp[i+1],cp[i+2],cp[i+3]];for(let k=0;k<40;k++){const t=k/40,m=1-t;s.P.push([m*m*m*a[0]+3*m*m*t*b[0]+3*m*t*t*c[0]+t*t*t*d[0],m*m*m*a[1]+3*m*m*t*b[1]+3*m*t*t*c[1]+t*t*t*d[1]]);}}s.P.push(s.P[0]);},
 draw(ctx,s,t,dt){gridBg(ctx,40,'#fbfdff','#eef2f7');s.u=(s.u+dt*s.p.sp)%1;const p=polyPt(s.P,s.u),q=polyPt(s.P,(s.u+.003)%1),a=Math.atan2(q[1]-p[1],q[0]-p[0]);
  if(s.p.path){ctx.setLineDash([6,8]);ctx.strokeStyle='#c7d2fe';ctx.lineWidth=2;ctx.beginPath();s.P.forEach((v,i)=>i?ctx.lineTo(v[0],v[1]):ctx.moveTo(v[0],v[1]));ctx.stroke();ctx.setLineDash([]);}
  s.tr.push(p);if(s.tr.length>70)s.tr.shift();s.tr.forEach((v,i)=>circle(ctx,v[0],v[1],1+i/70*3,'rgba(14,165,233,'+(i/70*.6)+')'));
  ctx.save();ctx.translate(p[0],p[1]);ctx.rotate(a);softShadow(ctx,4,18,22,6,.15);poly(ctx,[[26,0],[-18,-16],[-8,0],[-18,16]],'#fff','#1c1917',2.5);poly(ctx,[[26,0],[-8,0],[-18,16]],'#e0e7ff','#1c1917',2.5);ctx.restore();
  text(ctx,'progress '+(s.u*100).toFixed(0)+'%  ·  angle '+((a*57.3+360)%360).toFixed(0)+'°',W-18,28,C.mut,12.5,'right',MONO);cap(ctx,'gsap.to(".plane",{motionPath:{path:"#route",autoRotate:true}})');},
 code:`gsap.registerPlugin(MotionPathPlugin);
gsap.to('.plane',{duration:7,repeat:-1,ease:'none',
  motionPath:{path:'#route',align:'#route',autoRotate:true,alignOrigin:[.5,.5]}});`});

lib('anime','Anime.js','anim','A light, elegant engine for staggered grids, SVG line drawing, morphing, keyframes and counters.');
ex({t:'Grid stagger from the clicked cell',d:'Click any dot: every dot animates with a delay proportional to its distance, like anime.stagger(…, {grid, from: index}).',hint:'Click a dot to start a ripple.',int:1,
 init(s){s.cols=22;s.rows=13;s.st=[];s.org=[11,6];s.t0=-5;s.onDown=(x,y)=>{s.org=[clamp(Math.round((x-38)/30.5),0,21),clamp(Math.round((y-36)/28.5),0,12)];s.t0=s.t;};},
 draw(ctx,s,t){bg(ctx);if(t-s.t0>3.2&&!s.hover){s.org=[Math.floor(Math.random()*22),Math.floor(Math.random()*13)];s.t0=t;}
  for(let r=0;r<s.rows;r++)for(let c=0;c<s.cols;c++){const d=Math.hypot(c-s.org[0],r-s.org[1]),k=clamp((t-s.t0-d*.055)/.7,0,1),e=k<1?elastic(k):1,pulse=Math.sin(k*Math.PI),x=38+c*30.5,y=36+r*28.5;
   circle(ctx,x,y,4+pulse*7,hsl(250-d*9+pulse*60,70,lerp(78,55,pulse)));if(pulse>.3)circle(ctx,x,y,4+pulse*11,null,hsl(250-d*9,70,60,.25),1.5);}
  cap(ctx,'animate(".dot",{scale:[1,2.2,1], delay:stagger(55,{grid:[22,13],from:'+(s.org[1]*22+s.org[0])+'})})');},
 code:`import {animate,stagger} from './libs/anime.esm.js';
grid.onclick=e=>{const i=[...grid.children].indexOf(e.target);
  animate('.dot',{scale:[{to:2.2},{to:1}],backgroundColor:['#a5b4fc','#4f46e5'],
    delay:stagger(55,{grid:[22,13],from:i}),ease:'outElastic(1,.6)'});};`});
ex({t:'SVG line drawing illustration',d:'A landscape drawn stroke by stroke with staggered stroke-dashoffset animations, then filled with colour.',
 init(s){const P=[];P.push({c:'#0d9488',f:'rgba(13,148,136,.12)',p:[[30,330],[150,190],[230,270],[330,150],[450,300],[540,210],[690,330]]});const sun=[];for(let i=0;i<=40;i++){const a=-Math.PI/2+i/40*TAU;sun.push([560+Math.cos(a)*44,110+Math.sin(a)*44]);}P.push({c:'#d97706',f:'rgba(245,158,11,.25)',p:sun});
  const wv=(y,ph)=>{const a=[];for(let x=20;x<=700;x+=10)a.push([x,y+Math.sin(x*.04+ph)*7]);return a;};P.push({c:'#0284c7',p:wv(360,0)},{c:'#0284c7',p:wv(385,1.5)},{c:'#38bdf8',p:wv(410,3)});
  P.push({c:'#1c1917',p:[[120,96],[134,104],[148,96]]},{c:'#1c1917',p:[[170,74],[182,81],[194,74]]},{c:'#1c1917',p:[[215,110],[226,116],[237,110]]});
  P.push({c:'#4f46e5',f:'rgba(79,70,229,.12)',p:[[300,330],[300,270],[340,236],[380,270],[380,330],[300,330]]},{c:'#4f46e5',p:[[330,330],[330,298],[350,298],[350,330]]});s.P=P;},
 draw(ctx,s,t){bg(ctx,'#fffefb');const T=t%7.5,fade=clamp((7.5-T)/.6,0,1);ctx.globalAlpha=fade;ctx.lineCap='round';ctx.lineJoin='round';
  s.P.forEach((o,i)=>{const k=EASES['power3.inOut'](clamp((T-i*.32)/1.3,0,1));if(o.f&&k>=1){ctx.fillStyle=o.f.replace(/[\d.]+\)$/,m=>(parseFloat(m)*clamp((T-i*.32-1.3)/.6,0,1))+')');poly(ctx,o.p,ctx.fillStyle);}ctx.strokeStyle=o.c;ctx.lineWidth=3.5;drawPartial(ctx,o.p,k);});ctx.globalAlpha=1;
  cap(ctx,'animate(svg.createDrawable("path"),{draw:["0 0","0 1"], delay:stagger(320)})');},
 code:`import {animate,svg,stagger} from './libs/anime.esm.js';
animate(svg.createDrawable('.scene path'),{draw:['0 0','0 1'],ease:'inOutQuad',duration:1300,delay:stagger(320)});
animate('.scene path',{fillOpacity:[0,1],delay:stagger(320,{start:1300})});`});
ex({t:'Counters, rings & sparklines',d:'Numbers tween with rounding, progress rings sweep, and sparklines draw in: a whole dashboard intro from one timeline.',controls:[{type:'btn',l:'↻ Replay',pri:1,fn:s=>{s.t0=s.t;}}],
 init(s){s.t0=0;s.K=[['Visitors',48291,'#4f46e5',.78],['Conversion',3.84,'#0d9488',.62],['Revenue',128450,'#d97706',.9],['NPS',72,'#e11d48',.72]];s.sp=s.K.map((_,i)=>{const r=rng(i+3);let v=.5;return Array.from({length:24},()=>v=clamp(v+(r()-.45)*.25,.05,1));});},
 draw(ctx,s,t){bg(ctx,'#faf9f6');const T=t-s.t0;s.K.forEach((k,i)=>{const x=24+(i%2)*348,y=24+Math.floor(i/2)*204,e=easeOut(clamp((T-i*.15)/1.6,0,1));ctx.fillStyle='#fff';ctx.shadowColor='rgba(0,0,0,.06)';ctx.shadowBlur=14;rr(ctx,x,y,324,186,16);ctx.fill();ctx.shadowBlur=0;
  text(ctx,k[0],x+20,y+34,C.mut,14);const v=k[1]*e;text(ctx,i===1?v.toFixed(2)+'%':i===2?'$'+Math.round(v).toLocaleString():Math.round(v).toLocaleString(),x+20,y+76,C.ink,34,'left',FONT,700);
  const cx=x+262,cy=y+64;ctx.lineWidth=10;ctx.lineCap='round';ctx.strokeStyle='#f1efea';ctx.beginPath();ctx.arc(cx,cy,34,0,TAU);ctx.stroke();ctx.strokeStyle=k[2];ctx.beginPath();ctx.arc(cx,cy,34,-Math.PI/2,-Math.PI/2+TAU*k[3]*e);ctx.stroke();text(ctx,Math.round(k[3]*e*100)+'%',cx,cy+5,C.ink2,13,'center',FONT,600);
  const pts=s.sp[i].map((v,j)=>[x+20+j*12.5,y+168-v*58]);ctx.lineWidth=2.5;ctx.strokeStyle=k[2];drawPartial(ctx,pts,clamp((T-.4-i*.15)/1.4,0,1));});
  cap(ctx,'animate(counter,{value:[0,48291], modifier:utils.round(0), duration:1600})');},
 code:`const stats={visitors:0};
animate(stats,{visitors:48291,modifier:utils.round(0),duration:1600,ease:'outCubic',
  onUpdate:()=>el.textContent=stats.visitors.toLocaleString()});
animate('.ring',{strokeDashoffset:[utils.get('.ring','strokeDasharray'),0],delay:stagger(150)});`});

lib('motion','Motion','anim','Springs, gestures, scroll and layout animation with a tiny vanilla API (the engine behind Framer Motion).');
ex({t:'Springs with different stiffness',d:'Three springs chase the same target with stiffness 40, 90 and 180: the soft one lags and overshoots, the stiff one snaps.',hint:'Hover to steer the springs.',
 init(s){s.b=[[40,6,26,'#6366f1'],[90,10,20,'#06b6d4'],[180,16,14,'#ec4899']].map(a=>({x:W/2,y:H/2,vx:0,vy:0,k:a[0],c:a[1],r:a[2],col:a[3],tr:[]}));},
 draw(ctx,s,t,dt){paper(ctx);const tx=s.hover?s.mx:W/2+Math.cos(t*.9)*220,ty=s.hover?s.my:H/2+Math.sin(t*1.3)*120,h=dt/6;
  for(const b of s.b){for(let i=0;i<6;i++){b.vx+=(b.k*(tx-b.x)-b.c*b.vx)*h;b.vy+=(b.k*(ty-b.y)-b.c*b.vy)*h;b.x+=b.vx*h;b.y+=b.vy*h;}b.tr.push([b.x,b.y]);if(b.tr.length>30)b.tr.shift();ctx.strokeStyle=rgba(b.col,.25);ctx.lineWidth=2;ctx.beginPath();b.tr.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.stroke();}
  line(ctx,tx-12,ty,tx+12,ty,C.faint,1.5);line(ctx,tx,ty-12,tx,ty+12,C.faint,1.5);for(const b of s.b){ctx.shadowColor=rgba(b.col,.4);ctx.shadowBlur=16;circle(ctx,b.x,b.y,b.r*1.5,b.col);ctx.shadowBlur=0;}
  s.b.forEach((b,i)=>badge(ctx,'stiffness '+b.k,16+i*130,16,rgba(b.col,.12),b.col));cap(ctx,'animate(el,{x,y},{type:"spring", stiffness:40|90|180, damping})');},
 code:`import {animate} from './libs/motion.js';
addEventListener('pointermove',e=>
  animate('#ball',{x:e.clientX,y:e.clientY},{type:'spring',stiffness:90,damping:10}));`});
ex({t:'Layout animation (FLIP): shuffle, sort, filter',d:'Real DOM tiles. When the layout changes, each tile animates from its old position to its new one: Motion’s layout animation in vanilla JS.',hint:'Press Shuffle, Sort or Filter.',
 dom(el,s){el.innerHTML='<div class="pad dk"><div class="row"><button class="btn pri" data-a="sh">Shuffle</button><button class="btn" data-a="so">Sort</button><button class="btn" data-a="fi">Filter evens</button><span style="color:var(--mut);font-size:12px;margin-left:auto">FLIP: First · Last · Invert · Play</span></div><div class="fl" style="display:flex;flex-wrap:wrap;gap:10px;align-content:flex-start"></div></div>';
  const fl=el.querySelector('.fl');for(let i=1;i<=18;i++){const d=document.createElement('div');d.dataset.n=i;d.textContent=i;d.style.cssText='width:calc(16.66% - 9px);aspect-ratio:1.3;border-radius:14px;display:grid;place-items:center;font:700 22px var(--sans);color:#fff;background:linear-gradient(135deg,'+hsl(230+i*8,70,62)+','+hsl(260+i*8,65,50)+');box-shadow:0 6px 16px -6px rgba(79,70,229,.5)';fl.appendChild(d);}
  let filt=false;const flip=fn=>{const els=[...fl.children],R=new Map(els.map(e=>[e,e.getBoundingClientRect()]));fn();els.forEach(e=>{if(e.style.display==='none')return;const a=R.get(e),b=e.getBoundingClientRect();if(!a.width){e.animate([{opacity:0,transform:'scale(.6)'},{opacity:1,transform:'none'}],{duration:450,easing:'cubic-bezier(.2,.9,.3,1.3)'});return;}const dx=a.left-b.left,dy=a.top-b.top;if(dx||dy)e.animate([{transform:'translate('+dx+'px,'+dy+'px)'},{transform:'none'}],{duration:600,easing:'cubic-bezier(.2,.9,.25,1.15)'});});};
  el.querySelector('.row').addEventListener('click',e=>{const a=e.target.dataset.a;if(!a)return;flip(()=>{const els=[...fl.children];if(a==='sh')els.sort(()=>Math.random()-.5).forEach(x=>fl.appendChild(x));if(a==='so')els.sort((x,y)=>x.dataset.n-y.dataset.n).forEach(x=>fl.appendChild(x));if(a==='fi'){filt=!filt;e.target.textContent=filt?'Show all':'Filter evens';els.forEach(x=>{x.style.display=filt&&x.dataset.n%2?'none':'';});}});});},
 code:`import {animate} from './libs/motion.js';
function flip(change){const first=new Map([...items].map(el=>[el,el.getBoundingClientRect()]));
  change();                                           // reorder the DOM
  items.forEach(el=>{const a=first.get(el),b=el.getBoundingClientRect();
    animate(el,{x:[a.left-b.left,0],y:[a.top-b.top,0]},{type:'spring',bounce:.25});});}`});
ex({t:'Drag gesture with spring snap',d:'Drag the card anywhere and release: it springs to the nearest slot, with velocity carried into the spring. Hover lifts it.',hint:'Drag the card and let go.',int:1,
 init(s){s.slots=[[160,220],[360,220],[560,220]];s.c={x:360,y:220,vx:0,vy:0,sc:1,vs:0};s.target=1;s.drag=null;
  s.onDown=(x,y)=>{if(Math.abs(x-s.c.x)<80&&Math.abs(y-s.c.y)<56)s.drag=[x-s.c.x,y-s.c.y];};s.onMove=(x,y,dx,dy)=>{if(s.drag){s.c.x=x-s.drag[0];s.c.y=y-s.drag[1];s.c.vx=dx*60;s.c.vy=dy*60;}};
  s.onUp=()=>{if(s.drag){let b=0,bd=1e9;s.slots.forEach((p,i)=>{const d=Math.hypot(p[0]-(s.c.x+s.c.vx*.15),p[1]-(s.c.y+s.c.vy*.15));if(d<bd){bd=d;b=i;}});s.target=b;}s.drag=null;};},
 draw(ctx,s,t,dt){paper(ctx);const c=s.c,T=s.slots[s.target];if(!s.drag){for(let i=0;i<4;i++){const h=dt/4;c.vx+=(170*(T[0]-c.x)-14*c.vx)*h;c.vy+=(170*(T[1]-c.y)-14*c.vy)*h;c.x+=c.vx*h;c.y+=c.vy*h;}}
  const hov=s.hover&&Math.abs(s.mx-c.x)<80&&Math.abs(s.my-c.y)<56,ts=s.drag?1.08:hov?1.04:1;c.vs+=(300*(ts-c.sc)-18*c.vs)*dt;c.sc+=c.vs*dt;
  s.slots.forEach((p,i)=>{ctx.setLineDash([6,6]);ctx.strokeStyle=i===s.target?C.indigo:C.line;ctx.lineWidth=2;rr(ctx,p[0]-80,p[1]-56,160,112,18);ctx.stroke();ctx.setLineDash([]);text(ctx,'slot '+(i+1),p[0],p[1]+82,C.faint,12,'center',MONO);});
  const tilt=clamp(c.vx/2500,-.25,.25);ctx.save();ctx.translate(c.x,c.y);ctx.rotate(tilt);ctx.scale(c.sc,c.sc);ctx.shadowColor='rgba(28,25,23,.22)';ctx.shadowBlur=s.drag?34:18;ctx.shadowOffsetY=s.drag?18:8;const g=ctx.createLinearGradient(-80,-56,80,56);g.addColorStop(0,'#4f46e5');g.addColorStop(1,'#db2777');ctx.fillStyle=g;rr(ctx,-80,-56,160,112,18);ctx.fill();ctx.shadowColor='transparent';
  text(ctx,'Drag me',-60,-18,'#fff',20,'left',FONT,700);text(ctx,'spring · stiffness 170',-60,6,'rgba(255,255,255,.8)',12,'left',MONO);ctx.restore();
  if(s.stage)s.stage.style.cursor=s.drag?'grabbing':hov?'grab':'default';cap(ctx,'animate(card,{x:slot.x},{type:"spring", velocity: dragVelocity})');},
 code:`let start;card.onpointerdown=e=>{start=e;card.setPointerCapture(e.pointerId);};
card.onpointermove=e=>{if(start)card.style.transform='translate('+(e.clientX-start.clientX)+'px,0)';};
card.onpointerup=e=>{const slot=nearestSlot(e);start=null;
  animate(card,{x:slot.x,y:slot.y},{type:'spring',stiffness:170,damping:14,velocity:lastVelocity});};`});

lib('lottie','Lottie-web','anim','Plays After Effects animations exported as JSON (Bodymovin) as crisp vector graphics, with full playback control.',{ik:'Lottie-web'});
ex({t:'Icon animations: check, gear, heart, loader',d:'Designer-style micro-animations of the kind Lottie plays from JSON: stroke draw, rotation, pulse and staggered loader.',
 draw(ctx,s,t){bg(ctx,'#ffffff');const cy=H/2-20;ctx.lineCap='round';ctx.lineJoin='round';[100,260,420,580].forEach(x=>circle(ctx,x,cy,72,'#faf9f6'));
  let x=100,p=(t%2.4)/2.4;ctx.lineWidth=10;ctx.strokeStyle='#10b981';ctx.beginPath();ctx.arc(x,cy,48,-Math.PI/2,-Math.PI/2+TAU*easeOut(clamp(p/.5,0,1)));ctx.stroke();ctx.strokeStyle='#10b981';drawPartial(ctx,[[x-22,cy+2],[x-6,cy+18],[x+24,cy-16]],easeOut(clamp((p-.45)/.3,0,1)));
  x=260;ctx.save();ctx.translate(x,cy);ctx.rotate(t*1.2);ctx.fillStyle='#6366f1';for(let i=0;i<8;i++){ctx.save();ctx.rotate(i*TAU/8);rr(ctx,-8,-50,16,22,3);ctx.fill();ctx.restore();}circle(ctx,0,0,38,'#6366f1');circle(ctx,0,0,15,'#faf9f6');ctx.restore();
  x=420;const pul=1+.16*Math.pow(Math.max(0,Math.sin(t*5)),6);ctx.save();ctx.translate(x,cy+4);ctx.scale(pul*2.5,pul*2.5);ctx.fillStyle='#f43f5e';ctx.beginPath();for(let a=0;a<=TAU+.1;a+=.1){const hx=16*Math.pow(Math.sin(a),3),hy=-(13*Math.cos(a)-5*Math.cos(2*a)-2*Math.cos(3*a)-Math.cos(4*a));a?ctx.lineTo(hx,hy):ctx.moveTo(hx,hy);}ctx.fill();ctx.restore();
  x=580;for(let i=0;i<8;i++){const a=i/8*TAU,al=((t*1.2-i/8)%1+1)%1;circle(ctx,x+Math.cos(a)*36,cy+Math.sin(a)*36,8*(1-al*.4),'rgba(14,165,233,'+(1-al*.85)+')');}
  ['stroke draw','rotate','pulse','loop'].forEach((l,i)=>text(ctx,l,100+i*160,cy+108,C.mut,14,'center'));cap(ctx,'lottie.loadAnimation({ renderer:"svg", loop:true, animationData })');},
 code:`const anim=lottie.loadAnimation({container:document.getElementById('icon'),
  renderer:'svg',loop:true,autoplay:true,animationData:checkJson});   // embed JSON for offline use
anim.setSpeed(1.5);`});
function rocketScene(ctx,f){const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,mixHex('#e0e7ff','#1e1b4b',clamp((f-90)/90,0,1)));g.addColorStop(1,mixHex('#fdf2f8','#4c1d95',clamp((f-90)/90,0,1)));ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
 const r=rng(3);for(let i=0;i<60;i++){const x=r()*W,y=r()*H*.7;ctx.fillStyle='rgba(255,255,255,'+clamp((f-100)/60,0,1)*(.4+r()*.6)+')';ctx.fillRect(x,y,2,2);}
 const lift=f<60?0:Math.pow((f-60)/120,2)*560,shake=f>40&&f<70?Math.sin(f*3)*2:0,gy=380+Math.min(lift*.25,120);ctx.fillStyle='#c4b5fd';ctx.fillRect(0,gy,W,H);ctx.fillStyle='#a78bfa';ctx.fillRect(0,gy,W,8);
 const rx=W/2+shake,ry=300-lift;if(f>35){for(let i=0;i<14;i++){const a=(i*.7+f*.05)%1,px=rx+(i%2?-1:1)*a*80*(i%3),py=ry+70+a*40;circle(ctx,px,Math.min(py,gy+10),14+a*22,'rgba(255,255,255,'+(.9-a*.8)+')');}const fl=18+Math.sin(f*1.7)*6;poly(ctx,[[rx-14,ry+58],[rx,ry+58+fl*2.2],[rx+14,ry+58]],'#f97316');poly(ctx,[[rx-8,ry+58],[rx,ry+58+fl*1.4],[rx+8,ry+58]],'#fde047');}
 ctx.save();ctx.translate(rx,ry);poly(ctx,[[-22,40],[-40,64],[-22,58]],'#e11d48');poly(ctx,[[22,40],[40,64],[22,58]],'#e11d48');ctx.beginPath();ctx.moveTo(0,-70);ctx.bezierCurveTo(30,-40,26,30,22,58);ctx.lineTo(-22,58);ctx.bezierCurveTo(-26,30,-30,-40,0,-70);ctx.fillStyle='#fff';ctx.fill();ctx.strokeStyle='#1c1917';ctx.lineWidth=3;ctx.stroke();circle(ctx,0,-14,11,'#93c5fd','#1c1917',3);ctx.restore();
 if(f<60){const n=3-Math.floor(f/20);text(ctx,n>0?String(n):'',W/2,130,'#4c1d95',64,'center',FONT,800);}if(f>=60&&f<90)text(ctx,'Lift-off!',W/2,120,'#4c1d95',40,'center',FONT,800);}
ex({t:'Playback control: seek, segments, speed',d:'A 180-frame animation scrubbed like anim.goToAndStop(frame): countdown, ignition, lift-off, then night sky. Change speed and loop a segment.',hint:'Drag the frame slider · pick a segment.',
 controls:[{type:'btn',l:'▶ / ❚❚',pri:1,fn:s=>{s.play=!s.play;}},{type:'range',k:'f',l:'Frame',min:0,max:180,v:0},{type:'select',k:'sp',l:'Speed',v:'1×',opts:['0.25×','0.5×','1×','2×']},{type:'select',k:'seg',l:'Segment',v:'all',opts:['all','0–60 countdown','60–120 lift-off','120–180 night']}],
 init(s){s.f=0;s.play=true;},onCtl(s,k){if(k==='f'){s.f=s.p.f;s.play=false;}},
 draw(ctx,s,t,dt){const sg=s.p.seg==='all'?[0,180]:s.p.seg.match(/\d+/g).map(Number);if(s.play){s.f+=dt*60*parseFloat(s.p.sp);if(s.f>sg[1]||s.f<sg[0])s.f=sg[0];}rocketScene(ctx,s.f);
  ctx.fillStyle='rgba(255,255,255,.85)';rr(ctx,14,14,170,30,8);ctx.fill();text(ctx,'frame '+Math.floor(s.f)+' / 180',24,34,C.ink,13,'left',MONO);ctx.fillStyle='rgba(28,25,23,.15)';ctx.fillRect(0,H-4,W,4);ctx.fillStyle=C.indigo;ctx.fillRect(0,H-4,W*s.f/180,4);},
 code:`const anim=lottie.loadAnimation({container:el,renderer:'svg',loop:true,autoplay:false,animationData:rocket});
slider.oninput=e=>anim.goToAndStop(+e.target.value,true);   // seek to frame
anim.playSegments([60,120],true);                           // loop lift-off only
anim.setSpeed(.5);`});

lib('rive','Rive','anim','Interactive vector animation driven by state machines: characters, buttons and UI that react to input.');
ex({t:'Character state machine: look & mood',d:'Eyes follow a pointer input; a boolean input switches Happy / Sad; a blink fires on a timer, like a Rive state machine.',hint:'Move to make it look · click to toggle the mood.',int:1,
 init(s){s.mood=1;s.m=1;s.onDown=()=>{s.mood=-s.mood;};},
 draw(ctx,s,t){bg(ctx,s.mood>0?'#fff7ed':'#eef2ff');s.m+=(s.mood-s.m)*.12;const cx=W/2,cy=H/2+5;softShadow(ctx,cx,cy+150,110,16,.18);
  circle(ctx,cx,cy,140,s.mood>0?'#fbbf24':'#93c5fd',s.mood>0?'#f59e0b':'#60a5fa',6);const tx=s.hover?s.mx:cx+Math.cos(t)*260,ty=s.hover?s.my:cy+Math.sin(t*1.3)*120,bl=(t%4)<.15?.1:1;
  for(const sx of[-1,1]){const ex_=cx+sx*52,ey=cy-28;ctx.save();ctx.translate(ex_,ey);ctx.scale(1,bl);circle(ctx,0,0,30,'#fff');const a=Math.atan2(ty-ey,tx-ex_),d=Math.min(13,Math.hypot(tx-ex_,ty-ey)/9);circle(ctx,Math.cos(a)*d,Math.sin(a)*d,13,'#1c1917');circle(ctx,Math.cos(a)*d+4,Math.sin(a)*d-4,4,'#fff');ctx.restore();
   ctx.strokeStyle='#78350f';ctx.lineWidth=7;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(ex_-24,ey-50+(s.m<0?sx*8*-s.m:0));ctx.lineTo(ex_+24,ey-50-(s.m<0?sx*8*-s.m:0));ctx.stroke();}
  if(s.m>.2){circle(ctx,cx-92,cy+28,16,'rgba(244,63,94,.25)');circle(ctx,cx+92,cy+28,16,'rgba(244,63,94,.25)');}
  ctx.strokeStyle='#78350f';ctx.lineWidth=9;ctx.beginPath();ctx.moveTo(cx-58,cy+62);ctx.quadraticCurveTo(cx,cy+62+s.m*55,cx+58,cy+62);ctx.stroke();
  ctx.fillStyle='rgba(255,255,255,.9)';rr(ctx,14,14,196,74,10);ctx.fill();text(ctx,'StateMachine "Main"',24,34,C.ink,13,'left',MONO,600);text(ctx,'bool  happy = '+(s.mood>0),24,54,C.indigo,12.5,'left',MONO);text(ctx,'num   lookX = '+Math.round(tx),24,72,C.teal,12.5,'left',MONO);},
 code:`const r=new rive.Rive({src:'mascot.riv',canvas,autoplay:true,stateMachines:'Main',
  onLoad:()=>{const I=r.stateMachineInputs('Main');
    const happy=I.find(i=>i.name==='happy'),lookX=I.find(i=>i.name==='lookX');
    canvas.onclick=()=>happy.value=!happy.value;
    canvas.onpointermove=e=>lookX.value=e.offsetX;}});`});
ex({t:'Interactive UI: day/night toggle & like button',d:'Two state machines. The toggle morphs sun into moon and re-colours the sky; the heart has hover, press and a "liked" trigger with a particle burst.',hint:'Click the toggle and the heart.',int:1,
 init(s){s.night=false;s.k=0;s.liked=false;s.cnt=128;s.burst=[];s.hs=1;s.onDown=(x,y)=>{if(x<360){s.night=!s.night;}else if(Math.hypot(x-540,y-200)<70){s.liked=!s.liked;s.cnt+=s.liked?1:-1;if(s.liked)for(let i=0;i<22;i++){const a=i/22*TAU;s.burst.push({x:540,y:200,vx:Math.cos(a)*(150+Math.random()*120),vy:Math.sin(a)*(150+Math.random()*120),l:1,c:PAL[i%PAL.length]});}s.hs=.7;}};},
 draw(ctx,s,t,dt){bg(ctx);s.k+=((s.night?1:0)-s.k)*Math.min(1,dt*7);const k=s.k;
  const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,mixHex('#bae6fd','#1e1b4b',k));g.addColorStop(1,mixHex('#fef3c7','#312e81',k));ctx.fillStyle=g;rr(ctx,20,20,320,H-40,22);ctx.fill();
  for(let i=0;i<20;i++){ctx.fillStyle='rgba(255,255,255,'+k*(.5+.5*Math.sin(t*3+i))+')';ctx.fillRect(40+(i*137)%280,40+(i*71)%240,2.5,2.5);}
  const tx=180,ty=330;ctx.fillStyle=mixHex('#fde68a','#4338ca',k);rr(ctx,tx-80,ty-34,160,68,34);ctx.fill();const kx=lerp(tx-46,tx+46,easeOut(k));circle(ctx,kx,ty,28,mixHex('#f59e0b','#e0e7ff',k));
  ctx.save();ctx.beginPath();ctx.arc(kx,ty,28,0,TAU);ctx.clip();circle(ctx,kx+lerp(60,14,k),ty-lerp(30,8,k),24,mixHex('#fde68a','#4338ca',k));ctx.restore();
  const sx=180,sy=150;circle(ctx,sx,sy,lerp(46,40,k),mixHex('#fbbf24','#e0e7ff',k));ctx.save();ctx.beginPath();ctx.arc(sx,sy,46,0,TAU);ctx.clip();circle(ctx,sx+lerp(110,20,k),sy-lerp(40,14,k),40,mixHex('#bae6fd','#2b2a6b',k));ctx.restore();
  for(let i=0;i<8;i++){const a=i/8*TAU+t*.3;ctx.strokeStyle='rgba(245,158,11,'+(1-k)+')';ctx.lineWidth=4;ctx.lineCap='round';line(ctx,sx+Math.cos(a)*58,sy+Math.sin(a)*58,sx+Math.cos(a)*72,sy+Math.sin(a)*72,'rgba(245,158,11,'+(1-k)+')',4);}
  const hov=s.hover&&Math.hypot(s.mx-540,s.my-200)<70;s.hs+=((hov?1.12:1)-s.hs)*.15;circle(ctx,540,200,72,s.liked?'#ffe4e6':'#f5f5f4');ctx.save();ctx.translate(540,204);ctx.scale(s.hs*2.6,s.hs*2.6);ctx.fillStyle=s.liked?'#e11d48':'#fff';ctx.strokeStyle=s.liked?'#e11d48':'#a8a29e';ctx.lineWidth=1.4;ctx.beginPath();for(let a=0;a<=TAU+.1;a+=.1){const hx=16*Math.pow(Math.sin(a),3)*.9,hy=-(13*Math.cos(a)-5*Math.cos(2*a)-2*Math.cos(3*a)-Math.cos(4*a))*.9;a?ctx.lineTo(hx,hy):ctx.moveTo(hx,hy);}ctx.fill();ctx.stroke();ctx.restore();
  for(let i=s.burst.length-1;i>=0;i--){const b=s.burst[i];b.x+=b.vx*dt;b.y+=b.vy*dt;b.vx*=.92;b.vy*=.92;b.l-=dt*1.4;if(b.l<=0){s.burst.splice(i,1);continue;}circle(ctx,b.x,b.y,5*b.l,b.c);}
  text(ctx,s.cnt+' likes',540,310,C.ink,22,'center',FONT,700);text(ctx,'trigger "like" · bool "liked" = '+s.liked,540,336,C.mut,12,'center',MONO);text(ctx,'bool "isNight" = '+s.night,180,410,s.night?'#e0e7ff':C.ink2,12,'center',MONO);},
 code:`const r=new rive.Rive({src:'ui.riv',canvas,stateMachines:['Toggle','Like'],autoplay:true,
  onLoad:()=>{const night=r.stateMachineInputs('Toggle').find(i=>i.name==='isNight');
    const like=r.stateMachineInputs('Like').find(i=>i.name==='like');
    toggleHit.onclick=()=>night.value=!night.value;heartHit.onclick=()=>like.fire();}});`});

lib('theatre','Theatre.js','anim','A visual keyframe editor for choreographing Three.js and DOM animation, exported as JSON.');
ex({t:'Sequence editor with draggable keyframes',d:'Three tracks (x, y, rotation) with keyframes you can drag in time. The object above replays the sequence with eased interpolation, as Theatre.js Studio does.',hint:'Drag the diamonds left/right · click the ruler to move the playhead.',int:1,
 init(s){s.D=4;s.tracks=[{n:'x',c:C.indigo,k:[[0,-200],[1.3,120],[2.6,-40],[4,-200]]},{n:'y',c:C.teal,k:[[0,0],[.8,-70],[1.9,40],[3.2,-30],[4,0]]},{n:'rotation',c:C.rose,k:[[0,0],[2,180],[4,360]]}];s.ph=0;s.dr=null;
  const X=tt=>90+tt/s.D*(W-120),T=x=>clamp((x-90)/(W-120)*s.D,0,s.D);s.Xf=X;
  s.onDown=(x,y)=>{if(y>262&&y<282){s.ph=T(x);s.scrub=true;return;}s.tracks.forEach((tr,i)=>{const yy=310+i*40;tr.k.forEach((kf,j)=>{if(Math.abs(x-X(kf[0]))<10&&Math.abs(y-yy)<12)s.dr=[i,j];});});};
  s.onMove=x=>{if(s.scrub&&s.down)s.ph=T(x);if(s.dr&&s.down){const tr=s.tracks[s.dr[0]],k=tr.k,j=s.dr[1],lo=j?k[j-1][0]+.05:0,hi=j<k.length-1?k[j+1][0]-.05:s.D;k[j][0]=clamp(T(x),lo,hi);}};s.onUp=()=>{s.dr=null;s.scrub=false;};},
 draw(ctx,s,t,dt){bg(ctx,'#fbfaf8');if(!s.scrub&&!s.dr)s.ph=(s.ph+dt)%s.D;const val=tr=>{const k=tr.k;for(let j=0;j<k.length-1;j++)if(s.ph<=k[j+1][0]){const f=(s.ph-k[j][0])/(k[j+1][0]-k[j][0]);return lerp(k[j][1],k[j+1][1],ease(clamp(f,0,1)));}return k[k.length-1][1];};
  const x=val(s.tracks[0]),y=val(s.tracks[1]),r=val(s.tracks[2]);ctx.fillStyle='#fff';rr(ctx,14,14,W-28,232,12);ctx.fill();ctx.strokeStyle=C.grid;ctx.stroke();softShadow(ctx,W/2+x,214,40,8,.15);ctx.save();ctx.translate(W/2+x,128+y);ctx.rotate(r*D2R);const g=ctx.createLinearGradient(-36,-36,36,36);g.addColorStop(0,'#818cf8');g.addColorStop(1,'#e11d48');ctx.fillStyle=g;rr(ctx,-36,-36,72,72,16);ctx.fill();ctx.restore();
  ctx.fillStyle='#1c1917';rr(ctx,0,252,W,H-252,0);ctx.fill();for(let i=0;i<=8;i++){const xx=s.Xf(i/2);line(ctx,xx,262,xx,282,'#57534e',1);text(ctx,(i/2).toFixed(1)+'s',xx+3,276,'#a8a29e',10.5,'left',MONO);}
  s.tracks.forEach((tr,i)=>{const yy=310+i*40;text(ctx,tr.n,14,yy+4,'#e7e5e4',12.5,'left',MONO);text(ctx,val(tr).toFixed(0),82,yy+4,'#a8a29e',11,'right',MONO);line(ctx,90,yy,W-30,yy,'#44403c',1);ctx.strokeStyle=rgba(tr.c,.5);ctx.lineWidth=1.5;ctx.beginPath();for(let k=0;k<tr.k.length-1;k++){ctx.moveTo(s.Xf(tr.k[k][0]),yy);ctx.lineTo(s.Xf(tr.k[k+1][0]),yy);}ctx.stroke();
   tr.k.forEach((kf,j)=>{const kx=s.Xf(kf[0]),on=s.dr&&s.dr[0]===i&&s.dr[1]===j;ctx.save();ctx.translate(kx,yy);ctx.rotate(Math.PI/4);ctx.fillStyle=on?'#fff':tr.c;ctx.fillRect(-6,-6,12,12);ctx.restore();});});
  const px=s.Xf(s.ph);line(ctx,px,258,px,H,'#fbbf24',2);poly(ctx,[[px-6,256],[px+6,256],[px,264]],'#fbbf24');},
 code:`import {getProject,types} from '@theatre/core';
const sheet=getProject('Demo',{state:savedJson}).sheet('Scene');     // exported keyframes
const box=sheet.object('Box',{x:0,y:0,rotation:types.number(0,{range:[0,360]})});
box.onValuesChange(v=>{el.style.transform='translate('+v.x+'px,'+v.y+'px) rotate('+v.rotation+'deg)';});
sheet.sequence.play({iterationCount:Infinity});`});

lib('lenis','Lenis','anim','Smooth, inertia-based scrolling that keeps native scroll semantics and syncs with scroll animations.');
ex({t:'Smooth scroll with parallax layers',d:'Wheel input is eased toward a target (lerp 0.1) instead of jumping, and three parallax layers move at different speeds. Compare with native scrolling.',hint:'Scroll with the wheel or trackpad over the panel.',controls:[{type:'seg',k:'m',v:'Lenis',opts:['Lenis','Native']},{type:'range',k:'lp',l:'lerp',min:.03,max:.3,step:.01,v:.1}],
 dom(el,s){el.innerHTML='<div class="vp" style="position:absolute;inset:0;overflow:hidden;background:#f8fafc"><div class="ct" style="will-change:transform"></div><div class="ind" style="position:absolute;right:10px;top:10px;font:12px var(--mono);background:#fff;border:1px solid var(--line);border-radius:8px;padding:4px 8px"></div></div>';
  const vp=el.querySelector('.vp'),ct=el.querySelector('.ct'),ind=el.querySelector('.ind');let h='';const cols=['#4f46e5','#0d9488','#e11d48','#d97706','#7c3aed','#0284c7'];
  for(let i=0;i<6;i++)h+='<section style="height:260px;position:relative;overflow:hidden;border-bottom:1px solid var(--line)"><div class="px" data-k=".5" style="position:absolute;left:8%;top:30px;width:150px;height:150px;border-radius:50%;background:'+cols[i]+';opacity:.18"></div><div class="px" data-k=".25" style="position:absolute;right:10%;top:60px;width:90px;height:90px;border-radius:20px;background:'+cols[(i+2)%6]+';opacity:.35"></div><h3 class="px" data-k="-.15" style="position:absolute;left:8%;top:95px;margin:0;font:600 34px var(--serif)">Section '+(i+1)+'</h3><p style="position:absolute;left:8%;top:150px;color:var(--mut);margin:0">Layers move at 0.5×, 0.25× and −0.15× the scroll speed.</p></section>';
  ct.innerHTML=h;const px=[...ct.querySelectorAll('.px')];s.target=0;s.cur=0;
  vp.addEventListener('wheel',e=>{e.preventDefault();const max=ct.scrollHeight-vp.clientHeight;s.target=clamp(s.target+e.deltaY,0,max);if(s.p.m==='Native')s.cur=s.target;},{passive:false});
  s.upd=()=>{if(s.p.m==='Lenis')s.cur=lerp(s.cur,s.target,s.p.lp);ct.style.transform='translateY('+(-s.cur)+'px)';px.forEach(p=>{const sec=p.parentNode,rel=sec.offsetTop-s.cur;p.style.transform='translateY('+(rel*parseFloat(p.dataset.k)*.6)+'px)';});ind.textContent='target '+Math.round(s.target)+' · current '+Math.round(s.cur);};},tick(s){if(s.upd)s.upd();},
 code:`const lenis=new Lenis({lerp:.1,smoothWheel:true});
lenis.on('scroll',ScrollTrigger.update);            // keep GSAP in sync
gsap.ticker.add(t=>lenis.raf(t*1000));
document.querySelectorAll('[data-speed]').forEach(el=>
  gsap.to(el,{y:()=>innerHeight*el.dataset.speed,scrollTrigger:{scrub:true}}));`});

lib('typed','Typed.js','anim','Typewriter text: types, backspaces and loops through strings with a blinking cursor.',{isNew:true});
ex({t:'Hero headline with smart backspace',d:'Only the changing word is erased and retyped ("smartBackspace"), with natural speed jitter and a blinking cursor.',
 dom(el,s){el.innerHTML='<div style="position:absolute;inset:0;display:grid;place-items:center;background:radial-gradient(circle at 70% 20%,#eef2ff,#fff 60%)"><div style="text-align:center;padding:20px"><div style="font:600 13px var(--mono);letter-spacing:.1em;color:var(--ac);text-transform:uppercase">Typed.js</div><h2 style="font:600 44px/1.15 var(--serif);margin:10px 0 0">Build <span class="tw" style="color:#e11d48"></span><span class="cu" style="color:#e11d48;font-weight:300">|</span><br>in the browser.</h2></div></div>';
  s.words=['3D worlds','dashboards','offline maps','molecules','synthesizers'];s.i=0;s.txt='';s.mode='type';s.wait=0;s.tw=el.querySelector('.tw');s.cu=el.querySelector('.cu');},
 tick(s,t,dt){if(!s.tw)return;s.cu.style.opacity=Math.sin(t*7)>0?1:0;s.wait-=dt;if(s.wait>0)return;const w=s.words[s.i];if(s.mode==='type'){if(s.txt.length<w.length){s.txt=w.slice(0,s.txt.length+1);s.wait=.05+Math.random()*.07;}else{s.mode='del';s.wait=1.4;}}else{if(s.txt.length){s.txt=s.txt.slice(0,-1);s.wait=.03;}else{s.mode='type';s.i=(s.i+1)%s.words.length;s.wait=.3;}}s.tw.textContent=s.txt;},
 code:`new Typed('.tw',{strings:['3D worlds','dashboards','offline maps','molecules'],
  typeSpeed:60,backSpeed:30,backDelay:1400,smartBackspace:true,loop:true});`});
ex({t:'Terminal session replay',d:'Commands type out with pauses, and their output appears instantly, using Typed.js ^pause and `backtick` instant-print syntax.',controls:[{type:'btn',l:'↻ Replay',fn:s=>s.reset()}],
 dom(el,s){el.innerHTML='<div style="position:absolute;inset:14px;border-radius:12px;background:#1c1917;box-shadow:var(--sh2);overflow:hidden;display:flex;flex-direction:column"><div style="display:flex;gap:6px;padding:10px 12px;background:#292524"><i style="width:11px;height:11px;border-radius:50%;background:#f87171"></i><i style="width:11px;height:11px;border-radius:50%;background:#fbbf24"></i><i style="width:11px;height:11px;border-radius:50%;background:#34d399"></i><span style="margin-left:10px;color:#a8a29e;font:12px var(--mono)">~/atlas</span></div><pre class="tm" style="margin:0;padding:14px 16px;color:#e7e5e4;font:13.5px/1.6 var(--mono);white-space:pre-wrap;flex:1;overflow:auto"></pre></div>';
  const S=[['$ ','npm i --offline three gsap d3'],['','added 3 packages in 0.8s\n'],['$ ','python3 -m http.server 8080'],['','Serving HTTP on 0.0.0.0 port 8080 …\n'],['$ ','open http://localhost:8080'],['','✔ All demos running offline']];s.tm=el.querySelector('.tm');
  s.reset=()=>{s.li=0;s.ci=0;s.out='';s.wait=.4;};s.reset();s.S=S;},
 tick(s,t,dt){if(!s.tm)return;s.wait-=dt;if(s.wait<=0&&s.li<s.S.length){const[p,c]=s.S[s.li];if(!p){s.out+=c+'\n';s.li++;s.wait=.5;}else{if(s.ci===0)s.out+=p;if(s.ci<c.length){s.out+=c[s.ci++];s.wait=.035+Math.random()*.06;}else{s.out+='\n';s.li++;s.ci=0;s.wait=.45;}}}
  s.tm.innerHTML=esc(s.out).replace(/\$ /g,'<span style="color:#34d399">$ </span>').replace(/✔/g,'<span style="color:#34d399">✔</span>')+'<span style="background:#e7e5e4;opacity:'+(Math.sin(t*7)>0?1:0)+'"> </span>';},
 code:`new Typed('#term',{strings:['$ npm i --offline three gsap d3^600\\n\`added 3 packages in 0.8s\`',
  '$ python3 -m http.server 8080^500\\n\`Serving HTTP on 0.0.0.0 port 8080 …\`'],
  typeSpeed:40,showCursor:true,cursorChar:'▋'});`});
